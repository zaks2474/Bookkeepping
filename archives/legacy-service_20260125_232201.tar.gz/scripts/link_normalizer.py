#!/usr/bin/env python3
"""
Link Normalizer - Classify, resolve, and deduplicate URLs for Quarantine/Deal UX.

Handles:
- Link classification (deal_material, tracking, social, unsubscribe, portal, contact, other)
- Click-wrapper/tracking URL resolution (HubSpot, Mailchimp, etc.)
- Canonical key generation for deduplication
- Grouped link output for UI

Usage:
    from link_normalizer import LinkNormalizer

    normalizer = LinkNormalizer()
    classified = normalizer.classify_link(url, context="email body text")
    resolved = normalizer.resolve_tracking_url(url)
    canonical = normalizer.canonical_key(url)

    # For batch processing:
    deduped = normalizer.dedupe_links(links_list)
    grouped = normalizer.group_links(links_list)
"""

from __future__ import annotations

import hashlib
import logging
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Set, Tuple
from urllib.parse import urlparse, urlunparse, parse_qs, urlencode

import requests

logger = logging.getLogger(__name__)


class LinkCategory(Enum):
    """Primary link classification categories."""
    DEAL_MATERIAL = "deal_material"  # CIM, teaser, dataroom, NDA, financials
    TRACKING = "tracking"             # Click wrappers, email tracking pixels
    SOCIAL = "social"                 # LinkedIn, Twitter, Facebook, etc.
    UNSUBSCRIBE = "unsubscribe"       # Email preferences, unsubscribe links
    PORTAL = "portal"                 # Login portals, authentication pages
    CONTACT = "contact"               # Contact forms, mailto, phone
    CALENDAR = "calendar"             # Meeting scheduling (Calendly, etc.)
    OTHER = "other"                   # Uncategorized


# Known tracking/click-wrapper domains
TRACKING_DOMAINS = {
    # Email marketing platforms
    "hubspotlinksstarter.com",
    "hubspotstarter.net",  # HubSpot email preferences/unsubscribe pages
    "hubspotlinks.com",
    "hs-sales-engage.com",  # HubSpot sales engagement tracking
    "hs-analytics.net",
    "t.hubspotemail.net",
    "track.hubspot.com",
    "click.hubspot.com",
    "mailchimp.com",
    "list-manage.com",
    "links.constantcontact.com",
    "click.email.constantcontact.com",
    "sendgrid.net",
    "clicks.aweber.com",
    "clicks.convertkit.com",
    "t.dripemail.com",
    "click.mailerlite.com",
    "click.sendinblue.com",
    "trk.klclick.com",
    "click.klaviyo.com",
    "trk.klaviyo.com",
    "eclick.baremetal.com",
    "links.pardot.com",
    "click.pardot.com",
    "go.pardot.com",
    "trk.pardot.com",
    "links.marketo.com",
    "click.marketo.com",
    "mkt.marketo.com",
    "click.eloqua.com",
    "s.eloqua.com",
    # URL shorteners used for tracking
    "bit.ly",
    "t.co",
    "goo.gl",
    "ow.ly",
    "tinyurl.com",
    "is.gd",
    "buff.ly",
    "rebrand.ly",
    "shor.by",
    "bl.ink",
    "short.io",
    # Analytics
    "googleads.g.doubleclick.net",
    "click.google-analytics.com",
}

# Social media domains
SOCIAL_DOMAINS = {
    "linkedin.com",
    "twitter.com",
    "x.com",
    "facebook.com",
    "fb.com",
    "instagram.com",
    "youtube.com",
    "youtu.be",
    "tiktok.com",
    "pinterest.com",
    "reddit.com",
    "discord.com",
    "discord.gg",
    "threads.net",
    "bsky.app",
    "mastodon.social",
}

# Unsubscribe/preference patterns
UNSUBSCRIBE_PATTERNS = [
    r"unsubscribe",
    r"email[_-]?preference",
    r"manage[_-]?subscription",
    r"opt[_-]?out",
    r"remove[_-]?me",
    r"email[_-]?settings",
    r"notification[_-]?settings",
    r"communication[_-]?preference",
]

# Contact patterns
CONTACT_PATTERNS = [
    r"^mailto:",
    r"^tel:",
    r"contact[_-]?us",
    r"get[_-]?in[_-]?touch",
    r"reach[_-]?out",
]

# Calendar/meeting domains
CALENDAR_DOMAINS = {
    "calendly.com",
    "cal.com",
    "calendar.google.com",
    "outlook.office.com",
    "doodle.com",
    "meetingbird.com",
    "x.ai",
    "reclaim.ai",
    "hubspot.com/meetings",
    "zoom.us",
    "meet.google.com",
    "teams.microsoft.com",
}

# Deal material patterns (for context-based classification)
DEAL_MATERIAL_PATTERNS = [
    r"cim\b",
    r"confidential.*information.*memorandum",
    r"teaser",
    r"executive.*summary",
    r"dataroom",
    r"data[_-]?room",
    r"vdr\b",
    r"nda\b",
    r"non[_-]?disclosure",
    r"confidentiality.*agreement",
    r"financial",
    r"diligence",
    r"deal[_-]?materials",
    r"investment.*memorandum",
]

# Portal/auth patterns
PORTAL_PATTERNS = [
    r"/login",
    r"/signin",
    r"/sign[_-]?in",
    r"/auth",
    r"/sso",
    r"/oauth",
    r"/account",
    r"/portal",
    r"/secure",
    r"/member",
]


@dataclass
class ClassifiedLink:
    """A link with classification and normalization data."""
    original_url: str
    canonical_url: str
    canonical_key: str
    category: LinkCategory
    link_type: str  # Specific type (cim, nda, tracking, linkedin, etc.)
    auth_required: bool = False
    vendor_hint: Optional[str] = None
    resolved_url: Optional[str] = None  # Destination after following redirects
    context: Optional[str] = None
    confidence: float = 0.8
    # Meaning labels (Phase 4 enhancement)
    meaning_label: Optional[str] = None  # Human-readable label (e.g., "NDA Document", "Data Room")
    doc_type: Optional[str] = None  # Document type hint (nda, cim, teaser, financials, etc.)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "url": self.original_url,
            "canonical_url": self.canonical_url,
            "canonical_key": self.canonical_key,
            "category": self.category.value,
            "link_type": self.link_type,
            "auth_required": self.auth_required,
            "vendor_hint": self.vendor_hint,
            "resolved_url": self.resolved_url,
            "confidence": self.confidence,
            "meaning_label": self.meaning_label,
            "doc_type": self.doc_type,
        }


class LinkNormalizer:
    """
    Classifies, resolves, and deduplicates URLs.

    Key features:
    - Identifies tracking links vs deal materials
    - Optionally resolves click-wrapper URLs to destinations
    - Generates canonical keys for deduplication
    - Groups links by category for UI display
    """

    def __init__(
        self,
        *,
        resolve_tracking: bool = True,
        max_redirects: int = 5,
        timeout_seconds: float = 5.0,
        cache_resolutions: bool = True,
    ):
        self.resolve_tracking = resolve_tracking
        self.max_redirects = max_redirects
        self.timeout = timeout_seconds
        self.cache_resolutions = cache_resolutions
        self._resolution_cache: Dict[str, Optional[str]] = {}

        # Compile patterns
        self._unsubscribe_patterns = [re.compile(p, re.I) for p in UNSUBSCRIBE_PATTERNS]
        self._contact_patterns = [re.compile(p, re.I) for p in CONTACT_PATTERNS]
        self._deal_patterns = [re.compile(p, re.I) for p in DEAL_MATERIAL_PATTERNS]
        self._portal_patterns = [re.compile(p, re.I) for p in PORTAL_PATTERNS]

    def classify_link(
        self,
        url: str,
        context: Optional[str] = None,
        label: Optional[str] = None,
    ) -> ClassifiedLink:
        """
        Classify a URL and return normalized link data.

        Args:
            url: The URL to classify
            context: Surrounding text for classification hints
            label: Link text/label for classification hints

        Returns:
            ClassifiedLink with category, type, and canonical data
        """
        url = (url or "").strip()
        if not url:
            return ClassifiedLink(
                original_url=url,
                canonical_url="",
                canonical_key="",
                category=LinkCategory.OTHER,
                link_type="empty",
                confidence=0.0,
            )

        try:
            parsed = urlparse(url)
        except Exception:
            return ClassifiedLink(
                original_url=url,
                canonical_url=url,
                canonical_key=self._hash_url(url),
                category=LinkCategory.OTHER,
                link_type="invalid",
                confidence=0.0,
            )

        domain = (parsed.netloc or "").lower()
        if domain.startswith("www."):
            domain = domain[4:]

        path = (parsed.path or "").lower()
        combined_text = " ".join(filter(None, [label, context, path])).lower()

        # Determine category and type
        category, link_type, confidence = self._classify(
            url, domain, path, combined_text, label
        )

        # Resolve tracking URLs if enabled
        resolved_url = None
        if category == LinkCategory.TRACKING and self.resolve_tracking:
            resolved_url = self.resolve_tracking_url(url)

        # Generate canonical URL and key
        canonical_url = self._canonicalize_url(resolved_url or url)
        canonical_key = self._hash_url(canonical_url)

        # Detect vendor hint
        vendor_hint = self._detect_vendor(url)

        # Detect auth required
        auth_required = self._requires_auth(url, domain, path, vendor_hint)

        # Infer meaning label for non-tracking links
        meaning_label, doc_type = self._infer_meaning_label(
            url, domain, path, link_type, category, combined_text
        )

        return ClassifiedLink(
            original_url=url,
            canonical_url=canonical_url,
            canonical_key=canonical_key,
            category=category,
            link_type=link_type,
            auth_required=auth_required,
            vendor_hint=vendor_hint,
            resolved_url=resolved_url,
            context=context[:200] if context else None,
            confidence=confidence,
            meaning_label=meaning_label,
            doc_type=doc_type,
        )

    def _classify(
        self,
        url: str,
        domain: str,
        path: str,
        combined_text: str,
        label: Optional[str],
    ) -> Tuple[LinkCategory, str, float]:
        """Determine category and specific type for a URL."""

        # Check tracking domains first (highest priority)
        for tracking_domain in TRACKING_DOMAINS:
            if domain == tracking_domain or domain.endswith("." + tracking_domain):
                return LinkCategory.TRACKING, "email_tracking", 0.95

        # Check unsubscribe patterns
        for pattern in self._unsubscribe_patterns:
            if pattern.search(url) or pattern.search(combined_text):
                return LinkCategory.UNSUBSCRIBE, "unsubscribe", 0.9

        # Check social domains
        for social_domain in SOCIAL_DOMAINS:
            if domain == social_domain or domain.endswith("." + social_domain):
                # Determine specific social type
                social_type = social_domain.split(".")[0]
                return LinkCategory.SOCIAL, social_type, 0.95

        # Check calendar domains
        for cal_domain in CALENDAR_DOMAINS:
            if domain == cal_domain or domain.endswith("." + cal_domain) or cal_domain in url:
                return LinkCategory.CALENDAR, "meeting", 0.9

        # Check contact patterns
        for pattern in self._contact_patterns:
            if pattern.search(url):
                contact_type = "email" if "mailto:" in url else "contact"
                return LinkCategory.CONTACT, contact_type, 0.9

        # Check portal/auth patterns
        for pattern in self._portal_patterns:
            if pattern.search(path):
                return LinkCategory.PORTAL, "login", 0.8

        # Check deal material patterns (context-based)
        for pattern in self._deal_patterns:
            if pattern.search(combined_text):
                # Determine specific deal material type
                material_type = self._detect_deal_material_type(combined_text)
                return LinkCategory.DEAL_MATERIAL, material_type, 0.85

        # Default to deal_material if it has common deal-related domains
        deal_domains = {"axial", "firmex", "datasite", "intralinks", "dealroom", "tupelo", "sharefile", "box", "dropbox"}
        for deal_domain in deal_domains:
            if deal_domain in domain:
                return LinkCategory.DEAL_MATERIAL, "dataroom", 0.8

        # Default: classify as other
        return LinkCategory.OTHER, "other", 0.5

    def _detect_deal_material_type(self, text: str) -> str:
        """Detect specific deal material type from context."""
        text_lower = text.lower()

        if any(p in text_lower for p in ["cim", "confidential information memorandum", "investment memorandum"]):
            return "cim"
        if any(p in text_lower for p in ["teaser", "executive summary", "blind profile"]):
            return "teaser"
        if any(p in text_lower for p in ["nda", "non-disclosure", "confidentiality agreement"]):
            return "nda"
        if any(p in text_lower for p in ["dataroom", "data room", "vdr", "due diligence"]):
            return "dataroom"
        if any(p in text_lower for p in ["financial", "p&l", "income statement", "balance sheet"]):
            return "financials"

        return "document"

    def resolve_tracking_url(self, url: str) -> Optional[str]:
        """
        Resolve a tracking/click-wrapper URL to its destination.

        Uses HEAD requests with redirect following to find final destination.
        Results are cached to avoid repeated network calls.

        Args:
            url: The tracking URL to resolve

        Returns:
            Resolved destination URL, or None if resolution fails
        """
        if not url:
            return None

        # Check cache
        if self.cache_resolutions and url in self._resolution_cache:
            return self._resolution_cache[url]

        try:
            # Use HEAD with redirect following
            response = requests.head(
                url,
                allow_redirects=True,
                timeout=self.timeout,
                headers={"User-Agent": "Mozilla/5.0 (compatible; LinkResolver/1.0)"},
            )

            # Get final URL after redirects
            final_url = response.url

            # Check if we actually redirected somewhere different
            if final_url and final_url != url:
                parsed_final = urlparse(final_url)
                parsed_original = urlparse(url)

                # Only accept if domain changed (actual redirect, not just param changes)
                if parsed_final.netloc != parsed_original.netloc:
                    if self.cache_resolutions:
                        self._resolution_cache[url] = final_url
                    return final_url

            # No meaningful redirect
            if self.cache_resolutions:
                self._resolution_cache[url] = None
            return None

        except requests.RequestException as e:
            logger.debug(f"Failed to resolve tracking URL {url}: {e}")
            if self.cache_resolutions:
                self._resolution_cache[url] = None
            return None

    def _canonicalize_url(self, url: str) -> str:
        """
        Generate canonical form of URL for deduplication.

        - Lowercase scheme and host
        - Normalize path
        - Remove tracking query params
        - Remove fragment
        """
        if not url:
            return ""

        try:
            parsed = urlparse(url)

            # Normalize scheme and host
            scheme = (parsed.scheme or "https").lower()
            host = (parsed.netloc or "").lower()
            if host.startswith("www."):
                host = host[4:]

            # Normalize path
            path = (parsed.path or "").rstrip("/")

            # Filter tracking params from query
            if parsed.query:
                params = parse_qs(parsed.query)
                tracking_prefixes = (
                    "utm_", "ref", "source", "mc_", "fb_", "gclid", "fbclid",
                    "msclkid", "twclid", "li_", "igshid", "_hsenc", "_hsmi",
                    "mkt_tok", "trk", "trkId", "trkInfo",
                )
                filtered = {
                    k: v for k, v in params.items()
                    if not any(k.lower().startswith(p) for p in tracking_prefixes)
                }
                query = urlencode(filtered, doseq=True) if filtered else ""
            else:
                query = ""

            # Reconstruct without fragment
            return urlunparse((scheme, host, path, "", query, ""))

        except Exception:
            return url

    def _hash_url(self, url: str) -> str:
        """Generate a short hash key for URL deduplication."""
        return hashlib.sha256(url.encode()).hexdigest()[:16]

    def _detect_vendor(self, url: str) -> Optional[str]:
        """Detect vendor/platform from URL."""
        url_lower = url.lower()

        vendor_patterns = {
            "sharefile": ["sharefile.com", "sf-api.com"],
            "dropbox": ["dropbox.com", "db.tt"],
            "google_drive": ["drive.google.com", "docs.google.com"],
            "onedrive": ["onedrive.live.com", "1drv.ms", "sharepoint.com"],
            "box": ["box.com", "app.box.com"],
            "datasite": ["datasite.com", "merrillcorp.com"],
            "intralinks": ["intralinks.com", "il.ws"],
            "firmex": ["firmex.com"],
            "axial": ["axial.net", "axial.com"],
            "dealroom": ["dealroom.net"],
            "tupelo": ["tupelo.ai"],
            "hubspot": ["hubspot.com", "hubspotlinks", "hs-sites.com"],
            "calendly": ["calendly.com"],
            "docusign": ["docusign.com", "docusign.net"],
        }

        for vendor, patterns in vendor_patterns.items():
            if any(p in url_lower for p in patterns):
                return vendor

        return None

    def _requires_auth(
        self,
        url: str,
        domain: str,
        path: str,
        vendor_hint: Optional[str],
    ) -> bool:
        """Determine if URL requires authentication."""

        # Known auth-required domains
        auth_domains = {
            "axial.net", "axial.com", "tupelo.ai", "vestedbb.com",
            "dealroom.net", "firmex.com", "datasite.com", "intralinks.com",
            "merrillcorp.com",
        }

        for auth_domain in auth_domains:
            if domain == auth_domain or domain.endswith("." + auth_domain):
                return True

        # Auth path patterns
        for pattern in self._portal_patterns:
            if pattern.search(path):
                return True

        # Auth-required vendors
        auth_vendors = {"axial", "tupelo", "vestedbb", "dealroom", "firmex", "datasite", "intralinks"}
        if vendor_hint in auth_vendors:
            return True

        return False

    def _infer_meaning_label(
        self,
        url: str,
        domain: str,
        path: str,
        link_type: str,
        category: LinkCategory,
        combined_text: str,
    ) -> Tuple[Optional[str], Optional[str]]:
        """
        Infer a human-readable meaning label for a link.

        Returns: (meaning_label, doc_type)
        """
        url_lower = url.lower()

        # Skip tracking links
        if category == LinkCategory.TRACKING:
            return ("Tracking Link", "tracking")

        # Handle known categories first
        if category == LinkCategory.CALENDAR:
            return ("Schedule Meeting", "calendar")
        if category == LinkCategory.UNSUBSCRIBE:
            return ("Unsubscribe", "unsubscribe")
        if category == LinkCategory.CONTACT:
            if "mailto:" in url_lower:
                return ("Email Contact", "email")
            if "tel:" in url_lower:
                return ("Phone Contact", "phone")
            return ("Contact", "contact")
        if category == LinkCategory.SOCIAL:
            social_type = link_type.title() if link_type else "Social"
            return (f"{social_type} Profile", "social")
        if category == LinkCategory.PORTAL:
            return ("Portal / Login", "portal")

        # Deal material type-specific labels
        if link_type in ("nda", "non-disclosure"):
            return ("NDA / Agreement", "nda")
        if link_type in ("cim", "teaser", "executive_summary"):
            return ("CIM / Teaser", "cim")
        if link_type in ("dataroom", "vdr"):
            return ("Data Room", "dataroom")
        if link_type in ("financial", "financials"):
            return ("Financial Document", "financials")

        # Pattern-based inference for primary links
        meaning_patterns = {
            r"(dataroom|data-room|dealroom|deal-room|vdr)": ("Data Room", "dataroom"),
            r"(box\.com|sharefile|dropbox|onedrive|drive\.google)": ("File Share", "fileshare"),
            r"(nda|non-disclosure|confidential.*agreement)": ("NDA / Agreement", "nda"),
            r"(docusign|hellosign|pandadoc)": ("Document Signing", "esign"),
            r"(cim|teaser|executive.*summary|information.*memorandum)": ("CIM / Teaser", "cim"),
            r"(financial|p.*l|balance.*sheet|income.*statement)": ("Financial Document", "financials"),
            r"(calendly|cal\.com|schedule|book.*meeting)": ("Schedule Meeting", "calendar"),
            r"(portal|login|signin|dashboard|account)": ("Portal / Login", "portal"),
        }

        for pattern, (label, doc_type) in meaning_patterns.items():
            if re.search(pattern, url_lower) or re.search(pattern, combined_text):
                return (label, doc_type)

        # Vendor-based inference
        if domain:
            if any(d in domain for d in ("axial", "dealnexus", "bizbuysell", "businessforsale")):
                return ("Business Listing", "listing")
            if "linkedin" in domain:
                return ("LinkedIn Profile", "social")

        # Default for deal materials
        if category == LinkCategory.DEAL_MATERIAL:
            return ("Deal Document", "document")

        return (None, None)

    def dedupe_links(
        self,
        links: List[Dict[str, Any]],
        *,
        key_field: str = "canonical_key",
    ) -> List[ClassifiedLink]:
        """
        Deduplicate a list of links by canonical key.

        Args:
            links: List of link dicts with at least 'url' key
            key_field: Field to use for deduplication

        Returns:
            List of unique ClassifiedLink objects
        """
        seen_keys: Set[str] = set()
        result: List[ClassifiedLink] = []

        for link in links:
            if not isinstance(link, dict):
                continue

            url = str(link.get("url") or "").strip()
            if not url:
                continue

            context = link.get("context") or link.get("notes")
            label = link.get("label") or link.get("type")

            classified = self.classify_link(url, context=context, label=label)

            if classified.canonical_key not in seen_keys:
                seen_keys.add(classified.canonical_key)
                result.append(classified)

        return result

    def group_links(
        self,
        links: List[ClassifiedLink],
    ) -> Dict[str, List[ClassifiedLink]]:
        """
        Group classified links by category for UI display.

        Returns dict with keys:
        - deal_material: CIM, teaser, dataroom, NDA, financials
        - tracking: Click wrappers (usually hidden by default)
        - unsubscribe: Unsubscribe links (usually hidden)
        - social: Social media links
        - calendar: Meeting/scheduling links
        - contact: Contact forms, mailto, tel
        - portal: Login/auth pages
        - other: Uncategorized
        """
        groups: Dict[str, List[ClassifiedLink]] = {
            cat.value: [] for cat in LinkCategory
        }

        for link in links:
            groups[link.category.value].append(link)

        return groups

    def process_links(
        self,
        links: List[Dict[str, Any]],
    ) -> Dict[str, Any]:
        """
        Full pipeline: classify, dedupe, and group links.

        Returns UI-ready structure with:
        - unique_count: Number of unique canonical URLs
        - total_count: Original count before dedupe
        - groups: Dict of category -> list of link dicts
        - all_unique: Flat list of all unique links
        """
        classified = self.dedupe_links(links)
        grouped = self.group_links(classified)

        return {
            "unique_count": len(classified),
            "total_count": len(links),
            "duplicates_removed": len(links) - len(classified),
            "groups": {
                category: [link.to_dict() for link in category_links]
                for category, category_links in grouped.items()
            },
            "all_unique": [link.to_dict() for link in classified],
        }


# Convenience functions for use without instantiation

_default_normalizer: Optional[LinkNormalizer] = None


def get_normalizer() -> LinkNormalizer:
    """Get or create the default normalizer instance."""
    global _default_normalizer
    if _default_normalizer is None:
        _default_normalizer = LinkNormalizer()
    return _default_normalizer


def classify_link(url: str, context: Optional[str] = None) -> ClassifiedLink:
    """Classify a single URL."""
    return get_normalizer().classify_link(url, context)


def process_links(links: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Full pipeline: classify, dedupe, and group links."""
    return get_normalizer().process_links(links)


def dedupe_links(links: List[Dict[str, Any]]) -> List[ClassifiedLink]:
    """Deduplicate links by canonical key."""
    return get_normalizer().dedupe_links(links)
