#!/usr/bin/env python3
"""
Kinetic Action Engine admin utilities.

Used by Makefile targets:
- make actions-status
- make actions-retry-stuck
"""

from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone

from actions.engine.store import ActionStore


def cmd_status(args: argparse.Namespace) -> int:
    store = ActionStore()
    metrics = store.action_metrics(window_hours=args.window_hours)
    lease = store.get_runner_lease(runner_name=args.runner_name)
    metrics["runner_lease"] = lease.model_dump() if lease else None
    metrics["timestamp"] = datetime.now(timezone.utc).isoformat()
    print(json.dumps(metrics, indent=2, sort_keys=True))
    return 0


def cmd_retry_stuck(args: argparse.Namespace) -> int:
    store = ActionStore()
    stuck = store.list_stuck_processing_action_ids(
        older_than_seconds=args.older_than_seconds,
        limit=args.limit,
    )
    changed = 0
    for action_id in stuck:
        ok = store.unstick_action(action_id=action_id, actor=args.actor, reason=args.reason)
        if ok:
            changed += 1
    out = {
        "runner_name": args.runner_name,
        "older_than_seconds": args.older_than_seconds,
        "found": len(stuck),
        "unstuck": changed,
        "action_ids": stuck,
    }
    print(json.dumps(out, indent=2, sort_keys=True))
    return 0 if changed >= 0 else 1


def main() -> int:
    parser = argparse.ArgumentParser(description="Kinetic Action Engine admin")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_status = sub.add_parser("status", help="Print action metrics + runner lease")
    p_status.add_argument("--runner-name", default="kinetic_actions")
    p_status.add_argument("--window-hours", type=int, default=24)
    p_status.set_defaults(func=cmd_status)

    p_retry = sub.add_parser("retry-stuck", help="Release stale locks and retry stuck PROCESSING actions")
    p_retry.add_argument("--runner-name", default="kinetic_actions")
    p_retry.add_argument("--older-than-seconds", type=int, default=180)
    p_retry.add_argument("--limit", type=int, default=100)
    p_retry.add_argument("--actor", default="operator")
    p_retry.add_argument("--reason", default="operator_retry_stuck")
    p_retry.set_defaults(func=cmd_retry_stuck)

    args = parser.parse_args()
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())

