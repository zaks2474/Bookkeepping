#!/usr/bin/env python3
"""
Lifecycle Event Emitter

Post-ingest processor that converts emails/documents into lifecycle events.
Designed to run after sync_acquisition_emails.py completes.

Key Responsibilities:
- Match emails to deals (with quarantine for low-confidence)
- Emit email_received events
- Classify documents and emit document_classified events
- Apply stage policies (document triggers)
- Schedule follow-up actions based on policy
- Ensure idempotency (no duplicate events)

No Silent Drops Rule:
Every email produces either:
- A deal-linked email_received event, OR
- A quarantine_added item

Usage:
    python3 lifecycle_event_emitter.py process-manifests
    python3 lifecycle_event_emitter.py process-manifest /path/to/manifest.json
    python3 lifecycle_event_emitter.py process-email --deal-id DEAL-2025-001 --subject "RE: CIM"
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# Add paths
sys.path.insert(0, str(Path(__file__).parent))
sys.path.insert(0, str(Path("/home/zaks/Zaks-llm/src")))

from deal_registry import DealRegistry
from deal_events import DealEventStore
from deferred_actions import DeferredActionQueue
from schema_validators import PolicyLoader, validate_event

# Configuration
REGISTRY_PATH = "/home/zaks/DataRoom/.deal-registry/deal_registry.json"
QUARANTINE_PATH = Path("/home/zaks/DataRoom/.deal-registry/quarantine.json")
DEDUPE_DIR = Path("/home/zaks/DataRoom/.deal-registry/dedupe")
MANIFESTS_DIR = Path("/home/zaks/DataRoom/00-PIPELINE")

# Feature flags (from policy)
QUARANTINE_CONFIDENCE_THRESHOLD = 0.70


@dataclass
class EmailMatch:
    """Result of email-to-deal matching"""
    deal_id: Optional[str]
    confidence: float
    is_new: bool = False
    matched_by: str = "unknown"
    candidates: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class ProcessResult:
    """Result of processing an item"""
    success: bool
    deal_id: Optional[str]
    events_emitted: List[str] = field(default_factory=list)
    actions_scheduled: List[str] = field(default_factory=list)
    quarantined: bool = False
    quarantine_id: Optional[str] = None
    error: Optional[str] = None


class EmailDeduplicator:
    """
    Manages email/attachment deduplication to ensure idempotency.

    Uses RFC message_id as primary key, with fallback to content hash.
    """

    def __init__(self, dedupe_dir: Path = DEDUPE_DIR):
        self.dedupe_dir = dedupe_dir
        self.dedupe_dir.mkdir(parents=True, exist_ok=True)
        self.emails_path = dedupe_dir / "processed_emails.jsonl"
        self.attachments_path = dedupe_dir / "processed_attachments.jsonl"
        self._email_cache: set = set()
        self._attachment_cache: set = set()
        self._load_cache()

    def _load_cache(self) -> None:
        """Load processed IDs into memory"""
        if self.emails_path.exists():
            with open(self.emails_path, "r") as f:
                for line in f:
                    try:
                        entry = json.loads(line.strip())
                        self._email_cache.add(entry.get("key", ""))
                    except json.JSONDecodeError:
                        continue

        if self.attachments_path.exists():
            with open(self.attachments_path, "r") as f:
                for line in f:
                    try:
                        entry = json.loads(line.strip())
                        self._attachment_cache.add(entry.get("sha256", ""))
                    except json.JSONDecodeError:
                        continue

    def is_email_processed(self, message_id: str, fallback_hash: str = "") -> bool:
        """Check if email has been processed"""
        key = message_id or fallback_hash
        return key in self._email_cache

    def is_attachment_processed(self, sha256: str) -> bool:
        """Check if attachment has been processed"""
        return sha256 in self._attachment_cache

    def mark_email_processed(
        self,
        message_id: str,
        deal_id: str,
        manifest_path: str = "",
    ) -> None:
        """Mark email as processed"""
        key = message_id
        if key in self._email_cache:
            return

        entry = {
            "key": key,
            "deal_id": deal_id,
            "manifest_path": manifest_path,
            "processed_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        }
        with open(self.emails_path, "a") as f:
            f.write(json.dumps(entry) + "\n")
        self._email_cache.add(key)

    def mark_attachment_processed(
        self,
        sha256: str,
        deal_id: str,
        filename: str,
    ) -> None:
        """Mark attachment as processed"""
        if sha256 in self._attachment_cache:
            return

        entry = {
            "sha256": sha256,
            "deal_id": deal_id,
            "filename": filename,
            "processed_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        }
        with open(self.attachments_path, "a") as f:
            f.write(json.dumps(entry) + "\n")
        self._attachment_cache.add(sha256)


class QuarantineManager:
    """
    Manages quarantine for low-confidence email matches.

    Items in quarantine need operator resolution before being linked to deals.
    """

    def __init__(self, quarantine_path: Path = QUARANTINE_PATH):
        self.path = quarantine_path
        self._ensure_file()

    def _ensure_file(self) -> None:
        """Ensure quarantine file exists"""
        if not self.path.exists():
            self._save({"items": [], "resolved": []})

    def _load(self) -> Dict[str, Any]:
        """Load quarantine data"""
        try:
            with open(self.path, "r") as f:
                return json.load(f)
        except (json.JSONDecodeError, FileNotFoundError):
            return {"items": [], "resolved": []}

    def _save(self, data: Dict[str, Any]) -> None:
        """Save quarantine data"""
        data["updated_at"] = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        with open(self.path, "w") as f:
            json.dump(data, f, indent=2)

    def add(
        self,
        email_subject: str,
        email_from: str,
        reason: str,
        candidates: List[Dict[str, Any]] = None,
        confidence: float = 0.0,
        attachments: List[str] = None,
        manifest_path: str = "",
    ) -> str:
        """Add item to quarantine"""
        quarantine_id = f"QRN-{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S')}-{hashlib.sha256(email_subject.encode()).hexdigest()[:8]}"

        item = {
            "quarantine_id": quarantine_id,
            "email_subject": email_subject,
            "email_from": email_from,
            "reason": reason,
            "candidates": candidates or [],
            "confidence": confidence,
            "attachments": attachments or [],
            "manifest_path": manifest_path,
            "created_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "status": "pending",
        }

        data = self._load()
        data["items"].append(item)
        self._save(data)

        return quarantine_id

    def get_pending(self) -> List[Dict[str, Any]]:
        """Get all pending quarantine items"""
        data = self._load()
        return [i for i in data.get("items", []) if i.get("status") == "pending"]

    def get_item(self, quarantine_id: str) -> Optional[Dict[str, Any]]:
        """Get a specific quarantine item"""
        data = self._load()
        for item in data.get("items", []):
            if item.get("quarantine_id") == quarantine_id:
                return item
        return None

    def resolve(
        self,
        quarantine_id: str,
        resolution: str,
        deal_id: str = None,
        resolved_by: str = "operator",
    ) -> bool:
        """
        Resolve a quarantine item.

        resolution: "link_to_deal" | "create_new_deal" | "discard"
        """
        data = self._load()
        for item in data.get("items", []):
            if item.get("quarantine_id") == quarantine_id:
                item["status"] = "resolved"
                item["resolution"] = resolution
                item["deal_id"] = deal_id
                item["resolved_by"] = resolved_by
                item["resolved_at"] = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
                self._save(data)
                return True
        return False


class LifecycleEventEmitter:
    """
    Main processor for converting emails/documents into lifecycle events.
    """

    def __init__(self, llm_router=None):
        self.registry = DealRegistry(REGISTRY_PATH)
        self.event_store = DealEventStore()
        self.action_queue = DeferredActionQueue()
        self.policy_loader = PolicyLoader()
        self.deduplicator = EmailDeduplicator()
        self.quarantine = QuarantineManager()
        self.llm_router = llm_router

    def process_manifest(self, manifest_path: str) -> ProcessResult:
        """
        Process an email manifest file.

        Reads manifest, matches to deal, emits events.
        """
        path = Path(manifest_path)
        if not path.exists():
            return ProcessResult(
                success=False,
                deal_id=None,
                error=f"Manifest not found: {manifest_path}",
            )

        try:
            with open(path, "r") as f:
                manifest = json.load(f)
        except json.JSONDecodeError as e:
            return ProcessResult(
                success=False,
                deal_id=None,
                error=f"Invalid JSON: {e}",
            )

        return self.process_email(
            message_id=manifest.get("message_id", ""),
            subject=manifest.get("subject", ""),
            sender=manifest.get("sender", manifest.get("from", "")),
            date=manifest.get("received_date", manifest.get("date", "")),
            attachments=manifest.get("attachments", []),
            manifest_path=str(path),
            body_hash=manifest.get("body_hash", ""),
        )

    def process_email(
        self,
        message_id: str,
        subject: str,
        sender: str,
        date: str,
        attachments: List[Dict[str, Any]] = None,
        manifest_path: str = "",
        body_hash: str = "",
    ) -> ProcessResult:
        """
        Process a single email into lifecycle events.

        Implements "no silent drops" rule:
        - Every email becomes deal-linked event OR quarantine item
        """
        # Generate fallback key if no message_id
        key = message_id or hashlib.sha256(f"{sender}|{date}|{subject}|{body_hash}".encode()).hexdigest()

        # Check idempotency
        if self.deduplicator.is_email_processed(key):
            return ProcessResult(
                success=True,
                deal_id=None,
                error="Already processed (skipped)",
            )

        # Match to deal
        match = self._match_email_to_deal(subject, sender)

        # Quarantine if low confidence
        if match.confidence < QUARANTINE_CONFIDENCE_THRESHOLD:
            quarantine_id = self.quarantine.add(
                email_subject=subject,
                email_from=sender,
                reason="low_confidence_match",
                candidates=match.candidates,
                confidence=match.confidence,
                attachments=[a.get("filename", "") for a in (attachments or [])],
                manifest_path=manifest_path,
            )

            # Emit quarantine event
            self.event_store.create_event(
                deal_id="",  # No deal yet
                event_type="quarantine_added",
                actor="lifecycle_emitter",
                data={
                    "quarantine_id": quarantine_id,
                    "email_subject": subject,
                    "from": sender,
                    "candidates": match.candidates,
                    "confidence": match.confidence,
                    "reason": "low_confidence_match",
                },
            )

            return ProcessResult(
                success=True,
                deal_id=None,
                quarantined=True,
                quarantine_id=quarantine_id,
            )

        deal_id = match.deal_id

        # Create deal if new
        if match.is_new:
            deal_id = self._create_deal_from_email(subject, sender)
            self.event_store.create_event(
                deal_id=deal_id,
                event_type="deal_created",
                actor="lifecycle_emitter",
                data={
                    "source": "email_sync",
                    "broker": sender,
                    "initial_summary": subject[:200],
                },
            )

        # Emit email_received event
        self.event_store.create_event(
            deal_id=deal_id,
            event_type="email_received",
            actor="email_sync",
            data={
                "from": sender,
                "subject": subject,
                "date": date,
                "attachments": [a.get("filename", "") for a in (attachments or [])],
                "message_id": message_id,
                "matched_by": match.matched_by,
            },
        )

        events_emitted = ["email_received"]
        actions_scheduled = []

        # Process attachments
        for attachment in (attachments or []):
            filename = attachment.get("filename", "")
            path = attachment.get("path", "")
            sha256 = attachment.get("sha256", "")

            # Skip if already processed
            if sha256 and self.deduplicator.is_attachment_processed(sha256):
                continue

            # Emit document_attached event
            self.event_store.create_event(
                deal_id=deal_id,
                event_type="document_attached",
                actor="email_sync",
                data={
                    "filename": filename,
                    "path": path,
                    "size_bytes": attachment.get("size_bytes"),
                    "sha256": sha256,
                    "source": "email_attachment",
                },
            )
            events_emitted.append("document_attached")

            # Classify document
            doc_type, confidence = self._classify_document(filename, path)

            self.event_store.create_event(
                deal_id=deal_id,
                event_type="document_classified",
                actor="lifecycle_emitter",
                data={
                    "filename": filename,
                    "doc_type": doc_type,
                    "confidence": confidence,
                    "classifier": "rules" if not self.llm_router else "hybrid",
                },
            )
            events_emitted.append("document_classified")

            # Apply document policy
            action = self._apply_document_policy(deal_id, doc_type)
            if action:
                actions_scheduled.append(action)

            # Mark attachment processed
            if sha256:
                self.deduplicator.mark_attachment_processed(sha256, deal_id, filename)

        # Mark email processed
        self.deduplicator.mark_email_processed(key, deal_id, manifest_path)

        return ProcessResult(
            success=True,
            deal_id=deal_id,
            events_emitted=events_emitted,
            actions_scheduled=actions_scheduled,
        )

    def _match_email_to_deal(self, subject: str, sender: str) -> EmailMatch:
        """
        Match email to a deal using registry aliases.

        Returns match result with confidence score.
        """
        # Try matching via registry
        results = self.registry.search(subject)
        if not results:
            # Try sender email
            results = self.registry.search(sender)

        if not results:
            # No match - will need new deal or quarantine
            return EmailMatch(
                deal_id=None,
                confidence=0.0,
                is_new=True,
                matched_by="none",
            )

        # Use best match
        best = results[0]
        confidence = best.get("score", 0.5)

        # Check for ambiguity
        candidates = [
            {"deal_id": r["deal_id"], "name": r["canonical_name"], "score": r.get("score", 0)}
            for r in results[:5]
        ]

        if len(results) > 1 and results[1].get("score", 0) > 0.8 * confidence:
            # Multiple close matches - reduce confidence
            confidence *= 0.7

        return EmailMatch(
            deal_id=best["deal_id"],
            confidence=min(1.0, confidence),
            is_new=False,
            matched_by="alias" if confidence > 0.7 else "fuzzy",
            candidates=candidates,
        )

    def _create_deal_from_email(self, subject: str, sender: str) -> str:
        """Create a new deal from email"""
        # Extract deal name from subject
        name = subject[:100].strip()
        # Clean up common prefixes
        for prefix in ["RE:", "FW:", "Fwd:", "Re:"]:
            if name.upper().startswith(prefix.upper()):
                name = name[len(prefix):].strip()

        deal_id = self.registry.generate_deal_id()
        self.registry.create_deal(
            deal_id=deal_id,
            canonical_name=name,
            source="email_sync",
        )
        self.registry.save()

        return deal_id

    def _classify_document(self, filename: str, path: str = "") -> Tuple[str, float]:
        """
        Classify a document by type.

        Uses rules first, LLM if available.
        """
        filename_lower = filename.lower()

        # Rule-based classification
        if "cim" in filename_lower or "confidential information memo" in filename_lower:
            return "CIM", 0.95
        if "teaser" in filename_lower:
            return "TEASER", 0.90
        if "nda" in filename_lower or "non-disclosure" in filename_lower:
            return "NDA", 0.95
        if "loi" in filename_lower or "letter of intent" in filename_lower:
            return "LOI", 0.90
        if "financials" in filename_lower or "p&l" in filename_lower or "balance sheet" in filename_lower:
            return "FINANCIALS", 0.85
        if "tax" in filename_lower and ("return" in filename_lower or "1040" in filename_lower or "1120" in filename_lower):
            return "TAX", 0.85

        # Use LLM if available
        if self.llm_router:
            try:
                categories = ["CIM", "TEASER", "FINANCIALS", "NDA", "LOI", "TAX", "LEGAL", "OPERATIONS", "OTHER"]
                category, confidence, _ = self.llm_router.classify_with_fallback(
                    f"Document filename: {filename}",
                    categories,
                    context="M&A deal document classification",
                )
                return category, confidence
            except Exception:
                pass

        return "OTHER", 0.5

    def _apply_document_policy(self, deal_id: str, doc_type: str) -> Optional[str]:
        """
        Apply document trigger policies.

        Returns action scheduled if any.
        """
        triggers = self.policy_loader.get_document_triggers()
        trigger = triggers.get(doc_type)

        if not trigger:
            return None

        actions = trigger.get("actions", {})

        # CIM triggers advancement to SCREENING
        if doc_type == "CIM" and actions.get("advance_to_screening"):
            deal = self.registry.get_deal(deal_id)
            if deal and deal.stage == "inbound":
                # Update stage
                self.registry.update_deal(deal_id, stage="screening")
                self.registry.save()

                # Emit stage change event
                self.event_store.create_event(
                    deal_id=deal_id,
                    event_type="stage_changed",
                    actor="lifecycle_emitter",
                    data={
                        "from_stage": "inbound",
                        "to_stage": "screening",
                        "reason": "CIM received - auto-advanced per policy",
                        "auto_triggered": True,
                    },
                )

                # Schedule analysis
                self.action_queue.schedule_relative(
                    deal_id=deal_id,
                    action_type="run_agent",
                    days_from_now=0,  # Immediately
                    data={"agent": "underwriter", "task": "initial_analysis"},
                )

                return "run_agent:underwriter:initial_analysis"

        return None

    def process_pending_manifests(self, manifests_dir: Path = MANIFESTS_DIR) -> Dict[str, Any]:
        """
        Process all pending manifests in the pipeline.

        Scans for manifest.json files and processes them.
        """
        results = {
            "processed": 0,
            "quarantined": 0,
            "skipped": 0,
            "errors": 0,
            "deals_updated": [],
        }

        # Find all manifest files
        for manifest_path in manifests_dir.rglob("*manifest*.json"):
            try:
                result = self.process_manifest(str(manifest_path))

                if result.error and "Already processed" in result.error:
                    results["skipped"] += 1
                elif result.quarantined:
                    results["quarantined"] += 1
                elif result.success:
                    results["processed"] += 1
                    if result.deal_id and result.deal_id not in results["deals_updated"]:
                        results["deals_updated"].append(result.deal_id)
                else:
                    results["errors"] += 1

            except Exception as e:
                results["errors"] += 1

        return results


def cmd_process_manifests(args):
    """Process all pending manifests"""
    emitter = LifecycleEventEmitter()
    results = emitter.process_pending_manifests()

    print("\n" + "=" * 60)
    print("Lifecycle Event Processing Complete")
    print("=" * 60)
    print(f"Processed: {results['processed']}")
    print(f"Quarantined: {results['quarantined']}")
    print(f"Skipped: {results['skipped']}")
    print(f"Errors: {results['errors']}")
    if results["deals_updated"]:
        print(f"Deals updated: {', '.join(results['deals_updated'][:10])}")


def cmd_process_manifest(args):
    """Process a single manifest"""
    emitter = LifecycleEventEmitter()
    result = emitter.process_manifest(args.path)

    print(json.dumps({
        "success": result.success,
        "deal_id": result.deal_id,
        "events_emitted": result.events_emitted,
        "actions_scheduled": result.actions_scheduled,
        "quarantined": result.quarantined,
        "quarantine_id": result.quarantine_id,
        "error": result.error,
    }, indent=2))


def cmd_quarantine_list(args):
    """List quarantine items"""
    qm = QuarantineManager()
    items = qm.get_pending()

    print(f"\nQuarantine Items ({len(items)} pending)")
    print("=" * 60)

    for item in items:
        print(f"\n{item['quarantine_id']}")
        print(f"  Subject: {item['email_subject'][:50]}")
        print(f"  From: {item['email_from']}")
        print(f"  Reason: {item['reason']}")
        print(f"  Confidence: {item['confidence']:.0%}")
        if item.get("candidates"):
            print("  Candidates:")
            for c in item["candidates"][:3]:
                print(f"    - {c['deal_id']}: {c['name'][:30]}")


def cmd_quarantine_resolve(args):
    """Resolve a quarantine item"""
    qm = QuarantineManager()
    event_store = DealEventStore()

    item = qm.get_item(args.quarantine_id)
    if not item:
        print(f"Quarantine item not found: {args.quarantine_id}")
        return

    if args.action == "link":
        if not args.deal_id:
            print("--deal-id required for link action")
            return

        qm.resolve(args.quarantine_id, "link_to_deal", args.deal_id, "cli")

        # Process the quarantined email
        emitter = LifecycleEventEmitter()
        result = emitter.process_email(
            message_id=item.get("message_id", args.quarantine_id),
            subject=item["email_subject"],
            sender=item["email_from"],
            date=item.get("created_at", ""),
            manifest_path=item.get("manifest_path", ""),
        )

        event_store.create_event(
            deal_id=args.deal_id,
            event_type="quarantine_resolved",
            actor="cli",
            data={
                "quarantine_id": args.quarantine_id,
                "resolution": "linked",
            },
        )

        print(f"Resolved: linked to {args.deal_id}")

    elif args.action == "discard":
        qm.resolve(args.quarantine_id, "discard", resolved_by="cli")

        event_store.create_event(
            deal_id="",
            event_type="quarantine_resolved",
            actor="cli",
            data={
                "quarantine_id": args.quarantine_id,
                "resolution": "discarded",
            },
        )

        print(f"Resolved: discarded")

    elif args.action == "new-deal":
        # Create new deal
        registry = DealRegistry(REGISTRY_PATH)
        deal_id = registry.generate_deal_id()
        registry.create_deal(
            deal_id=deal_id,
            canonical_name=item["email_subject"][:100],
            source="quarantine_resolution",
        )
        registry.save()

        qm.resolve(args.quarantine_id, "create_new_deal", deal_id, "cli")

        event_store.create_event(
            deal_id=deal_id,
            event_type="quarantine_resolved",
            actor="cli",
            data={
                "quarantine_id": args.quarantine_id,
                "resolution": "new_deal_created",
            },
        )

        print(f"Resolved: created {deal_id}")


def main():
    parser = argparse.ArgumentParser(description="Lifecycle Event Emitter CLI")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # process-manifests
    subparsers.add_parser("process-manifests", help="Process all pending manifests")

    # process-manifest
    pm_p = subparsers.add_parser("process-manifest", help="Process single manifest")
    pm_p.add_argument("path", help="Path to manifest file")

    # quarantine-list
    subparsers.add_parser("quarantine-list", help="List quarantine items")

    # quarantine-resolve
    qr_p = subparsers.add_parser("quarantine-resolve", help="Resolve quarantine item")
    qr_p.add_argument("quarantine_id", help="Quarantine ID")
    qr_p.add_argument("--action", required=True, choices=["link", "discard", "new-deal"])
    qr_p.add_argument("--deal-id", help="Deal ID for link action")

    args = parser.parse_args()

    if args.command == "process-manifests":
        cmd_process_manifests(args)
    elif args.command == "process-manifest":
        cmd_process_manifest(args)
    elif args.command == "quarantine-list":
        cmd_quarantine_list(args)
    elif args.command == "quarantine-resolve":
        cmd_quarantine_resolve(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
