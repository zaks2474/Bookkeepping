#!/usr/bin/env python3
"""
Deal Lifecycle Controller (P2)

Deterministic controller loop that proposes next-best Kinetic Actions for active deals.

Non-negotiables:
- Never auto-send emails.
- Never auto-execute irreversible actions.
- Creates approval-gated actions only (PENDING_APPROVAL), relying on idempotency keys to avoid spam.
"""

from __future__ import annotations

import argparse
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from actions.engine.models import ActionPayload, compute_idempotency_key
from actions.engine.store import ActionStore
from actions.engine.validation import validate_action_creation
from deal_registry import DealRegistry


def _dataroom_root() -> Path:
    return Path(os.getenv("DATAROOM_ROOT", "/home/zaks/DataRoom")).resolve()


def _registry_path() -> Path:
    return _dataroom_root() / ".deal-registry" / "deal_registry.json"


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _has_open_action(store: ActionStore, *, deal_id: str, action_type: str) -> bool:
    rows = store.list_actions(
        deal_id=deal_id,
        action_type=action_type,
        limit=20,
        offset=0,
    )
    for a in rows:
        if a.status in {"PENDING_APPROVAL", "READY", "PROCESSING"}:
            return True
    return False


def propose_actions_for_deal(*, deal: Any, store: ActionStore) -> List[ActionPayload]:
    """
    Produce a list of approval-gated ActionPayload proposals for a single deal.
    """
    deal_id = str(getattr(deal, "deal_id", "") or "").strip()
    stage = str(getattr(deal, "stage", "") or "").strip().lower()
    if not deal_id or not stage:
        return []

    proposals: List[ActionPayload] = []

    # Minimal v1 rule: inbound/screening deals should have a doc-request action queued
    # (only once, via idempotency key).
    if stage in {"inbound", "screening"} and not _has_open_action(store, deal_id=deal_id, action_type="DILIGENCE.REQUEST_DOCS"):
        idem = compute_idempotency_key("controller", deal_id, "DILIGENCE.REQUEST_DOCS", "baseline_v1")
        proposals.append(
            ActionPayload(
                deal_id=deal_id,
                capability_id="diligence.request_docs.v1",
                type="DILIGENCE.REQUEST_DOCS",
                title="Request CIM/financials (controller)",
                summary="Controller proposal: request core deal materials (CIM, LTM financials, customer concentration).",
                status="PENDING_APPROVAL",
                created_by="deal_lifecycle_controller",
                source="system",
                risk_level="medium",
                requires_human_review=True,
                idempotency_key=idem,
                inputs={
                    "doc_type": "cim",
                    "description": "Please share the CIM, LTM financials, and customer concentration. If an NDA is required, send it over.",
                    "generated_at": _now_iso(),
                    "rule": "baseline_v1",
                },
            )
        )

    return proposals


def run_once(*, dry_run: bool = False, max_deals: int = 0, deal_id: str = "") -> Dict[str, Any]:
    store = ActionStore()
    registry = DealRegistry(str(_registry_path()))

    deals = registry.list_deals(status="active")
    if deal_id:
        deals = [d for d in deals if str(getattr(d, "deal_id", "")) == deal_id]

    if max_deals > 0:
        deals = deals[: max(1, int(max_deals))]

    created: List[Tuple[str, bool]] = []
    proposed_total = 0

    for d in deals:
        proposals = propose_actions_for_deal(deal=d, store=store)
        proposed_total += len(proposals)
        for p in proposals:
            if dry_run:
                created.append((p.type, False))
                continue
            validate_action_creation(action_type=p.type, capability_id=p.capability_id)
            _, created_new = store.create_action(p)
            created.append((p.type, bool(created_new)))

    return {
        "dry_run": dry_run,
        "deals_considered": len(deals),
        "proposals_generated": proposed_total,
        "actions_written": [{"action_type": t, "created_new": created_new} for t, created_new in created],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="ZakOps Deal Lifecycle Controller (propose-only)")
    parser.add_argument("--dry-run", action="store_true", help="Do not write actions; print summary only")
    parser.add_argument("--max-deals", type=int, default=0, help="Process at most N deals (0=all)")
    parser.add_argument("--deal-id", default="", help="Only process a specific deal_id")
    args = parser.parse_args()

    result = run_once(dry_run=bool(args.dry_run), max_deals=int(args.max_deals), deal_id=str(args.deal_id or ""))
    print(result)
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
