#!/usr/bin/env python3
"""
Deal Registry CLI - Manage the canonical deal registry

Usage:
  deal_registry_cli.py list [--stage <stage>] [--status <status>]
  deal_registry_cli.py show <deal_id>
  deal_registry_cli.py search <query>
  deal_registry_cli.py add-deal --name <name> [--folder <path>] [--broker <email>]
  deal_registry_cli.py add-alias <deal_id> --alias <alias> --type <type>
  deal_registry_cli.py merge <source_deal_id> <target_deal_id>
  deal_registry_cli.py archive <deal_id> [--reason <reason>]
  deal_registry_cli.py mark-junk <deal_id> [--reason <reason>]
  deal_registry_cli.py audit [--deal <deal_id>] [--days <n>]
  deal_registry_cli.py sync-csv  # Sync registry with MASTER-DEAL-TRACKER.csv
  deal_registry_cli.py migrate [--dry-run]  # Initial migration from existing folders
  deal_registry_cli.py validate  # Check registry integrity
  deal_registry_cli.py cleanup   # Clean up orphaned folders/entries
  deal_registry_cli.py stats     # Show registry statistics
"""

import argparse
import sys
import csv
import shutil
from pathlib import Path
from datetime import datetime, timedelta
from typing import Optional

# Add scripts directory to path
sys.path.insert(0, str(Path(__file__).parent))

from deal_registry import (
    DealRegistry, DealMatcher, Deal, BrokerInfo,
    migrate_from_existing, normalize_text
)

# Configuration
REGISTRY_PATH = "/home/zaks/DataRoom/.deal-registry/deal_registry.json"
DATAROOM_PATH = "/home/zaks/DataRoom"
TRACKER_CSV = "/home/zaks/DataRoom/00-PIPELINE/MASTER-DEAL-TRACKER.csv"
BROKER_CSV = "/home/zaks/DataRoom/03-DEAL-SOURCES/BROKER-TRACKER.csv"
JUNK_ARCHIVE = "/home/zaks/DataRoom/00-PIPELINE/Archive/_JUNK"


def get_registry() -> DealRegistry:
    """Get registry instance"""
    return DealRegistry(REGISTRY_PATH)


def cmd_list(args):
    """List all deals with optional filtering"""
    registry = get_registry()
    deals = registry.list_deals(
        stage=args.stage,
        status=args.status if args.status else 'active'
    )

    if not deals:
        print("No deals found matching criteria")
        return

    # Sort by priority and canonical name
    priority_order = {"HIGHEST": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}
    deals.sort(key=lambda d: (
        priority_order.get(d.metadata.priority, 4),
        d.canonical_name
    ))

    print(f"\n{'Deal ID':<16} {'Pri':<8} {'Stage':<12} {'Canonical Name':<45} {'Broker':<20}")
    print("=" * 105)

    for deal in deals:
        broker_name = deal.broker.name[:18] if deal.broker else "N/A"
        name_display = deal.canonical_name[:43] if len(deal.canonical_name) > 43 else deal.canonical_name
        print(f"{deal.deal_id:<16} {deal.metadata.priority:<8} {deal.stage:<12} {name_display:<45} {broker_name:<20}")

    print(f"\nTotal: {len(deals)} deals")


def cmd_show(args):
    """Show detailed deal information"""
    registry = get_registry()
    deal = registry.get_deal(args.deal_id)

    if not deal:
        # Try searching
        results = registry.search(args.deal_id)
        if results:
            print(f"Deal '{args.deal_id}' not found. Did you mean one of these?")
            for r in results[:5]:
                print(f"  {r['deal_id']}: {r['canonical_name']}")
        else:
            print(f"Deal not found: {args.deal_id}")
        return

    print(f"\n{'=' * 70}")
    print(f"Deal ID: {deal.deal_id}")
    print(f"{'=' * 70}")
    print(f"\nCanonical Name: {deal.canonical_name}")
    if deal.display_name:
        print(f"Display Name:   {deal.display_name}")
    print(f"Folder:         {deal.folder_path or 'Not set'}")
    print(f"Stage:          {deal.stage}")
    print(f"Status:         {deal.status}")
    print(f"Priority:       {deal.metadata.priority}")
    print(f"Created:        {deal.created_at}")
    print(f"Updated:        {deal.updated_at}")

    print(f"\n--- Identifiers ---")
    if deal.identifiers.listing_ids:
        print(f"Listing IDs:    {', '.join(deal.identifiers.listing_ids)}")
    if deal.identifiers.broker_reference_ids:
        print(f"Broker Refs:    {', '.join(deal.identifiers.broker_reference_ids)}")
    if deal.identifiers.bizbuysell_id:
        print(f"BizBuySell ID:  {deal.identifiers.bizbuysell_id}")

    print(f"\n--- Company Info ---")
    if deal.company_info.company_name:
        print(f"Company:        {deal.company_info.company_name}")
    if deal.company_info.sector:
        print(f"Sector:         {deal.company_info.sector}")
    if deal.company_info.location:
        loc = deal.company_info.location
        loc_str = ", ".join(filter(None, [loc.city, loc.state, loc.region]))
        if loc_str:
            print(f"Location:       {loc_str}")
    if deal.company_info.franchise_system:
        print(f"Franchise:      {deal.company_info.franchise_system}")

    print(f"\n--- Broker ---")
    if deal.broker:
        print(f"Name:           {deal.broker.name}")
        print(f"Email:          {deal.broker.email}")
        print(f"Company:        {deal.broker.company}")
        print(f"Phone:          {deal.broker.phone}")
        print(f"Rating:         {deal.broker.quality_rating}")
    else:
        print("No broker assigned")

    print(f"\n--- Metadata ---")
    if deal.metadata.asking_price:
        print(f"Asking Price:   {deal.metadata.asking_price}")
    if deal.metadata.ebitda:
        print(f"EBITDA:         {deal.metadata.ebitda}")
    print(f"NDA Status:     {deal.metadata.nda_status}")
    print(f"CIM Received:   {'Yes' if deal.metadata.cim_received else 'No'}")
    if deal.metadata.junk_reason:
        print(f"Junk Reason:    {deal.metadata.junk_reason}")

    print(f"\n--- Aliases ({len(deal.aliases)}) ---")
    for i, alias in enumerate(deal.aliases[:15]):
        conf_str = f"{alias.confidence:.2f}" if alias.confidence < 1.0 else "1.0"
        print(f"  [{alias.alias_type:<18}] {alias.alias:<40} (conf: {conf_str})")
    if len(deal.aliases) > 15:
        print(f"  ... and {len(deal.aliases) - 15} more aliases")

    if deal.email_thread_ids:
        print(f"\n--- Email Threads ({len(deal.email_thread_ids)}) ---")
        for tid in deal.email_thread_ids[:5]:
            print(f"  {tid}")
        if len(deal.email_thread_ids) > 5:
            print(f"  ... and {len(deal.email_thread_ids) - 5} more")

    if deal.related_folders:
        print(f"\n--- Related Folders ({len(deal.related_folders)}) ---")
        for folder in deal.related_folders:
            print(f"  {folder}")

    print(f"\n--- Audit Trail (last 10) ---")
    for entry in deal.audit_trail[-10:]:
        timestamp = entry.timestamp[:19].replace('T', ' ')
        print(f"  [{timestamp}] {entry.action}: {entry.details[:60]}")


def cmd_search(args):
    """Search registry by query"""
    registry = get_registry()
    results = registry.search(args.query)

    if not results:
        print(f"No results found for: '{args.query}'")
        return

    print(f"\nSearch results for: '{args.query}'")
    print("-" * 90)

    for result in results[:20]:
        status_badge = ""
        if result['status'] == 'junk':
            status_badge = " [JUNK]"
        elif result['status'] == 'archived':
            status_badge = " [ARCHIVED]"
        elif result['status'] == 'merged':
            status_badge = " [MERGED]"

        print(f"\n{result['deal_id']}: {result['canonical_name']}{status_badge}")
        print(f"  Matched: {result['matched_alias']} ({result['match_type']})")
        print(f"  Confidence: {result['confidence']:.2f}")
        print(f"  Stage: {result['stage']} | Status: {result['status']}")
        if result['folder_path']:
            print(f"  Folder: {result['folder_path']}")

    if len(results) > 20:
        print(f"\n... and {len(results) - 20} more results")


def cmd_add_deal(args):
    """Add a new deal manually"""
    registry = get_registry()

    # Check for existing
    existing = registry.search(args.name)
    if existing:
        print(f"Warning: Similar deal(s) may already exist:")
        for r in existing[:3]:
            print(f"  {r['deal_id']}: {r['canonical_name']}")
        confirm = input("\nCreate new deal anyway? [y/N]: ")
        if confirm.lower() != 'y':
            print("Aborted")
            return

    deal_id = registry.generate_deal_id()

    broker = None
    if args.broker:
        # Find broker by email
        for bid, b in registry.brokers.items():
            if b.email.lower() == args.broker.lower():
                broker = b
                break

    deal = registry.create_deal(
        deal_id=deal_id,
        canonical_name=args.name,
        folder_path=args.folder,
        broker=broker,
        source="cli_manual"
    )

    registry.save()
    print(f"Created deal: {deal_id}")
    print(f"  Name: {args.name}")
    if args.folder:
        print(f"  Folder: {args.folder}")
    if broker:
        print(f"  Broker: {broker.name}")


def cmd_add_alias(args):
    """Add alias to existing deal"""
    registry = get_registry()

    deal = registry.get_deal(args.deal_id)
    if not deal:
        print(f"Deal not found: {args.deal_id}")
        return

    success = registry.add_alias(
        deal_id=args.deal_id,
        alias=args.alias,
        alias_type=args.type,
        confidence=args.confidence or 1.0,
        source='cli_manual'
    )

    if success:
        registry.save()
        print(f"Added alias '{args.alias}' ({args.type}) to {args.deal_id}")
    else:
        print(f"Alias already exists or failed to add")


def cmd_merge(args):
    """Merge source deal into target deal"""
    registry = get_registry()

    source = registry.get_deal(args.source_deal_id)
    target = registry.get_deal(args.target_deal_id)

    if not source:
        print(f"Source deal not found: {args.source_deal_id}")
        return
    if not target:
        print(f"Target deal not found: {args.target_deal_id}")
        return

    print(f"\n{'=' * 60}")
    print("MERGE PREVIEW")
    print(f"{'=' * 60}")

    print(f"\nSOURCE (will be marked as merged):")
    print(f"  ID:      {source.deal_id}")
    print(f"  Name:    {source.canonical_name}")
    print(f"  Folder:  {source.folder_path}")
    print(f"  Aliases: {len(source.aliases)}")
    print(f"  Status:  {source.status}")

    print(f"\nTARGET (will receive source data):")
    print(f"  ID:      {target.deal_id}")
    print(f"  Name:    {target.canonical_name}")
    print(f"  Folder:  {target.folder_path}")
    print(f"  Aliases: {len(target.aliases)}")
    print(f"  Status:  {target.status}")

    confirm = input("\nProceed with merge? [y/N]: ")
    if confirm.lower() != 'y':
        print("Aborted")
        return

    result = registry.merge_deals(args.source_deal_id, args.target_deal_id, source="cli_command")

    if result.get("success"):
        registry.save()
        print(f"\nMerge complete:")
        print(f"  Aliases transferred: {result.get('aliases_merged', 0)}")
        print(f"  Source folder added to related: {result.get('source_folder', 'N/A')}")

        # Ask about physical folder merge
        if source.folder_path and target.folder_path:
            move = input(f"\nMove files from source folder to target? [y/N]: ")
            if move.lower() == 'y':
                _move_folder_contents(source.folder_path, target.folder_path)
    else:
        print(f"Merge failed: {result.get('error', 'Unknown error')}")


def _move_folder_contents(source_path: str, target_path: str):
    """Move folder contents and archive source"""
    source = Path(source_path)
    target = Path(target_path)

    if not source.exists():
        print(f"Source folder does not exist: {source}")
        return

    if not target.exists():
        print(f"Target folder does not exist: {target}")
        return

    # Move files from each subfolder
    moved = 0
    for subfolder in source.iterdir():
        if subfolder.is_dir():
            target_sub = target / subfolder.name
            target_sub.mkdir(exist_ok=True)
            for file in subfolder.iterdir():
                if file.is_file():
                    dest = target_sub / file.name
                    if dest.exists():
                        # Rename with timestamp
                        stem = file.stem
                        suffix = file.suffix
                        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                        dest = target_sub / f"{stem}_{timestamp}{suffix}"
                    shutil.move(str(file), str(dest))
                    moved += 1

    print(f"Moved {moved} files")

    # Archive source folder
    archive_base = Path(JUNK_ARCHIVE).parent
    archive_path = archive_base / "_MERGED" / source.name
    archive_path.parent.mkdir(parents=True, exist_ok=True)

    if archive_path.exists():
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        archive_path = archive_base / "_MERGED" / f"{source.name}_{timestamp}"

    shutil.move(str(source), str(archive_path))
    print(f"Source folder archived to: {archive_path}")


def cmd_archive(args):
    """Archive a deal"""
    registry = get_registry()

    deal = registry.get_deal(args.deal_id)
    if not deal:
        print(f"Deal not found: {args.deal_id}")
        return

    print(f"Archiving deal: {deal.deal_id}")
    print(f"  Name: {deal.canonical_name}")
    print(f"  Folder: {deal.folder_path}")

    confirm = input("\nConfirm archive? [y/N]: ")
    if confirm.lower() != 'y':
        print("Aborted")
        return

    registry.archive_deal(args.deal_id, reason=args.reason or "", source="cli_command")
    registry.save()
    print(f"Deal {args.deal_id} archived")


def cmd_mark_junk(args):
    """Mark a deal as junk and optionally move folder"""
    registry = get_registry()

    deal = registry.get_deal(args.deal_id)
    if not deal:
        print(f"Deal not found: {args.deal_id}")
        return

    print(f"Marking as JUNK: {deal.deal_id}")
    print(f"  Name: {deal.canonical_name}")
    print(f"  Folder: {deal.folder_path}")

    reason = args.reason
    if not reason:
        reason = input("Reason for marking as junk: ")

    confirm = input("\nConfirm mark as junk? [y/N]: ")
    if confirm.lower() != 'y':
        print("Aborted")
        return

    registry.mark_junk(args.deal_id, reason=reason, source="cli_command")

    # Add junk pattern if applicable
    if args.pattern:
        registry.add_junk_pattern(args.pattern, args.pattern_type or "subject_contains",
                                  "reject", f"Added when marking {args.deal_id} as junk")

    registry.save()
    print(f"Deal {args.deal_id} marked as junk")

    # Offer to move folder
    if deal.folder_path and Path(deal.folder_path).exists():
        move = input(f"\nMove folder to junk archive? [y/N]: ")
        if move.lower() == 'y':
            junk_path = Path(JUNK_ARCHIVE)
            junk_path.mkdir(parents=True, exist_ok=True)

            dest = junk_path / Path(deal.folder_path).name
            if dest.exists():
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                dest = junk_path / f"{Path(deal.folder_path).name}_{timestamp}"

            shutil.move(deal.folder_path, str(dest))
            print(f"Folder moved to: {dest}")


def cmd_migrate(args):
    """Initial migration from existing folders"""
    registry = get_registry()

    print("=" * 60)
    print("DEAL REGISTRY MIGRATION")
    print("=" * 60)

    if args.dry_run:
        print("\n[DRY RUN MODE - No changes will be made]\n")

    print(f"Data sources:")
    print(f"  Tracker CSV: {TRACKER_CSV}")
    print(f"  Broker CSV:  {BROKER_CSV}")
    print(f"  DataRoom:    {DATAROOM_PATH}")

    if not args.dry_run:
        confirm = input("\nProceed with migration? [y/N]: ")
        if confirm.lower() != 'y':
            print("Aborted")
            return

    result = migrate_from_existing(
        registry=registry,
        dataroom_path=DATAROOM_PATH,
        tracker_csv=TRACKER_CSV,
        broker_csv=BROKER_CSV,
        dry_run=args.dry_run
    )

    print(f"\n{'Migration Preview' if args.dry_run else 'Migration Complete'}:")
    print(f"  Deals created:        {result['deals_created']}")
    print(f"  Aliases created:      {result['aliases_created']}")
    print(f"  Brokers created:      {result['brokers_created']}")
    print(f"  Junk folders found:   {result['junk_identified']}")

    if result.get('duplicates'):
        print(f"\nPotential duplicates found ({len(result['duplicates'])}):")
        for dup in result['duplicates'][:10]:
            print(f"  - {dup}")

    if not args.dry_run:
        print(f"\nRegistry saved to: {REGISTRY_PATH}")


def cmd_sync_csv(args):
    """Sync registry with MASTER-DEAL-TRACKER.csv"""
    registry = get_registry()

    tracker_path = Path(TRACKER_CSV)
    if not tracker_path.exists():
        print(f"Tracker CSV not found: {TRACKER_CSV}")
        return

    direction = args.direction or "registry_to_csv"

    if direction == "registry_to_csv":
        # Export registry to CSV
        print("Syncing registry -> CSV")

        # Read existing to preserve extra columns
        existing_rows = {}
        fieldnames = None
        if tracker_path.exists():
            with open(tracker_path, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                fieldnames = reader.fieldnames
                for row in reader:
                    name = row.get('Deal Name', '').strip()
                    if name:
                        existing_rows[name.lower()] = row

        # Default fieldnames if new file
        if not fieldnames:
            fieldnames = [
                'Deal Name', 'Sector', 'Asking Price', 'EBITDA', 'Multiple',
                'Broker', 'Broker Email', 'Broker Phone', 'Date Received',
                'Stage', 'Next Action', 'Target Close Date', 'Priority', 'Status Notes'
            ]

        # Build rows from registry
        rows = []
        for deal in registry.deals.values():
            if deal.status in ('junk', 'merged'):
                continue

            name = deal.canonical_name

            # Start with existing data if available
            row = existing_rows.get(name.lower(), {})

            # Update with registry data
            row['Deal Name'] = name
            if deal.company_info.sector:
                row['Sector'] = deal.company_info.sector
            if deal.broker:
                row['Broker'] = deal.broker.name
                row['Broker Email'] = deal.broker.email
                row['Broker Phone'] = deal.broker.phone
            row['Priority'] = deal.metadata.priority
            if deal.metadata.asking_price:
                row['Asking Price'] = deal.metadata.asking_price
            if deal.metadata.ebitda:
                row['EBITDA'] = deal.metadata.ebitda

            # Map stage
            stage_map = {
                'inbound': 'New Inbound',
                'screening': 'NDA Pending',
                'qualified': 'Qualified',
                'loi': 'LOI Submitted',
                'closing': 'In Closing',
                'archive': 'Archived',
            }
            row['Stage'] = stage_map.get(deal.stage, deal.stage.title())

            # Ensure all fields exist
            for field in fieldnames:
                if field not in row:
                    row[field] = ''

            rows.append(row)

        # Sort by priority
        priority_order = {"HIGHEST": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}
        rows.sort(key=lambda r: (
            priority_order.get(r.get('Priority', 'LOW'), 4),
            r.get('Deal Name', '')
        ))

        # Write CSV
        with open(tracker_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)

        print(f"Updated {len(rows)} deals in {TRACKER_CSV}")

    else:
        # Import CSV to registry (csv_to_registry)
        print("This direction not implemented yet. Use 'migrate' for initial import.")


def cmd_validate(args):
    """Validate registry integrity"""
    registry = get_registry()

    print("Validating registry...")
    issues = []

    # Check for orphaned folders
    inbound = Path(DATAROOM_PATH) / "00-PIPELINE" / "Inbound"
    screening = Path(DATAROOM_PATH) / "00-PIPELINE" / "Screening"

    for folder_path in [inbound, screening]:
        if folder_path.exists():
            for folder in folder_path.iterdir():
                if folder.is_dir():
                    deal = registry.get_deal_by_folder(str(folder))
                    if not deal:
                        issues.append(f"Orphaned folder (not in registry): {folder}")

    # Check for missing folders
    for deal in registry.deals.values():
        if deal.status in ('active', 'inactive') and deal.folder_path:
            if not Path(deal.folder_path).exists():
                issues.append(f"Missing folder for deal {deal.deal_id}: {deal.folder_path}")

    # Check for duplicate aliases
    alias_to_deal = {}
    for deal_id, deal in registry.deals.items():
        for alias in deal.aliases:
            key = (alias.alias_normalized, alias.alias_type)
            if key in alias_to_deal and alias_to_deal[key] != deal_id:
                issues.append(f"Duplicate alias '{alias.alias}' ({alias.alias_type}): {alias_to_deal[key]} and {deal_id}")
            alias_to_deal[key] = deal_id

    # Report
    if issues:
        print(f"\nFound {len(issues)} issues:")
        for issue in issues[:20]:
            print(f"  - {issue}")
        if len(issues) > 20:
            print(f"  ... and {len(issues) - 20} more")
    else:
        print("No issues found!")

    print(f"\nRegistry stats:")
    print(f"  Total deals: {len(registry.deals)}")
    print(f"  Active deals: {len([d for d in registry.deals.values() if d.status == 'active'])}")
    print(f"  Junk deals: {len([d for d in registry.deals.values() if d.status == 'junk'])}")
    print(f"  Brokers: {len(registry.brokers)}")
    print(f"  Junk patterns: {len(registry.junk_patterns)}")


def cmd_stats(args):
    """Show registry statistics"""
    registry = get_registry()

    deals = list(registry.deals.values())

    print("\n" + "=" * 50)
    print("DEAL REGISTRY STATISTICS")
    print("=" * 50)

    # Overall counts
    print(f"\n--- Overall ---")
    print(f"Total deals:     {len(deals)}")
    print(f"Total brokers:   {len(registry.brokers)}")
    print(f"Junk patterns:   {len(registry.junk_patterns)}")

    # By status
    print(f"\n--- By Status ---")
    status_counts = {}
    for deal in deals:
        status_counts[deal.status] = status_counts.get(deal.status, 0) + 1
    for status, count in sorted(status_counts.items()):
        print(f"  {status:<12}: {count}")

    # By stage (active only)
    active_deals = [d for d in deals if d.status == 'active']
    print(f"\n--- By Stage (Active Only) ---")
    stage_counts = {}
    for deal in active_deals:
        stage_counts[deal.stage] = stage_counts.get(deal.stage, 0) + 1
    for stage, count in sorted(stage_counts.items()):
        print(f"  {stage:<12}: {count}")

    # By priority
    print(f"\n--- By Priority (Active Only) ---")
    priority_counts = {}
    for deal in active_deals:
        priority_counts[deal.metadata.priority] = priority_counts.get(deal.metadata.priority, 0) + 1
    for priority in ["HIGHEST", "HIGH", "MEDIUM", "LOW"]:
        count = priority_counts.get(priority, 0)
        print(f"  {priority:<12}: {count}")

    # By sector
    print(f"\n--- By Sector (Active Only) ---")
    sector_counts = {}
    for deal in active_deals:
        sector = deal.company_info.sector or "Unknown"
        sector_counts[sector] = sector_counts.get(sector, 0) + 1
    for sector, count in sorted(sector_counts.items(), key=lambda x: -x[1])[:10]:
        print(f"  {sector:<25}: {count}")

    # Alias statistics
    total_aliases = sum(len(d.aliases) for d in deals)
    print(f"\n--- Alias Statistics ---")
    print(f"Total aliases: {total_aliases}")
    print(f"Avg per deal:  {total_aliases / len(deals):.1f}" if deals else "N/A")


def cmd_cleanup(args):
    """Clean up orphaned entries"""
    registry = get_registry()

    print("Scanning for cleanup opportunities...")

    # Find folders not in registry
    orphaned_folders = []
    for path in [
        Path(DATAROOM_PATH) / "00-PIPELINE" / "Inbound",
        Path(DATAROOM_PATH) / "00-PIPELINE" / "Screening",
    ]:
        if path.exists():
            for folder in path.iterdir():
                if folder.is_dir():
                    if not registry.get_deal_by_folder(str(folder)):
                        orphaned_folders.append(folder)

    if orphaned_folders:
        print(f"\nOrphaned folders ({len(orphaned_folders)}):")
        for folder in orphaned_folders[:20]:
            print(f"  {folder}")

        if args.fix:
            print("\nAdding orphaned folders to registry...")
            for folder in orphaned_folders:
                deal_id = registry.generate_deal_id()
                deal = registry.create_deal(
                    deal_id=deal_id,
                    canonical_name=folder.name,
                    folder_path=str(folder),
                    source="cleanup"
                )
                print(f"  Created {deal_id}: {folder.name}")
            registry.save()
    else:
        print("No orphaned folders found")


def main():
    parser = argparse.ArgumentParser(
        description="Deal Registry CLI - Manage the canonical deal registry",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s list                         # List all active deals
  %(prog)s list --stage screening       # List deals in screening
  %(prog)s show DEAL-2025-001           # Show deal details
  %(prog)s search "57839"               # Search by listing ID
  %(prog)s search "teamlogic"           # Search by name
  %(prog)s add-alias DEAL-2025-001 --alias "57839" --type listing_number
  %(prog)s merge DEAL-2025-002 DEAL-2025-001  # Merge 002 into 001
  %(prog)s mark-junk DEAL-2025-003 --reason "Holiday promo"
  %(prog)s migrate --dry-run            # Preview migration
  %(prog)s migrate                      # Run migration
  %(prog)s sync-csv                     # Sync to MASTER-DEAL-TRACKER.csv
"""
    )

    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # list
    list_p = subparsers.add_parser('list', help='List all deals')
    list_p.add_argument('--stage', choices=['inbound', 'screening', 'qualified', 'loi', 'closing', 'archive'])
    list_p.add_argument('--status', choices=['active', 'inactive', 'merged', 'archived', 'junk'])

    # show
    show_p = subparsers.add_parser('show', help='Show deal details')
    show_p.add_argument('deal_id', help='Deal ID or search term')

    # search
    search_p = subparsers.add_parser('search', help='Search deals')
    search_p.add_argument('query', help='Search query')

    # add-deal
    add_deal_p = subparsers.add_parser('add-deal', help='Add new deal manually')
    add_deal_p.add_argument('--name', required=True, help='Deal name')
    add_deal_p.add_argument('--folder', help='Folder path')
    add_deal_p.add_argument('--broker', help='Broker email')

    # add-alias
    add_alias_p = subparsers.add_parser('add-alias', help='Add alias to deal')
    add_alias_p.add_argument('deal_id', help='Deal ID')
    add_alias_p.add_argument('--alias', required=True, help='Alias text')
    add_alias_p.add_argument('--type', required=True,
                             choices=['listing_id', 'listing_number', 'company_name', 'dba_name',
                                      'name_variation', 'subject_keywords', 'location_sector'],
                             help='Alias type')
    add_alias_p.add_argument('--confidence', type=float, help='Confidence score (0-1)')

    # merge
    merge_p = subparsers.add_parser('merge', help='Merge two deals')
    merge_p.add_argument('source_deal_id', help='Source deal (will be marked as merged)')
    merge_p.add_argument('target_deal_id', help='Target deal (will receive data)')

    # archive
    archive_p = subparsers.add_parser('archive', help='Archive a deal')
    archive_p.add_argument('deal_id', help='Deal ID')
    archive_p.add_argument('--reason', help='Archive reason')

    # mark-junk
    junk_p = subparsers.add_parser('mark-junk', help='Mark deal as junk')
    junk_p.add_argument('deal_id', help='Deal ID')
    junk_p.add_argument('--reason', help='Junk reason')
    junk_p.add_argument('--pattern', help='Add junk pattern')
    junk_p.add_argument('--pattern-type', choices=['domain', 'subject_regex', 'subject_contains', 'sender_email'])

    # migrate
    migrate_p = subparsers.add_parser('migrate', help='Migrate existing data to registry')
    migrate_p.add_argument('--dry-run', action='store_true', help='Preview without changes')

    # sync-csv
    sync_p = subparsers.add_parser('sync-csv', help='Sync with MASTER-DEAL-TRACKER.csv')
    sync_p.add_argument('--direction', choices=['registry_to_csv', 'csv_to_registry'],
                        default='registry_to_csv')

    # validate
    subparsers.add_parser('validate', help='Validate registry integrity')

    # stats
    subparsers.add_parser('stats', help='Show registry statistics')

    # cleanup
    cleanup_p = subparsers.add_parser('cleanup', help='Clean up orphaned entries')
    cleanup_p.add_argument('--fix', action='store_true', help='Actually fix issues')

    args = parser.parse_args()

    commands = {
        'list': cmd_list,
        'show': cmd_show,
        'search': cmd_search,
        'add-deal': cmd_add_deal,
        'add-alias': cmd_add_alias,
        'merge': cmd_merge,
        'archive': cmd_archive,
        'mark-junk': cmd_mark_junk,
        'migrate': cmd_migrate,
        'sync-csv': cmd_sync_csv,
        'validate': cmd_validate,
        'stats': cmd_stats,
        'cleanup': cmd_cleanup,
    }

    if args.command in commands:
        commands[args.command](args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
