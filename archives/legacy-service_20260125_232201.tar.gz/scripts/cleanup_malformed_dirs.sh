#!/bin/bash
# Remove malformed brace directories in DataRoom

DATAROOM="/home/zaks/DataRoom"
LOG_FILE="/home/zaks/logs/cleanup_$(date +%Y%m%d_%H%M%S).log"

echo "=== DataRoom Malformed Directory Cleanup ===" | tee -a "$LOG_FILE"
echo "Date: $(date)" | tee -a "$LOG_FILE"
echo "" | tee -a "$LOG_FILE"

# Find all directories with braces in name dynamically
echo "Scanning for malformed directories..." | tee -a "$LOG_FILE"
MALFORMED_DIRS=$(find "$DATAROOM" -type d \( -name "*{*" -o -name "*}*" \) 2>/dev/null)

if [ -z "$MALFORMED_DIRS" ]; then
    echo "No malformed directories found." | tee -a "$LOG_FILE"
    exit 0
fi

echo "Found malformed directories:" | tee -a "$LOG_FILE"
echo "$MALFORMED_DIRS" | tee -a "$LOG_FILE"
echo "" | tee -a "$LOG_FILE"

# Process each directory (sorted by depth descending to handle nested first)
echo "$MALFORMED_DIRS" | awk '{print length, $0}' | sort -rn | cut -d" " -f2- | while read -r DIR; do
    if [ -d "$DIR" ]; then
        echo "Processing: $DIR" | tee -a "$LOG_FILE"

        # Check if empty
        if [ -z "$(ls -A "$DIR" 2>/dev/null)" ]; then
            echo "  → Empty, safe to delete" | tee -a "$LOG_FILE"
            rm -rf "$DIR"
            echo "  ✓ Deleted" | tee -a "$LOG_FILE"
        else
            echo "  ⚠ NOT EMPTY - manual review required" | tee -a "$LOG_FILE"
            ls -la "$DIR" 2>/dev/null | head -10 | tee -a "$LOG_FILE"
        fi
    else
        echo "Not found (already removed?): $DIR" | tee -a "$LOG_FILE"
    fi
    echo "" | tee -a "$LOG_FILE"
done

echo "=== Cleanup Complete ===" | tee -a "$LOG_FILE"

# Verify
echo "" | tee -a "$LOG_FILE"
echo "Verification - remaining malformed directories:" | tee -a "$LOG_FILE"
find "$DATAROOM" -type d \( -name "*{*" -o -name "*}*" \) 2>/dev/null | tee -a "$LOG_FILE" || echo "  None found" | tee -a "$LOG_FILE"
