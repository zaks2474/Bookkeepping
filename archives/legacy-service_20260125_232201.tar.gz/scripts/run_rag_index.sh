#!/usr/bin/env bash
set -euo pipefail

LOG_DIR="/home/zaks/logs"
CACHE_DIR="/home/zaks/.cache"
LOG_FILE="${LOG_DIR}/rag_index_$(date +%Y%m%d).log"
LOCK_FILE="${CACHE_DIR}/rag_index.lock"

LEDGER_WRITER="/home/zaks/bookkeeping/scripts/run_ledger.py"
LEDGER_PATH="${ZAKOPS_RUN_LEDGER_PATH:-/home/zaks/logs/run-ledger.jsonl}"
RUN_TS="$(date -u +%Y%m%dT%H%M%SZ)"
RUN_ID="${RUN_TS}_rag_index_${$}"
STARTED_AT="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
START_EPOCH="$(date +%s)"
SKIPPED_REASON=""
ERROR_REASON=""
RAG_PORT=""

on_exit() {
  set +e
  local exit_code=$?
  local ended_at
  ended_at="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  local end_epoch
  end_epoch="$(date +%s)"
  local duration_seconds=$(( end_epoch - START_EPOCH ))

  local status="success"
  local -a errors=()

  if [ "${exit_code}" -ne 0 ] && [ -z "${ERROR_REASON}" ] && [ -f "${LOG_FILE}" ]; then
    if grep -q "Refusing to index (secret-like content detected)" "${LOG_FILE}" 2>/dev/null; then
      ERROR_REASON="secret_detected"
    fi
  fi

  if [ -n "${SKIPPED_REASON}" ]; then
    status="skipped"
    errors+=("${SKIPPED_REASON}")
  elif [ "${exit_code}" -eq 0 ]; then
    status="success"
  else
    status="fail"
    errors+=("exit_code_${exit_code}")
    if [ -n "${ERROR_REASON}" ]; then
      errors+=("${ERROR_REASON}")
    fi
  fi

  if [ -x "${LEDGER_WRITER}" ]; then
    local indexed="" skipped_unchanged="" errors_count="" candidate_files=""
    if [ -f "${LOG_FILE}" ]; then
      indexed="$(grep -E '^[[:space:]]+Indexed:' "${LOG_FILE}" 2>/dev/null | tail -n 1 | awk '{print $NF}' || true)"
      skipped_unchanged="$(grep -E '^[[:space:]]+Skipped \\(unchanged\\):' "${LOG_FILE}" 2>/dev/null | tail -n 1 | awk '{print $NF}' || true)"
      errors_count="$(grep -E '^[[:space:]]+Errors:' "${LOG_FILE}" 2>/dev/null | tail -n 1 | awk '{print $NF}' || true)"
      candidate_files="$(grep -E '^Found [0-9]+ files to potentially index' "${LOG_FILE}" 2>/dev/null | tail -n 1 | awk '{print $2}' || true)"
    fi

    ledger_args=(
      python3 "${LEDGER_WRITER}"
      --ledger-path "${LEDGER_PATH}"
      --component "rag_index"
      --run-id "${RUN_ID}"
      --status "${status}"
      --started-at "${STARTED_AT}"
      --ended-at "${ended_at}"
      --artifact "${LOG_FILE}"
      --metric "exit_code=${exit_code}"
      --metric "duration_seconds=${duration_seconds}"
    )
    if [[ "${candidate_files}" =~ ^[0-9]+$ ]]; then ledger_args+=(--metric "candidate_files=${candidate_files}"); fi
    if [[ "${indexed}" =~ ^[0-9]+$ ]]; then ledger_args+=(--metric "indexed=${indexed}"); fi
    if [[ "${skipped_unchanged}" =~ ^[0-9]+$ ]]; then ledger_args+=(--metric "skipped_unchanged=${skipped_unchanged}"); fi
    if [[ "${errors_count}" =~ ^[0-9]+$ ]]; then ledger_args+=(--metric "errors=${errors_count}"); fi
    if [ -n "${RAG_PORT}" ]; then
      ledger_args+=(--correlation "rag_port=${RAG_PORT}")
    fi
    if [ -n "${ZAKOPS_CORRELATION_ID:-}" ]; then ledger_args+=(--correlation "correlation_id=${ZAKOPS_CORRELATION_ID}"); fi
    if [ -n "${ZAKOPS_PARENT_RUN_ID:-}" ]; then ledger_args+=(--correlation "parent_run_id=${ZAKOPS_PARENT_RUN_ID}"); fi
    for err in "${errors[@]}"; do
      ledger_args+=(--error "${err}")
    done
    "${ledger_args[@]}" >/dev/null 2>&1 || true
  fi
}

trap on_exit EXIT

mkdir -p "$LOG_DIR" "$CACHE_DIR"

if command -v flock >/dev/null 2>&1; then
  exec 9>"$LOCK_FILE"
  if ! flock -n 9; then
    if [ -t 1 ]; then
      echo "⏭ RAG indexing already running; skipping."
    fi
    echo "$(date -Is) ⏭ RAG indexing already running; skipping." >>"$LOG_FILE"
    SKIPPED_REASON="lock_busy"
    exit 0
  fi
fi

detect_rag_port() {
  for port in 8052 8051 8080; do
    if curl -fsS "http://localhost:${port}/rag/stats" >/dev/null 2>&1; then
      echo "$port"
      return 0
    fi
  done
  return 1
}

run_index() {
  echo ""
  echo "================================================================"
  echo "RAG Index - $(date -Is)"
  echo "================================================================"

  local port
  if ! port="$(detect_rag_port)"; then
    echo "✗ RAG REST API not found (tried 8052, 8051, 8080)."
    echo "  Expected health: http://localhost:<port>/rag/stats"
    ERROR_REASON="rag_rest_not_found"
    return 2
  fi

  RAG_PORT="${port}"
  export RAG_API_URL="http://localhost:${port}/rag/add"
  echo "RAG API: ${RAG_API_URL}"
  python3 /home/zaks/scripts/index_dataroom_to_rag.py
  local status=$?
  echo "Done. Exit code: $status"
  return "$status"
}

if [ -t 1 ]; then
  set +e
  run_index 2>&1 | tee -a "$LOG_FILE"
  status=${PIPESTATUS[0]}
  set -e
  exit "$status"
fi

exec >>"$LOG_FILE" 2>&1
run_index
