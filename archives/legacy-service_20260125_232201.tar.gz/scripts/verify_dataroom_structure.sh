#!/bin/bash
# Verify DataRoom structure is clean and correct

DATAROOM="/home/zaks/DataRoom"

echo "=== DataRoom Structure Verification ==="
echo "Date: $(date)"
echo ""

# Check main directories exist
REQUIRED_DIRS=(
    "00-PIPELINE"
    "01-ACTIVE-DEALS"
    "02-PORTFOLIO"
    "03-DEAL-SOURCES"
    "04-FRAMEWORKS"
    "05-ADVISORS"
    "06-KNOWLEDGE-BASE"
    "07-FINANCE"
    "08-ARCHIVE"
)

echo "1. Required directories:"
for DIR in "${REQUIRED_DIRS[@]}"; do
    if [ -d "$DATAROOM/$DIR" ]; then
        echo "  ✓ $DIR exists"
    else
        echo "  ✗ $DIR MISSING"
    fi
done
echo ""

# Check for malformed directories
echo "2. Malformed directories (should be 0):"
MALFORMED_COUNT=$(find "$DATAROOM" -type d \( -name "*{*" -o -name "*}*" \) 2>/dev/null | wc -l)
if [ "$MALFORMED_COUNT" -eq 0 ]; then
    echo "  ✓ No malformed directories found"
else
    echo "  ✗ Found $MALFORMED_COUNT malformed directories:"
    find "$DATAROOM" -type d \( -name "*{*" -o -name "*}*" \) 2>/dev/null
fi
echo ""

# Check permissions
echo "3. Permission issues:"
ROOT_OWNED=$(find "$DATAROOM" -user root 2>/dev/null | wc -l)
if [ "$ROOT_OWNED" -eq 0 ]; then
    echo "  ✓ No root-owned files"
else
    echo "  ✗ Found $ROOT_OWNED root-owned files"
fi

PERMISSION_600=$(find "$DATAROOM" -type f -perm 600 2>/dev/null | wc -l)
if [ "$PERMISSION_600" -eq 0 ]; then
    echo "  ✓ No 600-permission files"
else
    echo "  ✗ Found $PERMISSION_600 files with 600 permissions"
fi
echo ""

# Check size
echo "4. DataRoom size:"
du -sh "$DATAROOM"
echo ""

# Check for OpenWebUI bloat
OPENWEBUI_ARCHIVE="$DATAROOM/08-ARCHIVE/openwebui-chats"
if [ -d "$OPENWEBUI_ARCHIVE" ]; then
    OWUI_SIZE=$(du -sh "$OPENWEBUI_ARCHIVE" | cut -f1)
    echo "  ⚠ OpenWebUI archive present: $OWUI_SIZE (should be removed)"
else
    echo "  ✓ No OpenWebUI runtime bloat"
fi
echo ""

# Check file counts
echo "5. Content summary:"
echo "  Markdown files: $(find "$DATAROOM" -type f -name "*.md" | wc -l)"
echo "  CSV files: $(find "$DATAROOM" -type f -name "*.csv" | wc -l)"
echo "  PDF files: $(find "$DATAROOM" -type f -name "*.pdf" | wc -l)"
echo "  Total files: $(find "$DATAROOM" -type f | wc -l)"
echo ""

# Check for proper AI-Sessions export directory
echo "6. OpenWebUI Export Directory:"
if [ -d "$DATAROOM/06-KNOWLEDGE-BASE/AI-Sessions/OpenWebUI" ]; then
    echo "  ✓ Export directory exists"
    EXPORT_COUNT=$(find "$DATAROOM/06-KNOWLEDGE-BASE/AI-Sessions/OpenWebUI" -type f -name "*.md" ! -name "README.md" | wc -l)
    echo "  Chat exports: $EXPORT_COUNT"
else
    echo "  ✗ Export directory missing"
fi
echo ""

echo "=== Verification Complete ==="
