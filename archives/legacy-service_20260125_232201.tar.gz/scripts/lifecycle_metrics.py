#!/usr/bin/env python3
"""
Lifecycle Metrics Collector

Tracks and reports on system metrics for Phase 6 evaluation:
- Classification accuracy (quarantine rate, resolution outcomes)
- LLM usage (token counts, cloud vs local ratio)
- Pipeline health (stage distribution, stuck deals)
- Action execution (success/failure rates)

Usage:
    python3 lifecycle_metrics.py summary
    python3 lifecycle_metrics.py classification --days 30
    python3 lifecycle_metrics.py llm-usage --days 7
    python3 lifecycle_metrics.py pipeline
    python3 lifecycle_metrics.py export --format json
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from collections import defaultdict
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# Configuration
REGISTRY_PATH = Path("/home/zaks/DataRoom/.deal-registry/deal_registry.json")
EVENTS_DIR = Path("/home/zaks/DataRoom/.deal-registry/events")
QUARANTINE_PATH = Path("/home/zaks/DataRoom/.deal-registry/quarantine.json")
RUN_LEDGER_PATH = Path("/home/zaks/logs/run-ledger.jsonl")
METRICS_DIR = Path("/home/zaks/DataRoom/.deal-registry/metrics")
DEFERRED_ACTIONS_PATH = Path("/home/zaks/DataRoom/.deal-registry/deferred_actions.json")

# Ensure directories exist
METRICS_DIR.mkdir(parents=True, exist_ok=True)


@dataclass
class ClassificationMetrics:
    """Classification and quarantine metrics"""
    period_start: str
    period_end: str
    total_emails_processed: int = 0
    emails_matched: int = 0
    emails_quarantined: int = 0
    quarantine_rate: float = 0.0
    # Resolution outcomes
    quarantine_resolved_to_deal: int = 0
    quarantine_resolved_discard: int = 0
    quarantine_pending: int = 0
    resolution_accuracy: float = 0.0  # % resolved to deal (not discarded)
    # Confidence distribution
    high_confidence_matches: int = 0  # >= 0.9
    medium_confidence_matches: int = 0  # 0.7-0.9
    low_confidence_matches: int = 0  # < 0.7
    avg_match_confidence: float = 0.0
    # By match type
    matches_by_type: Dict[str, int] = field(default_factory=dict)


@dataclass
class LLMUsageMetrics:
    """LLM usage tracking"""
    period_start: str
    period_end: str
    total_invocations: int = 0
    local_invocations: int = 0
    cloud_invocations: int = 0
    local_ratio: float = 0.0
    # Token counts
    total_input_tokens: int = 0
    total_output_tokens: int = 0
    avg_tokens_per_call: float = 0.0
    # By task type
    invocations_by_task: Dict[str, int] = field(default_factory=dict)
    # Errors
    total_errors: int = 0
    error_rate: float = 0.0
    fallback_count: int = 0  # Cloud failed, fell back to local


@dataclass
class PipelineMetrics:
    """Pipeline health metrics"""
    timestamp: str
    total_deals: int = 0
    active_deals: int = 0
    junk_deals: int = 0
    merged_deals: int = 0
    archived_deals: int = 0
    # By stage
    deals_by_stage: Dict[str, int] = field(default_factory=dict)
    # Stage health
    avg_days_in_stage: Dict[str, float] = field(default_factory=dict)
    stuck_deals: List[Dict[str, Any]] = field(default_factory=list)  # Deals in stage > threshold
    # Conversion
    stage_conversion_rates: Dict[str, float] = field(default_factory=dict)


@dataclass
class ActionMetrics:
    """Deferred action execution metrics"""
    period_start: str
    period_end: str
    total_actions: int = 0
    executed_actions: int = 0
    failed_actions: int = 0
    cancelled_actions: int = 0
    pending_actions: int = 0
    overdue_actions: int = 0
    success_rate: float = 0.0
    # By type
    actions_by_type: Dict[str, Dict[str, int]] = field(default_factory=dict)
    avg_execution_time_ms: float = 0.0


class MetricsCollector:
    """
    Collects and aggregates system metrics for evaluation and optimization.
    """

    # Stage thresholds for "stuck" detection (days)
    STAGE_THRESHOLDS = {
        "inbound": 14,
        "screening": 21,
        "qualified": 30,
        "loi": 45,
        "diligence": 90,
        "closing": 60,
        "integration": 90,
        "operations": 365,  # Annual review
        "growth": 365,
        "exit_planning": 180,
    }

    def __init__(self):
        self.registry = self._load_registry()
        self.quarantine = self._load_quarantine()

    def _load_registry(self) -> Dict[str, Any]:
        """Load deal registry"""
        if REGISTRY_PATH.exists():
            with open(REGISTRY_PATH) as f:
                return json.load(f)
        return {"deals": {}}

    def _load_quarantine(self) -> List[Dict[str, Any]]:
        """Load quarantine items"""
        if QUARANTINE_PATH.exists():
            with open(QUARANTINE_PATH) as f:
                data = json.load(f)
                return data.get("items", []) if isinstance(data, dict) else data
        return []

    def _load_run_ledger(self, since: Optional[datetime] = None) -> List[Dict[str, Any]]:
        """Load run ledger entries"""
        entries = []
        if RUN_LEDGER_PATH.exists():
            with open(RUN_LEDGER_PATH) as f:
                for line in f:
                    line = line.strip()
                    if line:
                        try:
                            entry = json.loads(line)
                            if since:
                                ts_str = entry.get("timestamp", "")
                                if ts_str:
                                    ts = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
                                    if ts < since:
                                        continue
                            entries.append(entry)
                        except (json.JSONDecodeError, ValueError):
                            continue
        return entries

    def _load_events(self, since: Optional[datetime] = None) -> List[Dict[str, Any]]:
        """Load all events from event store"""
        events = []
        if EVENTS_DIR.exists():
            for event_file in EVENTS_DIR.glob("*.jsonl"):
                with open(event_file) as f:
                    for line in f:
                        line = line.strip()
                        if line:
                            try:
                                event = json.loads(line)
                                if since:
                                    ts_str = event.get("timestamp", "")
                                    if ts_str:
                                        ts = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
                                        if ts < since:
                                            continue
                                events.append(event)
                            except (json.JSONDecodeError, ValueError):
                                continue
        return events

    def _load_deferred_actions(self) -> List[Dict[str, Any]]:
        """Load deferred actions"""
        if DEFERRED_ACTIONS_PATH.exists():
            with open(DEFERRED_ACTIONS_PATH) as f:
                data = json.load(f)
                actions = data.get("actions", {})
                # Handle both dict and list formats
                if isinstance(actions, dict):
                    return list(actions.values())
                return actions
        return []

    def collect_classification_metrics(self, days: int = 30) -> ClassificationMetrics:
        """
        Collect classification and quarantine metrics.

        Args:
            days: Number of days to analyze

        Returns:
            ClassificationMetrics with aggregated data
        """
        since = datetime.now(timezone.utc) - timedelta(days=days)

        metrics = ClassificationMetrics(
            period_start=since.isoformat(),
            period_end=datetime.now(timezone.utc).isoformat()
        )

        # Analyze events for email processing
        events = self._load_events(since)
        email_events = [e for e in events if e.get("event_type") == "email_received"]

        metrics.total_emails_processed = len(email_events)

        # Analyze confidence levels
        confidences = []
        for event in email_events:
            conf = event.get("data", {}).get("match_confidence") or event.get("match_confidence", 0)
            if conf:
                confidences.append(float(conf))
                if conf >= 0.9:
                    metrics.high_confidence_matches += 1
                elif conf >= 0.7:
                    metrics.medium_confidence_matches += 1
                else:
                    metrics.low_confidence_matches += 1

            match_type = event.get("data", {}).get("match_type") or event.get("match_type", "unknown")
            metrics.matches_by_type[match_type] = metrics.matches_by_type.get(match_type, 0) + 1

        metrics.emails_matched = len(email_events)

        if confidences:
            metrics.avg_match_confidence = round(sum(confidences) / len(confidences), 3)

        # Analyze quarantine
        quarantine_events = [e for e in events if e.get("event_type") == "quarantine_added"]
        metrics.emails_quarantined = len(quarantine_events)

        # Current quarantine status
        for item in self.quarantine:
            status = item.get("status", "pending")
            if status == "pending":
                metrics.quarantine_pending += 1
            elif status == "resolved":
                resolution = item.get("resolution", {})
                if resolution.get("action") == "link_to_deal":
                    metrics.quarantine_resolved_to_deal += 1
                else:
                    metrics.quarantine_resolved_discard += 1

        # Calculate rates
        total_processed = metrics.emails_matched + metrics.emails_quarantined
        if total_processed > 0:
            metrics.quarantine_rate = round(metrics.emails_quarantined / total_processed, 3)

        total_resolved = metrics.quarantine_resolved_to_deal + metrics.quarantine_resolved_discard
        if total_resolved > 0:
            metrics.resolution_accuracy = round(metrics.quarantine_resolved_to_deal / total_resolved, 3)

        return metrics

    def collect_llm_usage_metrics(self, days: int = 7) -> LLMUsageMetrics:
        """
        Collect LLM usage metrics from run ledger.

        Args:
            days: Number of days to analyze

        Returns:
            LLMUsageMetrics with aggregated data
        """
        since = datetime.now(timezone.utc) - timedelta(days=days)

        metrics = LLMUsageMetrics(
            period_start=since.isoformat(),
            period_end=datetime.now(timezone.utc).isoformat()
        )

        # Analyze run ledger for LLM invocations
        ledger = self._load_run_ledger(since)

        for entry in ledger:
            # Look for LLM-related entries
            agent = entry.get("agent", "")
            result = entry.get("result", {})

            # Check if this was an LLM invocation
            if "llm" in agent.lower() or result.get("provider"):
                metrics.total_invocations += 1

                provider = result.get("provider", "local")
                if provider == "local" or "vllm" in provider.lower():
                    metrics.local_invocations += 1
                else:
                    metrics.cloud_invocations += 1

                # Token counts
                metrics.total_input_tokens += result.get("input_tokens", 0)
                metrics.total_output_tokens += result.get("output_tokens", 0)

                # Task type
                task = result.get("task_type") or entry.get("operation", "unknown")
                metrics.invocations_by_task[task] = metrics.invocations_by_task.get(task, 0) + 1

                # Errors
                if result.get("error") or not result.get("success", True):
                    metrics.total_errors += 1

                if result.get("fallback"):
                    metrics.fallback_count += 1

            # Also count agent invocations that use LLM
            if agent in ["underwriter", "case_manager", "diligence_coordinator", "exit_strategist", "portfolio_operator"]:
                if result.get("llm_used"):
                    metrics.total_invocations += 1
                    task = entry.get("operation", agent)
                    metrics.invocations_by_task[task] = metrics.invocations_by_task.get(task, 0) + 1

        # Calculate rates
        if metrics.total_invocations > 0:
            metrics.local_ratio = round(metrics.local_invocations / metrics.total_invocations, 3)
            total_tokens = metrics.total_input_tokens + metrics.total_output_tokens
            metrics.avg_tokens_per_call = round(total_tokens / metrics.total_invocations, 1)
            metrics.error_rate = round(metrics.total_errors / metrics.total_invocations, 3)

        return metrics

    def collect_pipeline_metrics(self) -> PipelineMetrics:
        """
        Collect pipeline health metrics.

        Returns:
            PipelineMetrics with current pipeline state
        """
        metrics = PipelineMetrics(
            timestamp=datetime.now(timezone.utc).isoformat()
        )

        deals = self.registry.get("deals", {})
        now = datetime.now(timezone.utc)

        # Count by status
        for deal_id, deal in deals.items():
            metrics.total_deals += 1
            status = deal.get("status", "active")

            if status == "active":
                metrics.active_deals += 1
            elif status == "junk":
                metrics.junk_deals += 1
            elif status == "merged":
                metrics.merged_deals += 1
            elif status in ["archived", "archive"]:
                metrics.archived_deals += 1

            # Count by stage (active deals only)
            if status == "active":
                stage = deal.get("stage", "unknown").lower()
                metrics.deals_by_stage[stage] = metrics.deals_by_stage.get(stage, 0) + 1

                # Check for stuck deals
                updated_at = deal.get("updated_at")
                if updated_at:
                    try:
                        last_update = datetime.fromisoformat(updated_at.replace("Z", "+00:00"))
                        days_in_stage = (now - last_update).days
                        threshold = self.STAGE_THRESHOLDS.get(stage, 30)

                        if days_in_stage > threshold:
                            metrics.stuck_deals.append({
                                "deal_id": deal_id,
                                "stage": stage,
                                "days_in_stage": days_in_stage,
                                "threshold": threshold,
                                "company": deal.get("canonical_name", deal_id)
                            })
                    except (ValueError, TypeError):
                        pass

        # Calculate stage conversion rates from events
        events = self._load_events()
        stage_transitions = defaultdict(lambda: {"entered": 0, "exited_forward": 0})

        for event in events:
            if event.get("event_type") == "stage_changed":
                data = event.get("data", {})
                from_stage = data.get("from_stage", "").lower()
                to_stage = data.get("to_stage", "").lower()

                if from_stage:
                    stage_transitions[from_stage]["exited_forward"] += 1
                if to_stage:
                    stage_transitions[to_stage]["entered"] += 1

        for stage, counts in stage_transitions.items():
            if counts["entered"] > 0:
                rate = counts["exited_forward"] / counts["entered"]
                metrics.stage_conversion_rates[stage] = round(rate, 3)

        # Sort stuck deals by days_in_stage
        metrics.stuck_deals.sort(key=lambda x: x["days_in_stage"], reverse=True)

        return metrics

    def collect_action_metrics(self, days: int = 30) -> ActionMetrics:
        """
        Collect deferred action execution metrics.

        Args:
            days: Number of days to analyze

        Returns:
            ActionMetrics with aggregated data
        """
        since = datetime.now(timezone.utc) - timedelta(days=days)
        now = datetime.now(timezone.utc)

        metrics = ActionMetrics(
            period_start=since.isoformat(),
            period_end=now.isoformat()
        )

        actions = self._load_deferred_actions()

        for action in actions:
            metrics.total_actions += 1
            status = action.get("status", "pending")
            action_type = action.get("action_type", "unknown")

            # Initialize type tracking
            if action_type not in metrics.actions_by_type:
                metrics.actions_by_type[action_type] = {
                    "total": 0, "executed": 0, "failed": 0, "pending": 0
                }
            metrics.actions_by_type[action_type]["total"] += 1

            if status == "executed":
                metrics.executed_actions += 1
                metrics.actions_by_type[action_type]["executed"] += 1
            elif status == "failed":
                metrics.failed_actions += 1
                metrics.actions_by_type[action_type]["failed"] += 1
            elif status == "cancelled":
                metrics.cancelled_actions += 1
            elif status == "pending":
                metrics.pending_actions += 1
                metrics.actions_by_type[action_type]["pending"] += 1

                # Check if overdue
                scheduled = action.get("scheduled_for")
                if scheduled:
                    try:
                        sched_dt = datetime.fromisoformat(scheduled.replace("Z", "+00:00"))
                        if sched_dt < now:
                            metrics.overdue_actions += 1
                    except (ValueError, TypeError):
                        pass

        # Calculate success rate
        completed = metrics.executed_actions + metrics.failed_actions
        if completed > 0:
            metrics.success_rate = round(metrics.executed_actions / completed, 3)

        return metrics

    def collect_all_metrics(self, days: int = 30) -> Dict[str, Any]:
        """
        Collect all metrics into a single summary.

        Args:
            days: Number of days for time-based metrics

        Returns:
            Dict containing all metric categories
        """
        return {
            "collected_at": datetime.now(timezone.utc).isoformat(),
            "period_days": days,
            "classification": asdict(self.collect_classification_metrics(days)),
            "llm_usage": asdict(self.collect_llm_usage_metrics(min(days, 7))),
            "pipeline": asdict(self.collect_pipeline_metrics()),
            "actions": asdict(self.collect_action_metrics(days))
        }

    def save_metrics_snapshot(self, metrics: Dict[str, Any]) -> Path:
        """Save metrics snapshot to file"""
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        filepath = METRICS_DIR / f"metrics_{timestamp}.json"
        with open(filepath, "w") as f:
            json.dump(metrics, f, indent=2)
        return filepath

    def get_summary_report(self, days: int = 30) -> str:
        """
        Generate a human-readable summary report.

        Args:
            days: Number of days for time-based metrics

        Returns:
            Formatted summary string
        """
        classification = self.collect_classification_metrics(days)
        llm = self.collect_llm_usage_metrics(min(days, 7))
        pipeline = self.collect_pipeline_metrics()
        actions = self.collect_action_metrics(days)

        lines = [
            "=" * 60,
            "ZAKOPS LIFECYCLE METRICS SUMMARY",
            "=" * 60,
            f"Report Generated: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}",
            f"Analysis Period: Last {days} days",
            "",
            "--- PIPELINE HEALTH ---",
            f"Total Deals: {pipeline.total_deals}",
            f"  Active: {pipeline.active_deals}",
            f"  Junk: {pipeline.junk_deals}",
            f"  Merged: {pipeline.merged_deals}",
            f"  Archived: {pipeline.archived_deals}",
            "",
            "Deals by Stage:",
        ]

        for stage, count in sorted(pipeline.deals_by_stage.items()):
            lines.append(f"  {stage}: {count}")

        if pipeline.stuck_deals:
            lines.append("")
            lines.append(f"STUCK DEALS ({len(pipeline.stuck_deals)}):")
            for deal in pipeline.stuck_deals[:5]:
                lines.append(f"  - {deal['company']} ({deal['stage']}): {deal['days_in_stage']} days")
            if len(pipeline.stuck_deals) > 5:
                lines.append(f"  ... and {len(pipeline.stuck_deals) - 5} more")

        lines.extend([
            "",
            "--- CLASSIFICATION METRICS ---",
            f"Emails Processed: {classification.total_emails_processed}",
            f"Quarantine Rate: {classification.quarantine_rate * 100:.1f}%",
            f"Avg Match Confidence: {classification.avg_match_confidence:.2f}",
            f"High Confidence (>=0.9): {classification.high_confidence_matches}",
            f"Medium Confidence (0.7-0.9): {classification.medium_confidence_matches}",
            f"Low Confidence (<0.7): {classification.low_confidence_matches}",
            "",
            "Quarantine Status:",
            f"  Pending: {classification.quarantine_pending}",
            f"  Resolved to Deal: {classification.quarantine_resolved_to_deal}",
            f"  Discarded: {classification.quarantine_resolved_discard}",
            f"  Resolution Accuracy: {classification.resolution_accuracy * 100:.1f}%",
        ])

        lines.extend([
            "",
            "--- LLM USAGE (Last 7 Days) ---",
            f"Total Invocations: {llm.total_invocations}",
            f"  Local: {llm.local_invocations} ({llm.local_ratio * 100:.1f}%)",
            f"  Cloud: {llm.cloud_invocations}",
            f"Total Tokens: {llm.total_input_tokens + llm.total_output_tokens:,}",
            f"Avg Tokens/Call: {llm.avg_tokens_per_call:.0f}",
            f"Error Rate: {llm.error_rate * 100:.1f}%",
            f"Fallbacks: {llm.fallback_count}",
        ])

        lines.extend([
            "",
            "--- DEFERRED ACTIONS ---",
            f"Total Actions: {actions.total_actions}",
            f"  Executed: {actions.executed_actions}",
            f"  Failed: {actions.failed_actions}",
            f"  Pending: {actions.pending_actions}",
            f"  Overdue: {actions.overdue_actions}",
            f"Success Rate: {actions.success_rate * 100:.1f}%",
            "",
            "=" * 60,
        ])

        return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="Lifecycle Metrics Collector")
    subparsers = parser.add_subparsers(dest="command", help="Commands")

    # summary
    summary_parser = subparsers.add_parser("summary", help="Show summary report")
    summary_parser.add_argument("--days", type=int, default=30, help="Analysis period in days")

    # classification
    class_parser = subparsers.add_parser("classification", help="Classification metrics")
    class_parser.add_argument("--days", type=int, default=30, help="Analysis period in days")

    # llm-usage
    llm_parser = subparsers.add_parser("llm-usage", help="LLM usage metrics")
    llm_parser.add_argument("--days", type=int, default=7, help="Analysis period in days")

    # pipeline
    pipeline_parser = subparsers.add_parser("pipeline", help="Pipeline health metrics")

    # actions
    actions_parser = subparsers.add_parser("actions", help="Action execution metrics")
    actions_parser.add_argument("--days", type=int, default=30, help="Analysis period in days")

    # export
    export_parser = subparsers.add_parser("export", help="Export all metrics")
    export_parser.add_argument("--days", type=int, default=30, help="Analysis period in days")
    export_parser.add_argument("--format", choices=["json", "text"], default="json", help="Output format")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return

    collector = MetricsCollector()

    if args.command == "summary":
        print(collector.get_summary_report(args.days))

    elif args.command == "classification":
        metrics = collector.collect_classification_metrics(args.days)
        print(json.dumps(asdict(metrics), indent=2))

    elif args.command == "llm-usage":
        metrics = collector.collect_llm_usage_metrics(args.days)
        print(json.dumps(asdict(metrics), indent=2))

    elif args.command == "pipeline":
        metrics = collector.collect_pipeline_metrics()
        print(json.dumps(asdict(metrics), indent=2))

    elif args.command == "actions":
        metrics = collector.collect_action_metrics(args.days)
        print(json.dumps(asdict(metrics), indent=2))

    elif args.command == "export":
        metrics = collector.collect_all_metrics(args.days)
        if args.format == "json":
            filepath = collector.save_metrics_snapshot(metrics)
            print(f"Metrics exported to: {filepath}")
            print(json.dumps(metrics, indent=2))
        else:
            print(collector.get_summary_report(args.days))


if __name__ == "__main__":
    main()
