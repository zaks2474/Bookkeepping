#!/usr/bin/env python3
"""
Compare two deals side-by-side

Usage:
  ./compare_deals.py "TeamLogic-IT-MSP-2025" "NIN-IT-Services-2025"
"""

import sys
import os
import requests
import json
import argparse
from typing import Dict, List, Optional

RAG_QUERY_URL = os.getenv("RAG_QUERY_URL", "http://localhost:8052/rag/query")

COMPARISON_ASPECTS = [
    "Sector/Industry",
    "Annual Revenue",
    "EBITDA/Profit",
    "Location",
    "Customer Count",
    "Employee Count",
    "Growth Rate",
    "Customer Retention",
    "Key Strengths",
    "Key Risks",
]


def query_deal_info(deal_name: str, aspect: str) -> str:
    """Query RAG for specific deal information."""
    query = f"What is the {aspect} for {deal_name}?"

    payload = {
        "query": query,
        "match_count": 5,
        "source": "dataroom.local",
    }

    try:
        response = requests.post(RAG_QUERY_URL, json=payload, timeout=30)
        if response.status_code == 200:
            results = response.json().get("results", [])
            if results:
                # Extract relevant snippet
                content = results[0].get("content", "")
                # Return first 200 chars
                return content[:200].strip() or "N/A"
    except Exception as e:
        pass

    return "N/A"


def get_deal_summary(deal_name: str) -> Dict[str, str]:
    """Get summary info for a deal."""
    info = {}
    for aspect in COMPARISON_ASPECTS:
        info[aspect] = query_deal_info(deal_name, aspect)
    return info


def compare_deals(deal1: str, deal2: str, verbose: bool = False):
    """Compare two deals side by side."""
    print(f"\n{'='*90}")
    print(f"Deal Comparison: {deal1} vs {deal2}")
    print(f"{'='*90}\n")

    print("Gathering information...")

    # Get info for both deals
    info1 = get_deal_summary(deal1)
    info2 = get_deal_summary(deal2)

    # Display comparison table
    col_width = 35

    print(f"\n{'Aspect':<20} {deal1[:col_width]:<{col_width}} {deal2[:col_width]:<{col_width}}")
    print("-" * 90)

    for aspect in COMPARISON_ASPECTS:
        val1 = info1.get(aspect, "N/A")[:col_width]
        val2 = info2.get(aspect, "N/A")[:col_width]
        print(f"{aspect:<20} {val1:<{col_width}} {val2:<{col_width}}")

    print("-" * 90)

    # Try to determine recommendation
    print(f"\n{'='*90}")

    # Count N/A values as a data quality indicator
    na_count1 = sum(1 for v in info1.values() if v == "N/A")
    na_count2 = sum(1 for v in info2.values() if v == "N/A")

    if na_count1 < na_count2:
        print(f"Data Quality: {deal1} has more complete information ({len(COMPARISON_ASPECTS) - na_count1}/{len(COMPARISON_ASPECTS)} fields)")
    elif na_count2 < na_count1:
        print(f"Data Quality: {deal2} has more complete information ({len(COMPARISON_ASPECTS) - na_count2}/{len(COMPARISON_ASPECTS)} fields)")
    else:
        print(f"Data Quality: Both deals have similar data completeness")

    print(f"\n{'='*90}")
    print("\nNote: For detailed analysis, use score_deal.py on each deal individually.")
    print("      The scores can then be compared directly.\n")


def main():
    parser = argparse.ArgumentParser(description="Compare two deals side-by-side")
    parser.add_argument("deal1", help="First deal folder name")
    parser.add_argument("deal2", help="Second deal folder name")
    parser.add_argument("-v", "--verbose", action="store_true", help="Show more details")

    args = parser.parse_args()

    compare_deals(args.deal1, args.deal2, args.verbose)


if __name__ == "__main__":
    main()
