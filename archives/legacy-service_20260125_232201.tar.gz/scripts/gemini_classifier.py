#!/usr/bin/env python3
"""
Gemini classifier (optional).

This is intentionally gated behind explicit opt-in env vars because it can send
deal/email content to a cloud provider.

Required env vars to enable usage:
- CLASSIFICATION_ENABLE_CLOUD=true
- GEMINI_API_KEY=${GEMINI_API_KEY}

Recommended additional safety gate:
- GEMINI_ALLOW_CONTENT_UPLOAD=true
"""

from __future__ import annotations

import json
import os
from typing import Any, Dict, Sequence

try:
    import requests  # type: ignore
except Exception:  # pragma: no cover
    requests = None  # type: ignore


def _coerce_bool(value: str) -> bool:
    return value.strip().lower() in {"1", "true", "yes", "y", "on"}


class GeminiClassifier:
    def __init__(self) -> None:
        self.api_key = os.getenv("GEMINI_API_KEY", "").strip()
        self.model = os.getenv("GEMINI_CLASSIFICATION_MODEL", "gemini-1.5-pro").strip()

        # Explicit content-upload gate (separate from enablement).
        self.allow_upload = _coerce_bool(os.getenv("GEMINI_ALLOW_CONTENT_UPLOAD", "false"))

    def classify_one_of(self, *, text: str, labels: Sequence[str], context: str = "") -> Dict[str, Any]:
        if not self.api_key:
            raise RuntimeError("gemini_api_key_missing")
        if not self.allow_upload:
            raise RuntimeError("gemini_content_upload_not_allowed")
        if requests is None:
            raise RuntimeError("requests_not_available")

        # Note: This endpoint may change across Gemini API versions; keep it minimal and documented.
        endpoint = f"https://generativelanguage.googleapis.com/v1beta/models/{self.model}:generateContent?key={self.api_key}"
        labels_rendered = "\n".join([f"- {l}" for l in labels])

        prompt = (
            "You are a strict classifier.\n"
            "Return ONLY valid JSON (no markdown) matching this schema:\n"
            "{\n"
            '  "label": "<one of the provided labels>",\n'
            '  "confidence": <number 0.0-1.0>,\n'
            '  "reason": "<short>",\n'
            '  "alternatives": [{"label":"...","confidence":0.0}]\n'
            "}\n"
            "Labels:\n"
            f"{labels_rendered}\n\n"
            f"Context (optional): {context.strip()}\n\n"
            "Text to classify:\n"
            f"{text}\n"
        )

        payload = {
            "contents": [{"parts": [{"text": prompt}]}],
            "generationConfig": {"temperature": 0.0, "maxOutputTokens": 300},
        }
        res = requests.post(endpoint, json=payload, timeout=45)
        res.raise_for_status()
        data = res.json()

        # Extract text response.
        candidates = data.get("candidates") or []
        content = ""
        if candidates:
            parts = ((candidates[0].get("content") or {}).get("parts") or [])
            if parts:
                content = parts[0].get("text") or ""
        content = (content or "").strip()
        if not content:
            raise RuntimeError("gemini_empty_response")

        try:
            parsed = json.loads(content)
        except Exception as exc:
            raise RuntimeError(f"gemini_non_json_response: {type(exc).__name__}") from exc

        label = str(parsed.get("label", "")).strip()
        if label not in set(labels):
            raise RuntimeError("gemini_label_not_in_set")

        confidence = float(parsed.get("confidence", 0.0))
        return {
            "label": label,
            "confidence": max(0.0, min(1.0, confidence)),
            "reason": str(parsed.get("reason", "") or ""),
            "alternatives": list(parsed.get("alternatives", []) or [])[:5],
            "model": self.model,
        }


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit("This module is intended to be imported and used by HybridClassifier.")

