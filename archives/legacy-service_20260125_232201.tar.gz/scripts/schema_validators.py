#!/usr/bin/env python3
"""
Schema Validators for Deal Lifecycle Events and Actions

Validates payloads against YAML schema definitions.
Ensures all events and actions conform to contracts before persistence.

Usage:
    from schema_validators import EventValidator, ActionValidator, CaseFileValidator

    # Validate an event
    validator = EventValidator()
    result = validator.validate("email_received", {"from": "broker@example.com", "subject": "RE: Deal"})
    if not result.valid:
        print(f"Validation failed: {result.errors}")

    # Validate an action
    action_validator = ActionValidator()
    result = action_validator.validate("follow_up", {"follow_up_type": "materials"})

CLI:
    python3 schema_validators.py validate-event email_received '{"from": "test@test.com", "subject": "Test"}'
    python3 schema_validators.py validate-action follow_up '{"follow_up_type": "materials"}'
    python3 schema_validators.py list-event-types
    python3 schema_validators.py list-action-types
"""

from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

import yaml


# Default paths
SCHEMAS_DIR = Path(os.getenv(
    "DEAL_SCHEMAS_DIR",
    "/home/zaks/DataRoom/.deal-registry/schemas"
))
POLICY_DIR = Path(os.getenv(
    "DEAL_POLICY_DIR",
    "/home/zaks/DataRoom/.deal-registry/policy"
))


@dataclass
class ValidationResult:
    """Result of a validation operation"""
    valid: bool
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    normalized_data: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "valid": self.valid,
            "errors": self.errors,
            "warnings": self.warnings,
        }


class SchemaLoader:
    """Loads and caches YAML schemas"""

    _cache: Dict[str, Dict[str, Any]] = {}

    @classmethod
    def load(cls, schema_path: Path) -> Dict[str, Any]:
        """Load a YAML schema file with caching"""
        path_str = str(schema_path)
        if path_str not in cls._cache:
            if not schema_path.exists():
                raise FileNotFoundError(f"Schema file not found: {schema_path}")
            with open(schema_path, "r", encoding="utf-8") as f:
                cls._cache[path_str] = yaml.safe_load(f)
        return cls._cache[path_str]

    @classmethod
    def clear_cache(cls) -> None:
        """Clear the schema cache"""
        cls._cache.clear()


class BaseValidator:
    """Base class for schema validators"""

    def __init__(self, schema_path: Path):
        self.schema_path = schema_path
        self._schema: Optional[Dict[str, Any]] = None

    @property
    def schema(self) -> Dict[str, Any]:
        if self._schema is None:
            self._schema = SchemaLoader.load(self.schema_path)
        return self._schema

    def _validate_type(self, value: Any, expected_type: str, field_name: str) -> List[str]:
        """Validate a value against an expected type"""
        errors = []

        if expected_type == "string":
            if not isinstance(value, str):
                errors.append(f"{field_name}: expected string, got {type(value).__name__}")
        elif expected_type == "integer":
            if not isinstance(value, int) or isinstance(value, bool):
                errors.append(f"{field_name}: expected integer, got {type(value).__name__}")
        elif expected_type == "number":
            if not isinstance(value, (int, float)) or isinstance(value, bool):
                errors.append(f"{field_name}: expected number, got {type(value).__name__}")
        elif expected_type == "boolean":
            if not isinstance(value, bool):
                errors.append(f"{field_name}: expected boolean, got {type(value).__name__}")
        elif expected_type == "array":
            if not isinstance(value, list):
                errors.append(f"{field_name}: expected array, got {type(value).__name__}")
        elif expected_type == "object":
            if not isinstance(value, dict):
                errors.append(f"{field_name}: expected object, got {type(value).__name__}")

        return errors

    def _validate_format(self, value: str, format_type: str, field_name: str) -> List[str]:
        """Validate string format"""
        errors = []

        if format_type == "date-time":
            try:
                # Try parsing ISO format
                if value.endswith("Z"):
                    value = value[:-1] + "+00:00"
                datetime.fromisoformat(value)
            except ValueError:
                errors.append(f"{field_name}: invalid date-time format")

        elif format_type == "date":
            try:
                datetime.strptime(value, "%Y-%m-%d")
            except ValueError:
                errors.append(f"{field_name}: invalid date format (expected YYYY-MM-DD)")

        elif format_type == "email":
            if not re.match(r"^[^@]+@[^@]+\.[^@]+$", value):
                errors.append(f"{field_name}: invalid email format")

        return errors

    def _validate_pattern(self, value: str, pattern: str, field_name: str) -> List[str]:
        """Validate string against regex pattern"""
        errors = []
        if not re.match(pattern, value):
            errors.append(f"{field_name}: does not match pattern {pattern}")
        return errors

    def _validate_enum(self, value: Any, allowed: List[Any], field_name: str) -> List[str]:
        """Validate value is in allowed list"""
        errors = []
        if value not in allowed:
            errors.append(f"{field_name}: '{value}' not in allowed values {allowed}")
        return errors

    def _validate_constraints(
        self, value: Any, field_schema: Dict[str, Any], field_name: str
    ) -> List[str]:
        """Validate numeric/string constraints"""
        errors = []

        if "minimum" in field_schema and isinstance(value, (int, float)):
            if value < field_schema["minimum"]:
                errors.append(f"{field_name}: {value} is less than minimum {field_schema['minimum']}")

        if "maximum" in field_schema and isinstance(value, (int, float)):
            if value > field_schema["maximum"]:
                errors.append(f"{field_name}: {value} is greater than maximum {field_schema['maximum']}")

        if "max_length" in field_schema and isinstance(value, str):
            if len(value) > field_schema["max_length"]:
                errors.append(f"{field_name}: length {len(value)} exceeds max_length {field_schema['max_length']}")

        return errors


class EventValidator(BaseValidator):
    """Validates deal lifecycle events against schema"""

    def __init__(self, schema_path: Optional[Path] = None):
        super().__init__(schema_path or SCHEMAS_DIR / "event_schemas.yaml")

    def get_event_types(self) -> List[str]:
        """Get list of valid event types"""
        return list(self.schema.get("event_schemas", {}).keys())

    def get_event_schema(self, event_type: str) -> Optional[Dict[str, Any]]:
        """Get schema for a specific event type"""
        return self.schema.get("event_schemas", {}).get(event_type)

    def validate(self, event_type: str, data: Dict[str, Any]) -> ValidationResult:
        """
        Validate event data against schema.

        Args:
            event_type: Type of event (e.g., "email_received")
            data: Event data payload (the 'data' field of the event)

        Returns:
            ValidationResult with valid flag and any errors/warnings
        """
        errors: List[str] = []
        warnings: List[str] = []

        # Check event type exists
        event_schema = self.get_event_schema(event_type)
        if not event_schema:
            valid_types = self.get_event_types()
            return ValidationResult(
                valid=False,
                errors=[f"Unknown event type: '{event_type}'. Valid types: {valid_types}"]
            )

        # Check required fields
        required = event_schema.get("required", [])
        for req_field in required:
            if req_field not in data:
                errors.append(f"Missing required field: {req_field}")

        # Check optional fields are known
        optional = event_schema.get("optional", [])
        all_fields = set(required) | set(optional)
        fields_schema = event_schema.get("fields", {})

        for field_name, value in data.items():
            if field_name not in all_fields and field_name not in fields_schema:
                warnings.append(f"Unknown field: {field_name}")
                continue

            # Validate field if schema exists
            field_schema = fields_schema.get(field_name, {})
            if field_schema:
                # Type validation
                if "type" in field_schema:
                    errors.extend(self._validate_type(value, field_schema["type"], field_name))

                # Format validation
                if "format" in field_schema and isinstance(value, str):
                    errors.extend(self._validate_format(value, field_schema["format"], field_name))

                # Pattern validation
                if "pattern" in field_schema and isinstance(value, str):
                    errors.extend(self._validate_pattern(value, field_schema["pattern"], field_name))

                # Enum validation
                if "enum" in field_schema:
                    errors.extend(self._validate_enum(value, field_schema["enum"], field_name))

                # Constraint validation
                errors.extend(self._validate_constraints(value, field_schema, field_name))

        return ValidationResult(
            valid=len(errors) == 0,
            errors=errors,
            warnings=warnings,
            normalized_data=data
        )


class ActionValidator(BaseValidator):
    """Validates deferred actions against schema"""

    def __init__(self, schema_path: Optional[Path] = None):
        super().__init__(schema_path or SCHEMAS_DIR / "action_schemas.yaml")

    def get_action_types(self) -> List[str]:
        """Get list of valid action types"""
        return list(self.schema.get("action_schemas", {}).keys())

    def get_action_schema(self, action_type: str) -> Optional[Dict[str, Any]]:
        """Get schema for a specific action type"""
        return self.schema.get("action_schemas", {}).get(action_type)

    def validate(self, action_type: str, data: Dict[str, Any]) -> ValidationResult:
        """
        Validate action data against schema.

        Args:
            action_type: Type of action (e.g., "follow_up")
            data: Action data payload

        Returns:
            ValidationResult with valid flag and any errors/warnings
        """
        errors: List[str] = []
        warnings: List[str] = []

        # Check action type exists
        action_schema = self.get_action_schema(action_type)
        if not action_schema:
            valid_types = self.get_action_types()
            return ValidationResult(
                valid=False,
                errors=[f"Unknown action type: '{action_type}'. Valid types: {valid_types}"]
            )

        # Check required fields
        required = action_schema.get("required", [])
        for req_field in required:
            if req_field not in data:
                errors.append(f"Missing required field: {req_field}")

        # Check optional fields are known
        optional = action_schema.get("optional", [])
        all_fields = set(required) | set(optional)
        fields_schema = action_schema.get("fields", {})

        for field_name, value in data.items():
            if field_name not in all_fields and field_name not in fields_schema:
                warnings.append(f"Unknown field: {field_name}")
                continue

            # Validate field if schema exists
            field_schema = fields_schema.get(field_name, {})
            if field_schema:
                # Type validation
                if "type" in field_schema:
                    errors.extend(self._validate_type(value, field_schema["type"], field_name))

                # Format validation
                if "format" in field_schema and isinstance(value, str):
                    errors.extend(self._validate_format(value, field_schema["format"], field_name))

                # Enum validation
                if "enum" in field_schema:
                    errors.extend(self._validate_enum(value, field_schema["enum"], field_name))

                # Constraint validation
                errors.extend(self._validate_constraints(value, field_schema, field_name))

        return ValidationResult(
            valid=len(errors) == 0,
            errors=errors,
            warnings=warnings,
            normalized_data=data
        )


class CaseFileValidator(BaseValidator):
    """Validates case file projections against schema"""

    def __init__(self, schema_path: Optional[Path] = None):
        super().__init__(schema_path or SCHEMAS_DIR / "case_file_schema.yaml")

    def validate(self, case_file: Dict[str, Any]) -> ValidationResult:
        """
        Validate a case file against schema.

        Args:
            case_file: Case file data

        Returns:
            ValidationResult with valid flag and any errors/warnings
        """
        errors: List[str] = []
        warnings: List[str] = []

        schema = self.schema.get("case_file", {})

        # Check required fields
        for field_name, field_schema in schema.items():
            if isinstance(field_schema, dict) and field_schema.get("required"):
                if field_name not in case_file:
                    errors.append(f"Missing required field: {field_name}")

        # Validate present fields
        for field_name, value in case_file.items():
            field_schema = schema.get(field_name, {})
            if not isinstance(field_schema, dict):
                continue

            # Type validation
            if "type" in field_schema:
                errors.extend(self._validate_type(value, field_schema["type"], field_name))

            # Format validation
            if "format" in field_schema and isinstance(value, str):
                errors.extend(self._validate_format(value, field_schema["format"], field_name))

            # Constraint validation
            errors.extend(self._validate_constraints(value, field_schema, field_name))

        return ValidationResult(
            valid=len(errors) == 0,
            errors=errors,
            warnings=warnings,
            normalized_data=case_file
        )


class PolicyLoader:
    """Loads and provides access to stage policies"""

    def __init__(self, policy_path: Optional[Path] = None):
        self.policy_path = policy_path or POLICY_DIR / "stage_policies.yaml"
        self._policy: Optional[Dict[str, Any]] = None

    @property
    def policy(self) -> Dict[str, Any]:
        if self._policy is None:
            self._policy = SchemaLoader.load(self.policy_path)
        return self._policy

    def get_stage_policy(self, stage: str) -> Optional[Dict[str, Any]]:
        """Get policy for a specific stage"""
        stage_upper = stage.upper()
        return self.policy.get("stage_policies", {}).get(stage_upper)

    def get_stages(self) -> List[str]:
        """Get list of all stages"""
        return list(self.policy.get("stage_policies", {}).keys())

    def get_approval_required_stages(self) -> List[str]:
        """Get stages that require approval"""
        stages = []
        for stage, policy in self.policy.get("stage_policies", {}).items():
            if policy.get("requires_approval"):
                stages.append(stage)
        return stages

    def get_terminal_stages(self) -> List[str]:
        """Get terminal stages"""
        stages = []
        for stage, policy in self.policy.get("stage_policies", {}).items():
            if policy.get("terminal"):
                stages.append(stage)
        return stages

    def get_global_settings(self) -> Dict[str, Any]:
        """Get global policy settings"""
        return self.policy.get("global", {})

    def get_feature_flags(self) -> Dict[str, bool]:
        """Get feature flags"""
        return self.policy.get("feature_flags", {})

    def is_feature_enabled(self, flag_name: str) -> bool:
        """Check if a feature flag is enabled"""
        return self.get_feature_flags().get(flag_name, False)

    def get_document_triggers(self) -> Dict[str, Any]:
        """Get document trigger configurations"""
        return self.policy.get("document_triggers", {})


# Convenience functions
def validate_event(event_type: str, data: Dict[str, Any]) -> ValidationResult:
    """Validate an event payload"""
    return EventValidator().validate(event_type, data)


def validate_action(action_type: str, data: Dict[str, Any]) -> ValidationResult:
    """Validate an action payload"""
    return ActionValidator().validate(action_type, data)


def validate_case_file(case_file: Dict[str, Any]) -> ValidationResult:
    """Validate a case file"""
    return CaseFileValidator().validate(case_file)


def get_policy() -> PolicyLoader:
    """Get the policy loader"""
    return PolicyLoader()


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Schema Validators CLI")
    subparsers = parser.add_subparsers(dest="command")

    # Validate event
    validate_event_parser = subparsers.add_parser("validate-event", help="Validate an event")
    validate_event_parser.add_argument("event_type", help="Event type")
    validate_event_parser.add_argument("data", help="JSON data")

    # Validate action
    validate_action_parser = subparsers.add_parser("validate-action", help="Validate an action")
    validate_action_parser.add_argument("action_type", help="Action type")
    validate_action_parser.add_argument("data", help="JSON data")

    # List event types
    subparsers.add_parser("list-event-types", help="List valid event types")

    # List action types
    subparsers.add_parser("list-action-types", help="List valid action types")

    # List stages
    subparsers.add_parser("list-stages", help="List all stages")

    # Show stage policy
    show_stage_parser = subparsers.add_parser("show-stage", help="Show stage policy")
    show_stage_parser.add_argument("stage", help="Stage name")

    # Show feature flags
    subparsers.add_parser("show-flags", help="Show feature flags")

    args = parser.parse_args()

    if args.command == "validate-event":
        data = json.loads(args.data)
        result = validate_event(args.event_type, data)
        print(json.dumps(result.to_dict(), indent=2))
        raise SystemExit(0 if result.valid else 1)

    elif args.command == "validate-action":
        data = json.loads(args.data)
        result = validate_action(args.action_type, data)
        print(json.dumps(result.to_dict(), indent=2))
        raise SystemExit(0 if result.valid else 1)

    elif args.command == "list-event-types":
        validator = EventValidator()
        print("Valid event types:")
        for event_type in validator.get_event_types():
            schema = validator.get_event_schema(event_type)
            desc = schema.get("description", "")
            print(f"  {event_type}: {desc}")

    elif args.command == "list-action-types":
        validator = ActionValidator()
        print("Valid action types:")
        for action_type in validator.get_action_types():
            schema = validator.get_action_schema(action_type)
            desc = schema.get("description", "")
            print(f"  {action_type}: {desc}")

    elif args.command == "list-stages":
        policy = PolicyLoader()
        print("Stages:")
        for stage in policy.get_stages():
            stage_policy = policy.get_stage_policy(stage)
            approval = " (requires approval)" if stage_policy.get("requires_approval") else ""
            terminal = " [TERMINAL]" if stage_policy.get("terminal") else ""
            desc = stage_policy.get("description", "")
            print(f"  {stage}{approval}{terminal}")
            print(f"    {desc}")

    elif args.command == "show-stage":
        policy = PolicyLoader()
        stage_policy = policy.get_stage_policy(args.stage)
        if stage_policy:
            print(json.dumps(stage_policy, indent=2))
        else:
            print(f"Unknown stage: {args.stage}")
            raise SystemExit(1)

    elif args.command == "show-flags":
        policy = PolicyLoader()
        flags = policy.get_feature_flags()
        print("Feature flags:")
        for flag, enabled in flags.items():
            status = "ENABLED" if enabled else "disabled"
            print(f"  {flag}: {status}")

    else:
        parser.print_help()
