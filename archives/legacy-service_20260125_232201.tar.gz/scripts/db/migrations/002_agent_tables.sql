-- ============================================================================
-- Migration 002: Agent Thread/Run Tables
-- ZakOps Deal Lifecycle Engine - LangSmith Agent Builder Integration
-- ============================================================================

-- ============================================================================
-- AGENT THREADS
-- Conversation context for agent interactions (LangSmith thread model)
-- ============================================================================

CREATE TABLE IF NOT EXISTS zakops.agent_threads (
    thread_id VARCHAR(50) PRIMARY KEY,  -- UUID format

    -- Context
    deal_id VARCHAR(20) REFERENCES zakops.deals(deal_id) ON DELETE SET NULL,
    assistant_id VARCHAR(100) NOT NULL,  -- LangSmith assistant ID

    -- Status
    status VARCHAR(20) NOT NULL DEFAULT 'active',

    -- Metadata
    metadata JSONB NOT NULL DEFAULT '{}',

    -- User context
    user_id VARCHAR(100),
    user_context JSONB NOT NULL DEFAULT '{}',

    -- Message count (denormalized for queries)
    message_count INTEGER NOT NULL DEFAULT 0,

    -- Timestamps
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_active_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT valid_thread_status CHECK (status IN ('active', 'archived'))
);

-- ============================================================================
-- AGENT RUNS
-- Single execution within a thread (LangSmith run model)
-- ============================================================================

CREATE TABLE IF NOT EXISTS zakops.agent_runs (
    run_id VARCHAR(50) PRIMARY KEY,  -- UUID format
    thread_id VARCHAR(50) NOT NULL REFERENCES zakops.agent_threads(thread_id) ON DELETE CASCADE,
    assistant_id VARCHAR(100) NOT NULL,

    -- Status
    status VARCHAR(20) NOT NULL DEFAULT 'pending',

    -- Input/Output
    input_message TEXT,
    output_message TEXT,

    -- Timing
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    duration_ms INTEGER,

    -- Error handling
    error TEXT,
    error_code VARCHAR(50),

    -- Token usage
    input_tokens INTEGER,
    output_tokens INTEGER,
    total_tokens INTEGER,

    -- Metadata
    metadata JSONB NOT NULL DEFAULT '{}',

    -- SSE streaming state (for resume)
    last_event_id VARCHAR(100),
    stream_position INTEGER NOT NULL DEFAULT 0,

    -- Timestamps
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT valid_run_status CHECK (status IN ('pending', 'running', 'completed', 'failed', 'cancelled'))
);

-- ============================================================================
-- AGENT TOOL CALLS
-- Individual tool invocations within a run
-- ============================================================================

CREATE TABLE IF NOT EXISTS zakops.agent_tool_calls (
    tool_call_id VARCHAR(50) PRIMARY KEY,  -- UUID format
    run_id VARCHAR(50) NOT NULL REFERENCES zakops.agent_runs(run_id) ON DELETE CASCADE,

    -- Tool identification
    tool_name VARCHAR(100) NOT NULL,
    tool_input JSONB NOT NULL DEFAULT '{}',
    tool_output JSONB,

    -- Status
    status VARCHAR(20) NOT NULL DEFAULT 'pending',

    -- Risk & Approval
    risk_level VARCHAR(20) NOT NULL DEFAULT 'low',
    requires_approval BOOLEAN NOT NULL DEFAULT FALSE,
    approved_by VARCHAR(100),
    approved_at TIMESTAMPTZ,
    rejection_reason TEXT,

    -- Timing
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    duration_ms INTEGER,

    -- Error handling
    error TEXT,
    retry_count INTEGER NOT NULL DEFAULT 0,

    -- Linked action (if tool created a kinetic action)
    created_action_id VARCHAR(50) REFERENCES zakops.actions(action_id),

    -- Sequence within run
    sequence_number INTEGER NOT NULL DEFAULT 0,

    -- Timestamps
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT valid_tool_status CHECK (status IN ('pending', 'approved', 'rejected', 'running', 'completed', 'failed')),
    CONSTRAINT valid_tool_risk CHECK (risk_level IN ('low', 'medium', 'high', 'critical'))
);

-- ============================================================================
-- AGENT EVENTS
-- All events emitted during agent execution (for audit and replay)
-- ============================================================================

CREATE TABLE IF NOT EXISTS zakops.agent_events (
    id BIGSERIAL PRIMARY KEY,
    event_id VARCHAR(100) NOT NULL UNIQUE,  -- For SSE event ID (resume capability)

    -- Context
    thread_id VARCHAR(50) NOT NULL REFERENCES zakops.agent_threads(thread_id) ON DELETE CASCADE,
    run_id VARCHAR(50) NOT NULL REFERENCES zakops.agent_runs(run_id) ON DELETE CASCADE,
    tool_call_id VARCHAR(50) REFERENCES zakops.agent_tool_calls(tool_call_id) ON DELETE CASCADE,

    -- Event
    event_type VARCHAR(50) NOT NULL,
    event_data JSONB NOT NULL DEFAULT '{}',

    -- Sequence
    sequence_number INTEGER NOT NULL DEFAULT 0,

    -- Timestamp
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT valid_event_type CHECK (event_type IN (
        -- Run lifecycle
        'run_created', 'run_started', 'run_completed', 'run_failed', 'run_cancelled',
        -- Tool events
        'tool_call_started', 'tool_call_completed', 'tool_call_failed',
        'tool_approval_required', 'tool_approval_granted', 'tool_approval_denied',
        -- Streaming
        'stream_start', 'stream_token', 'stream_end', 'stream_error',
        -- Custom
        'custom'
    ))
);

-- ============================================================================
-- INDEXES
-- ============================================================================

-- Agent Threads
CREATE INDEX IF NOT EXISTS idx_agent_threads_deal ON zakops.agent_threads(deal_id);
CREATE INDEX IF NOT EXISTS idx_agent_threads_assistant ON zakops.agent_threads(assistant_id);
CREATE INDEX IF NOT EXISTS idx_agent_threads_status ON zakops.agent_threads(status);
CREATE INDEX IF NOT EXISTS idx_agent_threads_user ON zakops.agent_threads(user_id);
CREATE INDEX IF NOT EXISTS idx_agent_threads_active ON zakops.agent_threads(last_active_at DESC)
    WHERE status = 'active';

-- Agent Runs
CREATE INDEX IF NOT EXISTS idx_agent_runs_thread ON zakops.agent_runs(thread_id);
CREATE INDEX IF NOT EXISTS idx_agent_runs_status ON zakops.agent_runs(status);
CREATE INDEX IF NOT EXISTS idx_agent_runs_created ON zakops.agent_runs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_agent_runs_active ON zakops.agent_runs(thread_id, created_at DESC)
    WHERE status IN ('pending', 'running');

-- Agent Tool Calls
CREATE INDEX IF NOT EXISTS idx_agent_tool_calls_run ON zakops.agent_tool_calls(run_id);
CREATE INDEX IF NOT EXISTS idx_agent_tool_calls_status ON zakops.agent_tool_calls(status);
CREATE INDEX IF NOT EXISTS idx_agent_tool_calls_pending ON zakops.agent_tool_calls(run_id)
    WHERE status = 'pending' AND requires_approval = TRUE;
CREATE INDEX IF NOT EXISTS idx_agent_tool_calls_sequence ON zakops.agent_tool_calls(run_id, sequence_number);

-- Agent Events
CREATE INDEX IF NOT EXISTS idx_agent_events_thread ON zakops.agent_events(thread_id);
CREATE INDEX IF NOT EXISTS idx_agent_events_run ON zakops.agent_events(run_id);
CREATE INDEX IF NOT EXISTS idx_agent_events_type ON zakops.agent_events(event_type);
CREATE INDEX IF NOT EXISTS idx_agent_events_sequence ON zakops.agent_events(run_id, sequence_number);
CREATE INDEX IF NOT EXISTS idx_agent_events_created ON zakops.agent_events(created_at DESC);

-- ============================================================================
-- TRIGGERS
-- ============================================================================

-- Update timestamp triggers
CREATE TRIGGER IF NOT EXISTS tr_agent_threads_updated
    BEFORE UPDATE ON zakops.agent_threads
    FOR EACH ROW EXECUTE FUNCTION zakops.update_timestamp();

CREATE TRIGGER IF NOT EXISTS tr_agent_runs_updated
    BEFORE UPDATE ON zakops.agent_runs
    FOR EACH ROW EXECUTE FUNCTION zakops.update_timestamp();

CREATE TRIGGER IF NOT EXISTS tr_agent_tool_calls_updated
    BEFORE UPDATE ON zakops.agent_tool_calls
    FOR EACH ROW EXECUTE FUNCTION zakops.update_timestamp();

-- ============================================================================
-- FUNCTIONS
-- ============================================================================

-- Generate thread ID
CREATE OR REPLACE FUNCTION zakops.next_thread_id()
RETURNS VARCHAR(50) AS $$
BEGIN
    RETURN 'thread_' || REPLACE(uuid_generate_v4()::TEXT, '-', '');
END;
$$ LANGUAGE plpgsql;

-- Generate run ID
CREATE OR REPLACE FUNCTION zakops.next_run_id()
RETURNS VARCHAR(50) AS $$
BEGIN
    RETURN 'run_' || REPLACE(uuid_generate_v4()::TEXT, '-', '');
END;
$$ LANGUAGE plpgsql;

-- Generate tool call ID
CREATE OR REPLACE FUNCTION zakops.next_tool_call_id()
RETURNS VARCHAR(50) AS $$
BEGIN
    RETURN 'tc_' || REPLACE(uuid_generate_v4()::TEXT, '-', '');
END;
$$ LANGUAGE plpgsql;

-- Generate event ID (for SSE resume)
CREATE OR REPLACE FUNCTION zakops.next_event_id(p_run_id VARCHAR(50), p_seq INTEGER)
RETURNS VARCHAR(100) AS $$
BEGIN
    RETURN p_run_id || ':' || LPAD(p_seq::TEXT, 6, '0');
END;
$$ LANGUAGE plpgsql;

-- Record agent event with auto-sequencing
CREATE OR REPLACE FUNCTION zakops.record_agent_event(
    p_thread_id VARCHAR(50),
    p_run_id VARCHAR(50),
    p_event_type VARCHAR(50),
    p_event_data JSONB,
    p_tool_call_id VARCHAR(50) DEFAULT NULL
)
RETURNS VARCHAR(100) AS $$
DECLARE
    v_seq INTEGER;
    v_event_id VARCHAR(100);
BEGIN
    -- Get next sequence number for this run
    SELECT COALESCE(MAX(sequence_number), -1) + 1
    INTO v_seq
    FROM zakops.agent_events
    WHERE run_id = p_run_id;

    -- Generate event ID
    v_event_id := zakops.next_event_id(p_run_id, v_seq);

    -- Insert event
    INSERT INTO zakops.agent_events (
        event_id, thread_id, run_id, tool_call_id,
        event_type, event_data, sequence_number
    ) VALUES (
        v_event_id, p_thread_id, p_run_id, p_tool_call_id,
        p_event_type, p_event_data, v_seq
    );

    -- Update run's last_event_id and stream_position
    UPDATE zakops.agent_runs
    SET last_event_id = v_event_id, stream_position = v_seq
    WHERE run_id = p_run_id;

    RETURN v_event_id;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- VIEWS
-- ============================================================================

-- Active threads with recent activity
CREATE OR REPLACE VIEW zakops.v_active_threads AS
SELECT
    t.*,
    d.canonical_name AS deal_name,
    d.stage AS deal_stage,
    (SELECT COUNT(*) FROM zakops.agent_runs r WHERE r.thread_id = t.thread_id) AS run_count,
    (SELECT MAX(created_at) FROM zakops.agent_runs r WHERE r.thread_id = t.thread_id) AS last_run_at
FROM zakops.agent_threads t
LEFT JOIN zakops.deals d ON t.deal_id = d.deal_id
WHERE t.status = 'active'
ORDER BY t.last_active_at DESC;

-- Pending approvals view
CREATE OR REPLACE VIEW zakops.v_pending_tool_approvals AS
SELECT
    tc.*,
    r.thread_id,
    t.deal_id,
    d.canonical_name AS deal_name
FROM zakops.agent_tool_calls tc
JOIN zakops.agent_runs r ON tc.run_id = r.run_id
JOIN zakops.agent_threads t ON r.thread_id = t.thread_id
LEFT JOIN zakops.deals d ON t.deal_id = d.deal_id
WHERE tc.status = 'pending'
  AND tc.requires_approval = TRUE
ORDER BY tc.created_at;

-- Run history with stats
CREATE OR REPLACE VIEW zakops.v_run_history AS
SELECT
    r.*,
    t.deal_id,
    d.canonical_name AS deal_name,
    (SELECT COUNT(*) FROM zakops.agent_tool_calls tc WHERE tc.run_id = r.run_id) AS tool_call_count,
    (SELECT COUNT(*) FROM zakops.agent_tool_calls tc
     WHERE tc.run_id = r.run_id AND tc.status = 'completed') AS completed_tool_calls,
    (SELECT COUNT(*) FROM zakops.agent_events e WHERE e.run_id = r.run_id) AS event_count
FROM zakops.agent_runs r
JOIN zakops.agent_threads t ON r.thread_id = t.thread_id
LEFT JOIN zakops.deals d ON t.deal_id = d.deal_id
ORDER BY r.created_at DESC;

-- ============================================================================
-- MIGRATION COMPLETE
-- ============================================================================
