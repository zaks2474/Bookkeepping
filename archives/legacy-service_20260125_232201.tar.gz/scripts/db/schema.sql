-- ============================================================================
-- ZakOps Deal Lifecycle Engine - Unified PostgreSQL Schema
-- ============================================================================

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Create schemas
CREATE SCHEMA IF NOT EXISTS zakops;
CREATE SCHEMA IF NOT EXISTS zakops_rag;

-- ============================================================================
-- DEALS
-- ============================================================================

CREATE TABLE zakops.deals (
    deal_id VARCHAR(20) PRIMARY KEY,  -- DEAL-YYYY-NNN format
    canonical_name VARCHAR(255) NOT NULL,
    display_name VARCHAR(255),
    folder_path VARCHAR(500),

    -- Stage & Status
    stage VARCHAR(50) NOT NULL DEFAULT 'inbound',
    status VARCHAR(50) NOT NULL DEFAULT 'active',

    -- Identifiers (JSONB for flexibility)
    identifiers JSONB NOT NULL DEFAULT '{
        "listing_ids": [],
        "broker_reference_ids": [],
        "bizbuysell_id": null,
        "axial_id": null,
        "internal_codes": []
    }'::jsonb,

    -- Company Info
    company_info JSONB NOT NULL DEFAULT '{
        "company_name": null,
        "legal_entity": null,
        "dba_names": [],
        "location": null,
        "sector": null,
        "franchise_system": null
    }'::jsonb,

    -- Broker Info
    broker JSONB NOT NULL DEFAULT '{
        "broker_id": null,
        "name": null,
        "email": null,
        "phone": null,
        "company": null,
        "quality_rating": "MEDIUM",
        "sectors": [],
        "domain": null
    }'::jsonb,

    -- Metadata
    metadata JSONB NOT NULL DEFAULT '{
        "priority": "MEDIUM",
        "asking_price": null,
        "ebitda": null,
        "revenue": null,
        "employees": null,
        "nda_status": "none",
        "cim_received": false,
        "junk_reason": null
    }'::jsonb,

    -- Email Thread IDs
    email_thread_ids TEXT[] NOT NULL DEFAULT '{}',

    -- Related Folders
    related_folders TEXT[] NOT NULL DEFAULT '{}',

    -- Soft Delete
    deleted BOOLEAN NOT NULL DEFAULT FALSE,
    deleted_at TIMESTAMPTZ,
    deleted_by VARCHAR(100),
    deleted_reason TEXT,

    -- Timestamps
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    archived_at TIMESTAMPTZ,

    -- Constraints
    CONSTRAINT valid_stage CHECK (stage IN (
        'inbound', 'screening', 'qualified', 'loi',
        'diligence', 'closing', 'portfolio', 'junk', 'archived'
    )),
    CONSTRAINT valid_status CHECK (status IN ('active', 'junk', 'merged', 'archived'))
);

-- Deal Aliases (separate table for efficient matching)
CREATE TABLE zakops.deal_aliases (
    id SERIAL PRIMARY KEY,
    deal_id VARCHAR(20) NOT NULL REFERENCES zakops.deals(deal_id) ON DELETE CASCADE,
    alias VARCHAR(255) NOT NULL,
    alias_normalized VARCHAR(255) NOT NULL,
    alias_type VARCHAR(50) NOT NULL DEFAULT 'name_variation',
    confidence NUMERIC(3,2) NOT NULL DEFAULT 0.9,
    source VARCHAR(100) NOT NULL DEFAULT 'auto_generated',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT unique_alias UNIQUE (alias_normalized)
);

-- Deal Events (Event Sourcing / Audit Trail)
CREATE TABLE zakops.deal_events (
    id BIGSERIAL PRIMARY KEY,
    deal_id VARCHAR(20) NOT NULL REFERENCES zakops.deals(deal_id) ON DELETE CASCADE,
    event_type VARCHAR(100) NOT NULL,
    source VARCHAR(100) NOT NULL,
    actor VARCHAR(100),
    details JSONB NOT NULL DEFAULT '{}',
    previous_state JSONB,
    new_state JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================================
-- ACTIONS
-- ============================================================================

CREATE TABLE zakops.actions (
    action_id VARCHAR(50) PRIMARY KEY,  -- ACT-YYYYMMDD-hash format
    deal_id VARCHAR(20) REFERENCES zakops.deals(deal_id) ON DELETE SET NULL,
    capability_id VARCHAR(100) NOT NULL,
    action_type VARCHAR(100) NOT NULL,
    title VARCHAR(255) NOT NULL,
    summary TEXT,

    -- Status tracking
    status VARCHAR(50) NOT NULL DEFAULT 'PENDING_APPROVAL',

    -- Timing
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    scheduled_for TIMESTAMPTZ,
    duration_seconds NUMERIC(10,2),

    -- Ownership
    created_by VARCHAR(100) NOT NULL DEFAULT 'system',
    source VARCHAR(50) NOT NULL DEFAULT 'system',

    -- Risk & Approval
    risk_level VARCHAR(20) NOT NULL DEFAULT 'low',
    requires_human_review BOOLEAN NOT NULL DEFAULT TRUE,

    -- Idempotency
    idempotency_key VARCHAR(255) UNIQUE,

    -- Payloads
    inputs JSONB NOT NULL DEFAULT '{}',
    outputs JSONB NOT NULL DEFAULT '{}',

    -- Retry logic
    retry_count INTEGER NOT NULL DEFAULT 0,
    max_retries INTEGER NOT NULL DEFAULT 3,
    next_retry_at TIMESTAMPTZ,

    -- Chaining
    parent_action_id VARCHAR(50) REFERENCES zakops.actions(action_id),
    root_action_id VARCHAR(50),
    chain_depth INTEGER NOT NULL DEFAULT 0,

    -- Audit
    audit_trail JSONB NOT NULL DEFAULT '[]',
    artifacts JSONB NOT NULL DEFAULT '[]',
    error_message TEXT,

    -- Constraints
    CONSTRAINT valid_status CHECK (status IN (
        'PENDING_APPROVAL', 'QUEUED', 'READY', 'RUNNING', 'COMPLETED',
        'FAILED', 'CANCELLED', 'REJECTED'
    )),
    CONSTRAINT valid_risk CHECK (risk_level IN ('low', 'medium', 'high')),
    CONSTRAINT valid_source CHECK (source IN ('chat', 'ui', 'system', 'agent', 'api')),
    CONSTRAINT max_chain_depth CHECK (chain_depth <= 5)
);

-- ============================================================================
-- QUARANTINE
-- ============================================================================

CREATE TABLE zakops.quarantine_items (
    id VARCHAR(100) PRIMARY KEY,  -- message_id or UUID
    action_id VARCHAR(50) REFERENCES zakops.actions(action_id),

    -- Email metadata
    message_id VARCHAR(255),
    thread_id VARCHAR(255),
    email_subject TEXT,
    sender VARCHAR(255),
    sender_domain VARCHAR(255),
    received_at TIMESTAMPTZ,

    -- Classification
    classification VARCHAR(50) NOT NULL DEFAULT 'UNCERTAIN',
    urgency VARCHAR(20) NOT NULL DEFAULT 'MEDIUM',
    confidence NUMERIC(3,2),

    -- Extracted info
    company_name VARCHAR(255),
    broker_name VARCHAR(255),

    -- Links
    links JSONB NOT NULL DEFAULT '[]',

    -- File paths
    quarantine_dir VARCHAR(500),
    email_content_path VARCHAR(500),
    triage_summary_path VARCHAR(500),

    -- Status
    status VARCHAR(50) NOT NULL DEFAULT 'pending',
    processed_at TIMESTAMPTZ,
    processed_by VARCHAR(100),
    processing_result VARCHAR(50),
    created_deal_id VARCHAR(20) REFERENCES zakops.deals(deal_id),

    -- Timestamps
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT valid_classification CHECK (classification IN ('DEAL_SIGNAL', 'UNCERTAIN', 'JUNK')),
    CONSTRAINT valid_urgency CHECK (urgency IN ('HIGH', 'MEDIUM', 'LOW')),
    CONSTRAINT valid_status CHECK (status IN ('pending', 'approved', 'rejected', 'expired'))
);

-- ============================================================================
-- EMAIL INGESTION STATE
-- ============================================================================

CREATE TABLE zakops.email_ingestion_state (
    id BIGSERIAL PRIMARY KEY,
    message_id VARCHAR(255) UNIQUE NOT NULL,
    thread_id VARCHAR(255),

    -- Processing state
    stage_completed INTEGER NOT NULL DEFAULT 0,
    is_processed BOOLEAN NOT NULL DEFAULT FALSE,

    -- Classification
    matched_deal_id VARCHAR(20) REFERENCES zakops.deals(deal_id),
    quarantine_id VARCHAR(100) REFERENCES zakops.quarantine_items(id),

    -- Metadata
    from_address VARCHAR(255),
    subject TEXT,
    received_at TIMESTAMPTZ,

    -- Processing details
    processing_started_at TIMESTAMPTZ,
    processing_completed_at TIMESTAMPTZ,
    error_message TEXT,

    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================================
-- SENDER PROFILES
-- ============================================================================

CREATE TABLE zakops.sender_profiles (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    domain VARCHAR(255) NOT NULL,

    -- Profile
    name VARCHAR(255),
    company VARCHAR(255),
    role VARCHAR(100),

    -- Classification
    sender_type VARCHAR(50) NOT NULL DEFAULT 'unknown',
    quality_rating VARCHAR(20) NOT NULL DEFAULT 'MEDIUM',
    is_broker BOOLEAN NOT NULL DEFAULT FALSE,

    -- Statistics
    total_emails INTEGER NOT NULL DEFAULT 0,
    deal_emails INTEGER NOT NULL DEFAULT 0,
    last_email_at TIMESTAMPTZ,

    -- Associated deals
    associated_deal_ids TEXT[] NOT NULL DEFAULT '{}',

    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT valid_sender_type CHECK (sender_type IN ('broker', 'seller', 'advisor', 'platform', 'unknown')),
    CONSTRAINT valid_quality CHECK (quality_rating IN ('HIGH', 'MEDIUM', 'LOW'))
);

-- ============================================================================
-- DEFERRED ACTIONS
-- ============================================================================

CREATE TABLE zakops.deferred_actions (
    id SERIAL PRIMARY KEY,
    action_spec JSONB NOT NULL,
    scheduled_for TIMESTAMPTZ NOT NULL,

    -- Status
    status VARCHAR(50) NOT NULL DEFAULT 'pending',
    executed_at TIMESTAMPTZ,
    resulting_action_id VARCHAR(50) REFERENCES zakops.actions(action_id),

    -- Context
    deal_id VARCHAR(20) REFERENCES zakops.deals(deal_id),
    created_by VARCHAR(100),

    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT valid_status CHECK (status IN ('pending', 'executed', 'cancelled', 'failed'))
);

-- ============================================================================
-- INDEXES
-- ============================================================================

-- Deals
CREATE INDEX idx_deals_stage ON zakops.deals(stage) WHERE NOT deleted;
CREATE INDEX idx_deals_status ON zakops.deals(status) WHERE NOT deleted;
CREATE INDEX idx_deals_stage_status ON zakops.deals(stage, status) WHERE NOT deleted;
CREATE INDEX idx_deals_updated ON zakops.deals(updated_at DESC) WHERE NOT deleted;
CREATE INDEX idx_deals_broker_domain ON zakops.deals USING gin((broker->>'domain'));
CREATE INDEX idx_deals_email_threads ON zakops.deals USING gin(email_thread_ids);
CREATE INDEX idx_deals_metadata ON zakops.deals USING gin(metadata);
CREATE INDEX idx_deals_identifiers ON zakops.deals USING gin(identifiers);

-- Deal Aliases
CREATE INDEX idx_aliases_deal ON zakops.deal_aliases(deal_id);
CREATE INDEX idx_aliases_normalized ON zakops.deal_aliases(alias_normalized);

-- Deal Events
CREATE INDEX idx_events_deal ON zakops.deal_events(deal_id);
CREATE INDEX idx_events_type ON zakops.deal_events(event_type);
CREATE INDEX idx_events_created ON zakops.deal_events(created_at DESC);

-- Actions
CREATE INDEX idx_actions_deal ON zakops.actions(deal_id);
CREATE INDEX idx_actions_status ON zakops.actions(status);
CREATE INDEX idx_actions_type ON zakops.actions(action_type);
CREATE INDEX idx_actions_created ON zakops.actions(created_at DESC);
CREATE INDEX idx_actions_pending ON zakops.actions(created_at)
    WHERE status IN ('PENDING_APPROVAL', 'QUEUED');
CREATE INDEX idx_actions_scheduled ON zakops.actions(scheduled_for)
    WHERE scheduled_for IS NOT NULL AND status = 'QUEUED';

-- Quarantine
CREATE INDEX idx_quarantine_status ON zakops.quarantine_items(status);
CREATE INDEX idx_quarantine_classification ON zakops.quarantine_items(classification);
CREATE INDEX idx_quarantine_created ON zakops.quarantine_items(created_at DESC);
CREATE INDEX idx_quarantine_sender_domain ON zakops.quarantine_items(sender_domain);

-- Email Ingestion
CREATE INDEX idx_email_thread ON zakops.email_ingestion_state(thread_id);
CREATE INDEX idx_email_processed ON zakops.email_ingestion_state(is_processed);

-- Sender Profiles
CREATE INDEX idx_sender_domain ON zakops.sender_profiles(domain);
CREATE INDEX idx_sender_broker ON zakops.sender_profiles(is_broker) WHERE is_broker;

-- Deferred Actions
CREATE INDEX idx_deferred_scheduled ON zakops.deferred_actions(scheduled_for)
    WHERE status = 'pending';

-- ============================================================================
-- FUNCTIONS
-- ============================================================================

-- Generate next deal ID
CREATE OR REPLACE FUNCTION zakops.next_deal_id()
RETURNS VARCHAR(20) AS $$
DECLARE
    current_year INTEGER;
    max_seq INTEGER;
    new_seq INTEGER;
BEGIN
    current_year := EXTRACT(YEAR FROM NOW());

    SELECT COALESCE(MAX(
        CAST(SUBSTRING(deal_id FROM 'DEAL-\d{4}-(\d+)') AS INTEGER)
    ), 0)
    INTO max_seq
    FROM zakops.deals
    WHERE deal_id LIKE 'DEAL-' || current_year || '-%';

    new_seq := max_seq + 1;

    RETURN FORMAT('DEAL-%s-%s', current_year, LPAD(new_seq::TEXT, 3, '0'));
END;
$$ LANGUAGE plpgsql;

-- Generate action ID
CREATE OR REPLACE FUNCTION zakops.next_action_id()
RETURNS VARCHAR(50) AS $$
BEGIN
    RETURN FORMAT('ACT-%s-%s',
        TO_CHAR(NOW(), 'YYYYMMDD'),
        ENCODE(GEN_RANDOM_BYTES(6), 'hex')
    );
END;
$$ LANGUAGE plpgsql;

-- Record deal event
CREATE OR REPLACE FUNCTION zakops.record_deal_event(
    p_deal_id VARCHAR(20),
    p_event_type VARCHAR(100),
    p_source VARCHAR(100),
    p_actor VARCHAR(100),
    p_details JSONB,
    p_previous_state JSONB DEFAULT NULL,
    p_new_state JSONB DEFAULT NULL
)
RETURNS BIGINT AS $$
DECLARE
    event_id BIGINT;
BEGIN
    INSERT INTO zakops.deal_events (
        deal_id, event_type, source, actor, details, previous_state, new_state
    ) VALUES (
        p_deal_id, p_event_type, p_source, p_actor, p_details, p_previous_state, p_new_state
    ) RETURNING id INTO event_id;

    RETURN event_id;
END;
$$ LANGUAGE plpgsql;

-- Update timestamp trigger
CREATE OR REPLACE FUNCTION zakops.update_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply triggers
CREATE TRIGGER tr_deals_updated
    BEFORE UPDATE ON zakops.deals
    FOR EACH ROW EXECUTE FUNCTION zakops.update_timestamp();

CREATE TRIGGER tr_actions_updated
    BEFORE UPDATE ON zakops.actions
    FOR EACH ROW EXECUTE FUNCTION zakops.update_timestamp();

CREATE TRIGGER tr_quarantine_updated
    BEFORE UPDATE ON zakops.quarantine_items
    FOR EACH ROW EXECUTE FUNCTION zakops.update_timestamp();

CREATE TRIGGER tr_email_state_updated
    BEFORE UPDATE ON zakops.email_ingestion_state
    FOR EACH ROW EXECUTE FUNCTION zakops.update_timestamp();

CREATE TRIGGER tr_sender_updated
    BEFORE UPDATE ON zakops.sender_profiles
    FOR EACH ROW EXECUTE FUNCTION zakops.update_timestamp();

-- ============================================================================
-- VIEWS
-- ============================================================================

-- Active deals with computed fields
CREATE OR REPLACE VIEW zakops.v_active_deals AS
SELECT
    d.*,
    EXTRACT(DAY FROM NOW() - d.updated_at) AS days_since_update,
    (d.broker->>'name') AS broker_name,
    (d.broker->>'company') AS broker_company,
    (d.metadata->>'priority') AS priority_level,
    (d.metadata->>'asking_price')::NUMERIC AS asking_price,
    (d.metadata->>'ebitda')::NUMERIC AS ebitda,
    (SELECT COUNT(*) FROM zakops.actions a WHERE a.deal_id = d.deal_id) AS action_count,
    (SELECT COUNT(*) FROM zakops.deal_aliases a WHERE a.deal_id = d.deal_id) AS alias_count
FROM zakops.deals d
WHERE d.deleted = FALSE AND d.status = 'active';

-- Pipeline summary
CREATE OR REPLACE VIEW zakops.v_pipeline_summary AS
SELECT
    stage,
    COUNT(*) AS count,
    AVG(EXTRACT(DAY FROM NOW() - updated_at)) AS avg_days_in_stage
FROM zakops.deals
WHERE deleted = FALSE AND status = 'active'
GROUP BY stage
ORDER BY
    CASE stage
        WHEN 'inbound' THEN 1
        WHEN 'screening' THEN 2
        WHEN 'qualified' THEN 3
        WHEN 'loi' THEN 4
        WHEN 'diligence' THEN 5
        WHEN 'closing' THEN 6
        WHEN 'portfolio' THEN 7
    END;

-- Pending actions
CREATE OR REPLACE VIEW zakops.v_pending_actions AS
SELECT
    a.*,
    d.canonical_name AS deal_name,
    d.stage AS deal_stage
FROM zakops.actions a
LEFT JOIN zakops.deals d ON a.deal_id = d.deal_id
WHERE a.status IN ('PENDING_APPROVAL', 'QUEUED')
ORDER BY
    CASE a.status WHEN 'PENDING_APPROVAL' THEN 0 ELSE 1 END,
    a.created_at;

-- Quarantine dashboard
CREATE OR REPLACE VIEW zakops.v_quarantine_dashboard AS
SELECT
    q.*,
    sp.name AS sender_name,
    sp.company AS sender_company,
    sp.is_broker
FROM zakops.quarantine_items q
LEFT JOIN zakops.sender_profiles sp ON q.sender = sp.email
WHERE q.status = 'pending'
ORDER BY
    CASE q.urgency WHEN 'HIGH' THEN 0 WHEN 'MEDIUM' THEN 1 ELSE 2 END,
    q.created_at DESC;
