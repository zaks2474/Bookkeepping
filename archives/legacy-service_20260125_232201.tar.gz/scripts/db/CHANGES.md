# ZakOps Database Architecture Changes

> **Note**: The authoritative change log is `/home/zaks/bookkeeping/CHANGES.md`. All environment changes are recorded there per ONBOARDING.md guidelines.

See entry **2026-01-17: PostgreSQL Migration + Orchestration API** in the main changelog for full details.

## Quick Reference

| Component | Path |
|-----------|------|
| PostgreSQL Schema | `/home/zaks/scripts/db/schema.sql` |
| Migration Script | `/home/zaks/scripts/db/migrate_from_json.py` |
| Orchestration API | `/home/zaks/scripts/api/main.py` |
| API Service | `/home/zaks/scripts/api/zakops-api.service` |
| TypeScript Types | `/home/zaks/zakops-dashboard/src/types/api.ts` |
| React Query Client | `/home/zaks/zakops-dashboard/src/lib/api-client.ts` |
| Zod Schemas | `/home/zaks/zakops-dashboard/src/lib/api-schemas.ts` |

## Database Connection

```
postgresql://dealengine:changeme@localhost:5435/zakops
```

## API Endpoint

```
http://localhost:9200
```
