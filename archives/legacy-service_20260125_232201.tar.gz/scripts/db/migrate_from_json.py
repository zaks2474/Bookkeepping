#!/usr/bin/env python3
"""
Migrate existing ZakOps data from JSON/SQLite to PostgreSQL.

Usage:
    python migrate_from_json.py [--dry-run] [--verify]

Migrates:
    - deal_registry.json -> zakops.deals, zakops.deal_aliases
    - ingest_state.db -> zakops.actions, zakops.email_ingestion_state
    - quarantine.json -> zakops.quarantine_items
    - deferred_actions.json -> zakops.deferred_actions
"""

import asyncio
import json
import sqlite3
import argparse
from pathlib import Path
from datetime import datetime
from typing import Any

import asyncpg

# Paths
DATAROOM = Path("/home/zaks/DataRoom")
REGISTRY_DIR = DATAROOM / ".deal-registry"

DEAL_REGISTRY = REGISTRY_DIR / "deal_registry.json"
INGEST_STATE_DB = REGISTRY_DIR / "ingest_state.db"
QUARANTINE_JSON = REGISTRY_DIR / "quarantine.json"
DEFERRED_ACTIONS_JSON = REGISTRY_DIR / "deferred_actions.json"

# Database - using deal-engine-db container on port 5435
DB_URL = "postgresql://dealengine:changeme@localhost:5435/zakops"


class Migration:
    def __init__(self, dry_run: bool = False):
        self.dry_run = dry_run
        self.conn: asyncpg.Connection = None
        self.stats = {
            "deals": 0,
            "aliases": 0,
            "events": 0,
            "actions": 0,
            "quarantine": 0,
            "deferred": 0,
            "errors": []
        }

    async def connect(self):
        self.conn = await asyncpg.connect(DB_URL)
        print(f"Connected to PostgreSQL (dry_run={self.dry_run})")

    async def close(self):
        if self.conn:
            await self.conn.close()

    def parse_timestamp(self, ts_str):
        """Parse various timestamp formats."""
        if not ts_str:
            return None
        try:
            # Try ISO format first
            if 'T' in str(ts_str):
                return datetime.fromisoformat(ts_str.replace('Z', '+00:00'))
            # Try Unix timestamp
            if isinstance(ts_str, (int, float)):
                return datetime.fromtimestamp(ts_str)
            return datetime.fromisoformat(ts_str)
        except Exception:
            return datetime.now()

    async def migrate_deals(self):
        """Migrate deal_registry.json to zakops.deals."""
        print("\n=== Migrating Deals ===")

        if not DEAL_REGISTRY.exists():
            print(f"  [SKIP] {DEAL_REGISTRY} not found")
            return

        with open(DEAL_REGISTRY) as f:
            registry = json.load(f)

        deals = registry.get("deals", {})
        print(f"  Found {len(deals)} deals to migrate")

        for deal_id, deal in deals.items():
            try:
                if self.dry_run:
                    print(f"  [DRY] Would migrate {deal_id}: {deal.get('canonical_name')}")
                    self.stats["deals"] += 1
                    continue

                # Prepare JSONB fields
                identifiers = deal.get("identifiers", {})
                if not identifiers:
                    identifiers = {"listing_ids": [], "broker_reference_ids": []}

                company_info = deal.get("company_info", {})
                if not company_info:
                    company_info = {}

                broker = deal.get("broker", {})
                if not broker:
                    broker = {}

                metadata = deal.get("metadata", {})
                if not metadata:
                    metadata = {"priority": "MEDIUM"}

                # Insert deal
                await self.conn.execute("""
                    INSERT INTO zakops.deals (
                        deal_id, canonical_name, display_name, folder_path,
                        stage, status, identifiers, company_info, broker,
                        metadata, email_thread_ids, related_folders,
                        deleted, deleted_at, deleted_by, deleted_reason,
                        created_at, updated_at, archived_at
                    ) VALUES (
                        $1, $2, $3, $4, $5, $6, $7, $8, $9, $10,
                        $11, $12, $13, $14, $15, $16, $17, $18, $19
                    )
                    ON CONFLICT (deal_id) DO UPDATE SET
                        canonical_name = EXCLUDED.canonical_name,
                        display_name = EXCLUDED.display_name,
                        stage = EXCLUDED.stage,
                        status = EXCLUDED.status,
                        updated_at = NOW()
                """,
                    deal_id,
                    deal.get("canonical_name", "Unknown"),
                    deal.get("display_name"),
                    deal.get("folder_path"),
                    deal.get("stage", "inbound"),
                    deal.get("status", "active"),
                    json.dumps(identifiers),
                    json.dumps(company_info),
                    json.dumps(broker),
                    json.dumps(metadata),
                    deal.get("email_thread_ids", []),
                    deal.get("related_folders", []),
                    deal.get("deleted", False),
                    self.parse_timestamp(deal.get("deleted_at")),
                    deal.get("deleted_by"),
                    deal.get("deleted_reason"),
                    self.parse_timestamp(deal.get("created_at")) or datetime.now(),
                    self.parse_timestamp(deal.get("updated_at")) or datetime.now(),
                    self.parse_timestamp(deal.get("archived_at"))
                )

                # Insert aliases
                for alias in deal.get("aliases", []):
                    try:
                        alias_text = alias.get("alias", alias) if isinstance(alias, dict) else str(alias)
                        alias_normalized = alias_text.lower().strip()

                        await self.conn.execute("""
                            INSERT INTO zakops.deal_aliases (
                                deal_id, alias, alias_normalized, alias_type,
                                confidence, source, created_at
                            ) VALUES ($1, $2, $3, $4, $5, $6, $7)
                            ON CONFLICT (alias_normalized) DO NOTHING
                        """,
                            deal_id,
                            alias_text,
                            alias_normalized,
                            alias.get("alias_type", "name_variation") if isinstance(alias, dict) else "name_variation",
                            alias.get("confidence", 0.9) if isinstance(alias, dict) else 0.9,
                            alias.get("source", "migration") if isinstance(alias, dict) else "migration",
                            self.parse_timestamp(alias.get("created_at") if isinstance(alias, dict) else None) or datetime.now()
                        )
                        self.stats["aliases"] += 1
                    except Exception as e:
                        self.stats["errors"].append(f"Alias for {deal_id}: {e}")

                # Insert audit trail as events
                for event in deal.get("audit_trail", []):
                    try:
                        await self.conn.execute("""
                            INSERT INTO zakops.deal_events (
                                deal_id, event_type, source, actor, details, created_at
                            ) VALUES ($1, $2, $3, $4, $5, $6)
                        """,
                            deal_id,
                            event.get("action", "unknown"),
                            event.get("source", "migration"),
                            event.get("actor"),
                            json.dumps({"details": event.get("details", "")}),
                            self.parse_timestamp(event.get("timestamp")) or datetime.now()
                        )
                        self.stats["events"] += 1
                    except Exception as e:
                        self.stats["errors"].append(f"Event for {deal_id}: {e}")

                self.stats["deals"] += 1
                print(f"  [OK] Migrated {deal_id}: {deal.get('canonical_name')}")

            except Exception as e:
                self.stats["errors"].append(f"Deal {deal_id}: {e}")
                print(f"  [ERROR] {deal_id}: {e}")

    async def migrate_actions(self):
        """Migrate actions from ingest_state.db to zakops.actions."""
        print("\n=== Migrating Actions ===")

        if not INGEST_STATE_DB.exists():
            print(f"  [SKIP] {INGEST_STATE_DB} not found")
            return

        conn = sqlite3.connect(INGEST_STATE_DB)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        # Check if actions table exists
        cursor.execute("""
            SELECT name FROM sqlite_master
            WHERE type='table' AND name='actions'
        """)
        if not cursor.fetchone():
            print("  [SKIP] No actions table in SQLite")
            conn.close()
            return

        cursor.execute("SELECT * FROM actions")
        rows = cursor.fetchall()
        print(f"  Found {len(rows)} actions to migrate")

        for row in rows:
            row_dict = dict(row)
            action_id = row_dict.get('action_id')

            try:
                if self.dry_run:
                    print(f"  [DRY] Would migrate {action_id}")
                    self.stats["actions"] += 1
                    continue

                # Parse inputs/outputs as JSON
                inputs = row_dict.get('inputs', '{}')
                if isinstance(inputs, str):
                    try:
                        inputs = json.loads(inputs)
                    except:
                        inputs = {}

                outputs = row_dict.get('outputs', '{}')
                if isinstance(outputs, str):
                    try:
                        outputs = json.loads(outputs)
                    except:
                        outputs = {}

                audit_trail = row_dict.get('audit_trail', '[]')
                if isinstance(audit_trail, str):
                    try:
                        audit_trail = json.loads(audit_trail)
                    except:
                        audit_trail = []

                await self.conn.execute("""
                    INSERT INTO zakops.actions (
                        action_id, deal_id, capability_id, action_type, title, summary,
                        status, created_at, updated_at, started_at, completed_at,
                        created_by, source, risk_level, requires_human_review,
                        idempotency_key, inputs, outputs, retry_count, max_retries,
                        audit_trail
                    ) VALUES (
                        $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,
                        $12, $13, $14, $15, $16, $17, $18, $19, $20, $21
                    )
                    ON CONFLICT (action_id) DO NOTHING
                """,
                    action_id,
                    row_dict.get('deal_id'),
                    row_dict.get('capability_id', 'unknown.v1'),
                    row_dict.get('type', row_dict.get('action_type', 'unknown')),
                    row_dict.get('title', 'Untitled'),
                    row_dict.get('summary'),
                    row_dict.get('status', 'COMPLETED'),
                    self.parse_timestamp(row_dict.get('created_at')) or datetime.now(),
                    self.parse_timestamp(row_dict.get('updated_at')) or datetime.now(),
                    self.parse_timestamp(row_dict.get('started_at')),
                    self.parse_timestamp(row_dict.get('completed_at')),
                    row_dict.get('created_by', 'system'),
                    row_dict.get('source', 'system'),
                    row_dict.get('risk_level', 'low'),
                    bool(row_dict.get('requires_human_review', True)),
                    row_dict.get('idempotency_key'),
                    json.dumps(inputs),
                    json.dumps(outputs),
                    row_dict.get('retry_count', 0),
                    row_dict.get('max_retries', 3),
                    json.dumps(audit_trail)
                )
                self.stats["actions"] += 1
                print(f"  [OK] Migrated {action_id}")

            except Exception as e:
                self.stats["errors"].append(f"Action {action_id}: {e}")
                print(f"  [ERROR] {action_id}: {e}")

        conn.close()

    async def migrate_quarantine(self):
        """Migrate quarantine.json to zakops.quarantine_items."""
        print("\n=== Migrating Quarantine ===")

        if not QUARANTINE_JSON.exists():
            print(f"  [SKIP] {QUARANTINE_JSON} not found")
            return

        with open(QUARANTINE_JSON) as f:
            quarantine = json.load(f)

        items = quarantine if isinstance(quarantine, list) else quarantine.get("items", [])
        if not items and isinstance(quarantine, dict):
            # Try other keys
            for key in ["pending", "quarantine"]:
                if key in quarantine:
                    items = quarantine[key]
                    break

        print(f"  Found {len(items)} quarantine items to migrate")

        for item in items:
            try:
                item_id = item.get("id", item.get("message_id", str(datetime.now().timestamp())))

                if self.dry_run:
                    print(f"  [DRY] Would migrate {item_id}")
                    self.stats["quarantine"] += 1
                    continue

                sender = item.get("sender", "")
                sender_domain = sender.split('@')[-1] if '@' in sender else ""

                await self.conn.execute("""
                    INSERT INTO zakops.quarantine_items (
                        id, action_id, message_id, thread_id, email_subject,
                        sender, sender_domain, received_at, classification, urgency,
                        confidence, company_name, broker_name, links,
                        quarantine_dir, status, created_at
                    ) VALUES (
                        $1, $2, $3, $4, $5, $6, $7, $8, $9, $10,
                        $11, $12, $13, $14, $15, $16, $17
                    )
                    ON CONFLICT (id) DO NOTHING
                """,
                    item_id,
                    item.get("action_id"),
                    item.get("message_id"),
                    item.get("thread_id"),
                    item.get("email_subject", item.get("subject")),
                    sender,
                    sender_domain,
                    self.parse_timestamp(item.get("received_at")),
                    item.get("classification", "UNCERTAIN"),
                    item.get("urgency", "MEDIUM"),
                    item.get("confidence"),
                    item.get("company_name", item.get("company")),
                    item.get("broker_name"),
                    json.dumps(item.get("links", [])),
                    item.get("quarantine_dir"),
                    item.get("status", "pending"),
                    self.parse_timestamp(item.get("created_at")) or datetime.now()
                )
                self.stats["quarantine"] += 1
                print(f"  [OK] Migrated quarantine {item_id}")

            except Exception as e:
                self.stats["errors"].append(f"Quarantine {item_id}: {e}")
                print(f"  [ERROR] Quarantine: {e}")

    async def migrate_deferred(self):
        """Migrate deferred_actions.json to zakops.deferred_actions."""
        print("\n=== Migrating Deferred Actions ===")

        if not DEFERRED_ACTIONS_JSON.exists():
            print(f"  [SKIP] {DEFERRED_ACTIONS_JSON} not found")
            return

        with open(DEFERRED_ACTIONS_JSON) as f:
            deferred = json.load(f)

        items = deferred if isinstance(deferred, list) else deferred.get("actions", [])
        print(f"  Found {len(items)} deferred actions to migrate")

        for item in items:
            try:
                if self.dry_run:
                    print(f"  [DRY] Would migrate deferred action")
                    self.stats["deferred"] += 1
                    continue

                await self.conn.execute("""
                    INSERT INTO zakops.deferred_actions (
                        action_spec, scheduled_for, status, deal_id, created_by
                    ) VALUES ($1, $2, $3, $4, $5)
                """,
                    json.dumps(item.get("action_spec", item)),
                    self.parse_timestamp(item.get("scheduled_for")) or datetime.now(),
                    item.get("status", "pending"),
                    item.get("deal_id"),
                    item.get("created_by", "migration")
                )
                self.stats["deferred"] += 1

            except Exception as e:
                self.stats["errors"].append(f"Deferred: {e}")

    async def verify_migration(self):
        """Verify the migration by checking counts."""
        print("\n=== Verifying Migration ===")

        counts = await self.conn.fetch("""
            SELECT 'deals' as table_name, COUNT(*) as count FROM zakops.deals
            UNION ALL
            SELECT 'aliases', COUNT(*) FROM zakops.deal_aliases
            UNION ALL
            SELECT 'events', COUNT(*) FROM zakops.deal_events
            UNION ALL
            SELECT 'actions', COUNT(*) FROM zakops.actions
            UNION ALL
            SELECT 'quarantine', COUNT(*) FROM zakops.quarantine_items
            UNION ALL
            SELECT 'deferred', COUNT(*) FROM zakops.deferred_actions
        """)

        for row in counts:
            print(f"  {row['table_name']}: {row['count']} rows")

    def print_summary(self):
        print("\n" + "=" * 60)
        print("MIGRATION SUMMARY")
        print("=" * 60)
        print(f"  Deals migrated:      {self.stats['deals']}")
        print(f"  Aliases migrated:    {self.stats['aliases']}")
        print(f"  Events migrated:     {self.stats['events']}")
        print(f"  Actions migrated:    {self.stats['actions']}")
        print(f"  Quarantine migrated: {self.stats['quarantine']}")
        print(f"  Deferred migrated:   {self.stats['deferred']}")
        print(f"  Errors:              {len(self.stats['errors'])}")

        if self.stats['errors']:
            print("\nErrors:")
            for err in self.stats['errors'][:10]:
                print(f"  - {err}")
            if len(self.stats['errors']) > 10:
                print(f"  ... and {len(self.stats['errors']) - 10} more")


async def main():
    parser = argparse.ArgumentParser(description="Migrate ZakOps data to PostgreSQL")
    parser.add_argument("--dry-run", action="store_true", help="Don't actually migrate")
    parser.add_argument("--verify", action="store_true", help="Verify migration after")
    args = parser.parse_args()

    migration = Migration(dry_run=args.dry_run)

    try:
        await migration.connect()

        await migration.migrate_deals()
        await migration.migrate_actions()
        await migration.migrate_quarantine()
        await migration.migrate_deferred()

        migration.print_summary()

        if args.verify or not args.dry_run:
            await migration.verify_migration()

    finally:
        await migration.close()


if __name__ == "__main__":
    asyncio.run(main())
