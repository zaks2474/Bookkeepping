#!/usr/bin/env python3
"""
DFP Classification Router

Uses HybridClassifier to classify emails/documents into stable labels and emits
run-ledger records (component: classification) without logging raw content.
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Sequence

from hybrid_classifier import HybridClassifier


RUN_LEDGER_WRITER = "/home/zaks/bookkeeping/scripts/run_ledger.py"
RUN_LEDGER_PATH = os.getenv("ZAKOPS_RUN_LEDGER_PATH", "/home/zaks/logs/run-ledger.jsonl")


DEFAULT_DOC_LABELS: Dict[str, List[str]] = {
    "01-NDA": ["nda", "non-disclosure", "confidentiality", "mutual agreement"],
    "02-CIM": [
        "cim",
        "confidential information memorandum",
        "teaser",
        "executive summary",
        "offering memorandum",
        "deal summary",
        "business summary",
        "investment summary",
    ],
    "03-Financials": [
        "financial",
        "p&l",
        "profit",
        "loss",
        "tax return",
        "balance sheet",
        "income statement",
        "cash flow",
        "revenue",
        "ebitda",
        "trailing",
    ],
    "04-Operations": ["operations", "sop", "procedures", "employee", "org chart", "organizational", "process"],
    "05-Legal": ["contract", "agreement", "lease", "license", "legal", "corporate", "articles", "bylaws"],
    "99-Other": [],
}


def _emit_run_ledger(
    *,
    run_id: str,
    status: str,
    started_at: str,
    ended_at: str,
    artifacts: Optional[Sequence[str]] = None,
    metrics: Optional[Dict[str, int]] = None,
    errors: Optional[Sequence[str]] = None,
    correlation: Optional[Dict[str, str]] = None,
) -> None:
    if not os.path.exists(RUN_LEDGER_WRITER):
        return

    args = [
        "python3",
        RUN_LEDGER_WRITER,
        "--ledger-path",
        RUN_LEDGER_PATH,
        "--component",
        "classification",
        "--run-id",
        run_id,
        "--status",
        status,
        "--started-at",
        started_at,
        "--ended-at",
        ended_at,
    ]
    for artifact in artifacts or []:
        args.extend(["--artifact", str(artifact)])
    for k, v in (metrics or {}).items():
        args.extend(["--metric", f"{k}={int(v)}"])
    for e in errors or []:
        args.extend(["--error", str(e)])
    for k, v in (correlation or {}).items():
        args.extend(["--correlation", f"{k}={v}"])

    subprocess.run(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)


def _read_text(path: Path, max_bytes: int = 2_000_000) -> str:
    data = path.read_bytes()
    return data[:max_bytes].decode("utf-8", errors="ignore")


def main() -> int:
    parser = argparse.ArgumentParser(description="DFP classification router (heuristic/local/cloud)")
    parser.add_argument("--kind", choices=["document", "email"], default="document", help="Classification kind (default: document)")
    parser.add_argument("--text", default="", help="Inline text to classify")
    parser.add_argument("--file", default="", help="Read text from a file path")
    parser.add_argument("--labels", default="", help="Comma-separated label set (defaults are kind-specific)")
    parser.add_argument("--no-ledger", action="store_true", help="Disable run-ledger emission")
    parser.add_argument("--json", action="store_true", help="Print JSON only")
    args = parser.parse_args()

    started_at = datetime.now().astimezone().isoformat()
    run_id = f"{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}_classification_{os.getpid()}"

    try:
        if args.file:
            text = _read_text(Path(args.file))
        else:
            text = args.text or ""

        if not text.strip():
            raise ValueError("empty_input")

        if args.labels.strip():
            labels = [l.strip() for l in args.labels.split(",") if l.strip()]
            patterns_by_label = {l: [] for l in labels}
        else:
            if args.kind == "document":
                patterns_by_label = DEFAULT_DOC_LABELS
                labels = list(DEFAULT_DOC_LABELS.keys())
            else:
                patterns_by_label = {"deal_material": ["cim", "teaser", "nda", "ebitda"], "newsletter": ["unsubscribe", "newsletter"], "other": []}
                labels = list(patterns_by_label.keys())

        clf = HybridClassifier()
        result = clf.classify_one_of(text=text, labels=labels, patterns_by_label=patterns_by_label, context=f"kind={args.kind}")

        ended_at = datetime.now().astimezone().isoformat()
        if not args.no_ledger:
            _emit_run_ledger(
                run_id=run_id,
                status="success",
                started_at=started_at,
                ended_at=ended_at,
                artifacts=[args.file] if args.file else [],
                metrics={"input_chars": len(text), "tokens_est": result.input_tokens_est},
                correlation={
                    "route": result.route,
                    "label": result.label,
                    "model": result.model,
                    "input_hash": result.input_hash,
                    "kind": args.kind,
                },
            )

        payload = result.to_dict()
        if args.json:
            print(json.dumps(payload, ensure_ascii=False))
        else:
            print(json.dumps(payload, indent=2, ensure_ascii=False))
        return 0
    except Exception as exc:
        ended_at = datetime.now().astimezone().isoformat()
        if not args.no_ledger:
            _emit_run_ledger(
                run_id=run_id,
                status="fail",
                started_at=started_at,
                ended_at=ended_at,
                artifacts=[args.file] if args.file else [],
                metrics={},
                errors=[f"{type(exc).__name__}:{exc}"],
                correlation={"kind": args.kind},
            )
        if args.json:
            print(json.dumps({"error": str(exc)}))
        else:
            print(f"Error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
