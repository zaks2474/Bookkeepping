#!/usr/bin/env python3
"""
Deal Status CLI - Answer "What's the status and what's next?"

Unified view of deal lifecycle status combining:
- Registry data (canonical info, broker, stage)
- Event history (recent activity)
- Deferred actions (scheduled next steps)
- Case file (AI insights, key facts)
- State machine (allowed transitions)

Usage:
    python3 deal_status_cli.py status <deal_id>
    python3 deal_status_cli.py status DEAL-2025-001
    python3 deal_status_cli.py status "teamlogic"  # Search by name

This script fulfills Phase 0 acceptance criteria:
"A new operator can answer 'What's the status and what's next?' from one command"
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

# Add scripts directory to path
sys.path.insert(0, str(Path(__file__).parent))

from deal_registry import DealRegistry
from deal_events import DealEventStore
from deferred_actions import DeferredActionQueue
from deal_state_machine import DealStateMachine, DealStage

# Configuration
REGISTRY_PATH = "/home/zaks/DataRoom/.deal-registry/deal_registry.json"
CASE_FILES_DIR = Path("/home/zaks/DataRoom/.deal-registry/case_files")


def _now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _days_ago(iso_timestamp: str) -> int:
    """Calculate days since a timestamp"""
    try:
        if iso_timestamp.endswith("Z"):
            iso_timestamp = iso_timestamp[:-1] + "+00:00"
        ts = datetime.fromisoformat(iso_timestamp)
        now = datetime.now(timezone.utc)
        return (now - ts).days
    except (ValueError, TypeError):
        return -1


def load_case_file(deal_id: str) -> Optional[Dict[str, Any]]:
    """Load case file for a deal if it exists"""
    case_file_path = CASE_FILES_DIR / f"{deal_id}.json"
    if case_file_path.exists():
        try:
            with open(case_file_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            pass
    return None


def get_deal_status(deal_id: str) -> Dict[str, Any]:
    """
    Get comprehensive deal status.

    Returns a dictionary with:
    - deal: Basic deal info from registry
    - stage: Current stage with context
    - events: Recent events
    - actions: Pending deferred actions
    - case_file: Case file data if exists
    - transitions: Allowed next stages
    - alerts: Any alerts or warnings
    """
    registry = DealRegistry(REGISTRY_PATH)
    event_store = DealEventStore()
    action_queue = DeferredActionQueue()

    # Get deal from registry
    deal = registry.get_deal(deal_id)
    if not deal:
        # Try searching
        results = registry.search(deal_id)
        if results and len(results) == 1:
            deal = registry.get_deal(results[0]["deal_id"])
        elif results:
            return {
                "error": f"Multiple matches found for '{deal_id}'",
                "matches": [{"deal_id": r["deal_id"], "name": r["canonical_name"]} for r in results[:5]]
            }
        else:
            return {"error": f"Deal not found: {deal_id}"}

    result: Dict[str, Any] = {
        "deal_id": deal.deal_id,
        "canonical_name": deal.canonical_name,
        "timestamp": _now_iso(),
    }

    # Stage info
    sm = DealStateMachine(deal.stage, deal.deal_id)
    result["stage"] = {
        "current": deal.stage,
        "is_terminal": sm.is_terminal(),
        "allowed_transitions": [s.value for s in sm.get_allowed_transitions()],
        "advisory_context": sm.get_advisory_context(),
    }

    # Registry data summary
    result["deal"] = {
        "status": deal.status,
        "folder_path": deal.folder_path,
        "broker": {
            "name": deal.broker.name if deal.broker else None,
            "email": deal.broker.email if deal.broker else None,
            "company": deal.broker.company if deal.broker else None,
        },
        "priority": deal.metadata.priority,
        "created_at": deal.created_at,
        "updated_at": deal.updated_at,
        "days_since_update": _days_ago(deal.updated_at),
        "nda_status": deal.metadata.nda_status,
        "cim_received": deal.metadata.cim_received,
    }

    # Add financial info if available
    if deal.metadata.asking_price or deal.metadata.ebitda:
        result["deal"]["financials"] = {
            "asking_price": deal.metadata.asking_price,
            "ebitda": deal.metadata.ebitda,
        }

    # Recent events (last 10)
    events = event_store.get_events(deal.deal_id, limit=10)
    result["recent_events"] = [
        {
            "type": e.event_type,
            "timestamp": e.timestamp,
            "actor": e.actor,
            "summary": _summarize_event(e),
        }
        for e in reversed(events[-10:])  # Most recent first
    ]
    result["event_count"] = event_store.count_events(deal.deal_id)

    # Pending actions
    pending_actions = action_queue.get_actions_for_deal(deal.deal_id, status="pending")
    result["pending_actions"] = [
        {
            "action_id": a.action_id,
            "type": a.action_type,
            "scheduled_for": a.scheduled_for,
            "priority": a.priority,
            "is_due": a.is_due(),
            "days_until": _days_until(a.scheduled_for),
        }
        for a in sorted(pending_actions, key=lambda x: x.scheduled_for)
    ]

    # Case file (if exists)
    case_file = load_case_file(deal.deal_id)
    if case_file:
        result["case_file"] = {
            "summary": case_file.get("summary"),
            "key_facts": case_file.get("key_facts", {}),
            "buy_box_fit": case_file.get("buy_box_fit", {}),
            "open_questions": case_file.get("open_questions", []),
            "risk_flags": case_file.get("risk_flags", []),
            "last_updated": case_file.get("last_updated"),
        }

    # Alerts and warnings
    alerts = []

    # Check for stale deal
    days_since_update = result["deal"]["days_since_update"]
    if days_since_update > 30 and not sm.is_terminal():
        alerts.append({
            "type": "stall_warning",
            "severity": "warning",
            "message": f"Deal has not been updated in {days_since_update} days",
        })

    # Check for overdue actions
    overdue_actions = [a for a in pending_actions if a.is_due()]
    if overdue_actions:
        alerts.append({
            "type": "overdue_actions",
            "severity": "warning",
            "message": f"{len(overdue_actions)} action(s) overdue",
            "actions": [a.action_id for a in overdue_actions],
        })

    # Check for approval-required stage with no recent activity
    if sm.current_stage in {DealStage.LOI, DealStage.CLOSING, DealStage.EXIT_PLANNING}:
        if days_since_update > 14:
            alerts.append({
                "type": "approval_stage_stall",
                "severity": "high",
                "message": f"Deal in {sm.current_stage.value} stage with no activity for {days_since_update} days",
            })

    result["alerts"] = alerts

    return result


def _summarize_event(event) -> str:
    """Create a short summary of an event"""
    data = event.data or {}

    if event.event_type == "deal_created":
        return f"Deal created from {data.get('source', 'unknown')}"
    elif event.event_type == "stage_changed":
        return f"Stage changed: {data.get('old_stage')} → {data.get('new_stage')}"
    elif event.event_type == "email_received":
        return f"Email: {data.get('subject', 'No subject')[:40]}"
    elif event.event_type == "document_attached":
        return f"Document: {data.get('filename', 'Unknown')}"
    elif event.event_type == "document_classified":
        return f"Classified as {data.get('doc_type', 'unknown')} ({data.get('confidence', 0):.0%})"
    elif event.event_type == "ai_recommendation":
        return f"AI: {data.get('summary', 'Recommendation')[:50]}"
    elif event.event_type == "note_added":
        return f"Note: {data.get('content', '')[:40]}"
    else:
        return event.event_type.replace("_", " ").title()


def _days_until(iso_timestamp: str) -> int:
    """Calculate days until a timestamp"""
    try:
        if iso_timestamp.endswith("Z"):
            iso_timestamp = iso_timestamp[:-1] + "+00:00"
        ts = datetime.fromisoformat(iso_timestamp)
        now = datetime.now(timezone.utc)
        return (ts - now).days
    except (ValueError, TypeError):
        return 0


def print_status_human(status: Dict[str, Any]) -> None:
    """Print status in human-readable format"""
    if "error" in status:
        print(f"\nError: {status['error']}")
        if "matches" in status:
            print("\nDid you mean one of these?")
            for match in status["matches"]:
                print(f"  {match['deal_id']}: {match['name']}")
        return

    print("\n" + "=" * 70)
    print(f"DEAL STATUS: {status['deal_id']}")
    print(f"  {status['canonical_name']}")
    print("=" * 70)

    # Stage
    stage = status["stage"]
    print(f"\n📍 STAGE: {stage['current'].upper()}")
    if stage["is_terminal"]:
        print("   [TERMINAL STATE]")
    else:
        print(f"   Allowed transitions: {', '.join(stage['allowed_transitions'])}")
    if stage["advisory_context"]:
        print(f"   AI Focus: {stage['advisory_context']}")

    # Deal basics
    deal = status["deal"]
    print(f"\n📊 STATUS: {deal['status']}")
    print(f"   Priority: {deal['priority']}")
    print(f"   Last updated: {deal['updated_at']} ({deal['days_since_update']} days ago)")

    if deal["broker"]["name"]:
        print(f"\n👤 BROKER: {deal['broker']['name']}")
        if deal["broker"]["company"]:
            print(f"   Company: {deal['broker']['company']}")
        if deal["broker"]["email"]:
            print(f"   Email: {deal['broker']['email']}")

    if "financials" in deal:
        fin = deal["financials"]
        print("\n💰 FINANCIALS:")
        if fin.get("asking_price"):
            print(f"   Asking: {fin['asking_price']}")
        if fin.get("ebitda"):
            print(f"   EBITDA: {fin['ebitda']}")

    # Case file summary
    if "case_file" in status:
        cf = status["case_file"]
        print("\n📋 CASE FILE:")
        if cf.get("summary"):
            print(f"   {cf['summary']}")
        if cf.get("buy_box_fit", {}).get("score"):
            print(f"   Buy-Box Score: {cf['buy_box_fit']['score']}")
        if cf.get("risk_flags"):
            print(f"   Risk Flags: {', '.join(cf['risk_flags'])}")
        if cf.get("open_questions"):
            print("   Open Questions:")
            for q in cf["open_questions"][:3]:
                print(f"     • {q}")

    # Alerts
    if status.get("alerts"):
        print("\n⚠️  ALERTS:")
        for alert in status["alerts"]:
            severity_icon = "🔴" if alert["severity"] == "high" else "🟡"
            print(f"   {severity_icon} {alert['message']}")

    # Pending actions
    actions = status.get("pending_actions", [])
    if actions:
        print("\n📅 NEXT ACTIONS:")
        for action in actions[:5]:
            due_marker = "⚡ OVERDUE" if action["is_due"] else f"in {action['days_until']} days"
            print(f"   [{action['priority']}] {action['type']}: {due_marker}")
            print(f"      Scheduled: {action['scheduled_for']}")
    else:
        print("\n📅 NEXT ACTIONS: None scheduled")

    # Recent events
    events = status.get("recent_events", [])
    if events:
        print(f"\n📜 RECENT ACTIVITY ({status.get('event_count', 0)} total events):")
        for event in events[:5]:
            print(f"   [{event['timestamp'][:10]}] {event['summary']}")

    print("\n" + "=" * 70)


def cmd_status(args):
    """Handle status command"""
    status = get_deal_status(args.deal_id)

    if args.json:
        print(json.dumps(status, indent=2, default=str))
    else:
        print_status_human(status)


def cmd_pipeline(args):
    """Show pipeline overview"""
    registry = DealRegistry(REGISTRY_PATH)
    action_queue = DeferredActionQueue()

    # Get all active deals
    deals = registry.list_deals(status="active")

    # Group by stage
    stage_counts: Dict[str, List] = {}
    for deal in deals:
        stage = deal.stage
        if stage not in stage_counts:
            stage_counts[stage] = []
        stage_counts[stage].append(deal)

    # Stage order
    stage_order = [
        "inbound", "screening", "qualified", "loi", "diligence",
        "closing", "integration", "operations", "growth", "exit_planning"
    ]

    print("\n" + "=" * 70)
    print("DEAL PIPELINE OVERVIEW")
    print("=" * 70)

    total = 0
    for stage in stage_order:
        deals_in_stage = stage_counts.get(stage, [])
        count = len(deals_in_stage)
        total += count

        if count > 0:
            print(f"\n{stage.upper()}: {count} deal(s)")
            for deal in deals_in_stage[:5]:
                days = _days_ago(deal.updated_at)
                stale = " ⚠️ STALE" if days > 30 else ""
                print(f"   • {deal.deal_id}: {deal.canonical_name[:35]}{stale}")
            if len(deals_in_stage) > 5:
                print(f"   ... and {len(deals_in_stage) - 5} more")

    # Summary
    print(f"\n{'=' * 70}")
    print(f"TOTAL ACTIVE DEALS: {total}")

    # Due actions
    due_actions = action_queue.get_due_actions()
    if due_actions:
        print(f"\n⚠️  OVERDUE ACTIONS: {len(due_actions)}")
        for action in due_actions[:5]:
            print(f"   • {action.deal_id}: {action.action_type}")

    print("=" * 70 + "\n")


def main():
    parser = argparse.ArgumentParser(
        description="Deal Status CLI - Answer 'What's the status and what's next?'",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s status DEAL-2025-001         # Full status for a deal
  %(prog)s status DEAL-2025-001 --json  # JSON output
  %(prog)s status "teamlogic"           # Search by name
  %(prog)s pipeline                     # Pipeline overview
"""
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # status
    status_p = subparsers.add_parser("status", help="Get deal status")
    status_p.add_argument("deal_id", help="Deal ID or search term")
    status_p.add_argument("--json", action="store_true", help="Output as JSON")

    # pipeline
    subparsers.add_parser("pipeline", help="Show pipeline overview")

    args = parser.parse_args()

    if args.command == "status":
        cmd_status(args)
    elif args.command == "pipeline":
        cmd_pipeline(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
