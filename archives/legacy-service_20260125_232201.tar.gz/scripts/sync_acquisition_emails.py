#!/usr/bin/env python3
"""
Email-to-DataRoom Sync (v2 - IMAP Edition)

!!! DEPRECATED !!!
This script is superseded by the new email_ingestion pipeline.
Use: cd /home/zaks/scripts/email_ingestion && make ingest

To re-enable this script, set: EMAIL_INGESTION_LEGACY_ENABLED=true
Otherwise, this script will exit early with a warning.

---

Monitors Gmail for acquisition-related emails and automatically:
- Fetches emails via IMAP (standalone, no MCP dependency)
- Creates deal folders for new opportunities
- Downloads attachments (PDFs, Word docs, Excel files)
- Extracts text from PDFs/Office docs for RAG indexing
- Follows public links to download CIMs/documents
- Indexes content to RAG
- Generates per-email manifests and intake logs

Usage:
  ./sync_acquisition_emails.py              # Normal run (IMAP mode)
  ./sync_acquisition_emails.py --dry-run    # Preview without changes
  ./sync_acquisition_emails.py --force      # Re-process all (ignore cache)
  ./sync_acquisition_emails.py --hours 24   # Override search window
  ./sync_acquisition_emails.py --setup      # Create credentials template

Cron: DISABLED - Use email_ingestion pipeline instead

Credentials: /home/zaks/.config/email_sync.env
"""

import argparse
import csv
import email
import hashlib
import imaplib
import json
import logging
import os
import re
import requests
import subprocess
import sys
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta
from email.header import decode_header
from email.utils import parsedate_to_datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
from urllib.parse import urlparse
import base64

# Deal Registry integration
try:
    from deal_registry import DealRegistry, DealMatcher, EmailContent
    REGISTRY_AVAILABLE = True
except ImportError:
    REGISTRY_AVAILABLE = False
    logging.warning("deal_registry module not available, using legacy matching")

try:
    import fcntl  # type: ignore
except Exception:  # pragma: no cover
    fcntl = None

# ============================================================
# Configuration
# ============================================================

CONFIG = {
    "credentials_file": "/home/zaks/.config/email_sync.env",
    "broker_tracker_path": "/home/zaks/DataRoom/03-DEAL-SOURCES/BROKER-TRACKER.csv",
    "dataroom_path": "/home/zaks/DataRoom",
    "inbound_path": "/home/zaks/DataRoom/00-PIPELINE/Inbound",
    "screening_path": "/home/zaks/DataRoom/00-PIPELINE/Screening",
    "registry_path": "/home/zaks/DataRoom/.deal-registry/deal_registry.json",
    "downloads_path": "/mnt/c/Users/mzsai/Downloads",  # Windows Downloads folder
    "cache_dir": "/home/zaks/.cache",
    "log_dir": "/home/zaks/logs",
    "rag_api_url": os.getenv("RAG_API_URL", "http://localhost:8052/rag/add"),
    "crawl4ai_url": os.getenv("CRAWL4AI_URL", "http://localhost:8051"),
    "search_hours": 4,  # Look back 4 hours (2x cron interval)
    "max_attachment_size_mb": 50,
    "imap_server": "imap.gmail.com",
    "imap_port": 993,
}

ACQUISITION_KEYWORDS = [
    "CIM", "teaser", "NDA", "listing", "opportunity",
    "acquisition", "executive summary", "confidential memorandum",
    "business for sale", "asking price", "EBITDA", "SDE",
    "seller financing", "deal flow", "investment opportunity",
]

ATTACHMENT_EXTENSIONS = {".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx"}

# Domains requiring authentication - skip these
SKIP_DOMAINS = [
    "docusign.com", "adobesign.com", "hellosign.com",
    "pandadoc.com", "zoho.com", "tupelo.ai",
    "vestedbb.com", "axial.net",
]

# Subfolder classification patterns
SUBFOLDER_PATTERNS = {
    "01-NDA": ["nda", "non-disclosure", "confidentiality", "mutual agreement"],
    "02-CIM": ["cim", "confidential information memorandum", "teaser",
               "executive summary", "offering memorandum", "deal summary",
               "business summary", "investment summary"],
    "03-Financials": ["financial", "p&l", "profit", "loss", "tax return",
                      "balance sheet", "income statement", "cash flow",
                      "revenue", "ebitda", "trailing"],
    "04-Operations": ["operations", "sop", "procedures", "employee",
                      "org chart", "organizational", "process"],
    "05-Legal": ["contract", "agreement", "lease", "license", "legal",
                 "corporate", "articles", "bylaws"],
}

# Characters not allowed in filenames (Windows/SharePoint compatible)
INVALID_FILENAME_CHARS = '<>:"/\\|?*'
CONTROL_CHARS = '\r\n\t\x00\x01\x02\x03\x04\x05\x06\x07\x08\x0b\x0c\x0e\x0f'


def sanitize_filename(filename: str) -> str:
    """Sanitize filename to be compatible with Windows/SharePoint"""
    # Remove control characters
    for char in CONTROL_CHARS:
        filename = filename.replace(char, '')
    # Replace invalid characters with underscore
    for char in INVALID_FILENAME_CHARS:
        filename = filename.replace(char, '_')
    # Remove leading/trailing spaces and dots
    filename = filename.strip(' .')
    # Collapse multiple underscores
    while '__' in filename:
        filename = filename.replace('__', '_')
    return filename

# ============================================================
# Credentials Management
# ============================================================

def load_credentials() -> Dict[str, str]:
    """Load credentials from env file"""
    creds = {}
    creds_file = Path(CONFIG["credentials_file"])

    if not creds_file.exists():
        return creds

    with open(creds_file, 'r') as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#') and '=' in line:
                key, value = line.split('=', 1)
                creds[key.strip()] = value.strip().strip('"\'')

    return creds

def create_credentials_template():
    """Create credentials template file"""
    template = """# Email Sync Credentials
# Keep this file secure and never commit to git!

# Gmail IMAP Settings
# To use Gmail with IMAP, you need an App Password:
# 1. Go to https://myaccount.google.com/security
# 2. Enable 2-Factor Authentication if not already
# 3. Go to App Passwords (search for it)
# 4. Generate a new app password for "Mail"
# 5. Copy the 16-character password below

GMAIL_EMAIL=your-email@gmail.com
GMAIL_APP_PASSWORD=xxxx-xxxx-xxxx-xxxx

# Optional: Custom IMAP server (defaults to Gmail)
# IMAP_SERVER=imap.gmail.com
# IMAP_PORT=993
"""

    creds_file = Path(CONFIG["credentials_file"])
    creds_file.parent.mkdir(parents=True, exist_ok=True)

    if creds_file.exists():
        print(f"Credentials file already exists: {creds_file}")
        print("Edit it manually to update credentials.")
        return False

    with open(creds_file, 'w') as f:
        f.write(template)

    # Secure permissions
    os.chmod(creds_file, 0o600)

    print(f"Created credentials template: {creds_file}")
    print("\nNext steps:")
    print("1. Edit the file and add your Gmail address")
    print("2. Generate an App Password at https://myaccount.google.com/apppasswords")
    print("3. Add the App Password to the file")
    print("4. Run the sync again")

    return True

# ============================================================
# Data Classes
# ============================================================

@dataclass
class BrokerInfo:
    """Broker record from BROKER-TRACKER.csv"""
    name: str
    company: str
    email: str
    phone: str = ""
    sectors: List[str] = field(default_factory=list)
    quality_rating: str = "MEDIUM"
    notes: str = ""

@dataclass
class AttachmentInfo:
    """Downloaded attachment info"""
    filename: str
    original_filename: str
    save_path: str
    size_bytes: int
    file_hash: str
    mime_type: str
    subfolder: str
    text_extracted: bool = False
    text_path: Optional[str] = None
    ocr_applied: bool = False
    ocr_pdf_path: Optional[str] = None
    tables_extracted: bool = False
    tables_paths: List[str] = field(default_factory=list)

@dataclass
class EmailRecord:
    """Processed email record"""
    message_id: str
    thread_id: str
    subject: str
    sender: str
    sender_name: str
    received_date: str
    body_text: str
    body_html: str
    body_hash: str
    attachments: List[AttachmentInfo] = field(default_factory=list)
    extracted_links: List[str] = field(default_factory=list)
    matched_broker: Optional[str] = None
    matched_keywords: List[str] = field(default_factory=list)
    deal_folder: Optional[str] = None
    status: str = "new"
    processed_at: Optional[str] = None
    error_message: Optional[str] = None
    run_id: Optional[str] = None
    email_markdown_path: Optional[str] = None

@dataclass
class SyncStats:
    """Statistics for sync run"""
    run_id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    run_timestamp: str = field(default_factory=lambda: datetime.now().astimezone().isoformat())
    emails_fetched: int = 0
    emails_matched: int = 0
    emails_processed: int = 0
    emails_skipped: int = 0
    emails_failed: int = 0
    new_deals_created: int = 0
    attachments_downloaded: int = 0
    attachments_text_extracted: int = 0
    links_crawled: int = 0
    files_indexed: int = 0
    pdfs_ocr_applied: int = 0
    tables_csv_written: int = 0
    duration_seconds: float = 0
    errors: List[str] = field(default_factory=list)
    broker_activity: Dict[str, int] = field(default_factory=dict)
    deals_updated: List[str] = field(default_factory=list)
    zakops_manifests_analyzed: int = 0
    zakops_errors: int = 0

# ============================================================
# Document Text Extraction
# ============================================================

class DocumentExtractor:
    """Extract text from PDF and Office documents"""

    @staticmethod
    def _env_int(name: str, default: int) -> int:
        raw = os.getenv(name)
        if not raw:
            return default
        try:
            return int(raw)
        except Exception:
            return default

    @staticmethod
    def _env_float(name: str, default: float) -> float:
        raw = os.getenv(name)
        if not raw:
            return default
        try:
            return float(raw)
        except Exception:
            return default

    @staticmethod
    def _env_bool(name: str, default: bool = False) -> bool:
        raw = os.getenv(name)
        if raw is None:
            return default
        return raw.strip().lower() in {"1", "true", "yes", "y", "on"}

    @staticmethod
    def _clean_table_cell(cell: Any) -> str:
        if cell is None:
            return ""
        if isinstance(cell, str):
            return re.sub(r"\s+", " ", cell).strip()
        return str(cell)

    @classmethod
    def _table_has_content(cls, table: Any) -> bool:
        if not table:
            return False
        for row in table:
            if not row:
                continue
            for cell in row:
                if cls._clean_table_cell(cell):
                    return True
        return False

    @classmethod
    def extract_pdf_tables_to_csv(
        cls,
        file_path: str,
        *,
        output_dir: str,
        base_name: str,
        max_pages: Optional[int] = None,
        max_tables: Optional[int] = None,
    ) -> List[str]:
        """Extract tabular data from a PDF into CSV files (best-effort)."""
        try:
            import pdfplumber
        except ImportError:
            logging.warning("pdfplumber not installed. Install: pip install pdfplumber")
            return []

        out_dir = Path(output_dir)
        out_dir.mkdir(parents=True, exist_ok=True)

        max_pages = max_pages if max_pages is not None else cls._env_int("EMAIL_SYNC_PDF_TABLE_MAX_PAGES", 60)
        max_tables = max_tables if max_tables is not None else cls._env_int("EMAIL_SYNC_PDF_TABLE_MAX_TABLES", 80)

        written: List[str] = []
        try:
            with pdfplumber.open(file_path) as pdf:
                pages = pdf.pages
                if max_pages > 0:
                    pages = pages[:max_pages]

                for page_idx, page in enumerate(pages):
                    try:
                        tables = page.extract_tables() or []
                    except Exception as e:
                        logging.debug(f"pdfplumber table extraction failed ({file_path} page {page_idx+1}): {e}")
                        continue

                    for table_idx, table in enumerate(tables):
                        if len(written) >= max_tables:
                            return written
                        if not cls._table_has_content(table):
                            continue

                        csv_path = out_dir / f"{base_name}_p{page_idx+1:03}_t{table_idx+1:02}.csv"
                        try:
                            with open(csv_path, "w", newline="", encoding="utf-8") as f:
                                writer = csv.writer(f)
                                for row in table:
                                    if row is None:
                                        continue
                                    writer.writerow([cls._clean_table_cell(c) for c in row])
                            written.append(str(csv_path))
                        except Exception as e:
                            logging.debug(f"Failed to write CSV {csv_path}: {e}")
                            continue

            return written

        except Exception as e:
            logging.debug(f"Failed to extract tables from {file_path}: {e}")
            return []

    @classmethod
    def _extract_pdf_text_with_stats(cls, file_path: str) -> Tuple[Optional[str], Dict[str, Any]]:
        stats: Dict[str, Any] = {
            "engine": None,
            "page_count": None,
            "pages_with_text": None,
            "total_chars": None,
        }

        # Try PyMuPDF (fitz) first - best quality
        try:
            import fitz  # PyMuPDF
        except ImportError:
            fitz = None

        if fitz is not None:
            doc = None
            try:
                doc = fitz.open(file_path)
                page_count = int(getattr(doc, "page_count", 0) or 0)
                pages_with_text = 0
                total_chars = 0
                text_parts: List[str] = []

                for page in doc:
                    page_text = page.get_text() or ""
                    stripped = page_text.strip()
                    if stripped:
                        text_parts.append(stripped)
                    if len(stripped) >= 20:
                        pages_with_text += 1
                        total_chars += len(stripped)

                text = "\n".join(text_parts).strip()
                stats.update(
                    {
                        "engine": "pymupdf",
                        "page_count": page_count,
                        "pages_with_text": pages_with_text,
                        "total_chars": total_chars,
                    }
                )
                return (text if text else None, stats)
            except Exception as e:
                stats.update({"engine": "pymupdf", "error": f"pymupdf:{e}"})
            finally:
                if doc is not None:
                    try:
                        doc.close()
                    except Exception:
                        pass

        # Try pdfplumber as fallback
        try:
            import pdfplumber
            with pdfplumber.open(file_path) as pdf:
                pages_with_text = 0
                total_chars = 0
                text_parts = []
                for page in pdf.pages:
                    page_text = page.extract_text() or ""
                    stripped = page_text.strip()
                    if stripped:
                        text_parts.append(stripped)
                    if len(stripped) >= 20:
                        pages_with_text += 1
                        total_chars += len(stripped)
                text = "\n".join(text_parts).strip()
                stats.update(
                    {
                        "engine": "pdfplumber",
                        "page_count": len(pdf.pages),
                        "pages_with_text": pages_with_text,
                        "total_chars": total_chars,
                    }
                )
                return (text if text else None, stats)
        except ImportError:
            pass
        except Exception as e:
            stats.update({"engine": "pdfplumber", "error": f"pdfplumber:{e}"})

        # Try PyPDF2 as last resort
        try:
            from PyPDF2 import PdfReader
            reader = PdfReader(file_path)
            pages_with_text = 0
            total_chars = 0
            text_parts = []
            for page in reader.pages:
                page_text = page.extract_text() or ""
                stripped = page_text.strip()
                if stripped:
                    text_parts.append(stripped)
                if len(stripped) >= 20:
                    pages_with_text += 1
                    total_chars += len(stripped)
            text = "\n".join(text_parts).strip()
            stats.update(
                {
                    "engine": "pypdf2",
                    "page_count": len(reader.pages),
                    "pages_with_text": pages_with_text,
                    "total_chars": total_chars,
                }
            )
            return (text if text else None, stats)
        except ImportError:
            pass
        except Exception as e:
            stats.update({"engine": "pypdf2", "error": f"pypdf2:{e}"})

        logging.warning("No PDF library available. Install: pip install PyMuPDF")
        return None, stats

    @classmethod
    def _should_attempt_ocr(cls, extracted_text: Optional[str], stats: Dict[str, Any]) -> bool:
        if not extracted_text or not extracted_text.strip():
            return True

        text_len = len(extracted_text.strip())
        min_chars = cls._env_int("EMAIL_SYNC_PDF_SCANNED_TEXT_THRESHOLD", 200)
        min_text_page_ratio = cls._env_float("EMAIL_SYNC_PDF_TEXT_PAGE_RATIO_THRESHOLD", 0.25)

        page_count = stats.get("page_count")
        pages_with_text = stats.get("pages_with_text")

        if text_len < min_chars:
            return True

        if (
            page_count is not None
            and pages_with_text is not None
            and page_count >= 3
            and (pages_with_text / max(1, page_count)) < min_text_page_ratio
            and text_len < 2000
        ):
            return True

        return False

    @classmethod
    def _run_ocrmypdf(
        cls,
        input_pdf: str,
        output_pdf: str,
        sidecar_txt: str,
        *,
        timeout_seconds: int,
    ) -> Tuple[bool, str]:
        lang = (os.getenv("EMAIL_SYNC_OCR_LANG", "eng") or "eng").strip()
        jobs = max(1, cls._env_int("EMAIL_SYNC_OCR_JOBS", 1))

        cmd = [
            "ocrmypdf",
            "--skip-text",
            "--deskew",
            "--rotate-pages",
            "--sidecar",
            sidecar_txt,
            "--jobs",
            str(jobs),
            "-l",
            lang,
            input_pdf,
            output_pdf,
        ]

        try:
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout_seconds)
        except FileNotFoundError:
            return False, "ocrmypdf not found on PATH"
        except subprocess.TimeoutExpired:
            return False, f"timeout after {timeout_seconds}s"
        except Exception as e:
            return False, str(e)

        if proc.returncode != 0:
            stderr = (proc.stderr or proc.stdout or "").strip()
            return False, stderr[:2000] if stderr else f"ocrmypdf exited {proc.returncode}"

        return True, ""

    @classmethod
    def extract_pdf_text_with_ocr_and_tables(
        cls,
        file_path: str,
        *,
        ocr_output_dir: Optional[str] = None,
        tables_output_dir: Optional[str] = None,
        enable_table_extraction: bool = True,
    ) -> Tuple[Optional[str], Dict[str, Any]]:
        """Extract text from PDF; if likely scanned, OCR and optionally extract tables."""
        extracted_text, stats = cls._extract_pdf_text_with_stats(file_path)

        meta: Dict[str, Any] = {
            "initial_engine": stats.get("engine"),
            "page_count": stats.get("page_count"),
            "pages_with_text": stats.get("pages_with_text"),
            "ocr_applied": False,
            "ocr_pdf_path": None,
            "tables_paths": [],
        }

        if not cls._env_bool("EMAIL_SYNC_ENABLE_OCR", True):
            meta["final_engine"] = meta["initial_engine"]
            return extracted_text, meta

        if cls._should_attempt_ocr(extracted_text, stats):
            input_path = Path(file_path)
            ocr_dir = Path(ocr_output_dir) if ocr_output_dir else (input_path.parent / "_ocr")
            ocr_dir.mkdir(parents=True, exist_ok=True)

            ocr_pdf_path = ocr_dir / f"{input_path.stem}_OCR.pdf"
            sidecar_txt_path = ocr_dir / f"{input_path.stem}_OCR.txt"

            timeout_seconds = cls._env_int("EMAIL_SYNC_OCR_TIMEOUT_SECONDS", 300)
            ok, err = cls._run_ocrmypdf(
                str(input_path),
                str(ocr_pdf_path),
                str(sidecar_txt_path),
                timeout_seconds=timeout_seconds,
            )
            if ok:
                meta["ocr_applied"] = True
                meta["ocr_pdf_path"] = str(ocr_pdf_path)
                meta["final_engine"] = "ocrmypdf"

                try:
                    ocr_text = sidecar_txt_path.read_text(encoding="utf-8", errors="replace").strip()
                except Exception as e:
                    logging.debug(f"Failed to read OCR sidecar ({sidecar_txt_path}): {e}")
                    ocr_text = ""

                if ocr_text:
                    extracted_text = ocr_text

                extract_tables_always = cls._env_bool("EMAIL_SYNC_PDF_EXTRACT_TABLES_ALWAYS", False)
                if enable_table_extraction and (extract_tables_always or meta["ocr_applied"]):
                    tables_dir = Path(tables_output_dir) if tables_output_dir else (input_path.parent / "_tables")
                    table_paths = cls.extract_pdf_tables_to_csv(
                        str(ocr_pdf_path if ocr_pdf_path.exists() else input_path),
                        output_dir=str(tables_dir),
                        base_name=input_path.stem,
                    )
                    meta["tables_paths"] = table_paths
            else:
                meta["final_engine"] = meta["initial_engine"]
                if err:
                    meta["ocr_error"] = err
        else:
            meta["final_engine"] = meta["initial_engine"]

        return extracted_text, meta

    @staticmethod
    def extract_pdf_text(file_path: str) -> Optional[str]:
        """Extract text from PDF using available libraries"""
        try:
            text, _stats = DocumentExtractor._extract_pdf_text_with_stats(file_path)
            return text

        except Exception as e:
            logging.warning(f"Failed to extract PDF text from {file_path}: {e}")
            return None

    @staticmethod
    def extract_docx_text(file_path: str) -> Optional[str]:
        """Extract text from Word documents"""
        try:
            from docx import Document
            doc = Document(file_path)
            text = "\n".join([para.text for para in doc.paragraphs])
            return text.strip() if text.strip() else None
        except ImportError:
            logging.warning("python-docx not installed. Install: pip install python-docx")
            return None
        except Exception as e:
            logging.warning(f"Failed to extract DOCX text from {file_path}: {e}")
            return None

    @staticmethod
    def extract_xlsx_text(file_path: str) -> Optional[str]:
        """Extract text from Excel files"""
        try:
            import openpyxl
            wb = openpyxl.load_workbook(file_path, data_only=True)
            text_parts = []
            for sheet in wb.worksheets:
                text_parts.append(f"=== Sheet: {sheet.title} ===")
                for row in sheet.iter_rows(values_only=True):
                    row_text = [str(cell) if cell is not None else "" for cell in row]
                    if any(row_text):
                        text_parts.append("\t".join(row_text))
            wb.close()
            return "\n".join(text_parts) if text_parts else None
        except ImportError:
            logging.warning("openpyxl not installed. Install: pip install openpyxl")
            return None
        except Exception as e:
            logging.warning(f"Failed to extract XLSX text from {file_path}: {e}")
            return None

    @classmethod
    def extract_text(cls, file_path: str) -> Optional[str]:
        """Extract text from document based on extension"""
        ext = Path(file_path).suffix.lower()

        if ext == '.pdf':
            return cls.extract_pdf_text(file_path)
        elif ext in ('.doc', '.docx'):
            return cls.extract_docx_text(file_path)
        elif ext in ('.xls', '.xlsx'):
            return cls.extract_xlsx_text(file_path)
        else:
            return None

# ============================================================
# IMAP Gmail Client
# ============================================================

class IMAPGmailClient:
    """Gmail IMAP client for fetching emails"""

    def __init__(self, email_address: str, app_password: str,
                 server: str = "imap.gmail.com", port: int = 993):
        self.email_address = email_address
        self.app_password = app_password
        self.server = server
        self.port = port
        self.connection: Optional[imaplib.IMAP4_SSL] = None

    def connect(self) -> bool:
        """Connect to Gmail IMAP"""
        try:
            self.connection = imaplib.IMAP4_SSL(self.server, self.port)
            self.connection.login(self.email_address, self.app_password)
            logging.info(f"Connected to Gmail as {self.email_address}")
            return True
        except Exception as e:
            logging.error(f"Failed to connect to Gmail: {e}")
            return False

    def disconnect(self):
        """Disconnect from Gmail"""
        if self.connection:
            try:
                self.connection.logout()
            except:
                pass
            self.connection = None

    def build_search_criteria(self, broker_emails: List[str], keywords: List[str],
                              hours: int) -> str:
        """Build IMAP search criteria"""
        # IMAP search is limited, we'll do post-filtering
        # For now, search by date only and filter in Python
        since_date = (datetime.now() - timedelta(hours=hours)).strftime("%d-%b-%Y")
        return f'(SINCE {since_date})'

    def search_emails(self, broker_emails: List[str], keywords: List[str],
                      hours: int, max_results: int = 100) -> List[Dict]:
        """Search and fetch matching emails"""
        if not self.connection:
            if not self.connect():
                return []

        try:
            # Select inbox
            self.connection.select('INBOX')

            # Build search criteria
            criteria = self.build_search_criteria(broker_emails, keywords, hours)

            # Search
            _, message_ids = self.connection.search(None, criteria)

            if not message_ids[0]:
                logging.info("No emails found matching date criteria")
                return []

            ids = message_ids[0].split()
            logging.info(f"Found {len(ids)} emails in date range, filtering...")

            # Fetch and filter emails
            emails = []
            keywords_lower = [k.lower() for k in keywords]
            broker_emails_lower = [e.lower() for e in broker_emails]
            broker_domains = set(e.split('@')[1] for e in broker_emails_lower if '@' in e)

            for msg_id in ids[-max_results:]:  # Most recent first
                email_data = self._fetch_email(msg_id)
                if email_data:
                    # Check if matches criteria
                    sender_email = self._extract_email(email_data.get('from', '')).lower()
                    sender_domain = sender_email.split('@')[1] if '@' in sender_email else ''
                    subject_lower = email_data.get('subject', '').lower()

                    # Match by broker email or domain
                    broker_match = (
                        sender_email in broker_emails_lower or
                        sender_domain in broker_domains
                    )

                    # Match by keyword in subject
                    keyword_match = any(kw in subject_lower for kw in keywords_lower)

                    if broker_match or keyword_match:
                        email_data['match_reason'] = 'broker' if broker_match else 'keyword'
                        emails.append(email_data)

            logging.info(f"Filtered to {len(emails)} matching emails")
            return emails

        except Exception as e:
            logging.error(f"Error searching emails: {e}")
            return []

    def _fetch_email(self, msg_id: bytes) -> Optional[Dict]:
        """Fetch a single email by ID"""
        try:
            _, msg_data = self.connection.fetch(msg_id, '(RFC822)')

            if not msg_data or not msg_data[0]:
                return None

            raw_email = msg_data[0][1]
            msg = email.message_from_bytes(raw_email)

            # Parse headers
            subject = self._decode_header(msg.get('Subject', ''))
            sender = self._decode_header(msg.get('From', ''))
            date_str = msg.get('Date', '')
            message_id = msg.get('Message-ID', str(msg_id))

            # Parse date
            try:
                received_date = parsedate_to_datetime(date_str).isoformat()
            except:
                received_date = date_str

            # Extract body and attachments
            body_text, body_html, attachments = self._extract_content(msg)

            return {
                'id': message_id,
                'message_id': message_id,
                'thread_id': msg.get('Thread-Index', message_id),
                'subject': subject,
                'from': sender,
                'date': received_date,
                'body_text': body_text,
                'body_html': body_html,
                'attachments': attachments,
                'raw_size': len(raw_email),
            }

        except Exception as e:
            logging.warning(f"Failed to fetch email {msg_id}: {e}")
            return None

    def _decode_header(self, header: str) -> str:
        """Decode email header"""
        if not header:
            return ""

        decoded_parts = decode_header(header)
        result = []
        for part, charset in decoded_parts:
            if isinstance(part, bytes):
                try:
                    result.append(part.decode(charset or 'utf-8', errors='replace'))
                except:
                    result.append(part.decode('utf-8', errors='replace'))
            else:
                result.append(str(part))
        return ' '.join(result)

    def _extract_email(self, sender: str) -> str:
        """Extract email address from sender string"""
        match = re.search(r'<([^>]+)>', sender)
        if match:
            return match.group(1)
        # Maybe it's just the email
        if '@' in sender:
            return sender.strip()
        return sender

    def _extract_content(self, msg: email.message.Message) -> Tuple[str, str, List[Dict]]:
        """Extract body text, HTML, and attachments from email"""
        body_text = ""
        body_html = ""
        attachments = []

        if msg.is_multipart():
            for part in msg.walk():
                content_type = part.get_content_type()
                content_disposition = str(part.get("Content-Disposition", ""))

                # Attachment
                if "attachment" in content_disposition or part.get_filename():
                    filename = part.get_filename()
                    if filename:
                        filename = self._decode_header(filename)
                        payload = part.get_payload(decode=True)
                        if payload:
                            attachments.append({
                                'filename': filename,
                                'content_type': content_type,
                                'size': len(payload),
                                'data': payload,
                            })

                # Body text
                elif content_type == "text/plain" and not body_text:
                    payload = part.get_payload(decode=True)
                    if payload:
                        charset = part.get_content_charset() or 'utf-8'
                        try:
                            body_text = payload.decode(charset, errors='replace')
                        except:
                            body_text = payload.decode('utf-8', errors='replace')

                # Body HTML
                elif content_type == "text/html" and not body_html:
                    payload = part.get_payload(decode=True)
                    if payload:
                        charset = part.get_content_charset() or 'utf-8'
                        try:
                            body_html = payload.decode(charset, errors='replace')
                        except:
                            body_html = payload.decode('utf-8', errors='replace')
        else:
            # Not multipart
            content_type = msg.get_content_type()
            payload = msg.get_payload(decode=True)
            if payload:
                charset = msg.get_content_charset() or 'utf-8'
                try:
                    text = payload.decode(charset, errors='replace')
                except:
                    text = payload.decode('utf-8', errors='replace')

                if content_type == "text/html":
                    body_html = text
                else:
                    body_text = text

        return body_text, body_html, attachments

    def search_by_terms(self, search_terms: List[str], days_back: int = 90) -> List[Dict]:
        """Search emails by specific terms (company names, listing IDs, etc.)

        Returns list of matching emails with basic info.
        Used for finding provenance of downloaded documents.
        """
        if not self.connection:
            if not self.connect():
                return []

        try:
            self.connection.select('INBOX')

            # Date range for search
            since_date = (datetime.now() - timedelta(days=days_back)).strftime("%d-%b-%Y")

            all_matches = []
            seen_ids = set()

            # Common words to skip in search (too generic, cause false positives)
            skip_words = {'the', 'and', 'for', 'use', 'new', 'good', 'idea', 'summary',
                         'business', 'document', 'file', 'pdf', 'update', 'overview',
                         'information', 'your', 'our', 'this', 'that', 'with', 'from',
                         'executive', 'technologies', 'services', 'solutions'}

            for term in search_terms:
                if not term or len(str(term)) < 4:
                    continue

                # Clean and sanitize term for IMAP search
                term = re.sub(r'[\n\r\t]', ' ', str(term))  # Remove newlines/tabs
                term = re.sub(r'\s+', ' ', term).strip()  # Normalize whitespace
                term = term.replace('"', '')  # Remove quotes

                # Skip if too short after cleaning
                if len(term) < 4:
                    continue

                # Skip common/generic single words
                if term.lower() in skip_words:
                    continue

                try:
                    # Search in subject and body using IMAP TEXT search
                    criteria = f'(SINCE {since_date} TEXT "{term}")'
                    _, message_ids = self.connection.search(None, criteria)

                    if message_ids[0]:
                        for msg_id in message_ids[0].split()[:5]:  # Limit to 5 per term
                            if msg_id not in seen_ids:
                                seen_ids.add(msg_id)
                                email_data = self._fetch_email_summary(msg_id)
                                if email_data:
                                    email_data['matched_term'] = term
                                    all_matches.append(email_data)
                except Exception as e:
                    logging.debug(f"Search for '{term[:30]}...' failed: {e}")
                    continue

            return all_matches

        except Exception as e:
            logging.error(f"Error in provenance search: {e}")
            return []

    def _fetch_email_summary(self, msg_id: bytes) -> Optional[Dict]:
        """Fetch just email headers (lighter than full fetch)"""
        try:
            _, msg_data = self.connection.fetch(msg_id, '(BODY[HEADER.FIELDS (FROM SUBJECT DATE MESSAGE-ID)])')

            if not msg_data or not msg_data[0]:
                return None

            raw_headers = msg_data[0][1]
            msg = email.message_from_bytes(raw_headers)

            subject = self._decode_header(msg.get('Subject', ''))
            sender = self._decode_header(msg.get('From', ''))
            date_str = msg.get('Date', '')
            message_id = msg.get('Message-ID', str(msg_id))

            # Parse date
            try:
                received_date = parsedate_to_datetime(date_str).isoformat()
            except:
                received_date = date_str

            return {
                'message_id': message_id,
                'subject': subject,
                'from': sender,
                'sender_email': self._extract_email(sender),
                'date': received_date,
            }

        except Exception as e:
            logging.debug(f"Failed to fetch email summary {msg_id}: {e}")
            return None


# ============================================================
# Broker Matcher
# ============================================================

class BrokerMatcher:
    """Match emails against known brokers from BROKER-TRACKER.csv"""

    def __init__(self, csv_path: str):
        self.brokers: Dict[str, BrokerInfo] = {}
        self.broker_domains: Dict[str, List[BrokerInfo]] = {}
        self.load_brokers(csv_path)

    def load_brokers(self, csv_path: str):
        """Parse BROKER-TRACKER.csv into lookup structures"""
        if not Path(csv_path).exists():
            logging.warning(f"Broker tracker not found: {csv_path}")
            return

        with open(csv_path, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                email_addr = row.get('Email', '').strip().lower()
                if not email_addr or '@' not in email_addr:
                    continue

                broker = BrokerInfo(
                    name=row.get('Broker Name', '').strip(),
                    company=row.get('Company', '').strip(),
                    email=email_addr,
                    phone=row.get('Phone', '').strip(),
                    sectors=[s.strip() for s in row.get('Sectors', '').split(',') if s.strip()],
                    quality_rating=row.get('Quality Rating', 'MEDIUM').strip(),
                    notes=row.get('Notes', '').strip(),
                )

                self.brokers[email_addr] = broker

                # Index by domain
                domain = email_addr.split('@')[1]
                if domain not in self.broker_domains:
                    self.broker_domains[domain] = []
                self.broker_domains[domain].append(broker)

        logging.info(f"Loaded {len(self.brokers)} brokers from {csv_path}")

    def match_sender(self, sender_email: str) -> Optional[BrokerInfo]:
        """Find broker matching sender email"""
        email_addr = sender_email.lower().strip()

        # Extract email from "Name <email>" format
        match = re.search(r'<([^>]+)>', email_addr)
        if match:
            email_addr = match.group(1)

        # Try exact match
        if email_addr in self.brokers:
            return self.brokers[email_addr]

        # Try domain match
        if '@' in email_addr:
            domain = email_addr.split('@')[1]
            domain_brokers = self.broker_domains.get(domain, [])
            if domain_brokers:
                return domain_brokers[0]

        return None

    def get_broker_emails(self) -> List[str]:
        """Get all broker email addresses"""
        return list(self.brokers.keys())

# ============================================================
# Deduplication Manager
# ============================================================

class DeduplicationManager:
    """Prevent re-processing of same emails"""

    def __init__(self, cache_dir: str):
        self.cache_file = Path(cache_dir) / "email_sync_processed.json"
        self.processed: Dict[str, dict] = {}
        self.body_hashes: Dict[str, str] = {}
        self.load_cache()

    def load_cache(self):
        """Load processed email IDs and hashes"""
        if self.cache_file.exists():
            try:
                with open(self.cache_file, 'r') as f:
                    data = json.load(f)
                    self.processed = data.get('message_ids', {})
                    self.body_hashes = data.get('body_hashes', {})
                logging.info(f"Loaded {len(self.processed)} processed emails from cache")
            except (json.JSONDecodeError, IOError) as e:
                logging.warning(f"Failed to load cache: {e}")

    def save_cache(self):
        """Persist cache to disk"""
        self.cache_file.parent.mkdir(parents=True, exist_ok=True)
        data = {
            'message_ids': self.processed,
            'body_hashes': self.body_hashes,
            'last_sync': datetime.now().isoformat(),
        }
        with open(self.cache_file, 'w') as f:
            json.dump(data, f, indent=2)

    def is_processed(self, message_id: str, body_hash: Optional[str] = None) -> bool:
        """Check if email already processed"""
        # Normalize message ID
        msg_id = message_id.strip('<>').lower()

        if msg_id in self.processed:
            return True
        if body_hash and body_hash in self.body_hashes:
            return True
        return False

    def mark_processed(self, record: EmailRecord):
        """Record email as processed"""
        msg_id = record.message_id.strip('<>').lower()
        self.processed[msg_id] = {
            'processed_at': record.processed_at,
            'deal_folder': record.deal_folder,
            'status': record.status,
            'subject': record.subject[:100],
        }
        if record.body_hash:
            self.body_hashes[record.body_hash] = msg_id

# ============================================================
# Deal Manager
# ============================================================

class DealManager:
    """Match emails to existing deals or create new ones"""

    DEAL_SUBFOLDERS = [
        "01-NDA", "02-CIM", "03-Financials", "04-Operations",
        "05-Legal", "06-Analysis", "07-Correspondence",
        "08-LOI-Offer", "09-Closing"
    ]

    def __init__(self, dataroom_path: str, inbound_path: str, screening_path: str,
                 registry_path: str = None):
        self.dataroom_path = Path(dataroom_path)
        self.inbound_path = Path(inbound_path)
        self.screening_path = Path(screening_path)
        self.existing_deals = self.scan_existing_deals()

        # Initialize deal registry if available
        self.registry = None
        self.matcher = None
        if REGISTRY_AVAILABLE and registry_path:
            try:
                self.registry = DealRegistry(registry_path)
                self.matcher = DealMatcher(self.registry)
                logging.info(f"Deal registry loaded: {len(self.registry.deals)} deals")
            except Exception as e:
                logging.warning(f"Failed to load deal registry: {e}")

    def scan_existing_deals(self) -> Dict[str, str]:
        """Build index of existing deal folders"""
        deals = {}

        for scan_path in [self.inbound_path, self.screening_path]:
            if scan_path.exists():
                for folder in scan_path.iterdir():
                    if folder.is_dir() and not folder.name.startswith('_'):
                        deals[folder.name.lower()] = str(folder)

        logging.info(f"Found {len(deals)} existing deal folders")
        return deals

    def extract_deal_indicators(self, record: EmailRecord) -> Dict:
        """Extract deal name hints from email content"""
        indicators = {
            'company_names': [],
            'listing_ids': [],
            'locations': [],
            'sectors': [],
        }

        text = f"{record.subject} {record.body_text[:1000]}".lower()

        # Look for listing IDs
        listing_matches = re.findall(r'listing\s*[#:]?\s*(\d{4,})', text, re.IGNORECASE)
        indicators['listing_ids'] = listing_matches

        # Look for sector indicators
        sector_patterns = [
            (r'\bmsp\b', 'MSP'),
            (r'\bmanaged service', 'MSP'),
            (r'\bit service', 'IT-Services'),
            (r'\bsaas\b', 'SaaS'),
            (r'\becommerce\b', 'Ecommerce'),
            (r'\be-commerce\b', 'Ecommerce'),
            (r'\bsoftware\b', 'Software'),
            (r'\bcybersecurity\b', 'Cybersecurity'),
            (r'\bdigital marketing\b', 'Digital-Marketing'),
        ]
        for pattern, sector in sector_patterns:
            if re.search(pattern, text, re.IGNORECASE):
                indicators['sectors'].append(sector)

        # Look for location indicators
        state_patterns = [
            (r'\btexas\b', 'Texas'), (r'\btx\b', 'Texas'),
            (r'\bcalifornia\b', 'California'),
            (r'\bflorida\b', 'Florida'),
            (r'\bnew york\b', 'NewYork'),
        ]
        for pattern, location in state_patterns:
            if re.search(pattern, text, re.IGNORECASE):
                indicators['locations'].append(location)

        return indicators

    def generate_deal_name(self, record: EmailRecord, indicators: Dict,
                          broker: Optional[BrokerInfo]) -> str:
        """Generate a deal folder name from email content"""
        parts = []

        # Clean subject
        subject = record.subject
        subject = re.sub(r'^(re:|fw:|fwd:)\s*', '', subject, flags=re.IGNORECASE)
        subject = re.sub(r'^(new listing|new opportunity|deal alert)[\s:-]*', '',
                        subject, flags=re.IGNORECASE)

        # Take first meaningful words
        clean_subject = re.sub(r'[^\w\s-]', '', subject)
        words = [w for w in clean_subject.split() if len(w) > 2][:4]
        if words:
            parts.append('-'.join(w.title() for w in words))

        # Add sector
        if indicators.get('sectors'):
            parts.append(indicators['sectors'][0])
        elif broker and broker.sectors:
            parts.append(broker.sectors[0].replace(' ', '-').replace('/', '-'))

        # Add year
        parts.append(str(datetime.now().year))

        # Create name
        name = '-'.join(parts) if parts else f"NewDeal-{datetime.now().strftime('%Y%m%d-%H%M')}"
        name = re.sub(r'-+', '-', name).strip('-')

        return name

    def match_to_existing(self, record: EmailRecord, indicators: Dict,
                          broker: Optional[BrokerInfo] = None) -> Optional[str]:
        """Try to match to existing deal folder using registry first, then legacy"""
        # Try registry matching first (more robust)
        if self.registry and self.matcher:
            try:
                content = EmailContent(
                    subject=record.subject,
                    body=record.body_text,
                    sender=record.sender,
                    message_id=record.message_id,
                    thread_id=record.thread_id,
                )
                result = self.matcher.match(content)

                if result.matched and result.deal_id:
                    deal = self.registry.get_deal(result.deal_id)
                    if deal and deal.folder_path:
                        logging.info(f"Registry matched: {deal.canonical_name} "
                                   f"(via {result.match_type}, conf={result.confidence:.2f})")
                        # Auto-learn new aliases from this email
                        if result.suggested_aliases:
                            for alias, atype in result.suggested_aliases:
                                self.registry.add_alias(result.deal_id, alias, atype,
                                                       source="email_auto")
                            self.registry.save()
                        return deal.folder_path

                if result.action == 'reject':
                    logging.info(f"Registry rejected as junk: {result.reason}")
                    return "JUNK"

            except Exception as e:
                logging.warning(f"Registry matching failed: {e}")

        # Fallback to legacy matching (2+ word overlap)
        return self._legacy_match_to_existing(record)

    def _legacy_match_to_existing(self, record: EmailRecord) -> Optional[str]:
        """Legacy matching: 2+ word overlap with deal folder names"""
        subject_lower = record.subject.lower()

        for deal_name, deal_path in self.existing_deals.items():
            deal_words = deal_name.replace('-', ' ').split()
            matches = sum(1 for word in deal_words if word in subject_lower and len(word) > 3)
            if matches >= 2:
                logging.info(f"Legacy matched email to existing deal: {deal_name}")
                return deal_path

        return None

    def create_deal_folder(self, deal_name: str, record: EmailRecord,
                          broker: Optional[BrokerInfo]) -> str:
        """Create new deal folder with standard structure"""
        deal_path = self.inbound_path / deal_name

        # Handle duplicates
        if deal_path.exists():
            counter = 2
            while deal_path.exists():
                deal_path = self.inbound_path / f"{deal_name}-{counter}"
                counter += 1

        # Create structure
        deal_path.mkdir(parents=True, exist_ok=True)
        for subfolder in self.DEAL_SUBFOLDERS:
            (deal_path / subfolder).mkdir(exist_ok=True)

        # Create README
        self._create_deal_readme(deal_path, deal_name, record, broker)

        # Update index
        self.existing_deals[deal_name.lower()] = str(deal_path)

        # Add to MASTER-DEAL-TRACKER.csv and sort
        self._add_to_deal_tracker(deal_name, record, broker)

        # Register in deal registry
        if self.registry:
            try:
                deal_id = self.registry.generate_deal_id()
                registry_broker = None
                if broker:
                    from deal_registry import BrokerInfo as RegBrokerInfo
                    registry_broker = RegBrokerInfo(
                        name=broker.name,
                        email=broker.email,
                        phone=broker.phone,
                        company=broker.company,
                        quality_rating=broker.quality_rating,
                        sectors=broker.sectors,
                    )
                self.registry.create_deal(
                    deal_id=deal_id,
                    canonical_name=deal_name,
                    folder_path=str(deal_path),
                    broker=registry_broker,
                    source="email_sync"
                )
                # Add message_id for thread tracking
                if record.message_id:
                    self.registry.add_email_deal_mapping(record.message_id, deal_id)
                self.registry.save()
                logging.info(f"Registered new deal in registry: {deal_id}")
            except Exception as e:
                logging.warning(f"Failed to register deal in registry: {e}")

        logging.info(f"Created new deal folder: {deal_path}")
        return str(deal_path)

    def _create_deal_readme(self, deal_path: Path, deal_name: str,
                           record: EmailRecord, broker: Optional[BrokerInfo]):
        """Create README.md for new deal folder"""
        today = datetime.now().strftime("%B %d, %Y")

        broker_section = ""
        if broker:
            broker_section = f"""
## BROKER INFORMATION

- **Name:** {broker.name}
- **Company:** {broker.company}
- **Email:** {broker.email}
- **Phone:** {broker.phone}
- **Quality Rating:** {broker.quality_rating}
- **Sectors:** {', '.join(broker.sectors)}
"""

        readme = f"""# {deal_name}

**Deal Status:** New - Inbound
**Date Added:** {today}
**Source:** Email from {record.sender_name or record.sender}

---

## QUICK FACTS

- **Subject:** {record.subject}
- **Received:** {record.received_date}
- **Status:** Awaiting Review

---
{broker_section}
## INITIAL EMAIL SUMMARY

{record.body_text[:800]}{'...' if len(record.body_text) > 800 else ''}

---

## NEXT STEPS

- [ ] Review email and attachments
- [ ] Sign NDA if required
- [ ] Request CIM/financials
- [ ] Schedule introductory call
- [ ] Complete initial screening

---

## FOLDER STRUCTURE

- **01-NDA/** - NDA documents and signatures
- **02-CIM/** - Confidential Information Memorandum
- **03-Financials/** - P&Ls, tax returns, financial analysis
- **04-Operations/** - SOPs, client data, tech stack info
- **05-Legal/** - Contracts, leases, IP documentation
- **06-Analysis/** - Your evaluation, scorecard, models
- **07-Correspondence/** - Email threads, call notes
- **08-LOI-Offer/** - Letter of Intent, negotiation docs
- **09-Closing/** - Purchase agreement, closing documents

---

**Document Control:**
- Created: {today}
- Last Updated: {today}
- Status: Active - New Inbound
"""

        with open(deal_path / "README.md", 'w') as f:
            f.write(readme)

    def _add_to_deal_tracker(self, deal_name: str, record: EmailRecord,
                             broker: Optional[BrokerInfo]):
        """Add new deal to MASTER-DEAL-TRACKER.csv and sort by priority/price"""
        tracker_path = self.dataroom_path / "00-PIPELINE" / "MASTER-DEAL-TRACKER.csv"

        if not tracker_path.exists():
            logging.warning(f"MASTER-DEAL-TRACKER.csv not found at {tracker_path}")
            return

        try:
            # Read existing entries
            rows = []
            with open(tracker_path, 'r', newline='') as f:
                reader = csv.DictReader(f)
                fieldnames = reader.fieldnames
                rows = list(reader)

            # Check if deal already exists
            existing_names = [r.get('Deal Name', '').lower() for r in rows]
            if deal_name.lower() in existing_names:
                logging.info(f"Deal {deal_name} already in tracker, skipping")
                return

            # Extract sector from deal name
            sector = "TBD"
            sector_patterns = ['MSP', 'SaaS', 'IT-Services', 'Software', 'Ecommerce', 'Cybersecurity']
            for s in sector_patterns:
                if s.lower() in deal_name.lower():
                    sector = s
                    break

            # Create new entry
            new_row = {
                'Deal Name': deal_name,
                'Sector': sector,
                'Asking Price': 'TBD',
                'EBITDA': 'TBD',
                'Multiple': 'TBD',
                'Broker': broker.name if broker else 'Unknown',
                'Broker Email': broker.email if broker else '',
                'Broker Phone': broker.phone if broker else '',
                'Date Received': datetime.now().strftime('%Y-%m-%d'),
                'Stage': 'New Inbound',
                'Next Action': 'Review email and respond',
                'Target Close Date': 'TBD',
                'Priority': 'MEDIUM',  # Default priority for new deals
                'Status Notes': f"Auto-added from email: {record.subject[:50]}..."
            }
            rows.append(new_row)

            # Sort by Priority (HIGHEST first) then Asking Price (highest first)
            priority_order = {"HIGHEST": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}

            def parse_price(price_str):
                if not price_str or price_str.upper() == "TBD":
                    return 0
                clean = price_str.replace("$", "").replace(",", "")
                try:
                    return float(clean)
                except:
                    return 0

            sorted_rows = sorted(rows, key=lambda r: (
                priority_order.get(r.get("Priority", "LOW"), 4),
                -parse_price(r.get("Asking Price", "TBD"))
            ))

            # Write back sorted
            with open(tracker_path, 'w', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                writer.writerows(sorted_rows)

            logging.info(f"Added {deal_name} to MASTER-DEAL-TRACKER.csv (sorted)")

        except Exception as e:
            logging.error(f"Failed to update deal tracker: {e}")

    def _add_to_deal_tracker_from_download(self, deal_name: str, filename: str):
        """Add new deal to MASTER-DEAL-TRACKER.csv from downloaded document"""
        tracker_path = self.dataroom_path / "00-PIPELINE" / "MASTER-DEAL-TRACKER.csv"

        if not tracker_path.exists():
            logging.warning(f"MASTER-DEAL-TRACKER.csv not found at {tracker_path}")
            return

        try:
            # Read existing entries
            rows = []
            with open(tracker_path, 'r', newline='') as f:
                reader = csv.DictReader(f)
                fieldnames = reader.fieldnames
                rows = list(reader)

            # Check if deal already exists
            existing_names = [r.get('Deal Name', '').lower() for r in rows]
            if deal_name.lower() in existing_names:
                logging.info(f"Deal {deal_name} already in tracker, skipping")
                return

            # Extract sector from deal name
            sector = "TBD"
            sector_patterns = ['MSP', 'SaaS', 'IT-Services', 'Software', 'Ecommerce', 'Cybersecurity']
            for s in sector_patterns:
                if s.lower() in deal_name.lower():
                    sector = s
                    break

            # Create new entry
            new_row = {
                'Deal Name': deal_name,
                'Sector': sector,
                'Asking Price': 'TBD',
                'EBITDA': 'TBD',
                'Multiple': 'TBD',
                'Broker': 'Unknown',
                'Broker Email': '',
                'Broker Phone': '',
                'Date Received': datetime.now().strftime('%Y-%m-%d'),
                'Stage': 'New Inbound',
                'Next Action': 'Review document and respond',
                'Target Close Date': 'TBD',
                'Priority': 'MEDIUM',  # Default priority for new deals
                'Status Notes': f"Auto-added from download: {filename[:50]}..."
            }
            rows.append(new_row)

            # Sort by Priority (HIGHEST first) then Asking Price (highest first)
            priority_order = {"HIGHEST": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}

            def parse_price(price_str):
                if not price_str or price_str.upper() == "TBD":
                    return 0
                clean = price_str.replace("$", "").replace(",", "")
                try:
                    return float(clean)
                except:
                    return 0

            sorted_rows = sorted(rows, key=lambda r: (
                priority_order.get(r.get("Priority", "LOW"), 4),
                -parse_price(r.get("Asking Price", "TBD"))
            ))

            # Write back sorted
            with open(tracker_path, 'w', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                writer.writerows(sorted_rows)

            logging.info(f"Added {deal_name} to MASTER-DEAL-TRACKER.csv from download (sorted)")

        except Exception as e:
            logging.error(f"Failed to update deal tracker from download: {e}")

    def determine_subfolder(self, filename: str, content_hints: List[str] = None) -> str:
        """Determine which subfolder an attachment belongs in"""
        filename_lower = filename.lower()
        hints_text = ' '.join(content_hints or []).lower()
        combined = f"{filename_lower} {hints_text}"

        for subfolder, patterns in SUBFOLDER_PATTERNS.items():
            for pattern in patterns:
                if pattern in combined:
                    return subfolder

        return "07-Correspondence"


# ============================================================
# Downloads Folder Scanner
# ============================================================

class DownloadsFolderScanner:
    """Scan Windows Downloads folder for business documents and organize in DataRoom"""

    # Business document patterns to look for
    BUSINESS_DOC_PATTERNS = [
        r'(?i)(cim|confidential\s*information|business\s*summary|executive\s*summary)',
        r'(?i)(nda|non.?disclosure|confidentiality)',
        r'(?i)(p[&]?l|profit.?loss|financial|income\s*statement|balance\s*sheet)',
        r'(?i)(teaser|offering\s*memorandum|deal\s*summary)',
        r'(?i)(inquiry|listing|for\s*sale)',
        r'(?i)(tax\s*return|ebitda|revenue)',
        r'(?i)(due\s*diligence|dd\s*checklist)',
        r'(?i)(loi|letter\s*of\s*intent|offer)',
        r'(?i)(contract|agreement|lease)',
    ]

    # File extensions to process
    VALID_EXTENSIONS = {'.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx', '.txt', '.csv'}

    # Files/patterns to ignore
    IGNORE_PATTERNS = [
        r'(?i)^(chrome|firefox|edge|setup|install)',
        r'(?i)\.(exe|msi|dmg|pkg|deb|rpm|zip|tar|gz|7z)$',
        r'(?i)^desktop\.ini$',
        r'(?i)^\.ds_store$',
    ]

    def __init__(self, downloads_path: str, deal_manager: 'DealManager',
                 processed_cache_file: str, dry_run: bool = False,
                 email_client: 'IMAPGmailClient' = None,
                 doc_extractor: 'DocumentExtractor' = None,
                 broker_matcher: 'BrokerMatcher' = None):
        self.downloads_path = Path(downloads_path)
        self.deal_manager = deal_manager
        self.cache_file = Path(processed_cache_file)
        self.dry_run = dry_run
        self.email_client = email_client
        self.doc_extractor = doc_extractor or DocumentExtractor()
        self.broker_matcher = broker_matcher
        self.processed_files = self._load_cache()
        self.stats = {'processed': 0, 'matched': 0, 'new_deals': 0, 'skipped': 0, 'errors': 0,
                      'provenance_found': 0, 'no_provenance': 0}

    def _load_cache(self) -> Dict[str, str]:
        """Load cache of previously processed files"""
        if self.cache_file.exists():
            try:
                with open(self.cache_file, 'r') as f:
                    return json.load(f)
            except:
                return {}
        return {}

    def _save_cache(self):
        """Save processed files cache"""
        if not self.dry_run:
            self.cache_file.parent.mkdir(parents=True, exist_ok=True)
            with open(self.cache_file, 'w') as f:
                json.dump(self.processed_files, f, indent=2)

    def _should_ignore(self, filename: str) -> bool:
        """Check if file should be ignored"""
        for pattern in self.IGNORE_PATTERNS:
            if re.search(pattern, filename):
                return True
        return False

    def _is_business_document(self, filename: str) -> bool:
        """Check if file appears to be a business document"""
        # Check extension first
        ext = Path(filename).suffix.lower()
        if ext not in self.VALID_EXTENSIONS:
            return False

        # Check for business patterns in filename
        for pattern in self.BUSINESS_DOC_PATTERNS:
            if re.search(pattern, filename):
                return True

        return False

    def _classify_document(self, filename: str) -> str:
        """Determine which subfolder the document belongs in"""
        filename_lower = filename.lower()

        # NDA patterns
        if re.search(r'(?i)(nda|non.?disclosure|confidentiality|signed)', filename_lower):
            return "01-NDA"

        # CIM/Teaser patterns
        if re.search(r'(?i)(cim|teaser|executive\s*summary|business\s*summary|offering|highlights)', filename_lower):
            return "02-CIM"

        # Financial patterns
        if re.search(r'(?i)(p[&]?l|profit|loss|financial|tax|ebitda|revenue|income|balance)', filename_lower):
            return "03-Financials"

        # Operations patterns
        if re.search(r'(?i)(operations|sop|procedure|employee|org)', filename_lower):
            return "04-Operations"

        # Legal patterns
        if re.search(r'(?i)(contract|agreement|lease|legal|license)', filename_lower):
            return "05-Legal"

        # LOI/Offer patterns
        if re.search(r'(?i)(loi|letter\s*of\s*intent|offer|proposal)', filename_lower):
            return "08-LOI-Offer"

        # Default to correspondence
        return "07-Correspondence"

    def _extract_deal_hints(self, filename: str) -> Dict:
        """Extract potential deal identifiers from filename"""
        hints = {
            'company_names': [],
            'listing_ids': [],
            'keywords': [],
        }

        # Remove extension and clean up
        name = Path(filename).stem
        name_clean = re.sub(r'[_\-]+', ' ', name)

        # Look for listing IDs
        listing_matches = re.findall(r'\b(\d{4,7})\b', name)
        hints['listing_ids'] = listing_matches

        # Look for company-like names (capitalized words)
        words = name_clean.split()
        potential_names = []
        current_name = []

        for word in words:
            # Skip common non-name words
            skip_words = {'the', 'of', 'and', 'for', 'in', 'to', 'summary', 'executive',
                         'business', 'cim', 'nda', 'financial', 'signed', 'pdf', 'inquiry'}
            if word.lower() in skip_words:
                if current_name:
                    potential_names.append(' '.join(current_name))
                    current_name = []
                continue

            if len(word) > 2:
                current_name.append(word)

        if current_name:
            potential_names.append(' '.join(current_name))

        hints['company_names'] = [n for n in potential_names if len(n) > 3]

        return hints

    def _extract_document_content(self, filepath: Path) -> Dict:
        """Extract text and key identifiers from document content"""
        content_info = {
            'text': '',
            'company_names': [],
            'listing_ids': [],
            'broker_names': [],
            'search_terms': [],
        }

        # Extract text from document
        text = self.doc_extractor.extract_text(str(filepath))
        if not text:
            return content_info

        content_info['text'] = text[:10000]  # First 10K chars for analysis

        # Extract listing IDs (5-7 digit numbers that look like listing IDs)
        listing_matches = re.findall(r'\b(\d{5,7})\b', text)
        content_info['listing_ids'] = list(set(listing_matches))[:5]

        # Extract potential company names (look for patterns like "Company Name, LLC" etc.)
        company_patterns = [
            r'([A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+){1,4})\s*(?:LLC|Inc|Corp|Ltd|LP|LLP)',
            r'(?:business|company|owner):\s*([A-Za-z][A-Za-z\s&]+)',
        ]
        for pattern in company_patterns:
            matches = re.findall(pattern, text[:5000])
            for match in matches:
                name = match.strip()
                if len(name) > 4 and name not in content_info['company_names']:
                    content_info['company_names'].append(name)

        # Extract broker names (look for common broker signature patterns)
        broker_patterns = [
            r'(?:regards|sincerely|thanks)[,\s]+([A-Z][a-z]+\s+[A-Z][a-z]+)',
            r'(?:broker|advisor|agent):\s*([A-Z][a-z]+\s+[A-Z][a-z]+)',
        ]
        for pattern in broker_patterns:
            matches = re.findall(pattern, text[:3000], re.IGNORECASE)
            for match in matches:
                name = match.strip()
                if len(name) > 4 and name not in content_info['broker_names']:
                    content_info['broker_names'].append(name)

        # Build search terms for email lookup
        search_terms = []
        search_terms.extend(content_info['listing_ids'])
        search_terms.extend([c for c in content_info['company_names'] if len(c) > 5][:3])
        search_terms.extend(content_info['broker_names'][:2])
        content_info['search_terms'] = search_terms

        return content_info

    def _search_email_provenance(self, doc_info: Dict, filename_hints: Dict) -> Optional[Dict]:
        """Search emails to find the source/provenance of this document

        Returns matching email info if found, None otherwise.
        """
        if not self.email_client:
            logging.debug("No email client available for provenance search")
            return None

        # Build search terms from both document content and filename
        search_terms = []

        # From document content
        search_terms.extend(doc_info.get('search_terms', []))

        # From filename hints
        search_terms.extend(filename_hints.get('listing_ids', []))
        search_terms.extend([c for c in filename_hints.get('company_names', []) if len(c) > 5])

        # Remove duplicates and short terms
        search_terms = list(set(t for t in search_terms if t and len(str(t)) >= 4))

        if not search_terms:
            logging.debug(f"No search terms extracted for provenance search")
            return None

        logging.debug(f"Searching emails for provenance: {search_terms[:5]}")

        # Search emails
        matching_emails = self.email_client.search_by_terms(search_terms, days_back=90)

        if matching_emails:
            # Return the most relevant match (first one found)
            best_match = matching_emails[0]
            logging.info(f"Found email provenance: '{best_match.get('subject', '')[:50]}' "
                        f"from {best_match.get('sender_email', 'unknown')}")
            return best_match

        return None

    def _is_acquisition_related(self, doc_info: Dict, email_match: Dict) -> bool:
        """Verify the document is actually acquisition-related based on content and email"""
        # Check if email is from a known broker
        if self.broker_matcher and email_match:
            sender = email_match.get('sender_email', '').lower()
            if self.broker_matcher.match_sender(sender):
                return True

        # Check document content for acquisition keywords
        text = doc_info.get('text', '').lower()
        acquisition_keywords = [
            'acquisition', 'business for sale', 'asking price', 'ebitda',
            'seller financing', 'nda', 'confidential', 'cim', 'due diligence',
            'listing', 'broker', 'deal', 'revenue', 'cash flow', 'multiple',
            'confidential information memorandum', 'teaser', 'buyer',
        ]

        keyword_count = sum(1 for kw in acquisition_keywords if kw in text)
        return keyword_count >= 2  # At least 2 acquisition keywords

    def _match_to_deal(self, filename: str, hints: Dict) -> Optional[str]:
        """Try to match file to existing deal folder"""
        filename_lower = filename.lower()

        # First, check listing IDs
        for listing_id in hints.get('listing_ids', []):
            for deal_name, deal_path in self.deal_manager.existing_deals.items():
                if listing_id in deal_name:
                    logging.info(f"Matched {filename} to deal {deal_name} by listing ID {listing_id}")
                    return deal_path

        # Then check company names
        for company in hints.get('company_names', []):
            company_lower = company.lower()
            for deal_name, deal_path in self.deal_manager.existing_deals.items():
                # Check if significant words match
                deal_words = set(deal_name.lower().replace('-', ' ').split())
                company_words = set(company_lower.split())
                common = deal_words & company_words
                if len(common) >= 1 and any(len(w) > 4 for w in common):
                    logging.info(f"Matched {filename} to deal {deal_name} by company name")
                    return deal_path

        # Check filename against deal names directly
        for deal_name, deal_path in self.deal_manager.existing_deals.items():
            deal_words = deal_name.lower().replace('-', ' ').split()
            for word in deal_words:
                if len(word) > 4 and word in filename_lower:
                    logging.info(f"Matched {filename} to deal {deal_name} by keyword '{word}'")
                    return deal_path

        return None

    def _create_deal_from_document(self, filename: str, hints: Dict) -> Optional[str]:
        """Create a new deal folder based on the document"""
        # Generate deal name from filename
        name = Path(filename).stem
        name_clean = re.sub(r'[_\-]+', ' ', name)
        name_clean = re.sub(r'\s+', ' ', name_clean).strip()

        # Take first meaningful words
        words = [w for w in name_clean.split() if len(w) > 2 and w.lower() not in
                {'the', 'of', 'and', 'for', 'pdf', 'doc', 'signed', 'copy'}][:4]

        if not words:
            words = ['NewDeal']

        deal_name = '-'.join(w.title() for w in words) + f"-{datetime.now().year}"
        deal_name = re.sub(r'-+', '-', deal_name)

        # Create the deal folder structure
        deal_path = self.deal_manager.inbound_path / deal_name

        if deal_path.exists():
            # Already exists, return it
            return str(deal_path)

        if self.dry_run:
            logging.info(f"[DRY RUN] Would create deal folder: {deal_name}")
            return None

        # Create structure
        deal_path.mkdir(parents=True, exist_ok=True)
        for subfolder in self.deal_manager.DEAL_SUBFOLDERS:
            (deal_path / subfolder).mkdir(exist_ok=True)

        # Create basic README
        today = datetime.now().strftime("%B %d, %Y")
        readme = f"""# {deal_name}

**Deal Status:** New - From Downloads
**Date Added:** {today}
**Source:** Document found in Downloads folder

---

## QUICK FACTS

- **Original Document:** {filename}
- **Status:** Awaiting Review

---

## DOCUMENTS RECEIVED

- [{filename}](./{self._classify_document(filename)}/{filename}) - Added {today}

---

## NEXT STEPS

- [ ] Review document
- [ ] Identify broker/seller contact
- [ ] Sign NDA if required
- [ ] Request additional information
- [ ] Complete initial screening

---

**Document Control:**
- Created: {today}
- Last Updated: {today}
- Status: Active - New Inbound
"""
        with open(deal_path / "README.md", 'w') as f:
            f.write(readme)

        # Update deal manager index
        self.deal_manager.existing_deals[deal_name.lower()] = str(deal_path)

        # Add to MASTER-DEAL-TRACKER
        self.deal_manager._add_to_deal_tracker_from_download(deal_name, filename)

        logging.info(f"Created new deal from download: {deal_name}")
        self.stats['new_deals'] += 1

        return str(deal_path)

    def _update_deal_readme(self, deal_path: str, filename: str, subfolder: str):
        """Update the deal's README.md with new document info"""
        readme_path = Path(deal_path) / "README.md"

        if not readme_path.exists():
            return

        try:
            with open(readme_path, 'r') as f:
                content = f.read()

            today = datetime.now().strftime("%B %d, %Y")
            new_entry = f"- [{filename}](./{subfolder}/{filename}) - Added {today}"

            # Find the DOCUMENTS RECEIVED section or add after QUICK FACTS
            if "## DOCUMENTS RECEIVED" in content:
                # Add to existing section
                content = re.sub(
                    r'(## DOCUMENTS RECEIVED\n+)',
                    f'\\1{new_entry}\n',
                    content
                )
            elif "## NEXT STEPS" in content:
                # Insert new section before NEXT STEPS
                content = content.replace(
                    "## NEXT STEPS",
                    f"## DOCUMENTS RECEIVED\n\n{new_entry}\n\n---\n\n## NEXT STEPS"
                )

            # Update last modified date
            content = re.sub(
                r'Last Updated:.*',
                f'Last Updated: {today}',
                content
            )

            if not self.dry_run:
                with open(readme_path, 'w') as f:
                    f.write(content)

            logging.info(f"Updated README for deal with {filename}")

        except Exception as e:
            logging.error(f"Failed to update README: {e}")

    def _move_file_to_deal(self, src_path: Path, deal_path: str, subfolder: str) -> bool:
        """Move file from Downloads to deal folder"""
        dest_dir = Path(deal_path) / subfolder
        dest_path = dest_dir / src_path.name

        # Handle duplicate filenames
        if dest_path.exists():
            stem = src_path.stem
            suffix = src_path.suffix
            counter = 1
            while dest_path.exists():
                dest_path = dest_dir / f"{stem}_{counter}{suffix}"
                counter += 1

        if self.dry_run:
            logging.info(f"[DRY RUN] Would move {src_path.name} → {dest_path}")
            return True

        try:
            import shutil
            dest_dir.mkdir(parents=True, exist_ok=True)
            shutil.move(str(src_path), str(dest_path))
            logging.info(f"Moved {src_path.name} → {dest_path}")
            return True
        except Exception as e:
            logging.error(f"Failed to move {src_path.name}: {e}")
            return False

    def scan_and_process(self) -> Dict:
        """Main method: scan Downloads and process business documents

        New flow with email provenance checking:
        1. Extract document content (read PDF/Word)
        2. Extract hints from both filename and document content
        3. Try to match to existing deal folder
        4. If no match, search emails for provenance
        5. Only create new deal if email provenance found AND document is acquisition-related
        6. If no provenance found, skip the document
        """
        if not self.downloads_path.exists():
            logging.warning(f"Downloads path not found: {self.downloads_path}")
            return self.stats

        logging.info(f"Scanning Downloads folder: {self.downloads_path}")

        for filepath in self.downloads_path.iterdir():
            if not filepath.is_file():
                continue

            filename = filepath.name

            # Skip if already processed
            file_key = f"{filename}:{filepath.stat().st_mtime}"
            if file_key in self.processed_files:
                continue

            # Skip ignored files
            if self._should_ignore(filename):
                continue

            # Check extension is valid
            ext = Path(filename).suffix.lower()
            if ext not in self.VALID_EXTENSIONS:
                continue

            # Check if it's a business document (by filename patterns)
            if not self._is_business_document(filename):
                continue

            logging.info(f"Processing business document: {filename}")
            self.stats['processed'] += 1

            try:
                # Extract hints from filename
                filename_hints = self._extract_deal_hints(filename)

                # Extract content from document (read the actual file)
                doc_info = self._extract_document_content(filepath)

                # STEP 1: Try to match to existing deal folder
                deal_path = self._match_to_deal(filename, filename_hints)

                if deal_path:
                    # Matched to existing deal - process it
                    logging.info(f"Matched to existing deal: {Path(deal_path).name}")
                    self.stats['matched'] += 1
                    self._process_matched_document(filepath, deal_path, filename, file_key)
                    continue

                # STEP 2: No existing deal match - search emails for provenance
                logging.debug(f"No existing deal match, searching emails for provenance...")
                email_match = self._search_email_provenance(doc_info, filename_hints)

                if not email_match:
                    # No email provenance found - skip this document
                    logging.info(f"No email provenance found for {filename}, skipping (not acquisition-related)")
                    self.stats['no_provenance'] += 1
                    self.stats['skipped'] += 1
                    continue

                # STEP 3: Found email - verify it's acquisition-related
                if not self._is_acquisition_related(doc_info, email_match):
                    logging.info(f"Document {filename} not acquisition-related, skipping")
                    self.stats['skipped'] += 1
                    continue

                # STEP 4: Create new deal from email provenance
                self.stats['provenance_found'] += 1
                logging.info(f"Creating deal from email provenance: {email_match.get('subject', '')[:40]}")

                deal_path = self._create_deal_from_email(email_match, filename)
                if deal_path:
                    self._process_matched_document(filepath, deal_path, filename, file_key)

            except Exception as e:
                logging.error(f"Error processing {filename}: {e}")
                self.stats['errors'] += 1

        # Save cache
        self._save_cache()

        logging.info(f"Downloads scan complete: {self.stats}")
        return self.stats

    def _process_matched_document(self, filepath: Path, deal_path: str, filename: str, file_key: str):
        """Move document to deal folder and update README"""
        subfolder = self._classify_document(filename)

        if self._move_file_to_deal(filepath, deal_path, subfolder):
            # Update README
            self._update_deal_readme(deal_path, filename, subfolder)

            # Mark as processed
            if not self.dry_run:
                self.processed_files[file_key] = deal_path

    def _create_deal_from_email(self, email_match: Dict, filename: str) -> Optional[str]:
        """Create a new deal folder based on email provenance"""
        # Generate deal name from email subject
        subject = email_match.get('subject', 'Unknown Deal')
        subject = re.sub(r'^(re:|fw:|fwd:)\s*', '', subject, flags=re.IGNORECASE)
        subject = re.sub(r'^(new listing|new opportunity|deal alert)[\s:-]*', '', subject, flags=re.IGNORECASE)

        # Clean and create deal name
        clean_subject = re.sub(r'[^\w\s-]', '', subject)
        words = [w for w in clean_subject.split() if len(w) > 2][:4]
        if not words:
            words = ['NewDeal']

        deal_name = '-'.join(w.title() for w in words) + f"-{datetime.now().year}"
        deal_name = re.sub(r'-+', '-', deal_name).strip('-')

        deal_path = self.deal_manager.inbound_path / deal_name

        if deal_path.exists():
            return str(deal_path)

        if self.dry_run:
            logging.info(f"[DRY RUN] Would create deal folder from email: {deal_name}")
            return None

        # Create structure
        deal_path.mkdir(parents=True, exist_ok=True)
        for subfolder in self.deal_manager.DEAL_SUBFOLDERS:
            (deal_path / subfolder).mkdir(exist_ok=True)

        # Create README with email info
        today = datetime.now().strftime("%B %d, %Y")
        sender = email_match.get('from', 'Unknown')
        sender_email = email_match.get('sender_email', '')

        # Try to get broker info
        broker_section = ""
        if self.broker_matcher and sender_email:
            broker = self.broker_matcher.match_sender(sender_email)
            if broker:
                broker_section = f"""
## BROKER INFORMATION

- **Name:** {broker.name}
- **Company:** {broker.company}
- **Email:** {broker.email}
- **Phone:** {broker.phone}
"""

        readme = f"""# {deal_name}

**Deal Status:** New - From Downloads (Email Verified)
**Date Added:** {today}
**Source:** Email from {sender}

---

## QUICK FACTS

- **Email Subject:** {email_match.get('subject', 'N/A')}
- **Email Date:** {email_match.get('date', 'N/A')}
- **Original Document:** {filename}
- **Status:** Awaiting Review

---
{broker_section}
## DOCUMENTS RECEIVED

- [{filename}](./{self._classify_document(filename)}/{filename}) - Added {today}

---

## NEXT STEPS

- [ ] Review document
- [ ] Review original email thread
- [ ] Sign NDA if required
- [ ] Request additional information
- [ ] Complete initial screening

---

**Document Control:**
- Created: {today}
- Last Updated: {today}
- Status: Active - New Inbound
"""
        with open(deal_path / "README.md", 'w') as f:
            f.write(readme)

        # Update deal manager index
        self.deal_manager.existing_deals[deal_name.lower()] = str(deal_path)

        # Add to MASTER-DEAL-TRACKER
        self.deal_manager._add_to_deal_tracker_from_download(deal_name, filename)

        logging.info(f"Created new deal from email provenance: {deal_name}")
        self.stats['new_deals'] += 1

        return str(deal_path)


# ============================================================
# Link Crawler
# ============================================================

class LinkCrawler:
    """Extract and crawl public links from emails"""

    DOCUMENT_PATTERNS = [
        r'https?://[^\s<>"\']+\.pdf',
        r'https?://[^\s<>"\']+\.docx?',
        r'https?://[^\s<>"\']+\.xlsx?',
        r'https?://drive\.google\.com/[^\s<>"\']+',
        r'https?://dropbox\.com/[^\s<>"\']+',
    ]

    def __init__(self, crawl4ai_url: str):
        self.crawl4ai_url = crawl4ai_url

    def extract_links(self, text: str, html: str = "") -> List[str]:
        """Extract document links from email content"""
        links = []
        combined = f"{text} {html}"

        for pattern in self.DOCUMENT_PATTERNS:
            matches = re.findall(pattern, combined, re.IGNORECASE)
            links.extend(matches)

        # Extract general URLs with document keywords
        url_pattern = r'https?://[^\s<>"\']+(?:/[^\s<>"\']*)*'
        all_urls = re.findall(url_pattern, combined)

        for url in all_urls:
            if any(kw in url.lower() for kw in ['cim', 'teaser', 'doc', 'attachment', 'file', 'download']):
                if url not in links:
                    links.append(url)

        return list(set(links))

    def is_crawlable(self, url: str) -> bool:
        """Check if URL should be crawled"""
        parsed = urlparse(url)
        domain = parsed.netloc.lower()

        for skip_domain in SKIP_DOMAINS:
            if skip_domain in domain:
                return False

        return parsed.scheme == 'https'

    def download_direct(self, url: str, save_path: str) -> bool:
        """Direct download for document links"""
        try:
            response = requests.get(url, timeout=30, stream=True,
                                   headers={'User-Agent': 'Mozilla/5.0'})
            if response.status_code == 200:
                Path(save_path).parent.mkdir(parents=True, exist_ok=True)
                with open(save_path, 'wb') as f:
                    for chunk in response.iter_content(chunk_size=8192):
                        f.write(chunk)
                return True
        except Exception as e:
            logging.warning(f"Failed to download {url}: {e}")
        return False

# ============================================================
# RAG Indexer
# ============================================================

class RAGIndexer:
    """Index new content to RAG system"""

    def __init__(self, api_url: str):
        self.api_url = api_url
        self.url_prefix = "https://dataroom.local/DataRoom"

    def index_text(self, content: str, file_path: str, deal_name: str, doc_type: str) -> bool:
        """Index text content to RAG"""
        if not content or not content.strip():
            return False

        try:
            rel_path = str(file_path).replace('/home/zaks/DataRoom/', '')
            url = f"{self.url_prefix}/{rel_path}"

            metadata = {
                "source": "email_sync",
                "path": rel_path,
                "filename": Path(file_path).name,
                "deal": deal_name,
                "doc_type": doc_type,
                "indexed_at": datetime.now().isoformat(),
            }

            payload = {
                "url": url,
                "content": content,
                "metadata": metadata,
                "chunk_size": 5000,
            }

            response = requests.post(self.api_url, json=payload, timeout=30)
            return response.status_code == 200

        except Exception as e:
            logging.warning(f"Failed to index {file_path}: {e}")
            return False

    def index_file(self, file_path: str, deal_name: str, doc_type: str) -> bool:
        """Index a file to RAG (text files only)"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            return self.index_text(content, file_path, deal_name, doc_type)
        except UnicodeDecodeError:
            return False
        except Exception as e:
            logging.warning(f"Failed to read {file_path}: {e}")
            return False

# ============================================================
# Main Sync Orchestrator
# ============================================================

class EmailToDataRoomSync:
    """Main orchestration class"""

    def __init__(
        self,
        config: dict,
        dry_run: bool = False,
        force: bool = False,
        verbose: bool = False,
        zakops_analyze: bool = False,
        zakops_max_per_run: int = 3,
    ):
        self.config = config
        self.dry_run = dry_run
        self.force = force
        self.verbose = verbose
        self.zakops_analyze = zakops_analyze
        self.zakops_max_per_run = zakops_max_per_run
        self.stats = SyncStats()
        self.manifests_created: List[str] = []

        # Initialize components
        self.broker_matcher = BrokerMatcher(config['broker_tracker_path'])
        self.dedup_manager = DeduplicationManager(config['cache_dir'])
        self.deal_manager = DealManager(
            config['dataroom_path'],
            config['inbound_path'],
            config['screening_path'],
            registry_path=config.get('registry_path')
        )
        self.link_crawler = LinkCrawler(config['crawl4ai_url'])
        self.rag_indexer = RAGIndexer(config['rag_api_url'])
        self.doc_extractor = DocumentExtractor()
        self.gmail_client: Optional[IMAPGmailClient] = None

        # Initialize Downloads folder scanner
        downloads_cache = os.path.join(config['cache_dir'], 'downloads_processed.json')
        # Downloads scanner initialized here, email_client added after connection
        self.downloads_scanner = DownloadsFolderScanner(
            downloads_path=config.get('downloads_path', '/mnt/c/Users/mzsai/Downloads'),
            deal_manager=self.deal_manager,
            processed_cache_file=downloads_cache,
            dry_run=dry_run,
            email_client=None,  # Set after Gmail connection
            doc_extractor=self.doc_extractor,
            broker_matcher=self.broker_matcher,
        )

        self.setup_logging()

    def setup_logging(self):
        """Configure logging"""
        log_dir = Path(self.config['log_dir'])
        log_dir.mkdir(parents=True, exist_ok=True)

        log_file = log_dir / f"email_sync_{datetime.now().strftime('%Y%m%d')}.log"

        level = logging.DEBUG if self.verbose else logging.INFO

        # Clear existing handlers
        root_logger = logging.getLogger()
        root_logger.handlers = []

        logging.basicConfig(
            level=level,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_file),
                logging.StreamHandler()
            ]
        )

    def initialize_gmail(self) -> bool:
        """Initialize Gmail IMAP client"""
        creds = load_credentials()

        email_addr = creds.get('GMAIL_EMAIL')
        app_password = creds.get('GMAIL_APP_PASSWORD')

        if not email_addr or not app_password:
            logging.error("Gmail credentials not configured!")
            logging.error(f"Please edit: {CONFIG['credentials_file']}")
            logging.error("Run with --setup to create credentials template")
            return False

        server = creds.get('IMAP_SERVER', CONFIG['imap_server'])
        port = int(creds.get('IMAP_PORT', CONFIG['imap_port']))

        self.gmail_client = IMAPGmailClient(email_addr, app_password, server, port)
        return self.gmail_client.connect()

    def run(self) -> SyncStats:
        """Execute full sync pipeline"""
        start_time = datetime.now()

        lock_fh = None
        lock_path = Path(self.config['cache_dir']) / "email_sync.lock"
        if fcntl is not None:
            lock_path.parent.mkdir(parents=True, exist_ok=True)
            lock_fh = open(lock_path, "w")
            try:
                fcntl.flock(lock_fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                logging.warning(f"Another email sync run is in progress (lock: {lock_path}); exiting.")
                self.stats.errors.append("lock_busy")
                try:
                    lock_fh.close()
                finally:
                    lock_fh = None
                return self.stats
        else:
            logging.warning("fcntl not available; email sync lock disabled")

        logging.info("=" * 60)
        logging.info(f"Email-to-DataRoom Sync Starting (Run ID: {self.stats.run_id})")
        logging.info(f"Dry Run: {self.dry_run}")
        logging.info(f"Force: {self.force}")
        logging.info("=" * 60)

        try:
            # Initialize Gmail
            if not self.initialize_gmail():
                self.stats.errors.append("Failed to connect to Gmail")
                return self.stats

            # Search emails
            broker_emails = self.broker_matcher.get_broker_emails()
            emails = self.gmail_client.search_emails(
                broker_emails,
                ACQUISITION_KEYWORDS,
                self.config['search_hours']
            )

            self.stats.emails_fetched = len(emails)
            logging.info(f"Found {len(emails)} matching emails")

            # Process each email
            for email_data in emails:
                self.process_email(email_data)

            # Scan Downloads folder for business documents (BEFORE disconnecting Gmail)
            # This allows us to search emails for document provenance
            logging.info("")
            logging.info("=" * 60)
            logging.info("Scanning Downloads folder for business documents...")
            logging.info("=" * 60)

            # Pass the connected email client to scanner for provenance searches
            self.downloads_scanner.email_client = self.gmail_client
            downloads_stats = self.downloads_scanner.scan_and_process()

            # NOW disconnect from Gmail
            if self.gmail_client:
                self.gmail_client.disconnect()

            # Merge downloads stats into main stats
            self.stats.attachments_downloaded += downloads_stats.get('processed', 0)
            self.stats.new_deals_created += downloads_stats.get('new_deals', 0)
            downloads_errors = downloads_stats.get('errors', 0)
            if isinstance(downloads_errors, int) and downloads_errors > 0:
                self.stats.errors.append(f"Downloads scanner had {downloads_errors} errors")

            logging.info(f"Downloads scan complete: {downloads_stats.get('processed', 0)} files processed, "
                        f"{downloads_stats.get('matched', 0)} matched to deals, "
                        f"{downloads_stats.get('new_deals', 0)} new deals created")

            # Save state
            if not self.dry_run:
                self.dedup_manager.save_cache()
                self.update_inbox_index()

            # Optional Stage B analysis (ZakOps Prime)
            if self.zakops_analyze and not self.dry_run:
                self.run_zakops_analyzer()

            # Calculate duration
            self.stats.duration_seconds = (datetime.now() - start_time).total_seconds()

            # Generate report
            self.generate_report()

            return self.stats

        except Exception as e:
            logging.error(f"Sync failed: {e}")
            self.stats.errors.append(str(e))
            raise
        finally:
            if lock_fh is not None and fcntl is not None:
                try:
                    fcntl.flock(lock_fh.fileno(), fcntl.LOCK_UN)
                finally:
                    lock_fh.close()

    def run_zakops_analyzer(self):
        """Run Stage B analyzer for manifests created in this run (best-effort)."""
        if not self.manifests_created:
            return

        analyzer_script = os.getenv("ZAKOPS_ANALYZER_PATH", "/home/zaks/scripts/zakops_analyzer.py")
        max_to_run = max(0, int(self.zakops_max_per_run))
        if max_to_run == 0:
            return

        manifests = self.manifests_created[-max_to_run:]

        logging.info("=" * 60)
        logging.info(f"ZakOps Analyzer: running for {len(manifests)} manifest(s)")
        logging.info("=" * 60)

        for manifest_path in manifests:
            cmd = [sys.executable, analyzer_script, "--manifest", manifest_path]
            try:
                proc = subprocess.run(cmd, capture_output=True, text=True, timeout=900)
            except Exception as e:
                self.stats.zakops_errors += 1
                logging.error(f"ZakOps analyzer failed for {manifest_path}: {e}")
                continue

            if proc.returncode != 0:
                self.stats.zakops_errors += 1
                stderr = (proc.stderr or "").strip()
                logging.error(f"ZakOps analyzer non-zero exit for {manifest_path}: {stderr[:2000]}")
                continue

            self.stats.zakops_manifests_analyzed += 1
            stdout = (proc.stdout or "").strip()
            if stdout:
                logging.info(stdout[:2000])

    def process_email(self, email_data: dict):
        """Process single email through pipeline"""
        message_id = email_data.get('message_id', email_data.get('id', ''))

        if not message_id:
            logging.warning("Email missing message_id, skipping")
            return

        try:
            # Create record
            record = self.create_email_record(email_data)
            record.run_id = self.stats.run_id

            # Check deduplication
            if not self.force and self.dedup_manager.is_processed(message_id, record.body_hash):
                logging.debug(f"Skipping already processed: {record.subject[:50]}")
                self.stats.emails_skipped += 1
                return

            self.stats.emails_matched += 1

            # Match broker
            broker = self.broker_matcher.match_sender(record.sender)
            if broker:
                record.matched_broker = broker.name
                logging.info(f"Matched broker: {broker.name} ({broker.company})")

                # Track broker activity
                broker_key = broker.company or broker.name
                self.stats.broker_activity[broker_key] = \
                    self.stats.broker_activity.get(broker_key, 0) + 1

            # Match keywords
            record.matched_keywords = self.find_keywords(record)

            # Match or create deal
            deal_folder = self.match_or_create_deal(record, broker)
            record.deal_folder = deal_folder

            # Handle junk emails
            if deal_folder == "JUNK":
                logging.info(f"Skipping junk email: {record.subject[:50]}")
                self.stats.emails_skipped += 1
                self.dedup_manager.mark_processed(record)  # Mark so we don't reprocess
                return

            if self.dry_run:
                logging.info(f"[DRY RUN] Would process: {record.subject[:50]} -> {deal_folder}")
                self.stats.emails_processed += 1
                return

            # Download attachments
            downloaded = self.download_attachments(record, email_data, deal_folder)
            self.stats.attachments_downloaded += downloaded

            # Process links
            links = self.link_crawler.extract_links(record.body_text, record.body_html)
            record.extracted_links = links
            crawled = self.process_links(links, deal_folder, record)
            self.stats.links_crawled += crawled

            # Save email content and manifest
            record.email_markdown_path = self.save_email_content(record, deal_folder)

            # Index to RAG
            indexed = self.index_new_content(record, deal_folder)
            self.stats.files_indexed += indexed

            # Mark processed
            record.status = "processed"
            record.processed_at = datetime.now().isoformat()
            self.dedup_manager.mark_processed(record)
            self.stats.emails_processed += 1

            # Persist per-email manifest + intake log after successful processing
            manifest_path = self.save_email_manifest(record, deal_folder)
            if manifest_path:
                self.manifests_created.append(manifest_path)
            self.update_intake_log(record, deal_folder)

            # Track deal
            deal_name = Path(deal_folder).name
            if deal_name not in self.stats.deals_updated:
                self.stats.deals_updated.append(deal_name)

            logging.info(f"Processed: {record.subject[:50]}...")

        except Exception as e:
            logging.error(f"Failed to process email {message_id}: {e}")
            self.stats.emails_failed += 1
            self.stats.errors.append(f"{message_id}: {str(e)}")

    def create_email_record(self, email_data: dict) -> EmailRecord:
        """Create EmailRecord from raw email data"""
        body_text = email_data.get('body_text', '')
        body_html = email_data.get('body_html', '')

        # Compute hash from text content
        body_for_hash = body_text or body_html or ''
        body_hash = hashlib.sha256(body_for_hash.encode()).hexdigest()

        sender = email_data.get('from', '')

        return EmailRecord(
            message_id=email_data.get('message_id', email_data.get('id', '')),
            thread_id=email_data.get('thread_id', ''),
            subject=email_data.get('subject', 'No Subject'),
            sender=sender,
            sender_name=self.extract_sender_name(sender),
            received_date=email_data.get('date', ''),
            body_text=body_text,
            body_html=body_html,
            body_hash=body_hash,
        )

    def extract_sender_name(self, sender: str) -> str:
        """Extract name from sender string"""
        match = re.match(r'^([^<]+)\s*<', sender)
        if match:
            return match.group(1).strip().strip('"')
        return sender.split('@')[0] if '@' in sender else sender

    def find_keywords(self, record: EmailRecord) -> List[str]:
        """Find acquisition keywords in email"""
        found = []
        text = f"{record.subject} {record.body_text}".lower()

        for keyword in ACQUISITION_KEYWORDS:
            if keyword.lower() in text:
                found.append(keyword)

        return found

    def match_or_create_deal(self, record: EmailRecord, broker: Optional[BrokerInfo]) -> str:
        """Match email to existing deal or create new folder"""
        indicators = self.deal_manager.extract_deal_indicators(record)

        # Try matching existing (registry first, then legacy)
        existing = self.deal_manager.match_to_existing(record, indicators, broker)
        if existing:
            if existing == "JUNK":
                # Registry identified this as junk
                return "JUNK"
            return existing

        # Create new
        deal_name = self.deal_manager.generate_deal_name(record, indicators, broker)

        if self.dry_run:
            return f"[NEW] {deal_name}"

        folder = self.deal_manager.create_deal_folder(deal_name, record, broker)
        self.stats.new_deals_created += 1

        return folder

    def download_attachments(self, record: EmailRecord, email_data: dict, deal_folder: str) -> int:
        """Download email attachments with text extraction"""
        downloaded = 0
        attachments = email_data.get('attachments', [])

        for att in attachments:
            filename = att.get('filename', '')
            if not filename:
                continue

            ext = Path(filename).suffix.lower()
            if ext not in ATTACHMENT_EXTENSIONS:
                continue

            # Determine subfolder
            subfolder = self.deal_manager.determine_subfolder(filename, record.matched_keywords)
            save_dir = Path(deal_folder) / subfolder
            save_dir.mkdir(parents=True, exist_ok=True)

            # Generate unique filename with timestamp
            timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            msg_id_short = sanitize_filename(record.message_id.strip('<>')[:8])
            stem = sanitize_filename(Path(filename).stem)
            unique_filename = f"{timestamp}_{msg_id_short}_{stem}{ext}"
            save_path = save_dir / unique_filename

            # Save attachment data
            att_data = att.get('data')
            if att_data:
                try:
                    with open(save_path, 'wb') as f:
                        f.write(att_data)

                    file_hash = hashlib.sha256(att_data).hexdigest()

                    # Create attachment info
                    att_info = AttachmentInfo(
                        filename=unique_filename,
                        original_filename=filename,
                        save_path=str(save_path),
                        size_bytes=len(att_data),
                        file_hash=file_hash,
                        mime_type=att.get('content_type', ''),
                        subfolder=subfolder,
                    )

                    # Extract text for RAG (with OCR + table extraction for scanned PDFs)
                    extracted_text: Optional[str] = None
                    tables_paths: List[str] = []

                    if ext == ".pdf":
                        extracted_text, meta = DocumentExtractor.extract_pdf_text_with_ocr_and_tables(
                            str(save_path),
                            ocr_output_dir=str(save_dir / "_ocr"),
                            tables_output_dir=str(save_dir / "_tables"),
                            enable_table_extraction=True,
                        )
                        att_info.ocr_applied = bool(meta.get("ocr_applied"))
                        att_info.ocr_pdf_path = meta.get("ocr_pdf_path")
                        tables_paths = list(meta.get("tables_paths") or [])
                        att_info.tables_paths = tables_paths
                        att_info.tables_extracted = bool(tables_paths)

                        if att_info.ocr_applied:
                            self.stats.pdfs_ocr_applied += 1
                        if tables_paths:
                            self.stats.tables_csv_written += len(tables_paths)
                    else:
                        extracted_text = DocumentExtractor.extract_text(str(save_path))

                    if extracted_text or tables_paths:
                        # Save extracted text
                        text_filename = f"{unique_filename}.txt"
                        text_path = save_dir / text_filename
                        with open(text_path, 'w', encoding='utf-8') as f:
                            f.write(f"# Extracted from: {filename}\n")
                            f.write(f"# Date: {datetime.now().isoformat()}\n\n")
                            if att_info.ocr_applied:
                                f.write("# OCR Applied: true\n")
                                if att_info.ocr_pdf_path:
                                    f.write(f"# OCR PDF: {att_info.ocr_pdf_path}\n")
                            if tables_paths:
                                f.write(f"# Tables CSV: {len(tables_paths)}\n")
                                for table_csv in tables_paths:
                                    f.write(f"# - {table_csv}\n")
                            f.write("\n")
                            if extracted_text:
                                f.write(extracted_text)
                            else:
                                f.write("[No extractable text found]\n")

                            # Inline table CSV content for RAG indexing (bounded).
                            if tables_paths:
                                max_table_chars = DocumentExtractor._env_int("EMAIL_SYNC_MAX_TABLE_CHARS_IN_TXT", 100000)
                                remaining = max(0, max_table_chars)
                                f.write("\n\n# Extracted Tables (CSV)\n")
                                for table_csv_path in tables_paths:
                                    if remaining <= 0:
                                        f.write("\n[Tables truncated]\n")
                                        break
                                    f.write(f"\n## {Path(table_csv_path).name}\n")
                                    try:
                                        table_content = Path(table_csv_path).read_text(
                                            encoding="utf-8", errors="replace"
                                        )
                                    except Exception as e:
                                        f.write(f"[Failed to read table CSV: {e}]\n")
                                        continue
                                    if len(table_content) > remaining:
                                        f.write(table_content[:remaining])
                                        f.write("\n...[truncated]\n")
                                        remaining = 0
                                    else:
                                        f.write(table_content)
                                        remaining -= len(table_content)

                        att_info.text_extracted = True
                        att_info.text_path = str(text_path)
                        self.stats.attachments_text_extracted += 1
                        logging.info(f"Extracted text from: {filename}")

                    record.attachments.append(att_info)
                    downloaded += 1
                    logging.info(f"Downloaded: {filename} -> {save_path}")

                except Exception as e:
                    logging.error(f"Failed to save attachment {filename}: {e}")

        return downloaded

    def process_links(self, links: List[str], deal_folder: str, record: EmailRecord) -> int:
        """Process document links from email"""
        crawled = 0

        for url in links[:10]:
            if not self.link_crawler.is_crawlable(url):
                continue

            parsed = urlparse(url)
            filename = Path(parsed.path).name or 'document'
            if not Path(filename).suffix:
                filename += '.pdf'

            # Add timestamp for uniqueness and sanitize
            timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            filename = sanitize_filename(f"{timestamp}_{filename}")

            subfolder = self.deal_manager.determine_subfolder(filename, record.matched_keywords)
            save_dir = Path(deal_folder) / subfolder
            save_path = save_dir / filename

            if url.lower().endswith(('.pdf', '.doc', '.docx', '.xls', '.xlsx')):
                if self.link_crawler.download_direct(url, str(save_path)):
                    logging.info(f"Downloaded from URL: {url}")
                    crawled += 1

                    # Extract text (with OCR + table extraction for scanned PDFs)
                    extracted_text: Optional[str] = None
                    tables_paths: List[str] = []
                    meta: Dict[str, Any] = {}

                    if Path(save_path).suffix.lower() == ".pdf":
                        extracted_text, meta = DocumentExtractor.extract_pdf_text_with_ocr_and_tables(
                            str(save_path),
                            ocr_output_dir=str(save_dir / "_ocr"),
                            tables_output_dir=str(save_dir / "_tables"),
                            enable_table_extraction=True,
                        )
                        if meta.get("ocr_applied"):
                            self.stats.pdfs_ocr_applied += 1
                        tables_paths = list(meta.get("tables_paths") or [])
                        if tables_paths:
                            self.stats.tables_csv_written += len(tables_paths)
                    else:
                        extracted_text = DocumentExtractor.extract_text(str(save_path))

                    if extracted_text or tables_paths:
                        text_path = str(save_path) + '.txt'
                        with open(text_path, 'w', encoding='utf-8') as f:
                            f.write(f"# Extracted from URL: {url}\n\n")
                            if meta.get("ocr_applied"):
                                f.write("# OCR Applied: true\n")
                                if meta.get("ocr_pdf_path"):
                                    f.write(f"# OCR PDF: {meta.get('ocr_pdf_path')}\n")
                            if tables_paths:
                                f.write(f"# Tables CSV: {len(tables_paths)}\n")
                                for table_csv in tables_paths:
                                    f.write(f"# - {table_csv}\n")
                            f.write("\n")
                            if extracted_text:
                                f.write(extracted_text)
                            else:
                                f.write("[No extractable text found]\n")

                            if tables_paths:
                                max_table_chars = DocumentExtractor._env_int("EMAIL_SYNC_MAX_TABLE_CHARS_IN_TXT", 100000)
                                remaining = max(0, max_table_chars)
                                f.write("\n\n# Extracted Tables (CSV)\n")
                                for table_csv_path in tables_paths:
                                    if remaining <= 0:
                                        f.write("\n[Tables truncated]\n")
                                        break
                                    f.write(f"\n## {Path(table_csv_path).name}\n")
                                    try:
                                        table_content = Path(table_csv_path).read_text(
                                            encoding="utf-8", errors="replace"
                                        )
                                    except Exception as e:
                                        f.write(f"[Failed to read table CSV: {e}]\n")
                                        continue
                                    if len(table_content) > remaining:
                                        f.write(table_content[:remaining])
                                        f.write("\n...[truncated]\n")
                                        remaining = 0
                                    else:
                                        f.write(table_content)
                                        remaining -= len(table_content)
                        self.stats.attachments_text_extracted += 1

        return crawled

    def save_email_content(self, record: EmailRecord, deal_folder: str) -> str:
        """Save email content to correspondence folder"""
        corr_dir = Path(deal_folder) / "07-Correspondence"
        corr_dir.mkdir(parents=True, exist_ok=True)

        # Unique filename with timestamp and message ID
        timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        msg_id_short = sanitize_filename(record.message_id.strip('<>')[:8])
        sender_clean = re.sub(r'[^\w\s-]', '', record.sender_name).strip().replace(' ', '-')[:20]
        filename = f"{timestamp}_{msg_id_short}_{sender_clean}_email.md"
        save_path = corr_dir / filename

        content = f"""# Email from {record.sender_name}

**Date:** {record.received_date}
**From:** {record.sender}
**Subject:** {record.subject}
**Message ID:** {record.message_id}

---

{record.body_text}

---

**Metadata:**
- **Matched Keywords:** {', '.join(record.matched_keywords) if record.matched_keywords else 'None'}
- **Broker:** {record.matched_broker or 'Unknown'}
- **Run ID:** {record.run_id}
- **Attachments:** {len(record.attachments)}
- **Links Found:** {len(record.extracted_links)}
"""

        with open(save_path, 'w') as f:
            f.write(content)

        logging.info(f"Saved email content: {save_path}")
        return str(save_path)

    def save_email_manifest(self, record: EmailRecord, deal_folder: str) -> str:
        """Save per-email JSON manifest"""
        corr_dir = Path(deal_folder) / "07-Correspondence"

        timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        msg_id_short = record.message_id.strip('<>')[:8]
        manifest_file = corr_dir / f"{timestamp}_{msg_id_short}_manifest.json"

        manifest = {
            "manifest_version": "1.0",
            "ingested_at": datetime.now().isoformat(),
            "message_id": record.message_id,
            "thread_id": record.thread_id,
            "subject": record.subject,
            "sender": record.sender,
            "sender_name": record.sender_name,
            "received_date": record.received_date,
            "processed_at": record.processed_at,
            "run_id": record.run_id,
            "matched_broker": record.matched_broker,
            "matched_keywords": record.matched_keywords,
            "attachments": [asdict(a) if hasattr(a, '__dict__') else a for a in record.attachments],
            "links_found": record.extracted_links,
            "deal_folder": record.deal_folder,
            "status": record.status,
            "analysis_status": "pending",
            "email_markdown_path": record.email_markdown_path,
        }

        with open(manifest_file, 'w') as f:
            json.dump(manifest, f, indent=2, default=str)
        return str(manifest_file)

    def update_intake_log(self, record: EmailRecord, deal_folder: str):
        """Update deal-level intake log"""
        corr_dir = Path(deal_folder) / "07-Correspondence"
        intake_file = corr_dir / "INTAKE.md"

        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")

        entry = f"\n- **{timestamp}** | {record.subject[:60]} | From: {record.sender_name}"
        if record.attachments:
            entry += f" | {len(record.attachments)} attachment(s)"
        entry += "\n"

        # Append or create
        if intake_file.exists():
            with open(intake_file, 'a') as f:
                f.write(entry)
        else:
            header = f"""# Intake Log - {Path(deal_folder).name}

Auto-generated log of emails and documents received for this deal.

---
"""
            with open(intake_file, 'w') as f:
                f.write(header + entry)

    def update_inbox_index(self):
        """Update central inbox index"""
        index_file = Path(self.config['inbound_path']) / "_INBOX-INDEX.md"

        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")

        header = f"""# Inbound Deal Index

Last Updated: {timestamp}
Run ID: {self.stats.run_id}

---

## Recent Activity

"""

        entries = []
        for deal in self.stats.deals_updated:
            entries.append(f"- **{deal}** - Updated {timestamp}")

        if self.stats.new_deals_created > 0:
            entries.append(f"\n**New deals created this run:** {self.stats.new_deals_created}")

        content = header + "\n".join(entries) if entries else header + "No recent activity."

        with open(index_file, 'w') as f:
            f.write(content)

    def index_new_content(self, record: EmailRecord, deal_folder: str) -> int:
        """Index new files to RAG"""
        indexed = 0
        deal_name = Path(deal_folder).name

        # Index correspondence
        corr_dir = Path(deal_folder) / "07-Correspondence"
        for file in corr_dir.glob("*.md"):
            if self.rag_indexer.index_file(str(file), deal_name, "Correspondence"):
                indexed += 1

        # Index extracted text files
        for subfolder in self.deal_manager.DEAL_SUBFOLDERS:
            subfolder_path = Path(deal_folder) / subfolder
            if subfolder_path.exists():
                for txt_file in subfolder_path.glob("*.txt"):
                    if self.rag_indexer.index_file(str(txt_file), deal_name, subfolder):
                        indexed += 1

        return indexed

    def generate_report(self):
        """Generate sync report"""
        report_dir = Path(self.config['log_dir'])
        timestamp = datetime.now().strftime('%Y%m%d-%H%M%S')
        report_file = report_dir / f"email_sync_report_{timestamp}.json"

        report = asdict(self.stats)

        with open(report_file, 'w') as f:
            json.dump(report, f, indent=2, default=str)

        # Print summary
        logging.info("=" * 60)
        logging.info("SYNC COMPLETE")
        logging.info(f"  Run ID: {self.stats.run_id}")
        logging.info(f"  Emails Fetched: {self.stats.emails_fetched}")
        logging.info(f"  Emails Matched: {self.stats.emails_matched}")
        logging.info(f"  Emails Processed: {self.stats.emails_processed}")
        logging.info(f"  Emails Skipped: {self.stats.emails_skipped}")
        logging.info(f"  Emails Failed: {self.stats.emails_failed}")
        logging.info(f"  New Deals Created: {self.stats.new_deals_created}")
        logging.info(f"  Attachments Downloaded: {self.stats.attachments_downloaded}")
        logging.info(f"  Text Extracted: {self.stats.attachments_text_extracted}")
        logging.info(f"  PDFs OCR Applied: {self.stats.pdfs_ocr_applied}")
        logging.info(f"  Tables CSV Written: {self.stats.tables_csv_written}")
        logging.info(f"  Links Crawled: {self.stats.links_crawled}")
        logging.info(f"  Files Indexed: {self.stats.files_indexed}")
        if self.zakops_analyze:
            logging.info(f"  ZakOps Analyzed: {self.stats.zakops_manifests_analyzed}")
            if self.stats.zakops_errors > 0:
                logging.info(f"  ZakOps Errors: {self.stats.zakops_errors}")
        logging.info(f"  Duration: {self.stats.duration_seconds:.1f}s")
        logging.info(f"  Report: {report_file}")
        if self.stats.broker_activity:
            logging.info(f"  Broker Activity: {self.stats.broker_activity}")
        logging.info("=" * 60)

# ============================================================
# CLI Entry Point
# ============================================================

def main():
    # DEPRECATION GATE: Require explicit opt-in to run legacy script
    import os as _os
    if _os.environ.get("EMAIL_INGESTION_LEGACY_ENABLED", "").lower() not in ("true", "1", "yes"):
        print("=" * 70)
        print("DEPRECATED: This script is superseded by the new email_ingestion pipeline.")
        print("")
        print("Use: cd /home/zaks/scripts/email_ingestion && make ingest")
        print("")
        print("To re-enable this legacy script, set:")
        print("  export EMAIL_INGESTION_LEGACY_ENABLED=true")
        print("=" * 70)
        return 0  # Exit cleanly without processing

    parser = argparse.ArgumentParser(
        description="Sync acquisition emails to DataRoom (IMAP Edition) [DEPRECATED]",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
!!! DEPRECATED - Use email_ingestion pipeline instead !!!

Examples:
  %(prog)s                    # Normal run
  %(prog)s --dry-run          # Preview without changes
  %(prog)s --force            # Re-process all emails
  %(prog)s --hours 24         # Look back 24 hours
  %(prog)s --setup            # Create credentials template

Cron: DISABLED - Use email_ingestion pipeline
        """
    )
    parser.add_argument("--dry-run", action="store_true",
                       help="Preview without making changes")
    parser.add_argument("--force", action="store_true",
                       help="Re-process all emails (ignore cache)")
    parser.add_argument("--hours", type=int, default=4,
                       help="Hours to look back (default: 4)")
    parser.add_argument("--verbose", "-v", action="store_true",
                       help="Verbose output")
    parser.add_argument("--setup", action="store_true",
                       help="Create credentials template and exit")
    parser.add_argument("--show-query", action="store_true",
                       help="Show search criteria and exit")

    env_auto = os.getenv("ZAKOPS_AUTO_ANALYZE", "").strip().lower() in {"1", "true", "yes", "on"}
    parser.add_argument("--zakops-analyze", dest="zakops_analyze", action="store_true", default=env_auto,
                       help="Run ZakOps analyzer for new manifests (or set ZAKOPS_AUTO_ANALYZE=true)")
    parser.add_argument("--no-zakops-analyze", dest="zakops_analyze", action="store_false",
                       help="Disable ZakOps analyzer for this run")
    parser.add_argument("--zakops-max", type=int, default=int(os.getenv("ZAKOPS_MAX_PER_RUN", "3")),
                       help="Max manifests to analyze per run (default: 3 or ZAKOPS_MAX_PER_RUN)")

    args = parser.parse_args()

    # Handle setup
    if args.setup:
        create_credentials_template()
        sys.exit(0)

    # Handle show-query
    if args.show_query:
        print("=" * 60)
        print("Email-to-DataRoom Sync - Search Criteria")
        print("=" * 60)
        print(f"\nSearch window: Last {args.hours} hours")
        print(f"\nBroker emails monitored:")
        broker_matcher = BrokerMatcher(CONFIG['broker_tracker_path'])
        for email in sorted(broker_matcher.get_broker_emails()):
            print(f"  - {email}")
        print(f"\nKeywords (in subject/body):")
        for kw in ACQUISITION_KEYWORDS:
            print(f"  - {kw}")
        print(f"\nAllowed attachments: {', '.join(sorted(ATTACHMENT_EXTENSIONS))}")
        print(f"\nSkipped domains: {', '.join(SKIP_DOMAINS)}")
        print("\n" + "=" * 60)
        sys.exit(0)

    # Update config
    CONFIG['search_hours'] = args.hours

    # Check credentials exist
    if not Path(CONFIG['credentials_file']).exists():
        print("Credentials not configured!")
        print(f"Run: {sys.argv[0]} --setup")
        sys.exit(1)

    # Run sync
    sync = EmailToDataRoomSync(
        CONFIG,
        dry_run=args.dry_run,
        force=args.force,
        verbose=args.verbose,
        zakops_analyze=args.zakops_analyze,
        zakops_max_per_run=args.zakops_max,
    )

    stats = sync.run()

    # Best-effort run ledger record (append-only, no secrets).
    try:
        ledger_writer = "/home/zaks/bookkeeping/scripts/run_ledger.py"
        ledger_path = os.getenv("ZAKOPS_RUN_LEDGER_PATH", "/home/zaks/logs/run-ledger.jsonl")
        if os.path.exists(ledger_writer):
            errors = list(getattr(stats, "errors", []) or [])
            if "lock_busy" in errors:
                status = "skipped"
            elif any("Failed to connect to Gmail" in e for e in errors) or stats.emails_failed > 0:
                status = "fail"
            elif errors:
                status = "partial"
            else:
                status = "success"

            ended_at = datetime.now().astimezone().isoformat()
            log_dir = Path(CONFIG.get("log_dir", "/home/zaks/logs"))
            log_file = log_dir / f"email_sync_{datetime.now().strftime('%Y%m%d')}.log"
            report_file = ""
            try:
                candidates = list(log_dir.glob("email_sync_report_*.json"))
                if candidates:
                    report_file = str(max(candidates, key=lambda p: p.stat().st_mtime))
            except Exception:
                report_file = ""

            args = [
                "python3",
                ledger_writer,
                "--ledger-path",
                ledger_path,
                "--component",
                "email_sync",
                "--run-id",
                stats.run_id,
                "--status",
                status,
                "--started-at",
                stats.run_timestamp,
                "--ended-at",
                ended_at,
                "--artifact",
                "/home/zaks/logs/email_sync.log",
                "--metric",
                f"emails_fetched={stats.emails_fetched}",
                "--metric",
                f"emails_processed={stats.emails_processed}",
                "--metric",
                f"emails_failed={stats.emails_failed}",
                "--metric",
                f"attachments_downloaded={stats.attachments_downloaded}",
                "--metric",
                f"attachments_text_extracted={stats.attachments_text_extracted}",
                "--metric",
                f"pdfs_ocr_applied={stats.pdfs_ocr_applied}",
                "--metric",
                f"tables_csv_written={stats.tables_csv_written}",
                "--metric",
                f"links_crawled={stats.links_crawled}",
                "--metric",
                f"files_indexed={stats.files_indexed}",
                "--metric",
                f"duration_seconds={stats.duration_seconds}",
            ]
            correlation_id = os.getenv("ZAKOPS_CORRELATION_ID", "").strip()
            if correlation_id:
                args.extend(["--correlation", f"correlation_id={correlation_id}"])
            parent_run_id = os.getenv("ZAKOPS_PARENT_RUN_ID", "").strip()
            if parent_run_id:
                args.extend(["--correlation", f"parent_run_id={parent_run_id}"])
            if log_file.exists():
                args.extend(["--artifact", str(log_file)])
            if report_file:
                args.extend(["--artifact", report_file])
            for e in errors:
                args.extend(["--error", e])
            subprocess.run(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
    except Exception:
        pass

    # Exit code
    errors = list(getattr(stats, "errors", []) or [])
    if "lock_busy" in errors:
        sys.exit(2)
    if any("Failed to connect to Gmail" in e for e in errors):
        sys.exit(1)
    if stats.emails_failed > 0:
        sys.exit(1)
    sys.exit(0)


if __name__ == "__main__":
    main()
