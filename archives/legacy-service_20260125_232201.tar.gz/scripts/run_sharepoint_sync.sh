#!/usr/bin/env bash
set -euo pipefail

LOG_DIR="/home/zaks/logs"
CACHE_DIR="/home/zaks/.cache"
LOG_FILE="${LOG_DIR}/sharepoint_sync_$(date +%Y%m%d).log"
LOCK_FILE="${CACHE_DIR}/sharepoint_sync.lock"

LEDGER_WRITER="/home/zaks/bookkeeping/scripts/run_ledger.py"
LEDGER_PATH="${ZAKOPS_RUN_LEDGER_PATH:-/home/zaks/logs/run-ledger.jsonl}"
RUN_TS="$(date -u +%Y%m%dT%H%M%SZ)"
RUN_ID="${RUN_TS}_sharepoint_sync_${$}"
STARTED_AT="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
START_EPOCH="$(date +%s)"
SKIPPED_REASON=""
OPS_DIGEST_SCRIPT="/home/zaks/bookkeeping/scripts/ops_digest.py"
OPS_DIGEST_OUT_DIR="/home/zaks/DataRoom/06-KNOWLEDGE-BASE/ops-daily"
OPS_DIGEST_TZ="America/Chicago"
OPS_DIGEST_AFTER_HOUR=8

maybe_ops_digest() {
  if [ ! -f "${OPS_DIGEST_SCRIPT}" ]; then
    return 0
  fi

  local hour
  hour="$(TZ="${OPS_DIGEST_TZ}" date +%H 2>/dev/null || echo "")"
  if [[ ! "${hour}" =~ ^[0-9]{2}$ ]]; then
    return 0
  fi
  if (( 10#${hour} < OPS_DIGEST_AFTER_HOUR )); then
    return 0
  fi

  local today
  today="$(TZ="${OPS_DIGEST_TZ}" date +%Y-%m-%d 2>/dev/null || echo "")"
  if [ -z "${today}" ]; then
    return 0
  fi

  local out_file="${OPS_DIGEST_OUT_DIR}/${today}.md"
  if [ -f "${out_file}" ]; then
    return 0
  fi

  mkdir -p "${OPS_DIGEST_OUT_DIR}" >/dev/null 2>&1 || true

  local lock_file="${CACHE_DIR}/ops_digest.lock"
  if command -v flock >/dev/null 2>&1; then
    exec 8>"${lock_file}" || true
    flock -n 8 || return 0
  fi

  python3 "${OPS_DIGEST_SCRIPT}" --since-hours 24 --tz "${OPS_DIGEST_TZ}" --out "${out_file}" >/dev/null 2>&1 || true
}

on_exit() {
  set +e
  local exit_code=$?
  local ended_at
  ended_at="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  local end_epoch
  end_epoch="$(date +%s)"
  local duration_seconds=$(( end_epoch - START_EPOCH ))

  local status="success"
  local -a errors=()
  if [ -n "${SKIPPED_REASON}" ]; then
    status="skipped"
    errors+=("${SKIPPED_REASON}")
  elif [ "${exit_code}" -eq 0 ]; then
    status="success"
  else
    status="fail"
    errors+=("exit_code_${exit_code}")
    if [ "${exit_code}" -eq 2 ]; then
      errors+=("secret_detected")
    fi
  fi

  if [ -x "${LEDGER_WRITER}" ]; then
    local uploaded="" unchanged="" skipped="" errors_count=""
    if [ -f "${LOG_FILE}" ]; then
      uploaded="$(grep -E '^Uploaded:' "${LOG_FILE}" 2>/dev/null | tail -n 1 | awk '{print $2}' || true)"
      unchanged="$(grep -E '^Unchanged:' "${LOG_FILE}" 2>/dev/null | tail -n 1 | awk '{print $2}' || true)"
      skipped="$(grep -E '^Skipped:' "${LOG_FILE}" 2>/dev/null | tail -n 1 | awk '{print $2}' || true)"
      errors_count="$(grep -E '^Errors:' "${LOG_FILE}" 2>/dev/null | tail -n 1 | awk '{print $2}' || true)"
    fi

    ledger_args=(
      python3 "${LEDGER_WRITER}"
      --ledger-path "${LEDGER_PATH}"
      --component "sharepoint_sync"
      --run-id "${RUN_ID}"
      --status "${status}"
      --started-at "${STARTED_AT}"
      --ended-at "${ended_at}"
      --artifact "${LOG_FILE}"
      --metric "exit_code=${exit_code}"
      --metric "duration_seconds=${duration_seconds}"
    )
    if [ -n "${ZAKOPS_CORRELATION_ID:-}" ]; then ledger_args+=(--correlation "correlation_id=${ZAKOPS_CORRELATION_ID}"); fi
    if [ -n "${ZAKOPS_PARENT_RUN_ID:-}" ]; then ledger_args+=(--correlation "parent_run_id=${ZAKOPS_PARENT_RUN_ID}"); fi
    if [[ "${uploaded}" =~ ^[0-9]+$ ]]; then ledger_args+=(--metric "uploaded=${uploaded}"); fi
    if [[ "${unchanged}" =~ ^[0-9]+$ ]]; then ledger_args+=(--metric "unchanged=${unchanged}"); fi
    if [[ "${skipped}" =~ ^[0-9]+$ ]]; then ledger_args+=(--metric "skipped=${skipped}"); fi
    if [[ "${errors_count}" =~ ^[0-9]+$ ]]; then ledger_args+=(--metric "errors=${errors_count}"); fi
    for err in "${errors[@]}"; do
      ledger_args+=(--error "${err}")
    done
    "${ledger_args[@]}" >/dev/null 2>&1 || true
  fi

  maybe_ops_digest
}

trap on_exit EXIT

mkdir -p "$LOG_DIR" "$CACHE_DIR"

if command -v flock >/dev/null 2>&1; then
  exec 9>"$LOCK_FILE"
  if ! flock -n 9; then
    if [ -t 1 ]; then
      echo "⏭ SharePoint sync already running; skipping."
    fi
    echo "$(date -Is) ⏭ SharePoint sync already running; skipping." >>"$LOG_FILE"
    SKIPPED_REASON="lock_busy"
    exit 0
  fi
fi

run_sync() {
  echo ""
  echo "================================================================"
  echo "SharePoint Sync (Graph) - $(date -Is)"
  echo "================================================================"
  python3 /home/zaks/scripts/sync_sharepoint.py "$@"
  local status=$?
  echo "Done. Exit code: $status"
  return "$status"
}

if [ -t 1 ]; then
  set +e
  run_sync "$@" 2>&1 | tee -a "$LOG_FILE"
  status=${PIPESTATUS[0]}
  set -e
  exit "$status"
fi

exec >>"$LOG_FILE" 2>&1
run_sync "$@"
