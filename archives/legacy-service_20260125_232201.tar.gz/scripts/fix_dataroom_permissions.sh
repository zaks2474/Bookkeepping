#!/bin/bash
# Fix DataRoom ownership and permissions

DATAROOM="/home/zaks/DataRoom"
LOG_FILE="/home/zaks/logs/permissions_fix_$(date +%Y%m%d_%H%M%S).log"

echo "=== DataRoom Permission Fix ===" | tee -a "$LOG_FILE"
echo "Date: $(date)" | tee -a "$LOG_FILE"
echo "" | tee -a "$LOG_FILE"

# Report current issues
echo "Files with permission issues:" | tee -a "$LOG_FILE"
echo "Root-owned files:" | tee -a "$LOG_FILE"
find "$DATAROOM" -user root 2>/dev/null | tee -a "$LOG_FILE"
echo "" | tee -a "$LOG_FILE"
echo "Files with 600 permissions:" | tee -a "$LOG_FILE"
find "$DATAROOM" -perm 600 2>/dev/null | tee -a "$LOG_FILE"
echo "" | tee -a "$LOG_FILE"

# Fix ownership (requires sudo)
echo "Fixing ownership to zaks:zaks..." | tee -a "$LOG_FILE"
sudo chown -R zaks:zaks "$DATAROOM"
echo "✓ Ownership fixed" | tee -a "$LOG_FILE"
echo "" | tee -a "$LOG_FILE"

# Fix permissions
echo "Fixing permissions..." | tee -a "$LOG_FILE"

# Directories: 755 (rwxr-xr-x)
find "$DATAROOM" -type d -exec chmod 755 {} \;
echo "✓ Directories set to 755" | tee -a "$LOG_FILE"

# Files: 644 (rw-r--r--)
find "$DATAROOM" -type f -exec chmod 644 {} \;
echo "✓ Files set to 644" | tee -a "$LOG_FILE"

# Shell scripts: 755 (executable)
find "$DATAROOM" -type f -name "*.sh" -exec chmod 755 {} \;
echo "✓ Shell scripts set to 755" | tee -a "$LOG_FILE"

echo "" | tee -a "$LOG_FILE"
echo "=== Permission Fix Complete ===" | tee -a "$LOG_FILE"

# Verification
echo "" | tee -a "$LOG_FILE"
echo "Verification:" | tee -a "$LOG_FILE"
ROOT_COUNT=$(find "$DATAROOM" -user root 2>/dev/null | wc -l)
echo "Files owned by root (should be 0): $ROOT_COUNT" | tee -a "$LOG_FILE"
PERM_600=$(find "$DATAROOM" -perm 600 2>/dev/null | wc -l)
echo "Files with 600 permissions (should be 0): $PERM_600" | tee -a "$LOG_FILE"
