#!/usr/bin/env python3
"""
DFP Ingestion Gateway

Deterministic intake wrapper around Email-to-DataRoom manifests.

Primary responsibilities:
- Recompute deal matching confidence (DealMatcher) using manifest + email markdown
- Apply DFP quarantine policy
- Optionally write quarantine items to DataRoom quarantine registry + payload folder
- Emit run-ledger records (component: email_ingestion / quarantine_resolution)

Safety:
- Never writes secrets
- Never logs raw email bodies (only paths + hashes)
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

try:
    import fcntl  # type: ignore
except Exception:  # pragma: no cover
    fcntl = None  # type: ignore

# Deal Registry integration (best-effort).
sys.path.insert(0, str(Path(__file__).resolve().parent))
try:
    from deal_registry import DealRegistry, DealMatcher, EmailContent

    REGISTRY_AVAILABLE = True
except Exception:
    DealRegistry = None  # type: ignore
    DealMatcher = None  # type: ignore
    EmailContent = None  # type: ignore
    REGISTRY_AVAILABLE = False


RUN_LEDGER_WRITER = "/home/zaks/bookkeeping/scripts/run_ledger.py"
RUN_LEDGER_PATH = os.getenv("ZAKOPS_RUN_LEDGER_PATH", "/home/zaks/logs/run-ledger.jsonl")

DEAL_REGISTRY_PATH = os.getenv("ZAKOPS_DEAL_REGISTRY_PATH", "/home/zaks/DataRoom/.deal-registry/deal_registry.json")
QUARANTINE_REGISTRY_PATH = os.getenv("ZAKOPS_QUARANTINE_PATH", "/home/zaks/DataRoom/.deal-registry/quarantine.json")
QUARANTINE_DIR = os.getenv("ZAKOPS_QUARANTINE_DIR", "/home/zaks/DataRoom/_quarantine")


def _sha256_file(path: Path, max_bytes: int = 2_000_000) -> str:
    h = hashlib.sha256()
    try:
        with open(path, "rb") as f:
            h.update(f.read(max_bytes))
    except Exception:
        return ""
    return h.hexdigest()


def _emit_run_ledger(
    *,
    component: str,
    run_id: str,
    status: str,
    started_at: str,
    ended_at: str,
    artifacts: Optional[List[str]] = None,
    metrics: Optional[Dict[str, Any]] = None,
    errors: Optional[List[str]] = None,
    correlation: Optional[Dict[str, str]] = None,
) -> None:
    if not os.path.exists(RUN_LEDGER_WRITER):
        return

    args = [
        "python3",
        RUN_LEDGER_WRITER,
        "--ledger-path",
        RUN_LEDGER_PATH,
        "--component",
        component,
        "--run-id",
        run_id,
        "--status",
        status,
        "--started-at",
        started_at,
        "--ended-at",
        ended_at,
    ]
    for artifact in artifacts or []:
        args.extend(["--artifact", str(artifact)])
    for k, v in (metrics or {}).items():
        args.extend(["--metric", f"{k}={v}"])
    for e in errors or []:
        args.extend(["--error", str(e)])
    for k, v in (correlation or {}).items():
        args.extend(["--correlation", f"{k}={v}"])

    subprocess.run(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)


def _load_json(path: Path) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _atomic_write_json(path: Path, data: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
        f.write("\n")
    os.replace(tmp, path)


def _locked_update_quarantine(path: Path, updater) -> Dict[str, Any]:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        _atomic_write_json(path, {"schema_version": "1.0", "updated_at": None, "items": {}})

    with open(path, "r+", encoding="utf-8") as f:
        if fcntl is not None:
            try:
                fcntl.flock(f.fileno(), fcntl.LOCK_EX)
            except Exception:
                pass
        try:
            f.seek(0)
            current = json.load(f)
        except Exception:
            current = {"schema_version": "1.0", "updated_at": None, "items": {}}

        updated = updater(current)
        updated["updated_at"] = datetime.now().astimezone().isoformat()

        f.seek(0)
        f.truncate()
        json.dump(updated, f, indent=2, ensure_ascii=False)
        f.write("\n")
        return updated


def _gen_item_id() -> str:
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    nonce = hashlib.sha256(f"{ts}:{os.getpid()}:{time.time()}".encode("utf-8")).hexdigest()[:8]
    return f"Q-{ts}-{nonce}"


def _extract_email_body_from_markdown(md_path: Path, max_chars: int = 120_000) -> str:
    try:
        text = md_path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return ""

    # Email markdown follows: header, '---', body, '---', metadata.
    parts = text.split("\n---\n")
    if len(parts) >= 2:
        body = parts[1]
    else:
        body = text
    return body.strip()[:max_chars]


def _match_deal(manifest: Dict[str, Any]) -> Tuple[str, float, str, str]:
    """
    Returns: (decision, confidence, match_type, deal_id)
    decision: accept|quarantine|reject|unknown
    """
    if not REGISTRY_AVAILABLE or DealRegistry is None or DealMatcher is None or EmailContent is None:
        return "unknown", 0.0, "registry_unavailable", ""

    registry = DealRegistry(DEAL_REGISTRY_PATH)
    matcher = DealMatcher(registry)

    subject = str(manifest.get("subject", "") or "")
    sender = str(manifest.get("sender", "") or "")
    message_id = str(manifest.get("message_id", "") or "")
    thread_id = str(manifest.get("thread_id", "") or "")

    email_md_path = Path(str(manifest.get("email_markdown_path", "") or "")).expanduser()
    body = _extract_email_body_from_markdown(email_md_path) if email_md_path.exists() else ""

    content = EmailContent(
        subject=subject,
        body=body,
        sender=sender,
        message_id=message_id or None,
        thread_id=thread_id or None,
        received_date=str(manifest.get("received_date", "") or "") or None,
    )
    result = matcher.match(content)

    if result.action == "reject":
        return "reject", 0.0, str(result.reason or "reject"), ""
    if result.matched and result.deal_id:
        conf = float(result.confidence or 0.0)
        if conf >= 0.90:
            return "accept", conf, str(result.match_type or "matched"), str(result.deal_id)
        if conf >= 0.70:
            return "quarantine", conf, str(result.match_type or "low_confidence"), str(result.deal_id)
        return "quarantine", conf, str(result.match_type or "very_low_confidence"), str(result.deal_id)

    # No match: quarantine (DFP policy).
    return "quarantine", 0.0, "no_match", ""


def _create_quarantine_item(
    *,
    manifest_path: Path,
    manifest: Dict[str, Any],
    reason: str,
    confidence: float,
    match_type: str,
    suggested_deal_id: str,
    apply: bool,
) -> Dict[str, Any]:
    item_id = _gen_item_id()
    payload_dir = Path(QUARANTINE_DIR) / item_id

    email_md_path = Path(str(manifest.get("email_markdown_path", "") or "")).expanduser()

    item = {
        "item_id": item_id,
        "status": "pending",
        "created_at": datetime.now().astimezone().isoformat(),
        "reason": reason,
        "match": {
            "confidence": float(confidence),
            "match_type": match_type,
            "suggested_deal_id": suggested_deal_id or None,
        },
        "source": {
            "manifest_path": str(manifest_path),
            "email_markdown_path": str(email_md_path) if str(email_md_path) else None,
            "message_id": str(manifest.get("message_id", "") or ""),
            "thread_id": str(manifest.get("thread_id", "") or ""),
            "sender": str(manifest.get("sender", "") or ""),
            "subject": str(manifest.get("subject", "") or ""),
            "attachments_count": int(len(manifest.get("attachments", []) or [])),
        },
        "artifacts": {
            "payload_dir": str(payload_dir),
            "manifest_sha256": _sha256_file(manifest_path),
            "email_md_sha256": _sha256_file(email_md_path) if email_md_path.exists() else "",
        },
        "resolution": None,
    }

    if not apply:
        return item

    payload_dir.mkdir(parents=True, exist_ok=True)
    # Copy the manifest as a snapshot of what was ingested (sanitized metadata only).
    shutil.copy2(manifest_path, payload_dir / "manifest.json")
    _atomic_write_json(payload_dir / "item.json", item)

    def add_item(current: Dict[str, Any]) -> Dict[str, Any]:
        items = current.get("items")
        if not isinstance(items, dict):
            items = {}
        items[item_id] = item
        current["items"] = items
        return current

    _locked_update_quarantine(Path(QUARANTINE_REGISTRY_PATH), add_item)
    return item


def cmd_ingest(args) -> int:
    started_at = datetime.now().astimezone().isoformat()
    run_id = f"{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}_email_ingestion_{os.getpid()}"

    manifest_path = Path(args.manifest).expanduser().resolve()
    if not manifest_path.exists():
        raise FileNotFoundError(str(manifest_path))

    manifest = _load_json(manifest_path)

    decision, confidence, match_type, deal_id = _match_deal(manifest)

    result: Dict[str, Any] = {
        "decision": decision,
        "confidence": float(confidence),
        "match_type": match_type,
        "deal_id": deal_id or None,
        "manifest_path": str(manifest_path),
    }

    quarantine_item: Optional[Dict[str, Any]] = None
    if decision == "quarantine":
        quarantine_item = _create_quarantine_item(
            manifest_path=manifest_path,
            manifest=manifest,
            reason=match_type,
            confidence=confidence,
            match_type=match_type,
            suggested_deal_id=deal_id,
            apply=args.apply,
        )
        result["quarantine_item"] = quarantine_item

    ended_at = datetime.now().astimezone().isoformat()
    status = "success"
    errors: List[str] = []

    _emit_run_ledger(
        component="email_ingestion",
        run_id=run_id,
        status=status,
        started_at=started_at,
        ended_at=ended_at,
        artifacts=[str(manifest_path)],
        metrics={"quarantined": 1 if decision == "quarantine" else 0, "confidence": float(confidence)},
        errors=errors,
        correlation={
            "decision": decision,
            "match_type": match_type,
            "deal_id": deal_id or "",
        },
    )

    print(json.dumps(result, indent=2, ensure_ascii=False, default=str))
    return 0


def cmd_resolve(args) -> int:
    started_at = datetime.now().astimezone().isoformat()
    run_id = f"{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}_quarantine_resolution_{os.getpid()}"

    item_id = args.item_id.strip()
    if not item_id:
        raise ValueError("missing_item_id")

    action = args.action.strip().lower()
    if action not in {"accept", "reject"}:
        raise ValueError("action_must_be_accept_or_reject")

    deal_id = (args.deal_id or "").strip() or None

    def resolve_item(current: Dict[str, Any]) -> Dict[str, Any]:
        items = current.get("items")
        if not isinstance(items, dict) or item_id not in items:
            raise KeyError("item_not_found")
        item = items[item_id]
        if not isinstance(item, dict):
            raise ValueError("invalid_item")
        if item.get("status") == "resolved":
            return current
        item["status"] = "resolved"
        item["resolution"] = {
            "resolved_at": datetime.now().astimezone().isoformat(),
            "resolved_by": os.getenv("USER", "operator"),
            "action": action,
            "deal_id": deal_id,
            "notes": (args.notes or "").strip()[:500] or None,
        }
        items[item_id] = item
        current["items"] = items
        return current

    updated = _locked_update_quarantine(Path(QUARANTINE_REGISTRY_PATH), resolve_item) if args.apply else None

    ended_at = datetime.now().astimezone().isoformat()
    _emit_run_ledger(
        component="quarantine_resolution",
        run_id=run_id,
        status="success",
        started_at=started_at,
        ended_at=ended_at,
        artifacts=[QUARANTINE_REGISTRY_PATH],
        metrics={"resolved": 1},
        correlation={"item_id": item_id, "action": action, "deal_id": deal_id or ""},
    )

    print(
        json.dumps(
            {"item_id": item_id, "action": action, "deal_id": deal_id, "applied": bool(args.apply), "updated": bool(updated)},
            indent=2,
            ensure_ascii=False,
        )
    )
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="DFP ingestion gateway (manifest → accept/quarantine)")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_ingest = sub.add_parser("ingest", help="Ingest an Email-to-DataRoom manifest")
    p_ingest.add_argument("--manifest", required=True, help="Path to *_manifest.json")
    p_ingest.add_argument("--apply", action="store_true", help="Write quarantine item + payload folder (default: dry-run)")
    p_ingest.set_defaults(func=cmd_ingest)

    p_resolve = sub.add_parser("resolve", help="Resolve a quarantine item (manual operator action)")
    p_resolve.add_argument("--item-id", required=True, help="Quarantine item id (Q-...)")
    p_resolve.add_argument("--action", required=True, help="accept|reject")
    p_resolve.add_argument("--deal-id", default="", help="Optional deal id to associate with accept")
    p_resolve.add_argument("--notes", default="", help="Optional notes (max 500 chars)")
    p_resolve.add_argument("--apply", action="store_true", help="Apply mutation to quarantine registry (default: dry-run)")
    p_resolve.set_defaults(func=cmd_resolve)

    args = parser.parse_args()
    try:
        return int(args.func(args))
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
