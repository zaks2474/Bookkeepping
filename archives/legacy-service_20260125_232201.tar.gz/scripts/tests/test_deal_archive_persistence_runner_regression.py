import os
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path

SCRIPTS_DIR = Path(__file__).resolve().parents[1]
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))


class DealArchivePersistenceRunnerRegressionTests(unittest.TestCase):
    def setUp(self) -> None:
        self._old_env = dict(os.environ)
        self._tmpdir = tempfile.TemporaryDirectory(dir="/home/zaks/tmp")
        self.tmp_path = Path(self._tmpdir.name)

        self.dataroom_root = self.tmp_path / "DataRoom"
        (self.dataroom_root / ".deal-registry").mkdir(parents=True, exist_ok=True)
        (self.dataroom_root / ".deal-registry" / "case_files").mkdir(parents=True, exist_ok=True)
        (self.dataroom_root / "00-PIPELINE" / "_INBOX_QUARANTINE").mkdir(parents=True, exist_ok=True)
        (self.dataroom_root / "00-PIPELINE" / "Inbound").mkdir(parents=True, exist_ok=True)

        self.registry_path = self.dataroom_root / ".deal-registry" / "deal_registry.json"
        self.state_db_path = self.tmp_path / "state.db"
        self.events_dir = self.tmp_path / "events"

        os.environ["DATAROOM_ROOT"] = str(self.dataroom_root)
        os.environ["ZAKOPS_STATE_DB"] = str(self.state_db_path)
        os.environ["DEAL_EVENTS_DIR"] = str(self.events_dir)

        from deal_registry import DealRegistry

        reg = DealRegistry(str(self.registry_path))
        self._seed_deal_id = reg.generate_deal_id()
        reg.create_deal(
            deal_id=self._seed_deal_id,
            canonical_name="ExampleCo",
            folder_path=str(self.dataroom_root / "00-PIPELINE" / "Inbound" / f"ExampleCo--{self._seed_deal_id}"),
        )
        reg.save()

    def tearDown(self) -> None:
        os.environ.clear()
        os.environ.update(self._old_env)
        self._tmpdir.cleanup()

    def test_runner_processing_does_not_resurrect_archived_deals(self) -> None:
        """
        Regression test for: Deal archive (soft delete) being overwritten by the kinetic runner.

        Scenario:
        1) Runner starts (historically cached DealRegistry in-memory).
        2) API/operator archives a deal (writes deleted=true to registry file).
        3) Runner processes an action whose executor calls registry.save().
        Expected: archived deal remains deleted=true after runner run.
        """
        runner_env = dict(os.environ)
        proc = subprocess.Popen(
            [
                sys.executable,
                str(SCRIPTS_DIR / "actions_runner.py"),
                "--runner-name",
                "runner_regression_test",
                "--lease-seconds",
                "2",
                "--poll-seconds",
                "0.1",
                "--action-lock-seconds",
                "30",
                "--max-actions",
                "1",
            ],
            env=runner_env,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )

        try:
            # Give the runner a moment to start up and enter its poll loop.
            time.sleep(0.5)

            from deal_registry import DealRegistry

            reg = DealRegistry(str(self.registry_path))
            ok = reg.mark_deal_deleted(self._seed_deal_id, operator="tester", reason="regression_test")
            self.assertTrue(ok)
            reg.save()

            from actions.engine.models import ActionPayload, compute_idempotency_key
            from actions.engine.store import ActionStore

            message_id = "msg-regression-1"
            quarantine_dir = self.dataroom_root / "00-PIPELINE" / "_INBOX_QUARANTINE" / message_id
            quarantine_dir.mkdir(parents=True, exist_ok=True)
            (quarantine_dir / "email_body.txt").write_text(
                "ExampleCo teaser. Please review. https://example.com/dataroom",
                encoding="utf-8",
            )

            store = ActionStore()
            payload = ActionPayload(
                deal_id="GLOBAL",
                capability_id="email_triage.review_email.v1",
                type="EMAIL_TRIAGE.REVIEW_EMAIL",
                title="Review inbound deal email (regression)",
                summary="Regression test action to ensure deletes do not resurrect",
                status="PENDING_APPROVAL",
                created_by="tester",
                source="system",
                risk_level="medium",
                requires_human_review=True,
                idempotency_key=compute_idempotency_key("EMAIL_TRIAGE.REVIEW_EMAIL", message_id, "regression"),
                inputs={
                    "message_id": message_id,
                    "thread_id": "thread-regression-1",
                    "from": "Broker <broker@example.com>",
                    "to": "operator@example.com",
                    "date": "11 Jan 2026 00:00:00 +0000",
                    "subject": "ExampleCo teaser",
                    "company": "ExampleCo",
                    "classification": "DEAL_SIGNAL",
                    "urgency": "HIGH",
                    "confidence": 0.9,
                    "links": [{"type": "dataroom", "url": "https://example.com/dataroom", "auth_required": True}],
                    "attachments": [],
                    "quarantine_dir": str(quarantine_dir),
                },
            )
            created, _ = store.create_action(payload)
            store.approve_action(created.action_id, actor="tester")
            store.request_execute(created.action_id, actor="tester")

            proc.wait(timeout=30)
            self.assertEqual(proc.returncode, 0, (proc.stdout.read() if proc.stdout else "") + (proc.stderr.read() if proc.stderr else ""))

            # Assert the archived deal is still marked deleted in the canonical registry file.
            reg2 = DealRegistry(str(self.registry_path))
            deal = reg2.get_deal(self._seed_deal_id)
            self.assertIsNotNone(deal)
            self.assertTrue(bool(deal.deleted), "Archived deal resurrected by runner registry.save()")
        finally:
            if proc.poll() is None:
                proc.terminate()
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    proc.kill()
