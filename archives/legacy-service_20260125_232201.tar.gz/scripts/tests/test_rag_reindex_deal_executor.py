import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

SCRIPTS_DIR = Path(__file__).resolve().parents[1]
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))


class RagReindexDealExecutorTests(unittest.TestCase):
    def setUp(self) -> None:
        self._old_env = dict(os.environ)
        self._tmpdir = tempfile.TemporaryDirectory(dir="/home/zaks/tmp")
        self.tmp_path = Path(self._tmpdir.name)

        self.dataroom_root = self.tmp_path / "DataRoom"
        self.dataroom_root.mkdir(parents=True, exist_ok=True)
        os.environ["DATAROOM_ROOT"] = str(self.dataroom_root)

        (self.dataroom_root / ".deal-registry").mkdir(parents=True, exist_ok=True)

    def tearDown(self) -> None:
        os.environ.clear()
        os.environ.update(self._old_env)
        self._tmpdir.cleanup()

    def test_reindex_writes_manifest_and_reports(self) -> None:
        from actions.engine.models import ActionPayload, compute_idempotency_key
        from actions.executors.base import ExecutionContext
        from actions.executors.rag_reindex_deal import RagReindexDealExecutor

        # Create a deal folder (relative folder_path to exercise compatibility).
        rel_folder = Path("00-PIPELINE") / "Inbound" / "Test-Deal-2026"
        deal_dir = (self.dataroom_root / rel_folder).resolve()
        (deal_dir / "99-ACTIONS").mkdir(parents=True, exist_ok=True)
        (deal_dir / "07-Correspondence").mkdir(parents=True, exist_ok=True)

        doc = deal_dir / "07-Correspondence" / "email.md"
        doc.write_text("Hello world", encoding="utf-8")

        payload = ActionPayload(
            type="RAG.REINDEX_DEAL",
            deal_id="DEAL-2026-001",
            title="Reindex deal artifacts",
            created_by="unit_test",
            idempotency_key=compute_idempotency_key("rag_reindex", str(doc)),
            inputs={"artifact_paths": [str(doc)]},
        )
        ctx = ExecutionContext(action=payload, deal={"folder_path": str(rel_folder)}, case_file=None, tool_gateway=None)

        class _Resp:
            status_code = 200

        with patch("actions.executors.rag_reindex_deal.requests.post", return_value=_Resp()):
            result = RagReindexDealExecutor().execute(payload, ctx)

        out = result.outputs or {}
        self.assertEqual(out.get("indexed"), 1)
        manifest_path = Path(str(out.get("manifest_path") or "")).resolve()
        self.assertTrue(manifest_path.exists())
        data = json.loads(manifest_path.read_text(encoding="utf-8"))
        self.assertIn("files", data)
        self.assertTrue(data["files"])

