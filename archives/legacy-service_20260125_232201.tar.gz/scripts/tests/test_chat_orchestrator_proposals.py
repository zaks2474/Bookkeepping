import sys
from pathlib import Path
import unittest
from unittest.mock import patch

SCRIPTS_DIR = Path(__file__).resolve().parents[1]
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))


class ProposalParsingTests(unittest.TestCase):
    def test_extract_proposals_parses_indented_params(self):
        from chat_orchestrator import ChatOrchestrator

        orchestrator = ChatOrchestrator(allow_cloud=False)
        orchestrator.session_store = None

        text = """Hello

```proposal
type: add_note
deal_id: DEAL-TEST-001
params:
  content: "hello"
  category: "chat_note"
reason: test
```
"""

        proposals = orchestrator._extract_proposals(text)
        self.assertEqual(len(proposals), 1, proposals)
        proposal = proposals[0]

        self.assertEqual(proposal.get("type"), "add_note")
        self.assertEqual(proposal.get("deal_id"), "DEAL-TEST-001")
        self.assertIn("params", proposal)
        self.assertEqual(proposal["params"].get("content"), "hello")
        self.assertEqual(proposal["params"].get("category"), "chat_note")

    def test_extract_proposals_parses_strict_json_block(self):
        from chat_orchestrator import ChatOrchestrator

        orchestrator = ChatOrchestrator(allow_cloud=False)
        orchestrator.session_store = None

        text = """Hello

```proposal
{"type":"add_note","deal_id":"DEAL-TEST-001","params":{"content":"hello","category":"chat_note"},"reason":"test"}
```
"""

        proposals = orchestrator._extract_proposals(text)
        self.assertEqual(len(proposals), 1, proposals)
        proposal = proposals[0]
        self.assertEqual(proposal.get("type"), "add_note")
        self.assertEqual(proposal.get("deal_id"), "DEAL-TEST-001")
        self.assertEqual(proposal.get("params", {}).get("content"), "hello")

    def test_extract_proposals_parses_inline_json_params_value(self):
        from chat_orchestrator import ChatOrchestrator

        orchestrator = ChatOrchestrator(allow_cloud=False)
        orchestrator.session_store = None

        text = """Hello

```proposal
type: create_action
deal_id: DEAL-TEST-001
params:
  action_type: "DILIGENCE.REQUEST_DOCS"
  capability_id: "diligence.request_docs.v1"
  inputs: {"doc_type":"cim","description":"please share CIM"}
reason: test
```
"""

        proposals = orchestrator._extract_proposals(text)
        self.assertEqual(len(proposals), 1, proposals)
        proposal = proposals[0]
        self.assertEqual(proposal.get("type"), "create_action")
        self.assertIsInstance(proposal.get("params", {}).get("inputs"), dict)
        self.assertEqual(proposal["params"]["inputs"].get("doc_type"), "cim")

    def test_extract_proposals_parses_triple_quoted_multiline_param(self):
        from chat_orchestrator import ChatOrchestrator

        orchestrator = ChatOrchestrator(allow_cloud=False)
        orchestrator.session_store = None

        text = """Hello

```proposal
type: add_note
deal_id: DEAL-TEST-001
params:
  content: \"\"\"
  line1
  line2
  \"\"\"
reason: test
```
"""

        proposals = orchestrator._extract_proposals(text)
        self.assertEqual(len(proposals), 1, proposals)
        proposal = proposals[0]
        content = proposal.get("params", {}).get("content")
        self.assertIsInstance(content, str)
        self.assertIn("line1", content)
        self.assertIn("line2", content)


class ProposalNormalizationTests(unittest.TestCase):
    def test_normalize_proposals_fills_deal_id_in_deal_scope(self):
        from chat_orchestrator import ChatOrchestrator

        orchestrator = ChatOrchestrator(allow_cloud=False)
        proposals = [{"type": "add_note", "params": {"content": "x"}}]
        normalized = orchestrator._normalize_proposals_for_scope(proposals, {"type": "deal", "deal_id": "DEAL-TEST-001"})
        self.assertEqual(len(normalized), 1)
        self.assertEqual(normalized[0].get("deal_id"), "DEAL-TEST-001")

    def test_normalize_proposals_drops_placeholder_deal_id_in_global_scope(self):
        from chat_orchestrator import ChatOrchestrator

        orchestrator = ChatOrchestrator(allow_cloud=False)
        proposals = [{"type": "add_note", "deal_id": "DEAL-2025-XXX", "params": {"content": "x"}}]
        normalized = orchestrator._normalize_proposals_for_scope(proposals, {"type": "global"})
        self.assertEqual(normalized, [])


class ProposalExecutionTests(unittest.IsolatedAsyncioTestCase):
    async def test_execute_proposal_add_note_recovers_top_level_content(self):
        from chat_orchestrator import ChatOrchestrator, ChatMessage, ChatSession

        orchestrator = ChatOrchestrator(allow_cloud=False)
        orchestrator.session_store = None

        session_id = "sess-add-note"
        deal_id = "DEAL-TEST-001"
        proposal_id = "p-add-note"

        session = ChatSession(session_id=session_id, scope={"type": "deal", "deal_id": deal_id})
        # Regression fixture: content incorrectly stored at top-level (params missing)
        proposal = {
            "proposal_id": proposal_id,
            "type": "add_note",
            "deal_id": deal_id,
            "content": "hello",
            "status": "pending_approval",
            "reason": "capture note",
        }
        session.messages.append(ChatMessage(role="assistant", content="...", proposals=[proposal]))
        orchestrator.sessions[session_id] = session

        called = {}

        def fake_execute_add_note(*, deal_id: str, content: str, category: str):
            called["deal_id"] = deal_id
            called["content"] = content
            called["category"] = category
            return {"success": True, "event_id": "E-123"}

        orchestrator._execute_add_note = fake_execute_add_note  # type: ignore[assignment]

        result = await orchestrator.execute_proposal(
            proposal_id=proposal_id,
            approved_by="operator",
            session_id=session_id,
        )

        self.assertTrue(result.get("success"), result)
        self.assertEqual(result.get("proposal_type"), "add_note")
        self.assertEqual(called.get("deal_id"), deal_id)
        self.assertEqual(called.get("content"), "hello")
        self.assertEqual(result["proposal"]["status"], "executed")

    async def test_execute_proposal_alias_schedule_action_executes_create_task(self):
        from chat_orchestrator import ChatOrchestrator, ChatMessage, ChatSession

        orchestrator = ChatOrchestrator(allow_cloud=False)
        orchestrator.session_store = None

        session_id = "sess-alias"
        deal_id = "DEAL-TEST-002"
        proposal_id = "p-schedule-action"

        session = ChatSession(session_id=session_id, scope={"type": "deal", "deal_id": deal_id})
        session.messages.append(
            ChatMessage(
                role="assistant",
                content="...",
                proposals=[
                    {
                        "proposal_id": proposal_id,
                        "type": "schedule_action",
                        "deal_id": deal_id,
                        "params": {"description": "follow up", "due_days": 1},
                        "status": "pending_approval",
                        "reason": "Follow up with broker",
                    }
                ],
            )
        )
        orchestrator.sessions[session_id] = session

        with patch("deferred_actions.DeferredActionQueue") as MockQueue:
            instance = MockQueue.return_value
            instance.schedule_relative.return_value = "ACTION-1"

            result = await orchestrator.execute_proposal(
                proposal_id=proposal_id,
                approved_by="operator",
                session_id=session_id,
            )

        self.assertTrue(result.get("success"), result)
        self.assertEqual(result.get("proposal_type"), "create_task")
        self.assertEqual(result["proposal"]["type"], "create_task")
        self.assertEqual(result["proposal"]["status"], "executed")
        self.assertEqual(result["result"]["action_id"], "ACTION-1")

    async def test_execute_proposal_allows_retry_from_failed(self):
        from chat_orchestrator import ChatOrchestrator, ChatMessage, ChatSession

        orchestrator = ChatOrchestrator(allow_cloud=False)
        orchestrator.session_store = None

        session_id = "sess-retry"
        deal_id = "DEAL-TEST-020"
        proposal_id = "p-retry"

        session = ChatSession(session_id=session_id, scope={"type": "deal", "deal_id": deal_id})
        session.messages.append(
            ChatMessage(
                role="assistant",
                content="...",
                proposals=[
                    {
                        "proposal_id": proposal_id,
                        "type": "add_note",
                        "deal_id": deal_id,
                        "params": {"content": "retry note", "category": "chat_note"},
                        "status": "failed",
                        "error": "previous failure",
                    }
                ],
            )
        )
        orchestrator.sessions[session_id] = session

        def fake_execute_add_note(*, deal_id: str, content: str, category: str):
            return {"success": True, "event_id": "E-RETRY"}

        orchestrator._execute_add_note = fake_execute_add_note  # type: ignore[assignment]

        result = await orchestrator.execute_proposal(
            proposal_id=proposal_id,
            approved_by="operator",
            session_id=session_id,
            action="approve",
        )

        self.assertTrue(result.get("success"), result)
        self.assertEqual(result["proposal"]["status"], "executed")

    async def test_execute_proposal_draft_email_includes_provider(self):
        from chat_orchestrator import ChatOrchestrator, ChatMessage, ChatSession

        orchestrator = ChatOrchestrator(allow_cloud=False)
        orchestrator.session_store = None

        session_id = "sess-email"
        deal_id = "DEAL-TEST-003"
        proposal_id = "p-draft-email"

        session = ChatSession(session_id=session_id, scope={"type": "deal", "deal_id": deal_id})
        session.messages.append(
            ChatMessage(
                role="assistant",
                content="...",
                proposals=[
                    {
                        "proposal_id": proposal_id,
                        "type": "draft_email",
                        "deal_id": deal_id,
                        "params": {"recipient": "broker@example.com", "subject": "Re: CIM", "context": "Need CIM"},
                        "status": "pending_approval",
                        "reason": "Request CIM",
                    }
                ],
            )
        )
        orchestrator.sessions[session_id] = session

        async def fake_generate_broker_email(
            *,
            deal_id: str,
            recipient: str,
            subject: str,
            context: str,
            allow_cloud_override=None,
        ):
            return {
                "success": True,
                "subject": "Re: CIM Request",
                "body": "Hi — please send the CIM when available.\nThanks,",
                "provider": "gemini-pro",
                "model": "gemini-1.5-pro",
                "forced_reason": "email_draft",
                "warning": None,
            }

        orchestrator._generate_broker_email = fake_generate_broker_email  # type: ignore[assignment]

        result = await orchestrator.execute_proposal(
            proposal_id=proposal_id,
            approved_by="operator",
            session_id=session_id,
        )

        self.assertTrue(result.get("success"), result)
        self.assertEqual(result.get("proposal_type"), "draft_email")
        self.assertEqual(result["proposal"]["status"], "executed")
        self.assertEqual(result["result"]["provider"], "gemini-pro")
        self.assertEqual(result["result"]["model"], "gemini-1.5-pro")

    async def test_generate_broker_email_uses_gemini_pro_and_requires_json(self):
        from chat_llm_provider import HealthStatus, ProviderResponse
        from chat_orchestrator import ChatOrchestrator

        orchestrator = ChatOrchestrator(allow_cloud=False)
        orchestrator.session_store = None

        class StubGeminiPro:
            async def health_check(self):
                return HealthStatus(
                    healthy=True,
                    provider="gemini-pro",
                    model="gemini-1.5-pro",
                    endpoint="stub://gemini-pro",
                )

            async def generate(self, messages, temperature=0.4, max_tokens=600, **kwargs):
                return ProviderResponse(
                    content='{"subject":"Hello","body":"Body"}',
                    provider="gemini-pro",
                    model="gemini-1.5-pro",
                )

        with patch("chat_orchestrator.ALLOW_CLOUD", True), patch(
            "chat_orchestrator.get_provider", return_value=StubGeminiPro()
        ) as mock_get_provider:
            result = await orchestrator._generate_broker_email(
                deal_id="DEAL-TEST-004",
                recipient="broker@example.com",
                subject="Subject",
                context="Context",
            )

        self.assertTrue(result.get("success"), result)
        self.assertEqual(result.get("provider"), "gemini-pro")
        self.assertEqual(result.get("model"), "gemini-1.5-pro")
        mock_get_provider.assert_called_with("gemini-pro")
