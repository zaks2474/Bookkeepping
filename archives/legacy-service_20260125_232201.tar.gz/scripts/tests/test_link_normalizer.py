#!/usr/bin/env python3
"""
Regression tests for link_normalizer module.

Tests:
1. HubSpot tracking URL classification
2. Social media URL classification
3. Unsubscribe URL detection
4. Deal material URL classification
5. Canonical key generation
6. Deduplication behavior

Run with: python3 tests/test_link_normalizer.py
"""

import sys
from pathlib import Path

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from link_normalizer import (
    LinkNormalizer,
    LinkCategory,
    ClassifiedLink,
    classify_link,
    process_links,
    dedupe_links,
)


class TestLinkClassification:
    """Test link classification by category."""

    def setup_method(self):
        """Set up test normalizer (no network resolution)."""
        self.normalizer = LinkNormalizer(resolve_tracking=False)

    def test_hubspot_tracking_url(self):
        """HubSpot tracking links should be classified as tracking."""
        url = "https://d13dQH04.na1.hubspotlinksstarter.com/Ctc/5E+113/d13dQH04/VWP6ML1sNQB_"
        result = self.normalizer.classify_link(url)
        assert result.category == LinkCategory.TRACKING
        assert result.link_type == "email_tracking"
        assert result.confidence >= 0.9

    def test_mailchimp_tracking_url(self):
        """Mailchimp tracking links should be classified as tracking."""
        url = "https://list-manage.com/track/click?u=abc123&id=xyz"
        result = self.normalizer.classify_link(url)
        assert result.category == LinkCategory.TRACKING

    def test_linkedin_social_url(self):
        """LinkedIn URLs should be classified as social."""
        url = "https://www.linkedin.com/company/acme-corp"
        result = self.normalizer.classify_link(url)
        assert result.category == LinkCategory.SOCIAL
        assert result.link_type == "linkedin"

    def test_twitter_social_url(self):
        """Twitter/X URLs should be classified as social."""
        url = "https://twitter.com/acmecorp"
        result = self.normalizer.classify_link(url)
        assert result.category == LinkCategory.SOCIAL
        assert result.link_type == "twitter"

    def test_unsubscribe_url(self):
        """Unsubscribe URLs should be classified correctly."""
        urls = [
            "https://example.com/unsubscribe?email=test@test.com",
            "https://example.com/email-preferences",
            "https://example.com/manage-subscription",
            "https://example.com/opt-out",
        ]
        for url in urls:
            result = self.normalizer.classify_link(url)
            assert result.category == LinkCategory.UNSUBSCRIBE, f"Failed for {url}"

    def test_calendly_calendar_url(self):
        """Calendly URLs should be classified as calendar."""
        url = "https://calendly.com/broker-name/30min"
        result = self.normalizer.classify_link(url)
        assert result.category == LinkCategory.CALENDAR
        assert result.link_type == "meeting"

    def test_firmex_deal_material(self):
        """Firmex URLs should be classified as deal material."""
        url = "https://www.firmex.com/dataroom/project-alpha"
        result = self.normalizer.classify_link(url)
        assert result.category == LinkCategory.DEAL_MATERIAL
        assert result.auth_required == True

    def test_axial_auth_required(self):
        """Axial URLs should require auth."""
        url = "https://www.axial.net/project/123"
        result = self.normalizer.classify_link(url)
        assert result.auth_required == True

    def test_context_based_classification(self):
        """URLs should use context for classification hints."""
        url = "https://example.com/document/xyz"
        result = self.normalizer.classify_link(
            url,
            context="Please sign the NDA before accessing the data room."
        )
        assert result.category == LinkCategory.DEAL_MATERIAL


class TestCanonicalKey:
    """Test canonical URL and key generation."""

    def setup_method(self):
        self.normalizer = LinkNormalizer(resolve_tracking=False)

    def test_different_tracking_urls_different_keys(self):
        """Different tracking URLs (different paths) should have different keys."""
        url1 = "https://d13dQH04.na1.hubspotlinksstarter.com/Ctc/5E+113/d13dQH04/AAA"
        url2 = "https://d13dQH04.na1.hubspotlinksstarter.com/Ctc/5E+113/d13dQH04/BBB"

        result1 = self.normalizer.classify_link(url1)
        result2 = self.normalizer.classify_link(url2)

        # Different canonical keys (they're different tracking URLs)
        assert result1.canonical_key != result2.canonical_key

    def test_same_url_with_utm_params(self):
        """Same URL with different UTM params should have same canonical key."""
        url1 = "https://example.com/document?utm_source=email&utm_campaign=test"
        url2 = "https://example.com/document?utm_source=linkedin&utm_campaign=other"

        result1 = self.normalizer.classify_link(url1)
        result2 = self.normalizer.classify_link(url2)

        # Same canonical key (UTM params stripped)
        assert result1.canonical_key == result2.canonical_key

    def test_www_normalization(self):
        """www prefix should be normalized away."""
        url1 = "https://www.example.com/document"
        url2 = "https://example.com/document"

        result1 = self.normalizer.classify_link(url1)
        result2 = self.normalizer.classify_link(url2)

        assert result1.canonical_key == result2.canonical_key


class TestDeduplication:
    """Test link deduplication behavior."""

    def setup_method(self):
        self.normalizer = LinkNormalizer(resolve_tracking=False)

    def test_dedupe_identical_urls(self):
        """Identical URLs should be deduplicated."""
        links = [
            {"url": "https://example.com/document"},
            {"url": "https://example.com/document"},
            {"url": "https://example.com/document"},
        ]
        result = self.normalizer.dedupe_links(links)
        assert len(result) == 1

    def test_dedupe_urls_with_different_utm(self):
        """URLs differing only by UTM params should dedupe."""
        links = [
            {"url": "https://example.com/document?utm_source=email"},
            {"url": "https://example.com/document?utm_source=linkedin"},
            {"url": "https://example.com/document?utm_campaign=test"},
        ]
        result = self.normalizer.dedupe_links(links)
        assert len(result) == 1

    def test_dedupe_preserves_different_urls(self):
        """Different URLs should not be deduplicated."""
        links = [
            {"url": "https://example.com/doc1"},
            {"url": "https://example.com/doc2"},
            {"url": "https://other.com/doc1"},
        ]
        result = self.normalizer.dedupe_links(links)
        assert len(result) == 3

    def test_tracking_urls_not_collapsed(self):
        """Different tracking URLs should NOT be collapsed (different paths = different links)."""
        links = [
            {"url": "https://d13dQH04.na1.hubspotlinksstarter.com/Ctc/AAA"},
            {"url": "https://d13dQH04.na1.hubspotlinksstarter.com/Ctc/BBB"},
            {"url": "https://d13dQH04.na1.hubspotlinksstarter.com/Ctc/CCC"},
        ]
        result = self.normalizer.dedupe_links(links)
        # Note: Without URL resolution, these are treated as different links
        # because they have different paths
        assert len(result) == 3


class TestProcessLinks:
    """Test the full process_links pipeline."""

    def test_process_mixed_links(self):
        """Test full pipeline with mixed link types."""
        links = [
            {"url": "https://d13dQH04.na1.hubspotlinksstarter.com/Ctc/AAA", "type": "nda"},
            {"url": "https://d13dQH04.na1.hubspotlinksstarter.com/Ctc/BBB", "type": "nda"},
            {"url": "https://www.linkedin.com/company/acme"},
            {"url": "https://www.firmex.com/dataroom/123"},
            {"url": "https://example.com/unsubscribe"},
            {"url": "https://calendly.com/broker/meeting"},
        ]

        result = process_links(links)

        assert "groups" in result
        assert "all_unique" in result
        assert "unique_count" in result

        # Should have tracking group with HubSpot links
        assert "tracking" in result["groups"]
        assert len(result["groups"]["tracking"]) == 2

        # Should have social group with LinkedIn
        assert "social" in result["groups"]
        assert len(result["groups"]["social"]) == 1

        # Should have deal_material group
        assert "deal_material" in result["groups"]
        assert len(result["groups"]["deal_material"]) == 1

    def test_stats_calculation(self):
        """Test that stats are correctly calculated."""
        links = [
            {"url": "https://example.com/doc?utm_source=a"},
            {"url": "https://example.com/doc?utm_source=b"},
            {"url": "https://example.com/doc?utm_source=c"},
            {"url": "https://other.com/doc"},
        ]

        result = process_links(links)

        assert result["total_count"] == 4
        assert result["unique_count"] == 2  # example.com/doc deduped to 1
        assert result["duplicates_removed"] == 2


class TestConvenienceFunctions:
    """Test module-level convenience functions."""

    def test_classify_link_function(self):
        """Test standalone classify_link function."""
        result = classify_link("https://www.linkedin.com/company/test")
        assert result.category == LinkCategory.SOCIAL

    def test_dedupe_links_function(self):
        """Test standalone dedupe_links function."""
        links = [
            {"url": "https://example.com/doc"},
            {"url": "https://example.com/doc"},
        ]
        result = dedupe_links(links)
        assert len(result) == 1


def run_tests():
    """Run all tests without pytest."""
    passed = 0
    failed = 0

    test_classes = [
        TestLinkClassification,
        TestCanonicalKey,
        TestDeduplication,
        TestProcessLinks,
        TestConvenienceFunctions,
    ]

    for cls in test_classes:
        print(f"\n{cls.__name__}")
        print("-" * 40)
        instance = cls()
        if hasattr(instance, "setup_method"):
            instance.setup_method()

        for method_name in dir(instance):
            if method_name.startswith("test_"):
                try:
                    getattr(instance, method_name)()
                    print(f"  PASS: {method_name}")
                    passed += 1
                except AssertionError as e:
                    print(f"  FAIL: {method_name} - {e}")
                    failed += 1
                except Exception as e:
                    print(f"  ERROR: {method_name} - {e}")
                    failed += 1

    print(f"\n{'='*40}")
    print(f"Results: {passed} passed, {failed} failed")
    return failed == 0


if __name__ == "__main__":
    success = run_tests()
    sys.exit(0 if success else 1)
