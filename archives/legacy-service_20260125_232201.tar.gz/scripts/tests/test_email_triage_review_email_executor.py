import importlib
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

import httpx

SCRIPTS_DIR = Path(__file__).resolve().parents[1]
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))


class EmailTriageReviewEmailExecutorTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self._old_env = dict(os.environ)
        self._tmpdir = tempfile.TemporaryDirectory(dir="/home/zaks/tmp")
        self.tmp_path = Path(self._tmpdir.name)

        self.dataroom_root = self.tmp_path / "DataRoom"
        self.dataroom_root.mkdir(parents=True, exist_ok=True)

        os.environ["DATAROOM_ROOT"] = str(self.dataroom_root)
        os.environ["ZAKOPS_STATE_DB"] = str(self.tmp_path / "state.db")
        os.environ["DEAL_EVENTS_DIR"] = str(self.tmp_path / "events")

        # Reset module singletons that cache env-derived paths.
        import actions.capabilities.registry as cap_registry
        import tools.registry as tool_registry
        import tools.gateway as tool_gateway
        import actions.executors.registry as exec_registry

        cap_registry._REGISTRY = None
        tool_registry._REGISTRY = None
        tool_gateway._GATEWAY = None
        exec_registry._EXECUTORS.clear()
        exec_registry._BUILTINS_LOADED = False
        exec_registry._TOOL_EXECUTOR = None

        # Reload modules that bind DATAROOM_ROOT at import time.
        import actions.executors._artifacts as artifacts
        import deal_lifecycle_api
        import actions_runner

        importlib.reload(artifacts)
        importlib.reload(deal_lifecycle_api)
        importlib.reload(actions_runner)

        registry_dir = self.dataroom_root / ".deal-registry"
        registry_dir.mkdir(parents=True, exist_ok=True)
        (registry_dir / "case_files").mkdir(parents=True, exist_ok=True)

        (self.dataroom_root / "00-PIPELINE" / "Inbound").mkdir(parents=True, exist_ok=True)
        (self.dataroom_root / "00-PIPELINE" / "_INBOX_QUARANTINE").mkdir(parents=True, exist_ok=True)

        # Start with an empty registry.
        (registry_dir / "deal_registry.json").write_text(
            json.dumps(
                {
                    "deal_counter": 0,
                    "broker_counter": 0,
                    "deals": {},
                    "brokers": {},
                    "junk_patterns": [],
                    "email_to_deal": {},
                },
                indent=2,
                sort_keys=True,
            ),
            encoding="utf-8",
        )

    def tearDown(self):
        os.environ.clear()
        os.environ.update(self._old_env)
        self._tmpdir.cleanup()

    async def test_review_email_creates_deal_and_persists_artifacts(self):
        import deal_lifecycle_api
        import actions_runner

        message_id = "19b5-test-msg"
        thread_id = "thread-1"
        quarantine_dir = self.dataroom_root / "00-PIPELINE" / "_INBOX_QUARANTINE" / message_id
        quarantine_dir.mkdir(parents=True, exist_ok=True)
        (quarantine_dir / "email_body.txt").write_text("Hello, here is the teaser and CIM link.", encoding="utf-8")
        (quarantine_dir / "teaser.pdf").write_bytes(b"%PDF-1.4 fake teaser\n")

        transport = httpx.ASGITransport(app=deal_lifecycle_api.app)
        async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
            create = await client.post(
                "/api/actions",
                json={
                    "action_type": "EMAIL_TRIAGE.REVIEW_EMAIL",
                    "title": "Review inbound deal email: ExampleCo teaser",
                    "summary": "HIGH urgency. Contains deal signals.",
                    "deal_id": None,
                    "capability_id": "email_triage.review_email.v1",
                    "created_by": "email_triage_agent",
                    "source": "system",
                    "risk_level": "medium",
                    "requires_human_review": True,
                    "inputs": {
                        "message_id": message_id,
                        "thread_id": thread_id,
                        "from": "Broker <broker@example.com>",
                        "to": "operator@example.com",
                        "date": "01 Jan 2026 12:00:00 +0000",
                        "subject": "ExampleCo teaser",
                        "company": "ExampleCo",
                        "classification": "DEAL_SIGNAL",
                        "urgency": "HIGH",
                        "links": [],
                        "attachments": [{"filename": "teaser.pdf", "mime_type": "application/pdf", "size_bytes": 123}],
                        "quarantine_dir": str(quarantine_dir),
                    },
                },
            )
            self.assertEqual(create.status_code, 200, create.text)
            action_id = create.json()["action"]["action_id"]

            approve = await client.post(f"/api/actions/{action_id}/approve", json={"approved_by": "operator"})
            self.assertEqual(approve.status_code, 200, approve.text)

            execute = await client.post(f"/api/actions/{action_id}/execute", json={"requested_by": "operator"})
            self.assertEqual(execute.status_code, 200, execute.text)

        from actions.engine.store import ActionStore
        from deal_events import DealEventStore
        from deal_registry import DealRegistry

        store = ActionStore(Path(os.environ["ZAKOPS_STATE_DB"]))
        registry = DealRegistry(str(self.dataroom_root / ".deal-registry" / "deal_registry.json"))
        event_store = DealEventStore(events_dir=os.environ["DEAL_EVENTS_DIR"])

        actions_runner.process_one_action(
            store=store,
            registry=registry,
            event_store=event_store,
            owner_id="test-runner",
            action_id=action_id,
            action_lock_seconds=60,
        )

        completed = store.get_action(action_id)
        self.assertIsNotNone(completed)
        self.assertEqual(completed.status, "COMPLETED")

        outputs = completed.outputs or {}
        deal_id = str(outputs.get("deal_id") or "")
        deal_folder = str(outputs.get("deal_folder") or "")
        self.assertTrue(deal_id)
        self.assertTrue(deal_folder)

        deal_path = Path(deal_folder).resolve()
        self.assertTrue(deal_path.exists())
        self.assertTrue((deal_path / "README.md").exists())
        self.assertTrue((deal_path / "07-Correspondence").exists())

        # Follow-on: append email materials into 07-Correspondence/<bundle>/...
        append = store.list_actions(deal_id=deal_id, action_type="DEAL.APPEND_EMAIL_MATERIALS", limit=10)
        self.assertTrue(append)
        append_id = append[0].action_id
        actions_runner.process_one_action(
            store=store,
            registry=registry,
            event_store=event_store,
            owner_id="test-runner",
            action_id=append_id,
            action_lock_seconds=60,
        )
        appended = store.get_action(append_id)
        self.assertIsNotNone(appended)
        self.assertEqual(appended.status, "COMPLETED")

        corr = deal_path / "07-Correspondence"
        bundle_dirs = [p for p in corr.iterdir() if p.is_dir() and (p / "manifest.json").exists()]
        self.assertTrue(bundle_dirs)
        bundle = bundle_dirs[0]
        self.assertTrue((bundle / "email.md").exists())
        self.assertTrue((bundle / "manifest.json").exists())
        self.assertTrue((bundle / "attachments" / "teaser.pdf").exists())

        # Follow-on derived view: place attachments into top-level buckets.
        dedupe = store.list_actions(deal_id=deal_id, action_type="DEAL.DEDUPE_AND_PLACE_MATERIALS", limit=10)
        self.assertTrue(dedupe)
        dedupe_id = dedupe[0].action_id
        actions_runner.process_one_action(
            store=store,
            registry=registry,
            event_store=event_store,
            owner_id="test-runner",
            action_id=dedupe_id,
            action_lock_seconds=60,
        )
        deduped = store.get_action(dedupe_id)
        self.assertIsNotNone(deduped)
        self.assertEqual(deduped.status, "COMPLETED")
        self.assertTrue((deal_path / "02-CIM" / "teaser.pdf").exists())

        # Registry should contain the new deal.
        raw_registry = json.loads((self.dataroom_root / ".deal-registry" / "deal_registry.json").read_text(encoding="utf-8"))
        self.assertIn(deal_id, raw_registry.get("deals", {}))
        self.assertEqual(raw_registry.get("email_to_deal", {}).get(message_id), deal_id)
        self.assertEqual(raw_registry.get("thread_to_deal", {}).get(thread_id), deal_id)

    async def test_review_email_reuses_deal_for_same_thread(self):
        import deal_lifecycle_api
        import actions_runner

        thread_id = "thread-shared"
        message_1 = "msg-1"
        message_2 = "msg-2"

        for mid in (message_1, message_2):
            qdir = self.dataroom_root / "00-PIPELINE" / "_INBOX_QUARANTINE" / mid
            qdir.mkdir(parents=True, exist_ok=True)
            (qdir / "email_body.txt").write_text(f"Email for {mid}.", encoding="utf-8")
            (qdir / "teaser.pdf").write_bytes(b"%PDF-1.4 fake teaser\n")

        transport = httpx.ASGITransport(app=deal_lifecycle_api.app)
        async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
            # First email -> creates deal
            create1 = await client.post(
                "/api/actions",
                json={
                    "action_type": "EMAIL_TRIAGE.REVIEW_EMAIL",
                    "title": "Review inbound deal email: ExampleCo teaser 1",
                    "summary": "HIGH urgency. Contains deal signals.",
                    "deal_id": None,
                    "capability_id": "email_triage.review_email.v1",
                    "created_by": "email_triage_agent",
                    "source": "system",
                    "risk_level": "medium",
                    "requires_human_review": True,
                    "inputs": {
                        "message_id": message_1,
                        "thread_id": thread_id,
                        "from": "Broker <broker@example.com>",
                        "to": "operator@example.com",
                        "date": "01 Jan 2026 12:00:00 +0000",
                        "subject": "ExampleCo teaser",
                        "company": "ExampleCo",
                        "classification": "DEAL_SIGNAL",
                        "urgency": "HIGH",
                        "links": [],
                        "attachments": [{"filename": "teaser.pdf", "mime_type": "application/pdf", "size_bytes": 123}],
                        "quarantine_dir": str(self.dataroom_root / "00-PIPELINE" / "_INBOX_QUARANTINE" / message_1),
                    },
                },
            )
            self.assertEqual(create1.status_code, 200, create1.text)
            action_1 = create1.json()["action"]["action_id"]
            self.assertEqual((await client.post(f"/api/actions/{action_1}/approve", json={"approved_by": "operator"})).status_code, 200)
            self.assertEqual((await client.post(f"/api/actions/{action_1}/execute", json={"requested_by": "operator"})).status_code, 200)

            # Second email -> should reuse same deal via thread_to_deal mapping
            create2 = await client.post(
                "/api/actions",
                json={
                    "action_type": "EMAIL_TRIAGE.REVIEW_EMAIL",
                    "title": "Review inbound deal email: ExampleCo teaser 2",
                    "summary": "HIGH urgency. Follow-up in same thread.",
                    "deal_id": None,
                    "capability_id": "email_triage.review_email.v1",
                    "created_by": "email_triage_agent",
                    "source": "system",
                    "risk_level": "medium",
                    "requires_human_review": True,
                    "inputs": {
                        "message_id": message_2,
                        "thread_id": thread_id,
                        "from": "Broker <broker@example.com>",
                        "to": "operator@example.com",
                        "date": "01 Jan 2026 13:00:00 +0000",
                        "subject": "Re: ExampleCo teaser",
                        "company": "ExampleCo",
                        "classification": "DEAL_SIGNAL",
                        "urgency": "HIGH",
                        "links": [],
                        "attachments": [{"filename": "teaser.pdf", "mime_type": "application/pdf", "size_bytes": 123}],
                        "quarantine_dir": str(self.dataroom_root / "00-PIPELINE" / "_INBOX_QUARANTINE" / message_2),
                    },
                },
            )
            self.assertEqual(create2.status_code, 200, create2.text)
            action_2 = create2.json()["action"]["action_id"]
            self.assertEqual((await client.post(f"/api/actions/{action_2}/approve", json={"approved_by": "operator"})).status_code, 200)
            self.assertEqual((await client.post(f"/api/actions/{action_2}/execute", json={"requested_by": "operator"})).status_code, 200)

        from actions.engine.store import ActionStore
        from deal_events import DealEventStore
        from deal_registry import DealRegistry

        store = ActionStore(Path(os.environ["ZAKOPS_STATE_DB"]))
        event_store = DealEventStore(events_dir=os.environ["DEAL_EVENTS_DIR"])

        # Run both actions through the runner.
        reg1 = DealRegistry(str(self.dataroom_root / ".deal-registry" / "deal_registry.json"))
        actions_runner.process_one_action(
            store=store,
            registry=reg1,
            event_store=event_store,
            owner_id="test-runner",
            action_id=action_1,
            action_lock_seconds=60,
        )
        completed1 = store.get_action(action_1)
        self.assertIsNotNone(completed1)
        self.assertEqual(completed1.status, "COMPLETED")
        deal_id_1 = str((completed1.outputs or {}).get("deal_id") or "")
        self.assertTrue(deal_id_1)

        reg2 = DealRegistry(str(self.dataroom_root / ".deal-registry" / "deal_registry.json"))
        actions_runner.process_one_action(
            store=store,
            registry=reg2,
            event_store=event_store,
            owner_id="test-runner",
            action_id=action_2,
            action_lock_seconds=60,
        )
        completed2 = store.get_action(action_2)
        self.assertIsNotNone(completed2)
        self.assertEqual(completed2.status, "COMPLETED")
        deal_id_2 = str((completed2.outputs or {}).get("deal_id") or "")
        self.assertEqual(deal_id_2, deal_id_1)

        raw_registry = json.loads((self.dataroom_root / ".deal-registry" / "deal_registry.json").read_text(encoding="utf-8"))
        self.assertEqual(len(raw_registry.get("deals") or {}), 1)
        self.assertEqual(raw_registry.get("thread_to_deal", {}).get(thread_id), deal_id_1)
        self.assertEqual(raw_registry.get("email_to_deal", {}).get(message_1), deal_id_1)
        self.assertEqual(raw_registry.get("email_to_deal", {}).get(message_2), deal_id_1)
