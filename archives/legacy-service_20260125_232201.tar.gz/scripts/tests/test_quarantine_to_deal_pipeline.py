import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

SCRIPTS_DIR = Path(__file__).resolve().parents[1]
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))


class QuarantineToDealPipelineTests(unittest.TestCase):
    def setUp(self):
        self._old_env = dict(os.environ)
        self._tmpdir = tempfile.TemporaryDirectory(dir="/home/zaks/tmp")
        self.dataroom_root = Path(self._tmpdir.name) / "DataRoom"
        os.environ["DATAROOM_ROOT"] = str(self.dataroom_root)

    def tearDown(self):
        os.environ.clear()
        os.environ.update(self._old_env)
        self._tmpdir.cleanup()

    def test_create_deal_from_quarantine_is_idempotent(self):
        from actions.engine.models import ActionPayload, compute_idempotency_key
        from actions.executors.base import ExecutionContext

        message_id = "msg_12345"
        quarantine_root = self.dataroom_root / "00-PIPELINE" / "_INBOX_QUARANTINE"
        quarantine_dir = quarantine_root / message_id
        quarantine_dir.mkdir(parents=True, exist_ok=True)
        (quarantine_dir / "email_body.txt").write_text("Please sign the NDA attached.", encoding="utf-8")
        (quarantine_dir / "signed-nda.pdf").write_bytes(b"%PDF-FAKE")

        from actions.executors.deal_create_from_email import CreateDealFromEmailExecutor

        payload = ActionPayload(
            type="DEAL.CREATE_FROM_EMAIL",
            title="Create deal from quarantine email",
            created_by="unit_test",
            idempotency_key=compute_idempotency_key("create_deal_from_email", message_id),
            inputs={
                "gmail_message_id": message_id,
                "gmail_thread_id": "thread_1",
                "subject": "Signed NDA - Acme Widgets",
                "from_email": "broker@example.com",
                "inferred_company_name": "Acme Widgets",
                "quarantine_root": str(quarantine_root),
            },
        )
        ctx = ExecutionContext(action=payload, deal=None, case_file=None, tool_gateway=None)

        ex = CreateDealFromEmailExecutor()
        first = ex.execute(payload, ctx)

        deal_id_1 = str((first.outputs or {}).get("deal_id") or "")
        deal_path_1 = Path(str((first.outputs or {}).get("deal_path") or "")).resolve()
        self.assertTrue(deal_id_1.startswith("DEAL-"), deal_id_1)
        self.assertTrue(deal_path_1.exists(), deal_path_1)

        # Validate registry and email mapping
        reg_path = self.dataroom_root / ".deal-registry" / "deal_registry.json"
        reg = json.loads(reg_path.read_text(encoding="utf-8"))
        self.assertIn(deal_id_1, (reg.get("deals") or {}))
        self.assertEqual((reg.get("email_to_deal") or {}).get(message_id), deal_id_1)

        # Re-run should not create a second deal
        second = ex.execute(payload, ctx)
        deal_id_2 = str((second.outputs or {}).get("deal_id") or "")
        deal_path_2 = Path(str((second.outputs or {}).get("deal_path") or "")).resolve()
        self.assertEqual(deal_id_2, deal_id_1)
        self.assertEqual(deal_path_2, deal_path_1)

        reg2 = json.loads(reg_path.read_text(encoding="utf-8"))
        self.assertEqual(len(reg2.get("deals") or {}), 1)

        # Ensure key artifacts exist under correspondence
        inbox_dir = deal_path_1 / "07-Correspondence" / "INBOX"
        att_dir = deal_path_1 / "07-Correspondence" / "ATTACHMENTS"
        self.assertTrue(inbox_dir.exists())
        self.assertTrue(att_dir.exists())
        self.assertTrue((inbox_dir / f"{message_id}.md").exists())
        self.assertTrue((inbox_dir / f"{message_id}.json").exists())

        # Attachment copied (from quarantine) into deal attachments
        copied = list(att_dir.glob("*.pdf"))
        self.assertTrue(copied, "Expected at least one copied PDF attachment")

    def test_extract_email_artifacts_writes_outputs(self):
        from actions.engine.models import ActionPayload, compute_idempotency_key
        from actions.executors.base import ExecutionContext

        # Create a minimal deal folder + "email artifact" to scan
        deal_dir = self.dataroom_root / "00-PIPELINE" / "Inbound" / "Test-Deal-2026"
        (deal_dir / "99-ACTIONS").mkdir(parents=True, exist_ok=True)
        corr_dir = deal_dir / "07-Correspondence" / "INBOX"
        corr_dir.mkdir(parents=True, exist_ok=True)
        email_md = corr_dir / "email.md"
        email_md.write_text("We have $5M revenue and $1M EBITDA. Please sign the NDA.", encoding="utf-8")

        from actions.executors.deal_extract_email_artifacts import ExtractEmailArtifactsExecutor

        payload = ActionPayload(
            type="DEAL.EXTRACT_EMAIL_ARTIFACTS",
            title="Extract email artifacts",
            created_by="unit_test",
            deal_id="DEAL-2026-001",
            idempotency_key=compute_idempotency_key("extract_email_artifacts", str(email_md)),
            inputs={"artifact_paths": [str(email_md)]},
        )
        ctx = ExecutionContext(action=payload, deal={"folder_path": str(deal_dir)}, case_file=None, tool_gateway=None)

        ex = ExtractEmailArtifactsExecutor()
        result = ex.execute(payload, ctx)

        out = result.outputs or {}
        outputs = out.get("outputs") or {}
        summary = Path(str(outputs.get("extracted_summary_md") or "")).resolve()
        entities = Path(str(outputs.get("extracted_entities_json") or "")).resolve()
        doc_types = Path(str(outputs.get("detected_doc_types_json") or "")).resolve()

        self.assertTrue(summary.exists())
        self.assertTrue(entities.exists())
        self.assertTrue(doc_types.exists())

