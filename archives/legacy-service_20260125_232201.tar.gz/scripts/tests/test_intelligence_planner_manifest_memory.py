import importlib
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

SCRIPTS_DIR = Path(__file__).resolve().parents[1]
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))


def _write_manifest(path: Path, capabilities: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {"manifest_version": "1.0", "generated_at": "test", "capabilities": capabilities}
    path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")


class IntelligencePlannerTests(unittest.TestCase):
    def setUp(self):
        self._old_env = dict(os.environ)
        self._tmpdir = tempfile.TemporaryDirectory(dir="/home/zaks/tmp")
        self.tmp_path = Path(self._tmpdir.name)
        os.environ["ZAKOPS_STATE_DB"] = str(self.tmp_path / "state.db")
        os.environ["ZAKOPS_PLANNER_USE_LLM"] = "false"

        self.manifest_path = self.tmp_path / "manifest.json"
        os.environ["ZAKOPS_UNIFIED_MANIFEST_PATH"] = str(self.manifest_path)

    def tearDown(self):
        os.environ.clear()
        os.environ.update(self._old_env)
        self._tmpdir.cleanup()

    def test_manifest_lookup_works(self):
        _write_manifest(
            self.manifest_path,
            capabilities=[
                {
                    "capability_id": "document.generate_loi.v1",
                    "kind": "kinetic_action",
                    "tool_name": "DOCUMENT.GENERATE_LOI",
                    "action_type": "DOCUMENT.GENERATE_LOI",
                    "title": "Generate LOI",
                    "description": "Generate an LOI",
                    "input_schema": {"type": "object", "properties": {}, "required": []},
                    "output_schema": {},
                    "output_artifacts": [{"kind": "docx", "extension": ".docx", "mime_type": "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "required": True}],
                    "risk_level": "high",
                    "requires_approval": True,
                    "safety_class": "gated",
                    "irreversible": False,
                    "examples": [],
                    "constraints": [],
                    "tags": ["doc"],
                }
            ],
        )

        from tools.manifest.registry import UnifiedManifestRegistry

        reg = UnifiedManifestRegistry(Path(os.environ["ZAKOPS_UNIFIED_MANIFEST_PATH"]))
        reg.load()
        entry = reg.get_entry("document.generate_loi.v1")
        self.assertIsNotNone(entry)
        self.assertEqual(entry.action_type, "DOCUMENT.GENERATE_LOI")

    def test_planner_returns_planspec_for_loi(self):
        _write_manifest(
            self.manifest_path,
            capabilities=[
                {
                    "capability_id": "document.generate_loi.v1",
                    "kind": "kinetic_action",
                    "tool_name": "DOCUMENT.GENERATE_LOI",
                    "action_type": "DOCUMENT.GENERATE_LOI",
                    "title": "Generate LOI",
                    "description": "Generate an LOI",
                    "input_schema": {"type": "object", "properties": {}, "required": []},
                    "output_schema": {},
                    "output_artifacts": [],
                    "risk_level": "high",
                    "requires_approval": True,
                    "safety_class": "gated",
                    "irreversible": False,
                    "examples": [],
                    "constraints": [],
                    "tags": [],
                }
            ],
        )

        import tools.manifest.registry as reg_mod
        import actions.intelligence.planner as planner_mod
        import actions.intelligence.validator as validator_mod

        importlib.reload(reg_mod)
        importlib.reload(validator_mod)
        importlib.reload(planner_mod)

        planner = planner_mod.ToolRAGPlanner()
        plan = planner.plan("Generate LOI for DEAL-2025-001", deal_id="DEAL-2025-001")
        self.assertEqual(plan.status, "OK", plan.model_dump())
        self.assertEqual(plan.steps[0].action_type, "DOCUMENT.GENERATE_LOI")
        self.assertTrue(plan.steps[0].safety.gated)

        vr = validator_mod.PlanValidator().validate(plan)
        self.assertEqual(vr.status, "ok", vr)

    def test_validator_blocks_unsafe_irreversible_without_gate(self):
        _write_manifest(
            self.manifest_path,
            capabilities=[
                {
                    "capability_id": "TOOL.gmail__send_email.v1",
                    "kind": "tool_gateway",
                    "tool_name": "gmail__send_email",
                    "action_type": "TOOL.gmail__send_email",
                    "title": "Send email",
                    "description": "Send email",
                    "input_schema": {
                        "type": "object",
                        "properties": {"to": {"type": "array"}, "subject": {"type": "string"}, "body": {"type": "string"}},
                        "required": ["to", "subject", "body"],
                    },
                    "output_schema": {},
                    "output_artifacts": [],
                    "risk_level": "high",
                    "requires_approval": True,
                    "safety_class": "irreversible",
                    "irreversible": True,
                    "examples": [],
                    "constraints": [],
                    "tags": [],
                }
            ],
        )

        import tools.manifest.registry as reg_mod
        import actions.intelligence.validator as validator_mod

        importlib.reload(reg_mod)
        importlib.reload(validator_mod)

        from actions.contracts.plan_spec import PlanSpec

        plan = PlanSpec(
            status="OK",
            plan_id="PLAN-test",
            goal="Send email",
            steps=[
                {
                    "step_id": "step_1",
                    "capability_id": "TOOL.gmail__send_email.v1",
                    "action_type": "TOOL.gmail__send_email",
                    "tool_name": "gmail__send_email",
                    "title": "Send",
                    "summary": "",
                    "inputs": {"to": ["a@b.com"], "subject": "x", "body": "y"},
                    "depends_on": [],
                    "expected_artifacts": [],
                    "safety": {"safety_class": "irreversible", "irreversible": False, "gated": False, "requires_human_approval": True},
                }
            ],
        )

        vr = validator_mod.PlanValidator().validate(plan)
        self.assertEqual(vr.status, "blocked", vr)
        self.assertEqual(vr.reason, "validation_failed", vr)

    def test_memory_influences_plan(self):
        _write_manifest(
            self.manifest_path,
            capabilities=[
                {
                    "capability_id": "document.generate_loi.v1",
                    "kind": "kinetic_action",
                    "tool_name": "DOCUMENT.GENERATE_LOI",
                    "action_type": "DOCUMENT.GENERATE_LOI",
                    "title": "Generate LOI",
                    "description": "Generate an LOI",
                    "input_schema": {"type": "object", "properties": {}, "required": []},
                    "output_schema": {},
                    "output_artifacts": [],
                    "risk_level": "high",
                    "requires_approval": True,
                    "safety_class": "gated",
                    "irreversible": False,
                    "examples": [],
                    "constraints": [],
                    "tags": [],
                }
            ],
        )

        import tools.manifest.registry as reg_mod
        import actions.intelligence.planner as planner_mod

        importlib.reload(reg_mod)
        importlib.reload(planner_mod)

        from actions.contracts.plan_spec import PlanSpec
        from actions.memory.store import ActionMemoryStore, build_summary_from_action

        seed_plan = PlanSpec(
            status="OK",
            plan_id="PLAN-seed",
            goal="Generate LOI for DEAL-2025-001",
            deal_id="DEAL-2025-001",
            steps=[
                {
                    "step_id": "step_1",
                    "capability_id": "document.generate_loi.v1",
                    "action_type": "DOCUMENT.GENERATE_LOI",
                    "tool_name": "DOCUMENT.GENERATE_LOI",
                    "title": "Generate LOI",
                    "summary": "",
                    "inputs": {},
                    "depends_on": [],
                    "expected_artifacts": [],
                    "safety": {"safety_class": "gated", "irreversible": False, "gated": True, "requires_human_approval": True},
                }
            ],
        )

        store = ActionMemoryStore()
        summary = build_summary_from_action(
            action_id="ACT-seed",
            action_type="DOCUMENT.GENERATE_LOI",
            deal_id="DEAL-2025-001",
            inputs={},
            plan_spec=seed_plan.model_dump(),
            outcome_status="COMPLETED",
            artifacts=[],
            user_edits={},
        )
        store.record(summary)

        planner = planner_mod.ToolRAGPlanner(memory=store)
        plan = planner.plan("Generate LOI for DEAL-2025-001", deal_id="DEAL-2025-001")
        self.assertEqual(plan.status, "OK", plan.model_dump())
        self.assertIn("memory_reuse", plan.debug, plan.debug)

    def test_send_email_plan_marks_send_step_gated(self):
        _write_manifest(
            self.manifest_path,
            capabilities=[
                {
                    "capability_id": "communication.draft_email.v1",
                    "kind": "kinetic_action",
                    "tool_name": "COMMUNICATION.DRAFT_EMAIL",
                    "action_type": "COMMUNICATION.DRAFT_EMAIL",
                    "title": "Draft email",
                    "description": "Draft-only email",
                    "input_schema": {
                        "type": "object",
                        "properties": {"to": {"type": "string"}, "subject": {"type": "string"}, "context": {"type": "string"}},
                        "required": ["to", "subject", "context"],
                    },
                    "output_schema": {},
                    "output_artifacts": [],
                    "risk_level": "medium",
                    "requires_approval": True,
                    "safety_class": "reversible",
                    "irreversible": False,
                    "examples": [],
                    "constraints": [],
                    "tags": [],
                },
                {
                    "capability_id": "TOOL.gmail__send_email.v1",
                    "kind": "tool_gateway",
                    "tool_name": "gmail__send_email",
                    "action_type": "TOOL.gmail__send_email",
                    "title": "Send email",
                    "description": "Send email",
                    "input_schema": {
                        "type": "object",
                        "properties": {"to": {"type": "array"}, "subject": {"type": "string"}, "body": {"type": "string"}},
                        "required": ["to", "subject", "body"],
                    },
                    "output_schema": {},
                    "output_artifacts": [],
                    "risk_level": "high",
                    "requires_approval": True,
                    "safety_class": "irreversible",
                    "irreversible": True,
                    "examples": [],
                    "constraints": [],
                    "tags": [],
                },
            ],
        )

        import tools.manifest.registry as reg_mod
        import actions.intelligence.planner as planner_mod
        import actions.intelligence.validator as validator_mod

        importlib.reload(reg_mod)
        importlib.reload(validator_mod)
        importlib.reload(planner_mod)

        planner = planner_mod.ToolRAGPlanner()
        plan = planner.plan("Send email to broker@example.com", deal_id="DEAL-2025-001")
        self.assertEqual(plan.status, "OK", plan.model_dump())
        self.assertEqual(len(plan.steps), 2, plan.model_dump())
        self.assertTrue(plan.steps[1].safety.gated)
        self.assertTrue(plan.steps[1].safety.irreversible)

        vr = validator_mod.PlanValidator().validate(plan)
        self.assertEqual(vr.status, "ok", vr)

    def test_loi_missing_returns_needs_tool(self):
        _write_manifest(self.manifest_path, capabilities=[])

        import tools.manifest.registry as reg_mod
        import actions.intelligence.planner as planner_mod

        importlib.reload(reg_mod)
        importlib.reload(planner_mod)

        planner = planner_mod.ToolRAGPlanner()
        plan = planner.plan("Generate LOI for DEAL-2025-001", deal_id="DEAL-2025-001")
        self.assertEqual(plan.status, "NEEDS_TOOL", plan.model_dump())
        self.assertIsNotNone(plan.missing_capability)

