import sys
import unittest
from pathlib import Path
from unittest.mock import patch

import httpx

SCRIPTS_DIR = Path(__file__).resolve().parents[1]
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))


class ChatExecuteProposalApiTests(unittest.IsolatedAsyncioTestCase):
    async def test_execute_proposal_success_passthrough(self):
        import deal_lifecycle_api

        class StubOrchestrator:
            async def execute_proposal(self, proposal_id, approved_by, session_id, action="approve", reject_reason=None):
                return {
                    "success": True,
                    "result": {"ok": True},
                    "proposal": {"proposal_id": proposal_id, "type": "add_note", "status": "executed"},
                    "proposal_type": "add_note",
                }

        with patch("chat_orchestrator.get_orchestrator", return_value=StubOrchestrator()):
            transport = httpx.ASGITransport(app=deal_lifecycle_api.app)
            async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
                resp = await client.post(
                    "/api/chat/execute-proposal",
                    json={
                        "proposal_id": "p1",
                        "approved_by": "operator",
                        "session_id": "s1",
                        "action": "approve",
                    },
                )

        self.assertEqual(resp.status_code, 200, resp.text)
        data = resp.json()
        self.assertTrue(data.get("success"))
        self.assertEqual(data.get("proposal_type"), "add_note")

    async def test_execute_proposal_error_maps_reason_to_status_code(self):
        import deal_lifecycle_api

        class StubOrchestrator:
            async def execute_proposal(self, proposal_id, approved_by, session_id, action="approve", reject_reason=None):
                return {
                    "success": False,
                    "error": "Missing params.content",
                    "reason": "invalid_proposal_params",
                    "proposal_type": "add_note",
                }

        with patch("chat_orchestrator.get_orchestrator", return_value=StubOrchestrator()):
            transport = httpx.ASGITransport(app=deal_lifecycle_api.app)
            async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
                resp = await client.post(
                    "/api/chat/execute-proposal",
                    json={
                        "proposal_id": "p1",
                        "approved_by": "operator",
                        "session_id": "s1",
                        "action": "approve",
                    },
                )

        self.assertEqual(resp.status_code, 400, resp.text)
        data = resp.json()
        self.assertFalse(data.get("success"))
        self.assertEqual(data.get("reason"), "invalid_proposal_params")
