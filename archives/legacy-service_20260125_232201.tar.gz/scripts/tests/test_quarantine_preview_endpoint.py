import importlib
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

import httpx

SCRIPTS_DIR = Path(__file__).resolve().parents[1]
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))


class QuarantinePreviewEndpointTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self._old_env = dict(os.environ)
        self._tmpdir = tempfile.TemporaryDirectory(dir="/home/zaks/tmp")
        self.tmp_path = Path(self._tmpdir.name)

        self.dataroom_root = self.tmp_path / "DataRoom"
        self.dataroom_root.mkdir(parents=True, exist_ok=True)
        (self.dataroom_root / ".deal-registry").mkdir(parents=True, exist_ok=True)
        (self.dataroom_root / ".deal-registry" / "case_files").mkdir(parents=True, exist_ok=True)

        os.environ["DATAROOM_ROOT"] = str(self.dataroom_root)
        os.environ["ZAKOPS_STATE_DB"] = str(self.tmp_path / "state.db")
        os.environ["DEAL_EVENTS_DIR"] = str(self.tmp_path / "events")

        # Reset module singletons that cache env-derived paths.
        import actions.capabilities.registry as cap_registry
        import tools.registry as tool_registry
        import tools.gateway as tool_gateway
        import actions.executors.registry as exec_registry

        cap_registry._REGISTRY = None
        tool_registry._REGISTRY = None
        tool_gateway._GATEWAY = None
        exec_registry._EXECUTORS.clear()
        exec_registry._BUILTINS_LOADED = False
        exec_registry._TOOL_EXECUTOR = None

        import deal_lifecycle_api

        importlib.reload(deal_lifecycle_api)

        # Seed empty registry file (backward compatible).
        (self.dataroom_root / ".deal-registry" / "deal_registry.json").write_text(
            json.dumps(
                {
                    "deal_counter": 0,
                    "broker_counter": 0,
                    "deals": {},
                    "brokers": {},
                    "junk_patterns": [],
                    "email_to_deal": {},
                },
                indent=2,
                sort_keys=True,
            ),
            encoding="utf-8",
        )

        (self.dataroom_root / "00-PIPELINE" / "_INBOX_QUARANTINE").mkdir(parents=True, exist_ok=True)

    def tearDown(self):
        os.environ.clear()
        os.environ.update(self._old_env)
        self._tmpdir.cleanup()

    async def test_preview_returns_summary_links_and_body(self):
        import deal_lifecycle_api

        message_id = "msg-preview-1"
        quarantine_dir = self.dataroom_root / "00-PIPELINE" / "_INBOX_QUARANTINE" / message_id
        quarantine_dir.mkdir(parents=True, exist_ok=True)
        (quarantine_dir / "email_body.txt").write_text("Asking $5M. Please sign the NDA: https://example.com/nda?token=abc", encoding="utf-8")
        (quarantine_dir / "teaser.pdf").write_bytes(b"%PDF-FAKE")

        transport = httpx.ASGITransport(app=deal_lifecycle_api.app)
        async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
            create = await client.post(
                "/api/actions",
                json={
                    "action_type": "EMAIL_TRIAGE.REVIEW_EMAIL",
                    "title": "Review inbound deal email: ExampleCo teaser",
                    "summary": "HIGH urgency. Contains deal signals.",
                    "deal_id": None,
                    "capability_id": "email_triage.review_email.v1",
                    "created_by": "email_triage_agent",
                    "source": "system",
                    "risk_level": "medium",
                    "requires_human_review": True,
                    "inputs": {
                        "message_id": message_id,
                        "thread_id": "thread-preview",
                        "from": "Broker <broker@example.com>",
                        "to": "operator@example.com",
                        "date": "01 Jan 2026 12:00:00 +0000",
                        "subject": "ExampleCo teaser",
                        "company": "ExampleCo",
                        "classification": "DEAL_SIGNAL",
                        "urgency": "HIGH",
                        "links": [{"type": "nda", "url": "https://example.com/nda?token=abc", "auth_required": True}],
                        "attachments": [{"filename": "teaser.pdf", "mime_type": "application/pdf", "size_bytes": 123}],
                        "quarantine_dir": str(quarantine_dir),
                    },
                },
            )
            self.assertEqual(create.status_code, 200, create.text)
            action_id = create.json()["action"]["action_id"]

            resp = await client.get(f"/api/actions/quarantine/{action_id}/preview")
            self.assertEqual(resp.status_code, 200, resp.text)
            data = resp.json() or {}

            self.assertEqual(data.get("action_id"), action_id)
            self.assertIn("summary", data)
            self.assertIsInstance(data.get("summary"), list)
            self.assertIn("attachments", data)
            self.assertEqual(((data.get("attachments") or {}).get("count")), 1)
            self.assertIn("links", data)
            groups = ((data.get("links") or {}).get("groups")) or {}
            # NDA links are now categorized under 'deal_material' with link_type='nda'
            self.assertIn("deal_material", groups)
            deal_material_links = groups["deal_material"]
            self.assertTrue(deal_material_links)
            # Verify at least one link has type 'nda'
            nda_links = [l for l in deal_material_links if l.get("type") == "nda"]
            self.assertTrue(nda_links, "Expected at least one NDA link in deal_material group")
            self.assertIn("email", data)
            body = ((data.get("email") or {}).get("body")) or ""
            self.assertIn("Asking $5M", body)

