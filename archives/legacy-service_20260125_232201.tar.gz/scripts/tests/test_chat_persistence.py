import os
import sys
import tempfile
import unittest
from pathlib import Path

SCRIPTS_DIR = Path(__file__).resolve().parents[1]
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))


class ChatPersistenceTests(unittest.TestCase):
    def setUp(self):
        self._old_env = dict(os.environ)
        self._tmpdir = tempfile.TemporaryDirectory(dir="/home/zaks/tmp")
        self.db_path = Path(self._tmpdir.name) / "state.db"

        os.environ["ZAKOPS_STATE_DB"] = str(self.db_path)

        # Reset singletons so the store picks up our temp DB path.
        from email_ingestion.config import reset_config
        from email_ingestion.state.sqlite_store import reset_state_store

        reset_config()
        reset_state_store()

    def tearDown(self):
        os.environ.clear()
        os.environ.update(self._old_env)
        self._tmpdir.cleanup()

    def test_update_proposal_persists_status_changes(self):
        from email_ingestion.chat_persistence import ChatSessionStore

        store = ChatSessionStore()
        session_id = "sess-persist"

        store.save_session(session_id, scope={"type": "deal", "deal_id": "DEAL-TEST-010"})
        store.add_message(
            session_id=session_id,
            role="assistant",
            content="...",
            proposals=[
                {
                    "proposal_id": "p1",
                    "type": "add_note",
                    "deal_id": "DEAL-TEST-010",
                    "params": {"content": "hello"},
                    "status": "pending_approval",
                }
            ],
        )

        updated = store.update_proposal(
            session_id=session_id,
            proposal_id="p1",
            proposal={
                "proposal_id": "p1",
                "type": "add_note",
                "deal_id": "DEAL-TEST-010",
                "params": {"content": "hello"},
                "status": "executed",
                "result": {"event_id": "E-999"},
            },
        )

        self.assertTrue(updated)

        loaded = store.load_session(session_id)
        self.assertIsNotNone(loaded)
        self.assertEqual(len(loaded.messages), 1)
        proposals = loaded.messages[0].proposals
        self.assertEqual(len(proposals), 1)
        self.assertEqual(proposals[0].get("status"), "executed")
        self.assertEqual(proposals[0].get("result", {}).get("event_id"), "E-999")
