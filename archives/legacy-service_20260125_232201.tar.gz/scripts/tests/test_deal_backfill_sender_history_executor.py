import importlib
import os
import sys
import tempfile
import unittest
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional
from unittest.mock import patch


SCRIPTS_DIR = Path(__file__).resolve().parents[1]
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))


@dataclass
class StubDeal:
    deal_id: str
    folder_path: str
    canonical_name: str = "ExampleCo"
    display_name: str = "ExampleCo"


class StubRegistry:
    def __init__(self, deal: StubDeal):
        self._deal = deal
        self.email_to_deal: Dict[str, str] = {}
        self.thread_to_deal: Dict[str, str] = {}
        self.thread_to_non_deal: Dict[str, str] = {}

    def get_deal(self, deal_id: str) -> Optional[StubDeal]:
        return self._deal if deal_id == self._deal.deal_id else None

    def get_email_deal_mapping(self, message_id: str) -> Optional[str]:
        return self.email_to_deal.get(message_id)

    def is_thread_resolved(self, thread_id: str):
        tid = (thread_id or "").strip()
        if tid in self.thread_to_deal:
            return True, self.thread_to_deal.get(tid), None
        if tid in self.thread_to_non_deal:
            return True, None, self.thread_to_non_deal.get(tid)
        return False, None, None

    def add_email_deal_mapping(self, message_id: str, deal_id: str) -> None:
        self.email_to_deal[str(message_id)] = str(deal_id)

    def add_thread_deal_mapping(self, thread_id: str, deal_id: str) -> None:
        self.thread_to_deal[str(thread_id)] = str(deal_id)

    def save(self) -> None:
        return


class StubGateway:
    def __init__(self, *, search_text: str, read_by_id: Dict[str, str]):
        self.search_text = search_text
        self.read_by_id = read_by_id

    async def invoke(self, *, tool_name: str, args: Dict[str, Any], context, timeout_ms=None):
        from tools.gateway import ToolErrorCode, ToolResult

        if tool_name == "gmail__search_emails":
            return ToolResult(
                success=True,
                error_code=ToolErrorCode.SUCCESS,
                output={"content": [{"type": "text", "text": self.search_text}]},
            )
        if tool_name == "gmail__read_email":
            mid = str(args.get("messageId") or "")
            return ToolResult(
                success=True,
                error_code=ToolErrorCode.SUCCESS,
                output={"content": [{"type": "text", "text": self.read_by_id.get(mid, "")}]},
            )
        if tool_name == "gmail__download_attachment":
            return ToolResult(success=True, error_code=ToolErrorCode.SUCCESS, output={"content": [{"type": "text", "text": "ok"}]})

        return ToolResult(success=False, error_code=ToolErrorCode.TOOL_NOT_FOUND, error_message=f"unknown_tool:{tool_name}")


class DealBackfillSenderHistoryExecutorTests(unittest.TestCase):
    def setUp(self):
        self._old_env = dict(os.environ)
        self._tmpdir = tempfile.TemporaryDirectory(dir="/home/zaks/tmp")
        self.tmp_path = Path(self._tmpdir.name)

        self.dataroom_root = self.tmp_path / "DataRoom"
        self.dataroom_root.mkdir(parents=True, exist_ok=True)
        os.environ["DATAROOM_ROOT"] = str(self.dataroom_root)
        os.environ["ZAKOPS_STATE_DB"] = str(self.tmp_path / "state.db")
        os.environ["EMAIL_TRIAGE_STATE_DB"] = str(self.tmp_path / "email_triage_state.db")
        # Ensure triage state DB does not cause skips (missing table => treated as not processed).
        (self.tmp_path / "email_triage_state.db").write_text("", encoding="utf-8")

        # Reset module singletons that cache env-derived paths.
        import tools.registry as tool_registry
        import tools.gateway as tool_gateway
        import actions.executors.registry as exec_registry
        import actions.capabilities.registry as cap_registry

        tool_registry._REGISTRY = None
        tool_gateway._GATEWAY = None
        cap_registry._REGISTRY = None
        exec_registry._EXECUTORS.clear()
        exec_registry._BUILTINS_LOADED = False
        exec_registry._TOOL_EXECUTOR = None

        import actions.executors._artifacts as artifacts

        importlib.reload(artifacts)

        # Minimal deal folder for artifact dir resolution.
        self.deal_id = "DEAL-2026-001"
        self.deal_folder = Path("Deals") / self.deal_id
        (self.dataroom_root / self.deal_folder).mkdir(parents=True, exist_ok=True)

    def tearDown(self):
        os.environ.clear()
        os.environ.update(self._old_env)
        self._tmpdir.cleanup()

    def test_backfill_idempotent_and_emits_append_action(self):
        from actions.engine.models import ActionPayload, compute_idempotency_key
        from actions.executors.base import ExecutionContext
        from actions.executors.deal_backfill_sender_history import DealBackfillSenderHistoryExecutor
        from integrations.gmail_thread_fetch import GmailThreadFetchConfig

        # One candidate email from the sender.
        search_text = "\n".join(
            [
                "ID: msg-old-1",
                "Subject: ExampleCo follow-up",
                "From: Broker <broker@example.com>",
                "Date: 01 Jan 2026 10:00:00 +0000",
                "",
            ]
        )
        read_text = "\n".join(
            [
                "Thread ID: thread-old-1",
                "Subject: ExampleCo follow-up",
                "From: Broker <broker@example.com>",
                "To: operator@example.com",
                "Date: 01 Jan 2026 10:00:00 +0000",
                "",
                "Here is the CIM link: https://example.com/cim?token=secret",
                "",
            ]
        )

        gateway = StubGateway(search_text=search_text, read_by_id={"msg-old-1": read_text})

        registry = StubRegistry(StubDeal(deal_id=self.deal_id, folder_path=str(self.deal_folder)))

        action = ActionPayload(
            deal_id=self.deal_id,
            type="DEAL.BACKFILL_SENDER_HISTORY",
            title="Backfill sender history",
            summary="",
            status="PROCESSING",
            created_by="tester",
            source="system",
            risk_level="low",
            requires_human_review=False,
            idempotency_key=compute_idempotency_key("test", "backfill", self.deal_id),
            inputs={
                "deal_id": self.deal_id,
                "approved_message_id": "msg-approved",
                "sender_email": "broker@example.com",
                "lookback_days": 365,
                "max_messages": 10,
                "mode": "classify_and_quarantine",
                "min_confidence_same": 0.9,
                "max_thread_messages": 10,
            },
        )

        ctx = ExecutionContext(
            action=action,
            deal={"folder_path": str(self.deal_folder)},
            case_file=None,
            tool_gateway=None,
            cloud_allowed=False,
            registry=registry,
        )

        cfg = GmailThreadFetchConfig(
            credentials_path=self.tmp_path / "creds.json",
            oauth_keys_path=self.tmp_path / "keys.json",
            api_base="https://gmail.googleapis.com/gmail/v1",
            timeout_s=1.0,
        )

        with (
            patch("actions.executors.deal_backfill_sender_history.get_tool_gateway", return_value=gateway),
            patch("actions.executors.deal_backfill_sender_history.load_thread_fetch_config", return_value=cfg),
            patch("actions.executors.deal_backfill_sender_history.get_thread_message_ids", return_value=(["msg-old-1"], None)),
            patch(
                "actions.executors.deal_backfill_sender_history._call_local_vllm_json",
                return_value=(
                    {"belongs_to_deal": "same", "confidence": 0.95, "reason": "same broker thread", "evidence": []},
                    None,
                    {"endpoint": "http://localhost:8000/v1/chat/completions", "model": "Qwen", "latency_ms": 1},
                ),
            ),
        ):
            executor = DealBackfillSenderHistoryExecutor()
            result = executor.execute(action, ctx)

        self.assertEqual(result.outputs.get("deal_id"), self.deal_id)
        next_actions = result.outputs.get("next_actions")
        self.assertIsInstance(next_actions, list)
        self.assertTrue(next_actions)
        self.assertEqual(next_actions[0].get("action_type"), "DEAL.APPEND_EMAIL_MATERIALS")
        self.assertEqual(next_actions[0].get("inputs", {}).get("message_id"), "msg-old-1")

        # Quarantine dir materialized for append executor.
        qdir = self.dataroom_root / "00-PIPELINE" / "_INBOX_QUARANTINE" / "msg-old-1"
        self.assertTrue(qdir.exists())
        self.assertTrue((qdir / "email_body.txt").exists())
        # URL tokens should not be persisted in links payload (query stripped).
        links = next_actions[0].get("inputs", {}).get("links", [])
        self.assertTrue(links)
        self.assertEqual(links[0]["url"], "https://example.com/cim")

        # Second run: scan should be already completed (idempotent).
        action2 = ActionPayload(
            deal_id=self.deal_id,
            type="DEAL.BACKFILL_SENDER_HISTORY",
            title="Backfill sender history (rerun)",
            summary="",
            status="PROCESSING",
            created_by="tester",
            source="system",
            risk_level="low",
            requires_human_review=False,
            idempotency_key=compute_idempotency_key("test", "backfill2", self.deal_id),
            inputs=dict(action.inputs),
        )
        ctx2 = ExecutionContext(action=action2, deal={"folder_path": str(self.deal_folder)}, registry=registry)
        with patch("actions.executors.deal_backfill_sender_history.get_tool_gateway", return_value=gateway):
            executor = DealBackfillSenderHistoryExecutor()
            rerun = executor.execute(action2, ctx2)
        self.assertTrue(rerun.outputs.get("already_completed"))

