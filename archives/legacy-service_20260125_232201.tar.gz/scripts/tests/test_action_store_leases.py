import os
import sys
import tempfile
import unittest
from pathlib import Path

SCRIPTS_DIR = Path(__file__).resolve().parents[1]
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))


class ActionStoreLeaseTests(unittest.TestCase):
    def setUp(self):
        self._old_env = dict(os.environ)
        self._tmpdir = tempfile.TemporaryDirectory(dir="/home/zaks/tmp")
        self.db_path = Path(self._tmpdir.name) / "state.db"
        os.environ["ZAKOPS_STATE_DB"] = str(self.db_path)

    def tearDown(self):
        os.environ.clear()
        os.environ.update(self._old_env)
        self._tmpdir.cleanup()

    def test_runner_lease_is_exclusive(self):
        from actions.engine.store import ActionStore

        store = ActionStore(Path(os.environ["ZAKOPS_STATE_DB"]))
        ok1 = store.acquire_runner_lease(runner_name="kinetic_actions", owner_id="owner-1", lease_seconds=30, pid=1, host="h1")
        self.assertTrue(ok1)

        ok2 = store.acquire_runner_lease(runner_name="kinetic_actions", owner_id="owner-2", lease_seconds=30, pid=2, host="h2")
        self.assertFalse(ok2)

    def test_per_action_lock_prevents_double_claim(self):
        from actions.engine.models import ActionPayload, compute_idempotency_key
        from actions.engine.store import ActionStore

        store = ActionStore(Path(os.environ["ZAKOPS_STATE_DB"]))

        action = ActionPayload(
            deal_id="DEAL-LOCK-1",
            type="COMMUNICATION.DRAFT_EMAIL",
            title="t",
            summary="",
            status="PROCESSING",
            created_by="tester",
            source="system",
            risk_level="low",
            requires_human_review=True,
            idempotency_key=compute_idempotency_key("lock", "1"),
            inputs={"to": "a@b.com", "subject": "s", "context": "c"},
        )
        created, created_new = store.create_action(action)
        self.assertTrue(created_new)

        ok1 = store.claim_action_lock(action_id=created.action_id, owner_id="runner-1", lease_seconds=300)
        self.assertTrue(ok1)
        ok2 = store.claim_action_lock(action_id=created.action_id, owner_id="runner-2", lease_seconds=300)
        self.assertFalse(ok2)

        hb2 = store.heartbeat_action_lock(action_id=created.action_id, owner_id="runner-2", lease_seconds=300)
        self.assertFalse(hb2)
        hb1 = store.heartbeat_action_lock(action_id=created.action_id, owner_id="runner-1", lease_seconds=300)
        self.assertTrue(hb1)

        store.release_action_lock(action_id=created.action_id, owner_id="runner-1")
        ok3 = store.claim_action_lock(action_id=created.action_id, owner_id="runner-2", lease_seconds=300)
        self.assertTrue(ok3)

    def test_create_action_idempotency_key_dedupes(self):
        from actions.engine.models import ActionPayload
        from actions.engine.store import ActionStore

        store = ActionStore(Path(os.environ["ZAKOPS_STATE_DB"]))
        idem = "idem-test-123"

        a1, created_new_1 = store.create_action(
            ActionPayload(
                deal_id="DEAL-IDEM-1",
                type="COMMUNICATION.DRAFT_EMAIL",
                title="t",
                summary="",
                status="PENDING_APPROVAL",
                created_by="tester",
                source="system",
                risk_level="low",
                requires_human_review=True,
                idempotency_key=idem,
                inputs={"to": "a@b.com", "subject": "s", "context": "c"},
            )
        )
        a2, created_new_2 = store.create_action(
            ActionPayload(
                deal_id="DEAL-IDEM-1",
                type="COMMUNICATION.DRAFT_EMAIL",
                title="t",
                summary="",
                status="PENDING_APPROVAL",
                created_by="tester",
                source="system",
                risk_level="low",
                requires_human_review=True,
                idempotency_key=idem,
                inputs={"to": "a@b.com", "subject": "s", "context": "c"},
            )
        )
        self.assertTrue(created_new_1)
        self.assertFalse(created_new_2)
        self.assertEqual(a1.action_id, a2.action_id)

