import unittest
from unittest.mock import patch

from temporal_worker import activities as temporal_activities
from temporal_worker.subprocess_runner import SubprocessResult


class TemporalWorkerSmokeTests(unittest.IsolatedAsyncioTestCase):
    def _build_result(self) -> SubprocessResult:
        return SubprocessResult(
            ok=True,
            exit_code=0,
            command=["python3", "-m", "dummy"],
            cwd="/tmp",
            started_at="2026-01-01T00:00:00Z",
            finished_at="2026-01-01T00:00:01Z",
            duration_ms=1000,
            log_path="/tmp/log.txt",
            log_tail="done",
        )

    async def test_email_triage_activity_returns_status(self):
        result = self._build_result()
        with patch.object(temporal_activities, "run_command", return_value=result) as mock:
            response = await temporal_activities.run_email_triage_once(timeout_s=5)
            self.assertTrue(response.get("ok"))
            self.assertEqual(response.get("exit_code"), 0)
            mock.assert_called_once()
            called_kwargs = mock.call_args.kwargs
            self.assertIn("command", called_kwargs)
            self.assertIn("email_triage_agent.run_once", called_kwargs["command"][-1])

    async def test_controller_activity_returns_status(self):
        result = self._build_result()
        with patch.object(temporal_activities, "run_command", return_value=result) as mock:
            response = await temporal_activities.run_deal_lifecycle_controller_once(timeout_s=5)
            self.assertTrue(response.get("ok"))
            self.assertEqual(response.get("exit_code"), 0)
            mock.assert_called_once()
            called_kwargs = mock.call_args.kwargs
            self.assertIn("command", called_kwargs)
            self.assertIn("deal_lifecycle_controller.py", called_kwargs["command"][-1])
