import importlib
import os
import sys
import tempfile
import unittest
from pathlib import Path

import httpx

SCRIPTS_DIR = Path(__file__).resolve().parents[1]
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))


class ActionsListContractTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self._old_env = dict(os.environ)
        self._tmpdir = tempfile.TemporaryDirectory(dir="/home/zaks/tmp")
        self.tmp_path = Path(self._tmpdir.name)

        self.dataroom_root = self.tmp_path / "DataRoom"
        self.dataroom_root.mkdir(parents=True, exist_ok=True)
        (self.dataroom_root / ".deal-registry").mkdir(parents=True, exist_ok=True)
        (self.dataroom_root / ".deal-registry" / "case_files").mkdir(parents=True, exist_ok=True)

        os.environ["DATAROOM_ROOT"] = str(self.dataroom_root)
        os.environ["ZAKOPS_STATE_DB"] = str(self.tmp_path / "state.db")
        os.environ["DEAL_EVENTS_DIR"] = str(self.tmp_path / "events")

        # Reset module singletons that cache env-derived paths.
        import actions.capabilities.registry as cap_registry
        import tools.registry as tool_registry
        import tools.gateway as tool_gateway
        import actions.executors.registry as exec_registry

        cap_registry._REGISTRY = None
        tool_registry._REGISTRY = None
        tool_gateway._GATEWAY = None
        exec_registry._EXECUTORS.clear()
        exec_registry._BUILTINS_LOADED = False
        exec_registry._TOOL_EXECUTOR = None

        # Reload modules that bind DATAROOM_ROOT at import time.
        import deal_lifecycle_api

        importlib.reload(deal_lifecycle_api)

    def tearDown(self):
        os.environ.clear()
        os.environ.update(self._old_env)
        self._tmpdir.cleanup()

    async def test_list_actions_handles_global_and_missing_inputs(self):
        import deal_lifecycle_api

        transport = httpx.ASGITransport(app=deal_lifecycle_api.app)
        async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
            create = await client.post(
                "/api/actions",
                json={
                    "action_type": "EMAIL_TRIAGE.REVIEW_EMAIL",
                    "title": "Review inbound deal email: Test",
                    "summary": "",
                    # deal_id omitted intentionally (GLOBAL)
                    # inputs omitted intentionally (backend should coerce to {})
                    "created_by": "test",
                    "source": "system",
                    "risk_level": "medium",
                    "requires_human_review": True,
                },
            )
            self.assertEqual(create.status_code, 200, create.text)
            created_action = create.json().get("action") or {}
            action_id = created_action.get("action_id")
            self.assertTrue(action_id)

            resp = await client.get("/api/actions?limit=10&type=EMAIL_TRIAGE.REVIEW_EMAIL")
            self.assertEqual(resp.status_code, 200, resp.text)
            data = resp.json()

            self.assertIn("actions", data)
            self.assertIsInstance(data["actions"], list)
            self.assertGreaterEqual(len(data["actions"]), 1)

            row = next((a for a in data["actions"] if a.get("action_id") == action_id), None)
            self.assertIsNotNone(row)

            self.assertIsInstance(row.get("deal_id"), str)
            self.assertTrue(row["deal_id"])
            self.assertIsInstance(row.get("inputs"), dict)

    async def test_capabilities_include_cloud_required_flag(self):
        import deal_lifecycle_api

        transport = httpx.ASGITransport(app=deal_lifecycle_api.app)
        async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.get("/api/actions/capabilities")
            self.assertEqual(resp.status_code, 200, resp.text)
            data = resp.json()
            caps = data.get("capabilities") or []
            self.assertIsInstance(caps, list)

            draft = next((c for c in caps if c.get("capability_id") == "communication.draft_email.v1"), None)
            self.assertIsNotNone(draft)
            self.assertIs(draft.get("cloud_required"), True, draft)

            send = next((c for c in caps if c.get("capability_id") == "communication.send_email.v1"), None)
            self.assertIsNotNone(send)
            self.assertIs(send.get("cloud_required"), False, send)
