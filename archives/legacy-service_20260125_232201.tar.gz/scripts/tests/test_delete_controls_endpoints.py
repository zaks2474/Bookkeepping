import importlib
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

import httpx

SCRIPTS_DIR = Path(__file__).resolve().parents[1]
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))


class DeleteControlsEndpointsTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self) -> None:
        self._old_env = dict(os.environ)
        self._tmpdir = tempfile.TemporaryDirectory(dir="/home/zaks/tmp")
        self.tmp_path = Path(self._tmpdir.name)

        self.dataroom_root = self.tmp_path / "DataRoom"
        self.dataroom_root.mkdir(parents=True, exist_ok=True)
        (self.dataroom_root / ".deal-registry").mkdir(parents=True, exist_ok=True)
        (self.dataroom_root / ".deal-registry" / "case_files").mkdir(parents=True, exist_ok=True)
        (self.dataroom_root / "00-PIPELINE" / "_INBOX_QUARANTINE").mkdir(parents=True, exist_ok=True)
        (self.dataroom_root / "00-PIPELINE" / "Inbound").mkdir(parents=True, exist_ok=True)

        os.environ["DATAROOM_ROOT"] = str(self.dataroom_root)
        os.environ["ZAKOPS_STATE_DB"] = str(self.tmp_path / "state.db")
        os.environ["DEAL_EVENTS_DIR"] = str(self.tmp_path / "events")

        # Seed empty registry file (backward compatible).
        registry_path = self.dataroom_root / ".deal-registry" / "deal_registry.json"
        registry_path.write_text(
            json.dumps(
                {
                    "deal_counter": 0,
                    "broker_counter": 0,
                    "deals": {},
                    "brokers": {},
                    "junk_patterns": [],
                    "email_to_deal": {},
                },
                indent=2,
                sort_keys=True,
            ),
            encoding="utf-8",
        )

        # Reset module singletons that cache env-derived paths.
        import actions.capabilities.registry as cap_registry
        import tools.registry as tool_registry
        import tools.gateway as tool_gateway
        import actions.executors.registry as exec_registry

        cap_registry._REGISTRY = None
        tool_registry._REGISTRY = None
        tool_gateway._GATEWAY = None
        exec_registry._EXECUTORS.clear()
        exec_registry._BUILTINS_LOADED = False
        exec_registry._TOOL_EXECUTOR = None

        import deal_lifecycle_api

        importlib.reload(deal_lifecycle_api)

        # Create one deal in the registry.
        from deal_registry import DealRegistry

        reg = DealRegistry(str(registry_path))
        reg.create_deal(
            deal_id="DEAL-2026-001",
            canonical_name="ExampleCo",
            folder_path=str(self.dataroom_root / "00-PIPELINE" / "Inbound" / "ExampleCo--001"),
        )
        reg.save()

    def tearDown(self) -> None:
        os.environ.clear()
        os.environ.update(self._old_env)
        self._tmpdir.cleanup()

    async def test_deal_archive_hides_from_list(self) -> None:
        import deal_lifecycle_api

        transport = httpx.ASGITransport(app=deal_lifecycle_api.app)
        async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
            before = await client.get("/api/deals")
            self.assertEqual(before.status_code, 200, before.text)
            deals_before = (before.json() or {}).get("deals") or []
            self.assertTrue(any(d.get("deal_id") == "DEAL-2026-001" for d in deals_before))

            archived = await client.post(
                "/api/deals/DEAL-2026-001/archive",
                json={"operator": "tester", "reason": "ui_delete"},
            )
            self.assertEqual(archived.status_code, 200, archived.text)
            self.assertTrue((archived.json() or {}).get("archived"))

            after = await client.get("/api/deals")
            self.assertEqual(after.status_code, 200, after.text)
            deals_after = (after.json() or {}).get("deals") or []
            self.assertFalse(any(d.get("deal_id") == "DEAL-2026-001" for d in deals_after))

    async def test_quarantine_delete_hides_from_queue(self) -> None:
        import deal_lifecycle_api

        message_id = "msg-delete-1"
        quarantine_dir = self.dataroom_root / "00-PIPELINE" / "_INBOX_QUARANTINE" / message_id
        quarantine_dir.mkdir(parents=True, exist_ok=True)
        (quarantine_dir / "email_body.txt").write_text("ExampleCo teaser attached.", encoding="utf-8")

        transport = httpx.ASGITransport(app=deal_lifecycle_api.app)
        async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
            create = await client.post(
                "/api/actions",
                json={
                    "action_type": "EMAIL_TRIAGE.REVIEW_EMAIL",
                    "title": "Review inbound deal email",
                    "summary": "Deal-signal email pending approval",
                    "deal_id": None,
                    "capability_id": "email_triage.review_email.v1",
                    "created_by": "test",
                    "source": "system",
                    "risk_level": "medium",
                    "requires_human_review": True,
                    "inputs": {
                        "message_id": message_id,
                        "thread_id": "thread-delete-1",
                        "from": "Broker <broker@example.com>",
                        "subject": "ExampleCo teaser",
                        "classification": "DEAL_SIGNAL",
                        "urgency": "HIGH",
                        "quarantine_dir": str(quarantine_dir),
                    },
                },
            )
            self.assertEqual(create.status_code, 200, create.text)
            action_id = ((create.json() or {}).get("action") or {}).get("action_id")
            self.assertTrue(action_id)

            before = await client.get("/api/actions/quarantine?limit=50")
            self.assertEqual(before.status_code, 200, before.text)
            items_before = (before.json() or {}).get("items") or []
            self.assertTrue(any((i.get("action_id") or i.get("quarantine_id")) == action_id for i in items_before))

            deleted = await client.post(
                f"/api/quarantine/{action_id}/delete",
                json={"deleted_by": "tester", "reason": "ui_delete"},
            )
            self.assertEqual(deleted.status_code, 200, deleted.text)
            self.assertTrue((deleted.json() or {}).get("hidden"))

            after = await client.get("/api/actions/quarantine?limit=50")
            self.assertEqual(after.status_code, 200, after.text)
            items_after = (after.json() or {}).get("items") or []
            self.assertFalse(any((i.get("action_id") or i.get("quarantine_id")) == action_id for i in items_after))

