import os
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

SCRIPTS_DIR = Path(__file__).resolve().parents[1]
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))


class BrainIntegrationTests(unittest.IsolatedAsyncioTestCase):
    async def test_chat_complete_uses_brain_and_persists_proposal(self):
        from chat_evidence_builder import EvidenceBundle
        from chat_orchestrator import ChatOrchestrator

        orchestrator = ChatOrchestrator(allow_cloud=False)
        orchestrator.session_store = None

        async def stub_build(_query, _scope, _options):
            bundle = EvidenceBundle()
            bundle.registry = {"deal_id": _scope.get("deal_id"), "stage": "screening"}
            bundle.registry_loaded = True
            bundle.sources_queried = ["registry"]
            return bundle

        orchestrator.evidence_builder.build = stub_build  # type: ignore[assignment]

        async def stub_call_brain(self, **kwargs):
            return (
                "hello from brain",
                [
                    {
                        "proposal_id": "p1",
                        "type": "add_note",
                        "deal_id": "DEAL-TEST-100",
                        "params": {"content": "note from brain", "category": "chat_note"},
                        "status": "pending_approval",
                        "reason": "capture note",
                    }
                ],
                "zakops-api:local/Qwen",
                [],
            )

        with patch.dict(os.environ, {"ZAKOPS_BRAIN_MODE": "force"}, clear=False), patch.object(
            ChatOrchestrator, "_call_brain_complete", stub_call_brain
        ):
            resp = await orchestrator.chat(
                query="add a note",
                scope={"type": "deal", "deal_id": "DEAL-TEST-100"},
                session_id="sess-brain-1",
            )

        self.assertEqual(resp.content, "hello from brain")
        self.assertTrue(resp.model_used.startswith("zakops-api:"), resp.model_used)
        self.assertEqual(len(resp.proposals), 1)
        self.assertEqual(resp.proposals[0].get("proposal_id"), "p1")
        self.assertEqual(resp.proposals[0].get("type"), "add_note")
        self.assertEqual(resp.proposals[0].get("status"), "pending_approval")

        called = {}

        def fake_execute_add_note(*, deal_id: str, content: str, category: str):
            called["deal_id"] = deal_id
            called["content"] = content
            called["category"] = category
            return {"success": True, "event_id": "E-1"}

        orchestrator._execute_add_note = fake_execute_add_note  # type: ignore[assignment]
        result = await orchestrator.execute_proposal(
            proposal_id="p1",
            approved_by="operator",
            session_id="sess-brain-1",
        )

        self.assertTrue(result.get("success"), result)
        self.assertEqual(result.get("proposal_type"), "add_note")
        self.assertEqual(called.get("deal_id"), "DEAL-TEST-100")
        self.assertEqual(called.get("content"), "note from brain")

    async def test_chat_complete_auto_falls_back_when_brain_unavailable(self):
        from chat_evidence_builder import EvidenceBundle
        from chat_orchestrator import ChatOrchestrator

        orchestrator = ChatOrchestrator(allow_cloud=False)
        orchestrator.session_store = None

        async def stub_build(_query, _scope, _options):
            return EvidenceBundle()

        orchestrator.evidence_builder.build = stub_build  # type: ignore[assignment]

        async def stub_call_brain(self, **kwargs):
            return (None, [], "", ["brain_unavailable"])

        async def stub_call_llm(self, messages, stream=False):
            return ("local fallback", "vllm", [])

        with patch.dict(os.environ, {"ZAKOPS_BRAIN_MODE": "auto"}, clear=False), patch.object(
            ChatOrchestrator, "_call_brain_complete", stub_call_brain
        ), patch.object(ChatOrchestrator, "_call_llm", stub_call_llm):
            resp = await orchestrator.chat(
                query="hello",
                scope={"type": "global"},
                session_id="sess-brain-2",
            )

        self.assertEqual(resp.content, "local fallback")
        self.assertIn("brain_unavailable", " ".join(resp.warnings))

    async def test_call_brain_complete_payload_shape(self):
        from chat_orchestrator import ChatOrchestrator
        import chat_orchestrator as co

        orchestrator = ChatOrchestrator(allow_cloud=False)
        orchestrator.session_store = None

        captured = {}

        class StubResp:
            status_code = 200

            def json(self):
                return {
                    "final_text": "ok",
                    "proposals": [],
                    "debug": {"provider": "local", "model": "stub"},
                }

        class StubClient:
            def __init__(self, *args, **kwargs):
                pass

            async def __aenter__(self):
                return self

            async def __aexit__(self, exc_type, exc, tb):
                return False

            async def post(self, url, json=None):
                captured["url"] = url
                captured["json"] = json
                return StubResp()

        with patch.dict(os.environ, {"ZAKOPS_BRAIN_MODE": "force"}, clear=False), patch.object(
            co, "ZAKOPS_BRAIN_URL", "http://localhost:8080"
        ), patch.object(co.httpx, "AsyncClient", StubClient):
            final_text, proposals, model_used, warnings = await orchestrator._call_brain_complete(
                query="q",
                scope={"type": "deal", "deal_id": "DEAL-1"},
                session_id="sess-1",
                history=[{"role": "user", "content": "prev"}],
                evidence_context="evidence",
                options={},
            )

        self.assertEqual(final_text, "ok")
        self.assertEqual(proposals, [])
        self.assertTrue(model_used.startswith("zakops-api:"), model_used)
        self.assertEqual(warnings, [])

        payload = captured.get("json") or {}
        self.assertEqual(payload.get("query"), "q")
        self.assertEqual(payload.get("session_id"), "sess-1")
        self.assertIsInstance(payload.get("scope"), dict)
        self.assertEqual(payload["scope"].get("type"), "deal")
        self.assertEqual(payload["scope"].get("deal_id"), "DEAL-1")
        self.assertIsInstance(payload.get("options"), dict)
        self.assertIn("history", payload["options"])
        self.assertIn("evidence_context", payload["options"])

