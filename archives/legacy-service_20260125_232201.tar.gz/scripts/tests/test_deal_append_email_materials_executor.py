import importlib
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

import httpx

SCRIPTS_DIR = Path(__file__).resolve().parents[1]
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))


class DealAppendEmailMaterialsExecutorTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self._old_env = dict(os.environ)
        self._tmpdir = tempfile.TemporaryDirectory(dir="/home/zaks/tmp")
        self.tmp_path = Path(self._tmpdir.name)

        self.dataroom_root = self.tmp_path / "DataRoom"
        self.dataroom_root.mkdir(parents=True, exist_ok=True)

        os.environ["DATAROOM_ROOT"] = str(self.dataroom_root)
        os.environ["ZAKOPS_STATE_DB"] = str(self.tmp_path / "state.db")
        os.environ["DEAL_EVENTS_DIR"] = str(self.tmp_path / "events")

        # Reset module singletons that cache env-derived paths.
        import actions.capabilities.registry as cap_registry
        import tools.registry as tool_registry
        import tools.gateway as tool_gateway
        import actions.executors.registry as exec_registry

        cap_registry._REGISTRY = None
        tool_registry._REGISTRY = None
        tool_gateway._GATEWAY = None
        exec_registry._EXECUTORS.clear()
        exec_registry._BUILTINS_LOADED = False
        exec_registry._TOOL_EXECUTOR = None

        # Reload modules that bind DATAROOM_ROOT at import time.
        import actions.executors._artifacts as artifacts
        import deal_lifecycle_api
        import actions_runner

        importlib.reload(artifacts)
        importlib.reload(deal_lifecycle_api)
        importlib.reload(actions_runner)

        # Seed registry with one deal.
        registry_dir = self.dataroom_root / ".deal-registry"
        registry_dir.mkdir(parents=True, exist_ok=True)
        (registry_dir / "case_files").mkdir(parents=True, exist_ok=True)

        inbound = self.dataroom_root / "00-PIPELINE" / "Inbound"
        inbound.mkdir(parents=True, exist_ok=True)
        deal_path = inbound / "ExampleCo-2026"
        (deal_path / "07-Correspondence").mkdir(parents=True, exist_ok=True)

        from deal_registry import DealRegistry

        reg_path = registry_dir / "deal_registry.json"
        reg_path.write_text(
            json.dumps(
                {
                    "deal_counter": 1,
                    "broker_counter": 0,
                    "deals": {
                        "DEAL-2026-001": {
                            "canonical_name": "ExampleCo",
                            "display_name": "ExampleCo",
                            "folder_path": str(deal_path),
                            "stage": "screening",
                            "status": "active",
                            "identifiers": {},
                            "company_info": {},
                            "broker": None,
                            "aliases": [],
                            "email_thread_ids": [],
                            "related_folders": [],
                            "metadata": {},
                            "audit_trail": [],
                            "created_at": "2026-01-01T00:00:00",
                            "updated_at": "2026-01-01T00:00:00",
                        }
                    },
                    "brokers": {},
                    "junk_patterns": [],
                    "email_to_deal": {},
                    "thread_to_deal": {"thread_1": "DEAL-2026-001"},
                    "thread_to_non_deal": {},
                },
                indent=2,
                sort_keys=True,
            ),
            encoding="utf-8",
        )

        # Ensure DealRegistry can load it (schema flexibility).
        DealRegistry(str(reg_path))

        quarantine_root = self.dataroom_root / "00-PIPELINE" / "_INBOX_QUARANTINE"
        quarantine_root.mkdir(parents=True, exist_ok=True)

    def tearDown(self):
        os.environ.clear()
        os.environ.update(self._old_env)
        self._tmpdir.cleanup()

    async def test_append_email_materials_creates_bundle_and_dedups(self):
        import deal_lifecycle_api
        import actions_runner

        deal_id = "DEAL-2026-001"
        message_id = "msg-append-1"
        quarantine_dir = self.dataroom_root / "00-PIPELINE" / "_INBOX_QUARANTINE" / message_id
        quarantine_dir.mkdir(parents=True, exist_ok=True)
        (quarantine_dir / "email_body.txt").write_text("Follow-up email body.", encoding="utf-8")
        (quarantine_dir / "teaser.pdf").write_bytes(b"%PDF-FAKE")

        transport = httpx.ASGITransport(app=deal_lifecycle_api.app)
        async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
            create = await client.post(
                "/api/actions",
                json={
                    "action_type": "DEAL.APPEND_EMAIL_MATERIALS",
                    "title": "Append email materials",
                    "summary": "Follow-up email in existing deal thread",
                    "deal_id": deal_id,
                    "capability_id": "deal.append_email_materials.v1",
                    "created_by": "email_triage_agent",
                    "source": "system",
                    "risk_level": "low",
                    "requires_human_review": False,
                    "inputs": {
                        "deal_id": deal_id,
                        "message_id": message_id,
                        "thread_id": "thread_1",
                        "from": "Broker <broker@example.com>",
                        "to": "operator@example.com",
                        "date": "01 Jan 2026 13:00:00 +0000",
                        "subject": "Re: ExampleCo teaser",
                        "links": [{"type": "dataroom", "url": "https://example.com/dataroom?token=abc", "auth_required": True}],
                        "attachments": [{"filename": "teaser.pdf", "mime_type": "application/pdf", "size_bytes": 123}],
                        "quarantine_dir": str(quarantine_dir),
                    },
                },
            )
            self.assertEqual(create.status_code, 200, create.text)
            action_id = create.json()["action"]["action_id"]
            self.assertEqual((await client.post(f"/api/actions/{action_id}/approve", json={"approved_by": "operator"})).status_code, 200)
            self.assertEqual((await client.post(f"/api/actions/{action_id}/execute", json={"requested_by": "operator"})).status_code, 200)

            # Second action with same message_id but different idempotency key should be deduped by executor.
            create2 = await client.post(
                "/api/actions",
                json={
                    "action_type": "DEAL.APPEND_EMAIL_MATERIALS",
                    "title": "Append email materials (duplicate action)",
                    "summary": "Should dedup bundle",
                    "deal_id": deal_id,
                    "capability_id": "deal.append_email_materials.v1",
                    "created_by": "email_triage_agent",
                    "source": "system",
                    "risk_level": "low",
                    "requires_human_review": False,
                    "idempotency_key": "dedup-test-append-2",
                    "inputs": {
                        "deal_id": deal_id,
                        "message_id": message_id,
                        "thread_id": "thread_1",
                        "from": "Broker <broker@example.com>",
                        "to": "operator@example.com",
                        "date": "01 Jan 2026 13:00:00 +0000",
                        "subject": "Re: ExampleCo teaser",
                        "links": [{"type": "dataroom", "url": "https://example.com/dataroom?token=abc", "auth_required": True}],
                        "attachments": [{"filename": "teaser.pdf", "mime_type": "application/pdf", "size_bytes": 123}],
                        "quarantine_dir": str(quarantine_dir),
                    },
                },
            )
            self.assertEqual(create2.status_code, 200, create2.text)
            action_id_2 = create2.json()["action"]["action_id"]
            self.assertEqual((await client.post(f"/api/actions/{action_id_2}/approve", json={"approved_by": "operator"})).status_code, 200)
            self.assertEqual((await client.post(f"/api/actions/{action_id_2}/execute", json={"requested_by": "operator"})).status_code, 200)

        from actions.engine.store import ActionStore
        from deal_events import DealEventStore
        from deal_registry import DealRegistry

        store = ActionStore(Path(os.environ["ZAKOPS_STATE_DB"]))
        reg = DealRegistry(str(self.dataroom_root / ".deal-registry" / "deal_registry.json"))
        event_store = DealEventStore(events_dir=os.environ["DEAL_EVENTS_DIR"])

        actions_runner.process_one_action(store=store, registry=reg, event_store=event_store, owner_id="test", action_id=action_id, action_lock_seconds=60)
        completed = store.get_action(action_id)
        self.assertIsNotNone(completed)
        self.assertEqual(completed.status, "COMPLETED")

        outputs = completed.outputs or {}
        bundle_path = Path(str(outputs.get("bundle_path") or "")).resolve()
        self.assertTrue(bundle_path.exists(), bundle_path)
        self.assertTrue((bundle_path / "email.md").exists())
        self.assertTrue((bundle_path / "manifest.json").exists())
        self.assertTrue((bundle_path / "attachments" / "teaser.pdf").exists())

        # Aggregate links updated and sanitized (query stripped).
        agg_links = json.loads((Path(str(outputs.get("deal_path"))) / "07-Correspondence" / "links.json").read_text(encoding="utf-8"))
        urls = [l.get("url") for l in agg_links.get("links") or []]
        self.assertIn("https://example.com/dataroom", urls)

        # Phase 6: runner should enqueue follow-on actions (auto-approved + queued).
        extract = store.list_actions(action_type="DEAL.EXTRACT_EMAIL_ARTIFACTS", limit=10, offset=0)
        enrich = store.list_actions(action_type="DEAL.ENRICH_MATERIALS", limit=10, offset=0)
        rag = store.list_actions(action_type="RAG.REINDEX_DEAL", limit=10, offset=0)
        self.assertEqual(len(extract), 1)
        self.assertEqual(len(enrich), 1)
        self.assertEqual(len(rag), 1)
        self.assertEqual(extract[0].status, "READY")
        self.assertEqual(enrich[0].status, "READY")
        self.assertEqual(rag[0].status, "READY")

        # Second action should dedup against the existing bundle.
        reg2 = DealRegistry(str(self.dataroom_root / ".deal-registry" / "deal_registry.json"))
        actions_runner.process_one_action(store=store, registry=reg2, event_store=event_store, owner_id="test", action_id=action_id_2, action_lock_seconds=60)
        completed2 = store.get_action(action_id_2)
        self.assertIsNotNone(completed2)
        self.assertEqual(completed2.status, "COMPLETED")
        self.assertTrue(bool((completed2.outputs or {}).get("deduplicated")))

        corr_dir = Path(str(outputs.get("deal_path"))) / "07-Correspondence"
        suffix = "msg-append-1"
        bundles = [p for p in corr_dir.iterdir() if p.is_dir() and suffix in p.name]
        self.assertEqual(len(bundles), 1)
