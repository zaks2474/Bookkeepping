import importlib
import os
import sys
import tempfile
import unittest
from pathlib import Path

import httpx

SCRIPTS_DIR = Path(__file__).resolve().parents[1]
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))


class Prompt2RegressionsTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self._old_env = dict(os.environ)
        self._tmpdir = tempfile.TemporaryDirectory(dir="/home/zaks/tmp")
        self.tmp_path = Path(self._tmpdir.name)

        self.dataroom_root = self.tmp_path / "DataRoom"
        self.dataroom_root.mkdir(parents=True, exist_ok=True)
        (self.dataroom_root / ".deal-registry").mkdir(parents=True, exist_ok=True)
        (self.dataroom_root / ".deal-registry" / "case_files").mkdir(parents=True, exist_ok=True)

        os.environ["DATAROOM_ROOT"] = str(self.dataroom_root)
        os.environ["ZAKOPS_STATE_DB"] = str(self.tmp_path / "state.db")
        os.environ["DEAL_EVENTS_DIR"] = str(self.tmp_path / "events")

        # Reset module singletons that cache env-derived paths.
        import actions.capabilities.registry as cap_registry
        import tools.registry as tool_registry
        import tools.gateway as tool_gateway
        import actions.executors.registry as exec_registry

        cap_registry._REGISTRY = None
        tool_registry._REGISTRY = None
        tool_gateway._GATEWAY = None
        exec_registry._EXECUTORS.clear()
        exec_registry._BUILTINS_LOADED = False
        exec_registry._TOOL_EXECUTOR = None

        import deal_lifecycle_api

        importlib.reload(deal_lifecycle_api)

    def tearDown(self):
        os.environ.clear()
        os.environ.update(self._old_env)
        self._tmpdir.cleanup()

    async def test_create_action_unknown_executor_returns_400(self):
        import deal_lifecycle_api

        transport = httpx.ASGITransport(app=deal_lifecycle_api.app)
        async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.post(
                "/api/actions",
                json={
                    "action_type": "BOGUS.UNKNOWN_ACTION",
                    "title": "Bogus action",
                    "summary": "",
                    "created_by": "test",
                    "source": "system",
                    "risk_level": "low",
                    "requires_human_review": True,
                },
            )
            self.assertEqual(resp.status_code, 400, resp.text)
            detail = (resp.json() or {}).get("detail") or {}
            self.assertEqual(detail.get("code"), "executor_not_found", detail)

    async def test_create_action_capability_mismatch_returns_400(self):
        import deal_lifecycle_api

        transport = httpx.ASGITransport(app=deal_lifecycle_api.app)
        async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.post(
                "/api/actions",
                json={
                    "action_type": "COMMUNICATION.DRAFT_EMAIL",
                    "capability_id": "diligence.request_docs.v1",
                    "deal_id": "DEAL-TEST-001",
                    "title": "Mismatch",
                    "summary": "",
                    "created_by": "test",
                    "source": "system",
                    "risk_level": "low",
                    "requires_human_review": True,
                    "inputs": {"to": "a@b.com", "subject": "x", "context": "y"},
                },
            )
            self.assertEqual(resp.status_code, 400, resp.text)
            detail = (resp.json() or {}).get("detail") or {}
            self.assertEqual(detail.get("code"), "capability_action_type_mismatch", detail)

    async def test_debug_missing_executors_finds_broken_rows(self):
        import deal_lifecycle_api
        from actions.engine.models import ActionPayload, compute_idempotency_key
        from actions.engine.store import ActionStore

        store = ActionStore(Path(os.environ["ZAKOPS_STATE_DB"]))
        action = ActionPayload(
            deal_id=None,
            capability_id=None,
            type="EMAIL_TRIAGE.TEST",
            title="Broken type for debug",
            summary="",
            status="PENDING_APPROVAL",
            created_by="test",
            source="system",
            risk_level="low",
            requires_human_review=True,
            idempotency_key=compute_idempotency_key("broken", "EMAIL_TRIAGE.TEST"),
            inputs={},
        )
        store.create_action(action)

        transport = httpx.ASGITransport(app=deal_lifecycle_api.app)
        async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.get("/api/actions/debug/missing-executors?limit=50")
            self.assertEqual(resp.status_code, 200, resp.text)
            data = resp.json() or {}
            missing_types = set(data.get("missing_types") or [])
            self.assertIn("EMAIL_TRIAGE.TEST", missing_types)

    async def test_actions_quarantine_endpoint_returns_pending_triage_actions(self):
        import deal_lifecycle_api

        transport = httpx.ASGITransport(app=deal_lifecycle_api.app)
        async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
            create = await client.post(
                "/api/actions",
                json={
                    "action_type": "EMAIL_TRIAGE.REVIEW_EMAIL",
                    "title": "Review inbound deal email: ExampleCo teaser",
                    "summary": "HIGH urgency. Contains deal signals.",
                    "capability_id": "email_triage.review_email.v1",
                    "created_by": "email_triage_agent",
                    "source": "system",
                    "risk_level": "medium",
                    "requires_human_review": True,
                    "inputs": {
                        "message_id": "msg-1",
                        "thread_id": "thread-1",
                        "from": "Broker <broker@example.com>",
                        "to": "operator@example.com",
                        "date": "01 Jan 2026 12:00:00 +0000",
                        "subject": "ExampleCo teaser",
                        "company": "ExampleCo",
                        "classification": "DEAL_SIGNAL",
                        "urgency": "HIGH",
                        "links": [{"url": "https://example.com"}],
                        "attachments": [{"filename": "teaser.pdf", "mime_type": "application/pdf", "size_bytes": 123}],
                    },
                },
            )
            self.assertEqual(create.status_code, 200, create.text)
            action_id = create.json()["action"]["action_id"]

            q = await client.get("/api/actions/quarantine?limit=10")
            self.assertEqual(q.status_code, 200, q.text)
            qdata = q.json() or {}
            items = qdata.get("items") or []
            self.assertTrue(any(i.get("action_id") == action_id for i in items), items)

            legacy = await client.get("/api/quarantine")
            self.assertEqual(legacy.status_code, 200, legacy.text)
            ldata = legacy.json() or {}
            legacy_items = ldata.get("items") or []
            self.assertTrue(any((i.get("id") == action_id or i.get("quarantine_id") == action_id) for i in legacy_items), legacy_items)

    async def test_runner_status_includes_stuck_and_error_breakdown_fields(self):
        import deal_lifecycle_api

        transport = httpx.ASGITransport(app=deal_lifecycle_api.app)
        async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.get("/api/actions/runner-status")
            self.assertEqual(resp.status_code, 200, resp.text)
            data = resp.json() or {}
            self.assertIn("stuck_processing", data)
            self.assertIn("error_breakdown", data)

    async def test_unstick_endpoint_transitions_processing_to_ready(self):
        import deal_lifecycle_api
        from actions.engine.models import ActionPayload, compute_idempotency_key
        from actions.engine.store import ActionStore

        store = ActionStore(Path(os.environ["ZAKOPS_STATE_DB"]))
        action = ActionPayload(
            deal_id="DEAL-TEST-001",
            capability_id="communication.draft_email.v1",
            type="COMMUNICATION.DRAFT_EMAIL",
            title="Draft email (unstick test)",
            summary="",
            status="PENDING_APPROVAL",
            created_by="test",
            source="system",
            risk_level="low",
            requires_human_review=True,
            idempotency_key=compute_idempotency_key("unstick", "COMMUNICATION.DRAFT_EMAIL"),
            inputs={"to": "a@b.com", "subject": "x", "context": "y"},
        )
        created, _ = store.create_action(action)
        store.approve_action(created.action_id, actor="test")
        store.request_execute(created.action_id, actor="test")
        ok = store.begin_processing(action_id=created.action_id, owner_id="test-runner", lease_seconds=60)
        self.assertTrue(ok)

        transport = httpx.ASGITransport(app=deal_lifecycle_api.app)
        async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.post(f"/api/actions/{created.action_id}/unstick", json={"unstuck_by": "operator"})
            self.assertEqual(resp.status_code, 200, resp.text)
            data = resp.json() or {}
            self.assertTrue(data.get("success"))
            self.assertEqual(((data.get("action") or {}).get("status")), "READY")

    def test_enrich_materials_executor_is_registered(self):
        from actions.executors.registry import list_executors

        self.assertIn("DEAL.ENRICH_MATERIALS", list_executors())
