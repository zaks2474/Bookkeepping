import importlib
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import httpx

SCRIPTS_DIR = Path(__file__).resolve().parents[1]
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))


class DraftEmailCloudGateTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self._old_env = dict(os.environ)
        self._tmpdir = tempfile.TemporaryDirectory(dir="/home/zaks/tmp")
        self.tmp_path = Path(self._tmpdir.name)

        self.dataroom_root = self.tmp_path / "DataRoom"
        self.dataroom_root.mkdir(parents=True, exist_ok=True)

        os.environ["DATAROOM_ROOT"] = str(self.dataroom_root)
        os.environ["ZAKOPS_STATE_DB"] = str(self.tmp_path / "state.db")
        os.environ["DEAL_EVENTS_DIR"] = str(self.tmp_path / "events")
        os.environ["ZAKOPS_DRAFT_EMAIL_PROVIDER"] = "gemini"
        os.environ["GEMINI_ALLOW_CONTENT_UPLOAD"] = "true"
        os.environ["GEMINI_API_KEY"] = "test-key"

        # Reset module singletons that cache env-derived paths.
        import actions.capabilities.registry as cap_registry
        import tools.registry as tool_registry
        import tools.gateway as tool_gateway
        import actions.executors.registry as exec_registry

        cap_registry._REGISTRY = None
        tool_registry._REGISTRY = None
        tool_gateway._GATEWAY = None
        exec_registry._EXECUTORS.clear()
        exec_registry._BUILTINS_LOADED = False
        exec_registry._TOOL_EXECUTOR = None

        # Reload modules that bind DATAROOM_ROOT at import time.
        import actions.executors._artifacts as artifacts
        import deal_lifecycle_api
        import actions_runner

        importlib.reload(artifacts)
        importlib.reload(deal_lifecycle_api)
        importlib.reload(actions_runner)

        # Seed a single deal so the executor has a folder_path destination.
        self.deal_id = "DEAL-TEST-001"
        self.folder_path = "00-PIPELINE/Inbound/TestCo-2026"

        registry_dir = self.dataroom_root / ".deal-registry"
        registry_dir.mkdir(parents=True, exist_ok=True)
        (registry_dir / "case_files").mkdir(parents=True, exist_ok=True)

        (self.dataroom_root / self.folder_path).mkdir(parents=True, exist_ok=True)

        (registry_dir / "deal_registry.json").write_text(
            json.dumps(
                {
                    "deal_counter": 1,
                    "broker_counter": 0,
                    "deals": {
                        self.deal_id: {
                            "canonical_name": "TestCo",
                            "display_name": "TestCo",
                            "folder_path": str((self.dataroom_root / self.folder_path).resolve()),
                            "stage": "inbound",
                            "status": "active",
                            "identifiers": {},
                            "company_info": {},
                            "broker": None,
                            "aliases": [],
                            "email_thread_ids": [],
                            "related_folders": [],
                            "metadata": {},
                            "audit_trail": [],
                        }
                    },
                    "brokers": {},
                    "junk_patterns": [],
                    "email_to_deal": {},
                },
                indent=2,
                sort_keys=True,
            ),
            encoding="utf-8",
        )

    def tearDown(self):
        os.environ.clear()
        os.environ.update(self._old_env)
        self._tmpdir.cleanup()

    async def test_draft_email_succeeds_with_per_action_cloud_gate(self):
        import deal_lifecycle_api
        import actions_runner

        # Prevent real network calls: patch GeminiProProvider.generate to return strict JSON output.
        from chat_llm_provider import ProviderResponse

        async def _fake_generate(*args, **kwargs):
            return ProviderResponse(
                content='{"subject":"Re: CIM","body":"Hi\\n\\nPlease share the CIM.\\n\\nThanks,"}',
                provider="gemini-pro",
                model="gemini-2.5-pro",
                latency_ms=12,
            )

        with mock.patch("chat_llm_provider.GeminiProProvider.generate", new=mock.AsyncMock(side_effect=_fake_generate)):
            transport = httpx.ASGITransport(app=deal_lifecycle_api.app)
            async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
                create_resp = await client.post(
                    "/api/actions",
                    json={
                        "action_type": "COMMUNICATION.DRAFT_EMAIL",
                        "deal_id": self.deal_id,
                        "capability_id": "communication.draft_email.v1",
                        "title": "Draft broker email (cloud-gated)",
                        "summary": "Test draft",
                        "created_by": "operator",
                        "source": "ui",
                        "risk_level": "medium",
                        "requires_human_review": True,
                        "inputs": {
                            "to": "broker@example.com",
                            "subject": "Re: CIM",
                            "context": "Request the CIM and LTM financials.",
                            "tone": "professional",
                        },
                    },
                )
                self.assertEqual(create_resp.status_code, 200, create_resp.text)
                action_id = create_resp.json()["action"]["action_id"]

                approve_resp = await client.post(f"/api/actions/{action_id}/approve", json={"approved_by": "operator"})
                self.assertEqual(approve_resp.status_code, 200, approve_resp.text)

                exec_resp = await client.post(f"/api/actions/{action_id}/execute", json={"requested_by": "operator"})
                self.assertEqual(exec_resp.status_code, 200, exec_resp.text)

            from actions.engine.store import ActionStore
            from deal_events import DealEventStore
            from deal_registry import DealRegistry

            store = ActionStore(Path(os.environ["ZAKOPS_STATE_DB"]))
            registry = DealRegistry(str(self.dataroom_root / ".deal-registry" / "deal_registry.json"))
            event_store = DealEventStore(events_dir=os.environ["DEAL_EVENTS_DIR"])

            actions_runner.process_one_action(
                store=store,
                registry=registry,
                event_store=event_store,
                owner_id="test-runner",
                action_id=action_id,
                action_lock_seconds=60,
            )

            completed = store.get_action(action_id)
            self.assertIsNotNone(completed)
            self.assertEqual(completed.status, "COMPLETED", f"Action failed: {completed.error}")
            self.assertTrue(completed.artifacts, "Expected at least one artifact")
