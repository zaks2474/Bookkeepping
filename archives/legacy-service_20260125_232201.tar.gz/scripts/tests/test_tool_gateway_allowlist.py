import os
import sys
import tempfile
import unittest
from pathlib import Path

SCRIPTS_DIR = Path(__file__).resolve().parents[1]
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))


class ToolGatewayAllowlistTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self._old_env = dict(os.environ)
        self._tmpdir = tempfile.TemporaryDirectory(dir="/home/zaks/tmp")
        self.db_path = Path(self._tmpdir.name) / "state.db"
        os.environ["ZAKOPS_STATE_DB"] = str(self.db_path)

    def tearDown(self):
        os.environ.clear()
        os.environ.update(self._old_env)
        self._tmpdir.cleanup()

    async def test_allowlist_allows_and_blocks(self):
        from tools.gateway import ToolErrorCode, ToolGateway, ToolGatewayConfig, ToolInvocationContext
        from tools.registry import get_tool_registry

        reg = get_tool_registry()
        cfg = ToolGatewayConfig(
            enabled=True,
            require_allowlist=True,
            allowed_tools=["local__echo"],
            denied_tools=[],
            audit_db_path=str(self.db_path),
        )
        gateway = ToolGateway(config=cfg, tool_registry=reg)

        ctx = ToolInvocationContext(action_id="tool_health_check", bypass_db_approval=True)

        ok = await gateway.invoke(tool_name="local__echo", args={"hello": "world"}, context=ctx, timeout_ms=5000)
        self.assertTrue(ok.success, ok)
        self.assertEqual(ok.error_code, ToolErrorCode.SUCCESS)
        self.assertEqual((ok.output or {}).get("tool"), "echo")
        self.assertEqual(((ok.output or {}).get("echo") or {}).get("hello"), "world")

        blocked = await gateway.invoke(tool_name="gmail__search_emails", args={}, context=ctx, timeout_ms=5000)
        self.assertFalse(blocked.success)
        self.assertEqual(blocked.error_code, ToolErrorCode.TOOL_NOT_ALLOWED)

