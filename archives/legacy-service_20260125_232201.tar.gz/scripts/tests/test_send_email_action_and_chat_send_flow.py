import importlib
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path


SCRIPTS_DIR = Path(__file__).resolve().parents[1]
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))


class SendEmailExecutorE2ETests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self._old_env = dict(os.environ)
        self._tmpdir = tempfile.TemporaryDirectory(dir="/home/zaks/tmp")
        self.tmp_path = Path(self._tmpdir.name)

        self.dataroom_root = self.tmp_path / "DataRoom"
        self.dataroom_root.mkdir(parents=True, exist_ok=True)

        os.environ["DATAROOM_ROOT"] = str(self.dataroom_root)
        os.environ["ZAKOPS_STATE_DB"] = str(self.tmp_path / "state.db")
        os.environ["DEAL_EVENTS_DIR"] = str(self.tmp_path / "events")

        # Drafting: deterministic stub, no cloud.
        os.environ["ZAKOPS_DRAFT_EMAIL_PROVIDER"] = "stub"

        # ToolGateway: enable + allowlisted stubbed gmail__send_email tool.
        tools_dir = self.tmp_path / "tools"
        tools_dir.mkdir(parents=True, exist_ok=True)
        os.environ["ZAKOPS_TOOLS_DIR"] = str(tools_dir)
        os.environ["ZAKOPS_TOOL_GATEWAY_ENABLED"] = "true"
        os.environ["ZAKOPS_TOOL_REQUIRE_ALLOWLIST"] = "true"
        os.environ["ZAKOPS_TOOL_ALLOWLIST"] = "gmail__send_email"
        os.environ["ZAKOPS_MCP_RUNTIME_MODE"] = "stdio"

        (tools_dir / "gmail__send_email.yaml").write_text(
            "\n".join(
                [
                    'tool_id: "gmail__send_email"',
                    'version: "1.0.0"',
                    'title: "Gmail Send Email (stubbed)"',
                    'description: "TEST ONLY: sends nothing; echoes args via stdio stub."',
                    'provider: "mcp"',
                    'mcp_server: "local"',
                    'mcp_tool_name: "send_email"',
                    "mcp_stdio_command:",
                    '  - "python3"',
                    '  - "/home/zaks/scripts/tools/stubs/mcp_stdio_server.py"',
                    "timeout_ms: 5000",
                    "ttl_seconds: 0",
                    "health_check:",
                    "  enabled: false",
                    "secrets_refs: {}",
                    'risk_level: "high"',
                    "requires_approval: true",
                    'safety_class: "irreversible"',
                    "irreversible: true",
                    "input_schema:",
                    "  type: object",
                    "  additionalProperties: false",
                    "  properties:",
                    "    to: { type: array, items: { type: string } }",
                    "    subject: { type: string }",
                    "    body: { type: string }",
                    "  required: [to, subject, body]",
                    "output_schema:",
                    "  type: object",
                    "  properties:",
                    "    tool: { type: string }",
                    "    echo: { type: object }",
                    'tags: ["test"]',
                    'created: "2026-01-01"',
                    'owner: "tests"',
                    "",
                ]
            ),
            encoding="utf-8",
        )

        # Reload modules that cache env-derived defaults.
        import tools.registry
        import tools.gateway

        importlib.reload(tools.registry)
        importlib.reload(tools.gateway)

        import actions.executors._artifacts
        import actions.executors.communication_draft_email
        import actions.executors.communication_send_email
        import actions.executors.registry

        importlib.reload(actions.executors._artifacts)
        importlib.reload(actions.executors.communication_draft_email)
        importlib.reload(actions.executors.communication_send_email)
        importlib.reload(actions.executors.registry)
        import actions_runner

        importlib.reload(actions_runner)

    def tearDown(self):
        os.environ.clear()
        os.environ.update(self._old_env)
        # Restore module-level defaults that are captured at import time (e.g., DEFAULT_MANIFESTS_DIR).
        try:
            import tools.registry
            import tools.gateway

            importlib.reload(tools.registry)
            importlib.reload(tools.gateway)
        except Exception:
            pass
        self._tmpdir.cleanup()

    async def test_send_email_action_uses_tool_gateway_and_completes(self):
        from actions.engine.models import ActionPayload, compute_idempotency_key, safe_uuid
        from actions.engine.store import ActionStore
        import actions_runner
        from deal_events import DealEventStore
        from deal_registry import DealRegistry

        deal_id = "DEAL-TEST-SEND-001"
        folder_path = "01-ACTIVE-DEALS/DEAL-TEST-SEND-001"

        registry_dir = self.dataroom_root / ".deal-registry"
        registry_dir.mkdir(parents=True, exist_ok=True)
        (registry_dir / "case_files").mkdir(parents=True, exist_ok=True)
        (self.dataroom_root / folder_path).mkdir(parents=True, exist_ok=True)
        (registry_dir / "deal_registry.json").write_text(
            json.dumps(
                {
                    "deal_counter": 1,
                    "broker_counter": 0,
                    "deals": {
                        deal_id: {
                            "canonical_name": "TestCo",
                            "display_name": "TestCo",
                            "folder_path": folder_path,
                            "stage": "screening",
                            "status": "active",
                            "identifiers": {},
                            "company_info": {},
                            "broker": None,
                            "aliases": [],
                            "email_thread_ids": [],
                            "related_folders": [],
                            "metadata": {},
                            "audit_trail": [],
                        }
                    },
                    "brokers": {},
                    "junk_patterns": [],
                    "email_to_deal": {},
                },
                indent=2,
                sort_keys=True,
            ),
            encoding="utf-8",
        )

        store = ActionStore(Path(os.environ["ZAKOPS_STATE_DB"]))
        registry = DealRegistry(str(self.dataroom_root / ".deal-registry" / "deal_registry.json"))
        event_store = DealEventStore(events_dir=os.environ["DEAL_EVENTS_DIR"])

        # 1) Draft email (stub provider) -> COMPLETED with artifacts
        draft = ActionPayload(
            deal_id=deal_id,
            capability_id="communication.draft_email.v1",
            type="COMMUNICATION.DRAFT_EMAIL",
            title="Draft email",
            summary="Draft only",
            status="PENDING_APPROVAL",
            created_by="tests",
            source="system",
            risk_level="medium",
            requires_human_review=True,
            idempotency_key=compute_idempotency_key("draft", safe_uuid()),
            inputs={"to": "broker@example.com", "subject": "Re: CIM", "context": "Please send CIM."},
        )
        draft, _ = store.create_action(draft)
        draft = store.approve_action(draft.action_id, actor="tests")
        draft = store.request_execute(draft.action_id, actor="tests")
        actions_runner.process_one_action(
            store=store,
            registry=registry,
            event_store=event_store,
            owner_id="test-runner",
            action_id=draft.action_id,
            action_lock_seconds=60,
        )
        drafted = store.get_action(draft.action_id)
        self.assertIsNotNone(drafted)
        self.assertEqual(drafted.status, "COMPLETED")
        md_paths = [Path(a.path) for a in (drafted.artifacts or []) if str(a.filename).endswith(".md")]
        self.assertTrue(md_paths, "Expected draft .md artifact")
        draft_md = md_paths[0]
        self.assertTrue(draft_md.exists(), "Draft artifact missing on disk")

        # 2) Send email via ToolGateway stub -> COMPLETED + tool invocation log entry
        send = ActionPayload(
            deal_id=deal_id,
            capability_id="communication.send_email.v1",
            type="COMMUNICATION.SEND_EMAIL",
            title="Send drafted email",
            summary="Send via ToolGateway",
            status="PENDING_APPROVAL",
            created_by="tests",
            source="system",
            risk_level="high",
            requires_human_review=True,
            idempotency_key=compute_idempotency_key("send", safe_uuid()),
            inputs={"to": "broker@example.com", "subject": "Re: CIM", "body_artifact_path": str(draft_md)},
        )
        send, _ = store.create_action(send)
        send = store.approve_action(send.action_id, actor="tests")
        send = store.request_execute(send.action_id, actor="tests")
        actions_runner.process_one_action(
            store=store,
            registry=registry,
            event_store=event_store,
            owner_id="test-runner",
            action_id=send.action_id,
            action_lock_seconds=60,
        )
        sent = store.get_action(send.action_id)
        self.assertIsNotNone(sent)
        self.assertEqual(sent.status, "COMPLETED")
        self.assertTrue(sent.artifacts)

        # Tool invocation log evidence
        import sqlite3

        conn = sqlite3.connect(os.environ["ZAKOPS_STATE_DB"])
        conn.row_factory = sqlite3.Row
        row = conn.execute(
            "SELECT tool_name, success, error_code FROM tool_invocation_log WHERE action_id=? ORDER BY attempt_started_at DESC LIMIT 1",
            (send.action_id,),
        ).fetchone()
        conn.close()
        self.assertIsNotNone(row, "Expected tool_invocation_log row for send action")
        self.assertEqual(row["tool_name"], "gmail__send_email")
        self.assertEqual(int(row["success"]), 1)


class ChatSendEmailLoopTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self._old_env = dict(os.environ)
        self._tmpdir = tempfile.TemporaryDirectory(dir="/home/zaks/tmp")
        self.tmp_path = Path(self._tmpdir.name)

        os.environ["DATAROOM_ROOT"] = str(self.tmp_path / "DataRoom")
        os.environ["ZAKOPS_STATE_DB"] = str(self.tmp_path / "state.db")

        # Ensure ActionStore doesn't scan the real machine DB.
        (Path(os.environ["DATAROOM_ROOT"]) / ".deal-registry").mkdir(parents=True, exist_ok=True)

    def tearDown(self):
        os.environ.clear()
        os.environ.update(self._old_env)
        self._tmpdir.cleanup()

    async def test_send_it_creates_send_email_action_proposal_not_redraft(self):
        from chat_orchestrator import ChatMessage, ChatOrchestrator, ChatSession

        orchestrator = ChatOrchestrator(allow_cloud=False)
        orchestrator.session_store = None

        session_id = "sess-send-loop"
        deal_id = "DEAL-TEST-LOOP-001"

        session = ChatSession(session_id=session_id, scope={"type": "deal", "deal_id": deal_id})
        session.messages.append(
            ChatMessage(
                role="assistant",
                content="...",
                proposals=[
                    {
                        "proposal_id": "p-draft-email",
                        "type": "draft_email",
                        "deal_id": deal_id,
                        "params": {"recipient": "broker@example.com", "subject": "Re: CIM", "context": "Need CIM"},
                        "status": "executed",
                        "result": {"success": True, "subject": "Re: CIM", "body": "Hi — please send the CIM. Thanks,"},
                    }
                ],
            )
        )
        orchestrator.sessions[session_id] = session

        resp = await orchestrator.chat(
            query="Send it to the broker.",
            scope={"type": "deal", "deal_id": deal_id},
            session_id=session_id,
            options={},
        )

        self.assertTrue(resp.proposals, resp)
        p = resp.proposals[0]
        self.assertEqual(p.get("type"), "create_action")
        self.assertEqual(p.get("deal_id"), deal_id)
        self.assertEqual(p.get("params", {}).get("action_type"), "COMMUNICATION.SEND_EMAIL")
        # Crucially: this should NOT propose another draft.
        self.assertNotEqual(p.get("type"), "draft_email")
