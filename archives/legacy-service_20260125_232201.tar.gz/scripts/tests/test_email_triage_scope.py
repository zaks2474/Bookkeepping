import sys
import unittest
from pathlib import Path

# Prefer the bookkeeping triage agent implementation over any shadow copies in /home/zaks/scripts.
BOOKKEEPING_SCRIPTS_DIR = Path("/home/zaks/bookkeeping/scripts")
if str(BOOKKEEPING_SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(BOOKKEEPING_SCRIPTS_DIR))


class EmailTriageScopeTests(unittest.TestCase):
    def test_receipt_pdf_is_not_deal_signal(self):
        from email_triage_agent.gmail_mcp import EmailAttachment
        from email_triage_agent.triage_logic import classify_email

        att = EmailAttachment(
            attachment_id="att1",
            filename="Receipt-2410-4037-8811.pdf",
            mime_type="application/pdf",
            size_bytes=12000,
        )
        cls = classify_email(
            subject="Your Costco receipt",
            sender="Costco <noreply@costco.com>",
            body_text="Thanks for your purchase. Receipt attached.",
            links=[],
            attachments=[att],
        )
        self.assertNotEqual(cls.classification, "DEAL_SIGNAL", cls)

    def test_denylisted_sender_is_not_deal_signal(self):
        from email_triage_agent.gmail_mcp import EmailAttachment
        from email_triage_agent.triage_logic import classify_email

        att = EmailAttachment(
            attachment_id="att1",
            filename="welcome.pdf",
            mime_type="application/pdf",
            size_bytes=12000,
        )
        cls = classify_email(
            subject="Welcome to Bitdefender!",
            sender="Bitdefender <no-reply@info.bitdefender.com>",
            body_text="Welcome! Your subscription includes multiple devices.",
            links=[],
            attachments=[att],
        )
        self.assertNotEqual(cls.classification, "DEAL_SIGNAL", cls)

    def test_newsletter_language_is_not_deal_signal(self):
        from email_triage_agent.triage_logic import classify_email

        cls = classify_email(
            subject="Courts set AI rules. Harvey hits $8B.",
            sender="The Daily Brief <newsletter@example.com>",
            body_text="This week's newsletter covers multiple stories. Unsubscribe anytime.",
            links=[],
            attachments=[],
        )
        self.assertNotEqual(cls.classification, "DEAL_SIGNAL", cls)

    def test_nda_attachment_is_deal_signal(self):
        from email_triage_agent.gmail_mcp import EmailAttachment
        from email_triage_agent.triage_logic import classify_email

        att = EmailAttachment(
            attachment_id="att1",
            filename="saidi-zakari-osseni-signed-tupelo-nda.pdf",
            mime_type="application/pdf",
            size_bytes=250000,
        )
        cls = classify_email(
            subject="Signed NDA attached",
            sender="Broker <broker@example.com>",
            body_text="Please find the signed NDA attached. Next step is CIM access.",
            links=[],
            attachments=[att],
        )
        self.assertEqual(cls.classification, "DEAL_SIGNAL", cls)
