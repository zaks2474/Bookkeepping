import importlib
import os
import sys
import tempfile
import unittest
from pathlib import Path

import httpx

SCRIPTS_DIR = Path(__file__).resolve().parents[1]
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))


class ActionsPlanEndpointTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self._old_env = dict(os.environ)
        self._tmpdir = tempfile.TemporaryDirectory(dir="/home/zaks/tmp")
        self.tmp_path = Path(self._tmpdir.name)

        dataroom_root = self.tmp_path / "DataRoom"
        dataroom_root.mkdir(parents=True, exist_ok=True)
        os.environ["DATAROOM_ROOT"] = str(dataroom_root)
        os.environ["ZAKOPS_STATE_DB"] = str(self.tmp_path / "state.db")

        # Reload API so it binds DATAROOM_ROOT from env.
        import deal_lifecycle_api
        importlib.reload(deal_lifecycle_api)

    def tearDown(self):
        os.environ.clear()
        os.environ.update(self._old_env)
        self._tmpdir.cleanup()

    async def test_plan_returns_clarifying_questions_for_missing_inputs(self):
        import deal_lifecycle_api

        transport = httpx.ASGITransport(app=deal_lifecycle_api.app)
        async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.post(
                "/api/actions/plan",
                json={"query": "Draft email to john@seller.com about LOI terms"},
            )
        self.assertEqual(resp.status_code, 200, resp.text)
        data = resp.json()
        self.assertFalse(data.get("is_refusal"), data)
        self.assertTrue(data.get("requires_clarification"), data)
        self.assertTrue(data.get("missing_fields"), data)

    async def test_plan_decomposes_multi_step_when_multiple_capabilities_match(self):
        import deal_lifecycle_api

        transport = httpx.ASGITransport(app=deal_lifecycle_api.app)
        async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.post(
                "/api/actions/plan",
                json={"query": "Draft an email and build a valuation model"},
            )
        self.assertEqual(resp.status_code, 200, resp.text)
        data = resp.json()
        steps = data.get("plan_steps") or []
        self.assertGreaterEqual(len(steps), 2, data)

