import os
import sys
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

SCRIPTS_DIR = Path(__file__).resolve().parents[1]
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))


class ActionWatchdogRequeueTests(unittest.TestCase):
    def setUp(self):
        self._old_env = dict(os.environ)
        self._tmpdir = tempfile.TemporaryDirectory(dir="/home/zaks/tmp")
        self.db_path = Path(self._tmpdir.name) / "state.db"
        os.environ["ZAKOPS_STATE_DB"] = str(self.db_path)

    def tearDown(self):
        os.environ.clear()
        os.environ.update(self._old_env)
        self._tmpdir.cleanup()

    def test_processing_watchdog_marks_failed_and_requeue_moves_to_ready(self):
        from actions.engine.models import ActionPayload, compute_idempotency_key
        from actions.engine.store import ActionStore

        store = ActionStore(Path(os.environ["ZAKOPS_STATE_DB"]))

        started_at = (datetime.now(timezone.utc) - timedelta(seconds=5000)).replace(microsecond=0).isoformat().replace("+00:00", "Z")
        action, created_new = store.create_action(
            ActionPayload(
                deal_id="DEAL-WD-1",
                type="DILIGENCE.REQUEST_DOCS",
                title="t",
                summary="",
                status="PROCESSING",
                started_at=started_at,
                created_by="tester",
                source="system",
                risk_level="low",
                requires_human_review=True,
                idempotency_key=compute_idempotency_key("wd", "1"),
                inputs={"doc_type": "financials", "description": "x"},
            )
        )
        self.assertTrue(created_new)

        failed = store.mark_processing_timeouts(older_than_seconds=60, actor="test_watchdog", limit=10)
        self.assertEqual(failed, 1)

        refreshed = store.get_action(action.action_id)
        self.assertIsNotNone(refreshed)
        self.assertEqual(refreshed.status, "FAILED")
        self.assertIsNotNone(refreshed.error)
        self.assertEqual(refreshed.error.code, "processing_timeout")

        requeued = store.requeue_failed_action(action_id=action.action_id, actor="operator", reason="test")
        self.assertEqual(requeued.status, "READY")
        self.assertIsNone(requeued.error)
        self.assertIsNotNone(requeued.next_attempt_at)

