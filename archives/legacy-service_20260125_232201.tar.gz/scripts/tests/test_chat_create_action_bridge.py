import importlib
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import httpx

SCRIPTS_DIR = Path(__file__).resolve().parents[1]
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))


class ChatCreateActionBridgeTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self._old_env = dict(os.environ)
        self._tmpdir = tempfile.TemporaryDirectory(dir="/home/zaks/tmp")
        self.tmp_path = Path(self._tmpdir.name)

        self.dataroom_root = self.tmp_path / "DataRoom"
        self.dataroom_root.mkdir(parents=True, exist_ok=True)

        os.environ["DATAROOM_ROOT"] = str(self.dataroom_root)
        os.environ["ZAKOPS_STATE_DB"] = str(self.tmp_path / "state.db")
        os.environ["DEAL_EVENTS_DIR"] = str(self.tmp_path / "events")
        os.environ["ZAKOPS_DRAFT_EMAIL_PROVIDER"] = "stub"

        # Reload API so it binds DATAROOM_ROOT from env.
        import deal_lifecycle_api
        importlib.reload(deal_lifecycle_api)

    def tearDown(self):
        os.environ.clear()
        os.environ.update(self._old_env)
        self._tmpdir.cleanup()

    async def test_execute_proposal_create_action_creates_action_record(self):
        import deal_lifecycle_api
        from actions.engine.store import ActionStore
        from chat_orchestrator import ChatMessage, ChatOrchestrator, ChatSession
        import actions_runner
        from deal_events import DealEventStore
        from deal_registry import DealRegistry

        orchestrator = ChatOrchestrator(allow_cloud=False)
        orchestrator.session_store = None

        session_id = "sess-create-action"
        deal_id = "DEAL-TEST-900"
        proposal_id = "p-create-action-1"

        folder_path = "01-ACTIVE-DEALS/DEAL-TEST-900"
        registry_dir = self.dataroom_root / ".deal-registry"
        registry_dir.mkdir(parents=True, exist_ok=True)
        (registry_dir / "case_files").mkdir(parents=True, exist_ok=True)
        (self.dataroom_root / folder_path).mkdir(parents=True, exist_ok=True)
        (registry_dir / "deal_registry.json").write_text(
            json.dumps(
                {
                    "deal_counter": 1,
                    "broker_counter": 0,
                    "deals": {
                        deal_id: {
                            "canonical_name": "TestCo",
                            "display_name": "TestCo",
                            "folder_path": folder_path,
                            "stage": "screening",
                            "status": "active",
                            "identifiers": {},
                            "company_info": {},
                            "broker": None,
                            "aliases": [],
                            "email_thread_ids": [],
                            "related_folders": [],
                            "metadata": {},
                            "audit_trail": [],
                        }
                    },
                    "brokers": {},
                    "junk_patterns": [],
                    "email_to_deal": {},
                },
                indent=2,
                sort_keys=True,
            ),
            encoding="utf-8",
        )

        session = ChatSession(session_id=session_id, scope={"type": "deal", "deal_id": deal_id})
        session.messages.append(
            ChatMessage(
                role="assistant",
                content="...",
                proposals=[
                    {
                        "proposal_id": proposal_id,
                        "type": "create_action",
                        "deal_id": deal_id,
                        "params": {
                            "action_type": "DILIGENCE.REQUEST_DOCS",
                            "title": "Request diligence docs",
                            "inputs": {"doc_type": "financials", "description": "Request LTM financials and last 3 years statements."},
                        },
                        "status": "pending_approval",
                        "reason": "Draft email",
                    }
                ],
            )
        )
        orchestrator.sessions[session_id] = session

        transport = httpx.ASGITransport(app=deal_lifecycle_api.app)
        async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
            with patch("chat_orchestrator.get_orchestrator", return_value=orchestrator):
                resp = await client.post(
                    "/api/chat/execute-proposal",
                    json={
                        "proposal_id": proposal_id,
                        "approved_by": "operator",
                        "session_id": session_id,
                        "action": "approve",
                    },
                )

        self.assertEqual(resp.status_code, 200, resp.text)
        data = resp.json()
        self.assertTrue(data.get("success"), data)
        self.assertEqual(data.get("proposal_type"), "create_action")
        action_id = data.get("result", {}).get("action_id")
        self.assertTrue(action_id, data)

        store = ActionStore(Path(os.environ["ZAKOPS_STATE_DB"]))
        action = store.get_action(action_id)
        self.assertIsNotNone(action)
        self.assertEqual(action.deal_id, deal_id)
        self.assertEqual(action.type, "DILIGENCE.REQUEST_DOCS")
        # Chat approval auto-approves + enqueues for runner.
        self.assertIn(action.status, {"READY", "PROCESSING", "COMPLETED"})

        # Execute via runner (in-process)
        registry = DealRegistry(str(self.dataroom_root / ".deal-registry" / "deal_registry.json"))
        event_store = DealEventStore(events_dir=os.environ["DEAL_EVENTS_DIR"])
        actions_runner.process_one_action(
            store=store,
            registry=registry,
            event_store=event_store,
            owner_id="test-runner",
            action_id=action_id,
            action_lock_seconds=60,
        )

        final = store.get_action(action_id)
        self.assertIsNotNone(final)
        self.assertEqual(final.status, "COMPLETED")
        self.assertTrue(final.artifacts)
