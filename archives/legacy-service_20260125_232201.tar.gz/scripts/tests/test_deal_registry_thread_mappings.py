import json
import sys
import tempfile
import unittest
from pathlib import Path

SCRIPTS_DIR = Path(__file__).resolve().parents[1]
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))


class DealRegistryThreadMappingsTests(unittest.TestCase):
    def setUp(self) -> None:
        self._tmpdir = tempfile.TemporaryDirectory(dir="/home/zaks/tmp")
        self.tmp_path = Path(self._tmpdir.name)
        self.registry_dir = self.tmp_path / ".deal-registry"
        self.registry_dir.mkdir(parents=True, exist_ok=True)
        self.registry_path = self.registry_dir / "deal_registry.json"

    def tearDown(self) -> None:
        self._tmpdir.cleanup()

    def test_thread_mappings_persist_roundtrip(self) -> None:
        from deal_registry import DealRegistry

        # Backward-compatible seed (no thread_to_* keys).
        self.registry_path.write_text(
            json.dumps(
                {
                    "deal_counter": 0,
                    "broker_counter": 0,
                    "deals": {},
                    "brokers": {},
                    "junk_patterns": [],
                    "email_to_deal": {},
                },
                indent=2,
                sort_keys=True,
            ),
            encoding="utf-8",
        )

        reg = DealRegistry(str(self.registry_path))
        self.assertEqual(reg.thread_to_deal, {})
        self.assertEqual(reg.thread_to_non_deal, {})

        reg.add_thread_deal_mapping("thread_1", "DEAL-2026-001")
        reg.add_thread_non_deal_mapping("thread_2", "not_a_deal")
        reg.save()

        raw = json.loads(self.registry_path.read_text(encoding="utf-8"))
        self.assertEqual(raw.get("thread_to_deal", {}).get("thread_1"), "DEAL-2026-001")
        self.assertEqual(raw.get("thread_to_non_deal", {}).get("thread_2"), "not_a_deal")

        reg2 = DealRegistry(str(self.registry_path))
        self.assertEqual(reg2.get_thread_deal_mapping("thread_1"), "DEAL-2026-001")
        self.assertEqual(reg2.get_thread_non_deal_mapping("thread_2"), "not_a_deal")

    def test_migration_populates_thread_to_deal_from_email_thread_ids(self) -> None:
        from deal_registry import DealRegistry
        from migrations.migrate_thread_mappings import migrate

        reg = DealRegistry(str(self.registry_path))
        deal = reg.create_deal(deal_id="DEAL-2026-001", canonical_name="ExampleCo", folder_path=str(self.tmp_path / "ExampleCo"))
        deal.email_thread_ids.append("thread_abc")
        reg.save()

        # Ensure mapping isn't already present.
        raw_before = json.loads(self.registry_path.read_text(encoding="utf-8"))
        self.assertEqual(raw_before.get("thread_to_deal") or {}, {})

        result = migrate(registry_path=str(self.registry_path))
        self.assertEqual(result.get("migrated"), 1)

        raw_after = json.loads(self.registry_path.read_text(encoding="utf-8"))
        self.assertEqual(raw_after.get("thread_to_deal", {}).get("thread_abc"), "DEAL-2026-001")

