#!/usr/bin/env python3
import argparse
import contextlib
import json
from pathlib import Path
import shlex
import subprocess
import sys


def run(cmd):
    proc = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    return proc.returncode, proc.stdout.strip(), proc.stderr.strip()


def run_and_report(title, cmd):
    ret, out, err = run(cmd)
    print(f"## {title}")
    print(f"$ {cmd}")
    if out:
        print(out)
    if err:
        print(err)
    print(f"returncode: {ret}")
    print()
    return ret, out


def curl_json(url):
    ret, out, err = run(f"curl -s {shlex.quote(url)}")
    if ret != 0:
        return None
    try:
        return json.loads(out)
    except json.JSONDecodeError:
        return None


def emit_report(*, components: set[str]) -> int:
    print("# Baseline health report")
    print()

    if "ports" in components:
        run_and_report(
            "Listening ports (3003, 8080, 8000, 8090)",
            "ss -ltnp | egrep ':(3003|8080|8000|8090)\\b' || true",
        )

    if "services" in components:
        services = [
            "zakops-api-8090.service",
            "kinetic-actions-runner.service",
            "zakops-email-triage.timer",
            "zakops-deal-lifecycle-controller.timer",
        ]
        for svc in services:
            run_and_report(f"Service {svc}", f"systemctl status {svc} --no-pager || true")

    if "backend" in components:
        run_and_report("Backend version", "curl -s http://localhost:8090/api/version")
        run_and_report("Actions runner status", "curl -s http://localhost:8090/api/actions/runner-status")

    if "gmail" in components:
        run_and_report("Gmail MCP health", "curl -s http://localhost:8090/api/gmail/health")
        run_and_report(
            "Gmail MCP stray processes (should be empty; clients should spawn-per-call)",
            "ps aux | rg -n \"server-gmail-autoauth-mcp\" | head -n 50 || true",
        )

    if "dashboard" in components:
        run_and_report("Dashboard sample action", "curl -s http://localhost:3003/api/actions | head -n 40")

    if "quarantine" in components:
        quarantine = curl_json("http://localhost:8090/api/actions/quarantine?limit=5")
        print("## Quarantine preview items")
        if quarantine:
            print(json.dumps(quarantine, indent=2))
            if quarantine.get("items"):
                action_id = quarantine["items"][0].get("action_id")
                if action_id:
                    run_and_report(
                        f"Quarantine preview for {action_id}",
                        f"curl -s http://localhost:8090/api/actions/quarantine/{action_id}/preview",
                    )
        else:
            print("Unable to fetch quarantine items")
        print()

    print("Baseline capture complete.")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="ZakOps baseline health report (writes markdown).")
    parser.add_argument("--output", help="Write output to a markdown file instead of stdout.")
    parser.add_argument(
        "--component",
        action="append",
        choices=["ports", "services", "backend", "gmail", "dashboard", "quarantine", "all"],
        help="Only run selected component checks (repeatable). Default: all.",
    )
    args = parser.parse_args()

    components = set(args.component or [])
    if not components or "all" in components:
        components = {"ports", "services", "backend", "gmail", "dashboard", "quarantine"}

    if args.output:
        out_path = Path(str(args.output)).expanduser().resolve()
        out_path.parent.mkdir(parents=True, exist_ok=True)
        with out_path.open("w", encoding="utf-8") as f, contextlib.redirect_stdout(f):
            rc = emit_report(components=components)
        print(f"Wrote: {out_path}")
        return int(rc)

    return emit_report(components=components)


if __name__ == "__main__":
    raise SystemExit(main())
