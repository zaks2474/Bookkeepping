#!/usr/bin/env python3
"""
Deal Diligence Coordinator Agent

Mission: "Run DD playbook."
- Initialize and maintain due diligence checklists
- Track missing documents
- Schedule reminders and deadlines
- Generate progress reports

Inputs:
- Deal context (registry, events, case file)
- Document inventory
- DD checklist templates

Outputs:
- DD checklist artifacts
- Deferred actions (reminders, progress checks)
- Events (checklist updates, milestone completions)

Hard Boundaries:
- No contacting counterparties directly
- Advisory only - does not make decisions
- No direct file system modifications outside registry

Usage:
    python3 deal_diligence_coordinator.py initialize DEAL-2025-001
    python3 deal_diligence_coordinator.py progress DEAL-2025-001
    python3 deal_diligence_coordinator.py missing-docs DEAL-2025-001
"""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

# Add paths
sys.path.insert(0, str(Path(__file__).parent))
sys.path.insert(0, str(Path("/home/zaks/Zaks-llm/src")))

from deal_registry import DealRegistry
from deal_events import DealEventStore
from deferred_actions import DeferredActionQueue
from deal_case_manager import DealCaseManagerAgent, AgentResult

# Configuration
REGISTRY_PATH = "/home/zaks/DataRoom/.deal-registry/deal_registry.json"
CASE_FILES_DIR = Path("/home/zaks/DataRoom/.deal-registry/case_files")
CHECKLISTS_DIR = Path("/home/zaks/DataRoom/.deal-registry/checklists")
RUN_LEDGER_PATH = Path("/home/zaks/logs/run-ledger.jsonl")

# DD Checklist Template
DD_CHECKLIST_TEMPLATE = {
    "financial": [
        {"item": "Last 3 years audited financials", "required": True},
        {"item": "Last 3 years tax returns", "required": True},
        {"item": "Current year YTD financials", "required": True},
        {"item": "Monthly P&L for last 12 months", "required": True},
        {"item": "Accounts receivable aging", "required": True},
        {"item": "Accounts payable aging", "required": True},
        {"item": "Revenue by customer breakdown", "required": True},
        {"item": "Revenue by product/service breakdown", "required": False},
        {"item": "Cash flow projections", "required": False},
        {"item": "Capital expenditure schedule", "required": False},
    ],
    "legal": [
        {"item": "Corporate formation documents", "required": True},
        {"item": "Operating agreements / bylaws", "required": True},
        {"item": "List of all contracts over $10K", "required": True},
        {"item": "Customer contracts (top 10)", "required": True},
        {"item": "Vendor contracts (key suppliers)", "required": True},
        {"item": "Lease agreements", "required": True},
        {"item": "Intellectual property documentation", "required": True},
        {"item": "Pending/threatened litigation", "required": True},
        {"item": "Insurance policies", "required": True},
        {"item": "Regulatory licenses/permits", "required": False},
    ],
    "operations": [
        {"item": "Organizational chart", "required": True},
        {"item": "Employee roster with compensation", "required": True},
        {"item": "Employee handbook / policies", "required": False},
        {"item": "Key employee contracts", "required": True},
        {"item": "Benefit plans documentation", "required": True},
        {"item": "Standard operating procedures", "required": False},
        {"item": "Vendor/supplier list", "required": True},
        {"item": "Customer list with contact info", "required": True},
    ],
    "it": [
        {"item": "Technology stack overview", "required": True},
        {"item": "Software licenses", "required": True},
        {"item": "IT infrastructure diagram", "required": False},
        {"item": "Security policies and certifications", "required": True},
        {"item": "Data backup procedures", "required": True},
        {"item": "Disaster recovery plan", "required": False},
    ],
    "commercial": [
        {"item": "Sales pipeline report", "required": True},
        {"item": "Customer churn analysis", "required": True},
        {"item": "Market analysis / competitive landscape", "required": False},
        {"item": "Marketing materials and strategy", "required": False},
        {"item": "Pricing documentation", "required": True},
    ],
}


@dataclass
class ChecklistItem:
    """Individual DD checklist item"""
    category: str
    item: str
    required: bool
    status: str = "not_started"  # not_started, in_progress, received, reviewed, flagged
    document_path: Optional[str] = None
    notes: str = ""
    updated_at: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "category": self.category,
            "item": self.item,
            "required": self.required,
            "status": self.status,
            "document_path": self.document_path,
            "notes": self.notes,
            "updated_at": self.updated_at,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "ChecklistItem":
        return cls(
            category=d.get("category", ""),
            item=d.get("item", ""),
            required=d.get("required", False),
            status=d.get("status", "not_started"),
            document_path=d.get("document_path"),
            notes=d.get("notes", ""),
            updated_at=d.get("updated_at"),
        )


@dataclass
class DDChecklist:
    """Complete DD checklist for a deal"""
    deal_id: str
    created_at: str
    updated_at: str
    items: List[ChecklistItem] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def completion_pct(self) -> int:
        """Calculate completion percentage"""
        if not self.items:
            return 0
        completed = sum(1 for i in self.items if i.status in ("received", "reviewed"))
        return int(100 * completed / len(self.items))

    def required_completion_pct(self) -> int:
        """Calculate completion percentage for required items only"""
        required = [i for i in self.items if i.required]
        if not required:
            return 100
        completed = sum(1 for i in required if i.status in ("received", "reviewed"))
        return int(100 * completed / len(required))

    def missing_items(self, required_only: bool = True) -> List[ChecklistItem]:
        """Get items that haven't been received"""
        items = self.items
        if required_only:
            items = [i for i in items if i.required]
        return [i for i in items if i.status in ("not_started", "in_progress")]

    def flagged_items(self) -> List[ChecklistItem]:
        """Get items that have been flagged for issues"""
        return [i for i in self.items if i.status == "flagged"]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "deal_id": self.deal_id,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "items": [i.to_dict() for i in self.items],
            "metadata": self.metadata,
            "completion_pct": self.completion_pct(),
            "required_completion_pct": self.required_completion_pct(),
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "DDChecklist":
        items = [ChecklistItem.from_dict(i) for i in d.get("items", [])]
        return cls(
            deal_id=d.get("deal_id", ""),
            created_at=d.get("created_at", ""),
            updated_at=d.get("updated_at", ""),
            items=items,
            metadata=d.get("metadata", {}),
        )


class DiligenceCoordinatorAgent:
    """
    Diligence Coordinator Agent - manages DD process.
    """

    def __init__(self, llm_router=None):
        self.registry = DealRegistry(REGISTRY_PATH)
        self.event_store = DealEventStore()
        self.action_queue = DeferredActionQueue()
        self.case_manager = DealCaseManagerAgent(llm_router)
        self.llm_router = llm_router
        self._ensure_dirs()

    def _ensure_dirs(self) -> None:
        """Ensure required directories exist"""
        CHECKLISTS_DIR.mkdir(parents=True, exist_ok=True)

    def _checklist_path(self, deal_id: str) -> Path:
        """Get checklist file path"""
        return CHECKLISTS_DIR / f"{deal_id}_dd_checklist.json"

    def _load_checklist(self, deal_id: str) -> Optional[DDChecklist]:
        """Load checklist for a deal"""
        path = self._checklist_path(deal_id)
        if path.exists():
            try:
                with open(path, "r") as f:
                    return DDChecklist.from_dict(json.load(f))
            except (json.JSONDecodeError, IOError):
                pass
        return None

    def _save_checklist(self, checklist: DDChecklist) -> None:
        """Save checklist"""
        checklist.updated_at = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        path = self._checklist_path(checklist.deal_id)
        with open(path, "w") as f:
            json.dump(checklist.to_dict(), f, indent=2)

    def _log_run(self, deal_id: str, task: str, result: AgentResult) -> None:
        """Log agent run to ledger"""
        entry = {
            "timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "agent": "diligence_coordinator",
            "deal_id": deal_id,
            "task": task,
            "success": result.success,
            "summary": result.summary[:200],
            "confidence": result.confidence,
        }
        with open(RUN_LEDGER_PATH, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry) + "\n")

    def initialize(self, deal_id: str) -> AgentResult:
        """
        Initialize DD checklist for a deal.

        Creates checklist from template and schedules progress checks.
        """
        context = self.case_manager.load_context(deal_id)
        if not context:
            return AgentResult(
                success=False,
                summary=f"Deal not found: {deal_id}",
                errors=[f"Deal {deal_id} not found in registry"],
            )

        # Check if checklist already exists
        existing = self._load_checklist(deal_id)
        if existing:
            return AgentResult(
                success=True,
                summary=f"Checklist already exists with {len(existing.items)} items ({existing.completion_pct()}% complete)",
                confidence=1.0,
            )

        # Create from template
        now = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        items = []
        for category, category_items in DD_CHECKLIST_TEMPLATE.items():
            for item_def in category_items:
                items.append(ChecklistItem(
                    category=category,
                    item=item_def["item"],
                    required=item_def.get("required", False),
                ))

        checklist = DDChecklist(
            deal_id=deal_id,
            created_at=now,
            updated_at=now,
            items=items,
            metadata={
                "template": "standard",
                "initialized_by": "diligence_coordinator",
            },
        )
        self._save_checklist(checklist)

        # Update case file
        case_file = context.case_file or {"deal_id": deal_id}
        case_file["dd_checklist"] = {
            "items": len(items),
            "completion_pct": 0,
            "initialized_at": now,
        }
        self.case_manager._save_case_file(deal_id, case_file)

        # Emit event
        self.event_store.create_event(
            deal_id=deal_id,
            event_type="ai_recommendation",
            actor="diligence_coordinator",
            data={
                "agent": "diligence_coordinator",
                "recommendation_type": "action_needed",
                "summary": f"DD checklist initialized with {len(items)} items. Begin requesting documents.",
            },
        )

        # Schedule weekly progress check
        self.action_queue.schedule_relative(
            deal_id=deal_id,
            action_type="dd_progress_check",
            days_from_now=7,
            recurrence="weekly",
            data={"alert_threshold_pct": 80},
            metadata={"scheduled_by": "diligence_coordinator"},
        )

        result = AgentResult(
            success=True,
            summary=f"Initialized DD checklist with {len(items)} items. Weekly progress checks scheduled.",
            scheduled_actions=[{"type": "dd_progress_check", "frequency": "weekly"}],
            confidence=1.0,
        )
        self._log_run(deal_id, "initialize", result)
        return result

    def progress(self, deal_id: str) -> AgentResult:
        """
        Generate DD progress report.
        """
        checklist = self._load_checklist(deal_id)
        if not checklist:
            return AgentResult(
                success=False,
                summary=f"No DD checklist found for {deal_id}. Run 'initialize' first.",
                errors=["Checklist not found"],
            )

        missing = checklist.missing_items(required_only=True)
        flagged = checklist.flagged_items()
        completion = checklist.completion_pct()
        required_completion = checklist.required_completion_pct()

        # Update case file
        context = self.case_manager.load_context(deal_id)
        if context:
            case_file = context.case_file or {"deal_id": deal_id}
            case_file["dd_checklist"] = {
                "items": len(checklist.items),
                "completion_pct": completion,
                "required_completion_pct": required_completion,
                "missing_required": len(missing),
                "flagged": len(flagged),
            }
            self.case_manager._save_case_file(deal_id, case_file)

        # Generate summary
        summary_parts = [
            f"DD Progress: {completion}% complete ({required_completion}% of required)",
        ]
        if missing:
            summary_parts.append(f"{len(missing)} required items outstanding")
        if flagged:
            summary_parts.append(f"{len(flagged)} items flagged for review")

        # Category breakdown
        categories = {}
        for item in checklist.items:
            if item.category not in categories:
                categories[item.category] = {"total": 0, "complete": 0}
            categories[item.category]["total"] += 1
            if item.status in ("received", "reviewed"):
                categories[item.category]["complete"] += 1

        result = AgentResult(
            success=True,
            summary=". ".join(summary_parts),
            case_file_update={"dd_checklist": case_file.get("dd_checklist") if context else None},
            confidence=1.0,
        )
        self._log_run(deal_id, "progress", result)
        return result

    def missing_docs(self, deal_id: str, required_only: bool = True) -> AgentResult:
        """
        List missing documents.
        """
        checklist = self._load_checklist(deal_id)
        if not checklist:
            return AgentResult(
                success=False,
                summary=f"No DD checklist found for {deal_id}",
                errors=["Checklist not found"],
            )

        missing = checklist.missing_items(required_only=required_only)

        # Group by category
        by_category: Dict[str, List[str]] = {}
        for item in missing:
            if item.category not in by_category:
                by_category[item.category] = []
            by_category[item.category].append(item.item)

        result = AgentResult(
            success=True,
            summary=f"{len(missing)} {'required ' if required_only else ''}documents outstanding across {len(by_category)} categories",
            scheduled_actions=[
                {"type": "request_document", "category": cat, "items": items}
                for cat, items in by_category.items()
            ],
            confidence=1.0,
        )
        self._log_run(deal_id, "missing_docs", result)
        return result

    def update_item(
        self,
        deal_id: str,
        item_pattern: str,
        status: str,
        document_path: str = None,
        notes: str = "",
    ) -> AgentResult:
        """
        Update a checklist item status.
        """
        checklist = self._load_checklist(deal_id)
        if not checklist:
            return AgentResult(
                success=False,
                summary=f"No DD checklist found for {deal_id}",
                errors=["Checklist not found"],
            )

        # Find matching item
        pattern_lower = item_pattern.lower()
        matched = None
        for item in checklist.items:
            if pattern_lower in item.item.lower():
                matched = item
                break

        if not matched:
            return AgentResult(
                success=False,
                summary=f"No item matching '{item_pattern}' found",
                errors=["Item not found"],
            )

        # Update item
        old_status = matched.status
        matched.status = status
        matched.updated_at = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        if document_path:
            matched.document_path = document_path
        if notes:
            matched.notes = notes

        self._save_checklist(checklist)

        # Emit event if status changed significantly
        if old_status != status:
            self.event_store.create_event(
                deal_id=deal_id,
                event_type="ai_recommendation" if status == "flagged" else "note_added",
                actor="diligence_coordinator",
                data={
                    "category": matched.category,
                    "item": matched.item,
                    "old_status": old_status,
                    "new_status": status,
                    "notes": notes,
                },
            )

        result = AgentResult(
            success=True,
            summary=f"Updated '{matched.item}': {old_status} → {status}",
            events=[{"type": "checklist_item_updated", "item": matched.item, "status": status}],
            confidence=1.0,
        )
        self._log_run(deal_id, "update_item", result)
        return result


def main():
    parser = argparse.ArgumentParser(description="Diligence Coordinator Agent CLI")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # initialize
    init_p = subparsers.add_parser("initialize", help="Initialize DD checklist")
    init_p.add_argument("deal_id", help="Deal ID")
    init_p.add_argument("--json", action="store_true", help="Output as JSON")

    # progress
    prog_p = subparsers.add_parser("progress", help="DD progress report")
    prog_p.add_argument("deal_id", help="Deal ID")
    prog_p.add_argument("--json", action="store_true", help="Output as JSON")

    # missing-docs
    miss_p = subparsers.add_parser("missing-docs", help="List missing documents")
    miss_p.add_argument("deal_id", help="Deal ID")
    miss_p.add_argument("--all", action="store_true", help="Include non-required items")
    miss_p.add_argument("--json", action="store_true", help="Output as JSON")

    # update-item
    upd_p = subparsers.add_parser("update-item", help="Update checklist item")
    upd_p.add_argument("deal_id", help="Deal ID")
    upd_p.add_argument("--item", required=True, help="Item name pattern")
    upd_p.add_argument("--status", required=True, choices=["not_started", "in_progress", "received", "reviewed", "flagged"])
    upd_p.add_argument("--path", help="Document path")
    upd_p.add_argument("--notes", help="Notes")

    args = parser.parse_args()

    agent = DiligenceCoordinatorAgent()

    if args.command == "initialize":
        result = agent.initialize(args.deal_id)
    elif args.command == "progress":
        result = agent.progress(args.deal_id)
    elif args.command == "missing-docs":
        result = agent.missing_docs(args.deal_id, required_only=not args.all)
    elif args.command == "update-item":
        result = agent.update_item(
            args.deal_id,
            args.item,
            args.status,
            document_path=args.path,
            notes=args.notes or "",
        )
    else:
        parser.print_help()
        return

    if hasattr(args, 'json') and args.json:
        print(json.dumps(result.to_dict(), indent=2))
    else:
        print(f"\n{'=' * 60}")
        print(f"Diligence Coordinator: {args.command}")
        print(f"{'=' * 60}")
        print(f"Success: {result.success}")
        print(f"Summary: {result.summary}")

        if result.scheduled_actions:
            print(f"\nActions ({len(result.scheduled_actions)}):")
            for action in result.scheduled_actions[:10]:
                if "items" in action:
                    print(f"  {action['category']}: {len(action['items'])} items")
                else:
                    print(f"  {action.get('type', 'action')}")

        if result.errors:
            print(f"\nErrors: {', '.join(result.errors)}")


if __name__ == "__main__":
    main()
