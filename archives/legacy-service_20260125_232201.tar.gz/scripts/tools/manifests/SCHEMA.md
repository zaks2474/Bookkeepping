# Tool Manifest Schema (ZakOps v1.2)

Each tool is described by a YAML manifest in `scripts/tools/manifests/`.

Minimum required fields:
- `tool_id`
- `version`
- `title`
- `description`
- `provider` (`mcp` or `http`)
- Provider-specific config:
  - MCP: `mcp_server`, `mcp_tool_name`, `mcp_stdio_command` (for stdio mode)
  - HTTP: `http_endpoint`, optional `http_method`, `http_headers`

Safety:
- Tools are invoked ONLY via `tools.gateway.ToolGateway`.
- `ToolGateway` enforces allowlist/denylist, DB-sourced approval, secret-scan gate, audit logging.
- Each tool must declare:
  - `safety_class`: `reversible|gated|irreversible`
  - `irreversible`: boolean (e.g., send email, uploads)
