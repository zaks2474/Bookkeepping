#!/usr/bin/env python3
"""
Minimal MCP-ish JSON-RPC stdio server stub for ToolGateway development/testing.

This implements the subset of MCP used by `tools.gateway.ToolGateway`:
- initialize
- tools/list (best-effort)
- tools/call

I/O contract:
- newline-delimited JSON-RPC messages (one JSON object per line)
- newline-delimited JSON-RPC responses (one JSON object per line)

This file is intentionally dependency-free and safe to run in unit tests.
"""

from __future__ import annotations

import json
import sys
from typing import Any, Dict, List, Optional


def _json_dumps(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False)


def _write_response(payload: Dict[str, Any]) -> None:
    sys.stdout.write(_json_dumps(payload) + "\n")
    sys.stdout.flush()


def _handle_initialize(req_id: Any, params: Dict[str, Any]) -> None:
    protocol_version = str(params.get("protocolVersion") or "2024-11-05")
    result = {
        "protocolVersion": protocol_version,
        "capabilities": {"tools": {"listChanged": False}},
        "serverInfo": {"name": "zakops-mcp-stdio-stub", "version": "1.0.0"},
    }
    _write_response({"jsonrpc": "2.0", "id": req_id, "result": result})


def _handle_tools_list(req_id: Any) -> None:
    tools: List[Dict[str, Any]] = [
        {
            "name": "ping",
            "description": "Health check tool",
            "inputSchema": {"type": "object", "additionalProperties": True},
        },
        {
            "name": "echo",
            "description": "Echo back arguments",
            "inputSchema": {"type": "object", "additionalProperties": True},
        },
        {
            "name": "send_email",
            "description": "Test-only send (echoes args)",
            "inputSchema": {"type": "object", "additionalProperties": True},
        },
    ]
    _write_response({"jsonrpc": "2.0", "id": req_id, "result": {"tools": tools}})


def _handle_tools_call(req_id: Any, params: Dict[str, Any]) -> None:
    name = str(params.get("name") or "")
    args = params.get("arguments") if isinstance(params.get("arguments"), dict) else {}
    if name == "ping":
        result: Any = {"ok": True}
    else:
        result = {"tool": name, "echo": args}
    _write_response({"jsonrpc": "2.0", "id": req_id, "result": result})


def _handle_unknown(req_id: Any, method: str) -> None:
    _write_response({"jsonrpc": "2.0", "id": req_id, "error": {"message": f"unsupported_method:{method}"}})


def main() -> int:
    for raw_line in sys.stdin:
        line = raw_line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
        except Exception as e:
            _write_response({"jsonrpc": "2.0", "id": None, "error": {"message": str(e)}})
            continue

        if not isinstance(req, dict):
            _write_response({"jsonrpc": "2.0", "id": None, "error": {"message": "invalid_request"}})
            continue

        req_id: Optional[Any] = req.get("id")
        method = str(req.get("method") or "")
        params: Dict[str, Any] = req.get("params") if isinstance(req.get("params"), dict) else {}

        if method == "initialize":
            _handle_initialize(req_id, params)
            continue
        if method == "tools/list":
            _handle_tools_list(req_id)
            continue
        if method == "tools/call":
            _handle_tools_call(req_id, params)
            continue

        _handle_unknown(req_id, method)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
