from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional


DEFAULT_MANIFEST_PATH = Path(
    os.getenv("ZAKOPS_UNIFIED_MANIFEST_PATH", "/home/zaks/scripts/tools/manifest/manifest.json")
)


def _tokenize(text: str) -> List[str]:
    cleaned = re.sub(r"[^a-z0-9]+", " ", (text or "").lower()).strip()
    if not cleaned:
        return []
    return [t for t in cleaned.split() if len(t) > 1]


def _jaccard(a: List[str], b: List[str]) -> float:
    sa = set(a)
    sb = set(b)
    if not sa or not sb:
        return 0.0
    return len(sa & sb) / max(1, len(sa | sb))


@dataclass(frozen=True)
class ManifestEntry:
    capability_id: str
    kind: str  # kinetic_action|tool_gateway
    tool_name: str
    action_type: str
    title: str
    description: str

    input_schema: Dict[str, Any]
    output_schema: Dict[str, Any]
    output_artifacts: List[Dict[str, Any]]

    risk_level: str
    requires_approval: bool
    safety_class: str  # reversible|gated|irreversible
    irreversible: bool

    examples: List[Dict[str, Any]]
    constraints: List[str]
    tags: List[str]


@dataclass(frozen=True)
class ManifestMatch:
    capability_id: str
    score: float
    reason: str


class UnifiedManifestRegistry:
    def __init__(self, manifest_path: Optional[Path] = None):
        self.manifest_path = manifest_path or DEFAULT_MANIFEST_PATH
        self._by_id: Dict[str, ManifestEntry] = {}

    def load(self) -> None:
        if not self.manifest_path.exists():
            raise FileNotFoundError(f"unified_manifest_not_found:{self.manifest_path}")
        data = json.loads(self.manifest_path.read_text(encoding="utf-8"))
        entries = data.get("capabilities") or []
        if not isinstance(entries, list):
            raise ValueError("invalid_unified_manifest:capabilities_not_list")

        by_id: Dict[str, ManifestEntry] = {}
        for raw in entries:
            if not isinstance(raw, dict):
                continue
            entry = ManifestEntry(
                capability_id=str(raw.get("capability_id") or "").strip(),
                kind=str(raw.get("kind") or "").strip(),
                tool_name=str(raw.get("tool_name") or "").strip(),
                action_type=str(raw.get("action_type") or "").strip(),
                title=str(raw.get("title") or "").strip(),
                description=str(raw.get("description") or "").strip(),
                input_schema=raw.get("input_schema") or {},
                output_schema=raw.get("output_schema") or {},
                output_artifacts=list(raw.get("output_artifacts") or []),
                risk_level=str(raw.get("risk_level") or "medium").strip().lower(),
                requires_approval=bool(raw.get("requires_approval", True)),
                safety_class=str(raw.get("safety_class") or "reversible").strip().lower(),
                irreversible=bool(raw.get("irreversible", False)),
                examples=list(raw.get("examples") or []),
                constraints=list(raw.get("constraints") or []),
                tags=list(raw.get("tags") or []),
            )
            if not entry.capability_id:
                continue
            by_id[entry.capability_id] = entry

        self._by_id = by_id

    def list_entries(self) -> List[ManifestEntry]:
        return [self._by_id[k] for k in sorted(self._by_id.keys())]

    def get_entry(self, capability_id: str) -> Optional[ManifestEntry]:
        return self._by_id.get((capability_id or "").strip())

    def match(self, query: str, *, top_k: int = 8) -> List[ManifestMatch]:
        intent = (query or "").strip()
        if not intent:
            return []

        intent_tokens = _tokenize(intent)
        out: List[ManifestMatch] = []
        for entry in self._by_id.values():
            haystack = " ".join(
                [
                    entry.capability_id,
                    entry.action_type,
                    entry.tool_name,
                    entry.title,
                    entry.description,
                    " ".join(entry.constraints or []),
                ]
            )
            score = _jaccard(intent_tokens, _tokenize(haystack))
            if score <= 0:
                continue
            out.append(ManifestMatch(capability_id=entry.capability_id, score=float(score), reason="jaccard"))
        out.sort(key=lambda m: m.score, reverse=True)
        return out[: max(1, int(top_k))]


_REGISTRY: Optional[UnifiedManifestRegistry] = None


def get_unified_manifest_registry() -> UnifiedManifestRegistry:
    global _REGISTRY
    if _REGISTRY is None:
        reg = UnifiedManifestRegistry()
        reg.load()
        _REGISTRY = reg
    return _REGISTRY

