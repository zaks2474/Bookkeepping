from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from actions.capabilities.registry import get_registry
from tools.registry import ToolManifest, get_tool_registry


def _risk_rank(risk: str) -> int:
    r = (risk or "").lower().strip()
    return {"low": 0, "medium": 1, "high": 2}.get(r, 1)


def _derive_safety_class(*, risk_level: str, irreversible: bool) -> str:
    if irreversible:
        return "irreversible"
    if _risk_rank(risk_level) >= _risk_rank("high"):
        return "gated"
    return "reversible"


def _tool_capability_id(tool: ToolManifest) -> str:
    version = str(getattr(tool, "version", "") or "").strip() or "1.0.0"
    major = version.split(".")[0] or "1"
    return f"TOOL.{tool.tool_id}.v{major}"


def _tool_action_type(tool: ToolManifest) -> str:
    return f"TOOL.{tool.tool_id}"


def build_unified_manifest(*, out_path: Path, include_tools: bool = True, include_internal: bool = True) -> Dict[str, Any]:
    capabilities: List[Dict[str, Any]] = []

    if include_internal:
        cap_reg = get_registry()
        for cap in cap_reg.list_capabilities():
            cap_dict = cap_reg.to_jsonable(cap)
            risk = str(cap_dict.get("risk_level") or "medium").strip().lower()
            irreversible = bool(cap_dict.get("irreversible", False))
            safety_class = str(cap_dict.get("safety_class") or "").strip().lower() or _derive_safety_class(
                risk_level=risk,
                irreversible=irreversible,
            )
            capabilities.append(
                {
                    "capability_id": cap_dict.get("capability_id"),
                    "kind": "kinetic_action",
                    "tool_name": cap_dict.get("action_type"),
                    "action_type": cap_dict.get("action_type"),
                    "title": cap_dict.get("title"),
                    "description": cap_dict.get("description"),
                    "input_schema": cap_dict.get("input_schema") or {},
                    "output_schema": {},
                    "output_artifacts": cap_dict.get("output_artifacts") or [],
                    "risk_level": risk,
                    "requires_approval": bool(cap_dict.get("requires_approval", True)),
                    "safety_class": safety_class,
                    "irreversible": irreversible,
                    "examples": cap_dict.get("examples") or [],
                    "constraints": cap_dict.get("constraints") or [],
                    "tags": cap_dict.get("tags") or [],
                }
            )

    if include_tools:
        tool_reg = get_tool_registry()
        for tool in tool_reg.list_tools():
            risk = str(getattr(tool, "risk_level", "medium") or "medium").strip().lower()
            irreversible = bool(getattr(tool, "irreversible", False))
            safety_class = str(getattr(tool, "safety_class", "") or "").strip().lower() or _derive_safety_class(
                risk_level=risk,
                irreversible=irreversible,
            )
            capabilities.append(
                {
                    "capability_id": _tool_capability_id(tool),
                    "kind": "tool_gateway",
                    "tool_name": tool.tool_id,
                    "action_type": _tool_action_type(tool),
                    "title": tool.title,
                    "description": tool.description,
                    "input_schema": tool.input_schema or {},
                    "output_schema": tool.output_schema or {},
                    "output_artifacts": [],
                    "risk_level": risk,
                    "requires_approval": bool(getattr(tool, "requires_approval", True)),
                    "safety_class": safety_class,
                    "irreversible": irreversible,
                    "examples": tool.examples or [],
                    "constraints": tool.constraints or [],
                    "tags": tool.tags or [],
                }
            )

    payload = {
        "manifest_version": "1.0",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "capabilities": sorted(capabilities, key=lambda c: str(c.get("capability_id") or "")),
    }

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    return payload


def default_manifest_path() -> Path:
    return Path("/home/zaks/scripts/tools/manifest/manifest.json")


if __name__ == "__main__":
    build_unified_manifest(out_path=default_manifest_path())
    print(default_manifest_path())

