"""Unified capability/tool manifest (planner source of truth)."""

