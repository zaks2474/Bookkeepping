from __future__ import annotations

import asyncio
import hashlib
import ipaddress
import json
import logging
import os
import random
import re
import shlex
import socket
import sqlite3
import time
import subprocess
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional
from urllib.parse import urlparse

import httpx

from actions.engine.store import ActionStore
from tools.registry import ToolManifest, get_tool_registry

logger = logging.getLogger(__name__)


class ToolErrorCode(str):
    SUCCESS = "SUCCESS"

    # Permission / policy (permanent)
    TOOL_NOT_ALLOWED = "TOOL_NOT_ALLOWED"
    TOOL_DENIED = "TOOL_DENIED"
    SECRET_DETECTED = "SECRET_DETECTED"
    ACTION_NOT_APPROVED = "ACTION_NOT_APPROVED"
    UNAUTHORIZED = "UNAUTHORIZED"

    # Transient (retry)
    TIMEOUT = "TIMEOUT"
    RATE_LIMITED = "RATE_LIMITED"
    CONNECTION_ERROR = "CONNECTION_ERROR"
    SERVICE_UNAVAILABLE = "SERVICE_UNAVAILABLE"
    MCP_SPAWN_FAILED = "MCP_SPAWN_FAILED"

    # Permanent (do not retry)
    INVALID_INPUT = "INVALID_INPUT"
    TOOL_NOT_FOUND = "TOOL_NOT_FOUND"
    MALFORMED_RESPONSE = "MALFORMED_RESPONSE"
    HEALTH_CHECK_FAILED = "HEALTH_CHECK_FAILED"
    SSRF_BLOCKED = "SSRF_BLOCKED"

    # Internal
    GATEWAY_DISABLED = "GATEWAY_DISABLED"
    GATEWAY_ERROR = "GATEWAY_ERROR"


RETRYABLE_ERRORS = {
    ToolErrorCode.TIMEOUT,
    ToolErrorCode.RATE_LIMITED,
    ToolErrorCode.CONNECTION_ERROR,
    ToolErrorCode.SERVICE_UNAVAILABLE,
    ToolErrorCode.MCP_SPAWN_FAILED,
    ToolErrorCode.GATEWAY_ERROR,
}


@dataclass(frozen=True)
class ToolResult:
    success: bool
    error_code: str
    error_message: Optional[str] = None
    output: Optional[Dict[str, Any]] = None
    duration_ms: int = 0
    retry_after_seconds: Optional[int] = None

    def should_retry(self) -> bool:
        return self.error_code in RETRYABLE_ERRORS


@dataclass(frozen=True)
class ToolInvocationContext:
    action_id: str
    action_status: str = ""  # informational only; DB is source of truth
    deal_id: Optional[str] = None
    user_id: Optional[str] = None
    session_id: Optional[str] = None
    approved: bool = False  # informational only; DB is source of truth
    bypass_db_approval: bool = False  # internal usage only (health checks)


class SecretScanner:
    """Hardened secret scanner - blocks calls, not just redacts."""

    # Value patterns that indicate secrets
    SECRET_PATTERNS = [
        (r"\blsv2_pt_[A-Za-z0-9]{16,}_[A-Za-z0-9]{8,}\b", "langsmith_api_key"),
        (r"\bsk-(?:proj-)?[A-Za-z0-9_-]{20,}\b", "openai_key"),
        (r"\bghp_[A-Za-z0-9]{30,}\b", "github_token"),
        (r"\bxox[baprs]-[A-Za-z0-9-]{20,}\b", "slack_token"),
        (r"\b(?:AKIA|ASIA)[0-9A-Z]{16}\b", "aws_access_key_id"),
        (r"\bAIza[0-9A-Za-z_-]{20,}\b", "google_api_key"),
        (r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----", "private_key_block"),
        (r"\bBearer\s+[A-Za-z0-9._~+/-]{20,}={0,2}\b", "bearer_token"),
    ]

    UUID_PATTERN = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.I)
    ACTION_ID_PATTERN = re.compile(r"^(ACT|INV|DEAL)[-_][A-Za-z0-9]{6,}$", re.I)

    BLOCKED_KEY_PATTERNS = [
        r"password",
        r"passwd",
        r"secret",
        r"token",
        r"api_key",
        r"apikey",
        r"authorization",
        r"bearer",
        r"credential",
        r"private_key",
        r"client_secret",
        r"refresh_token",
    ]

    _patterns = [(re.compile(p, re.IGNORECASE), name) for p, name in SECRET_PATTERNS]
    _blocked_key_patterns = [re.compile(p, re.IGNORECASE) for p in BLOCKED_KEY_PATTERNS]

    @classmethod
    def scan(cls, data: Dict[str, Any], path: str = "") -> List[str]:
        detections: List[str] = []
        if not isinstance(data, dict):
            return detections

        for key, value in data.items():
            current_path = f"{path}.{key}" if path else str(key)

            if any(p.search(str(key)) for p in cls._blocked_key_patterns):
                if isinstance(value, str) and value:
                    detections.append(f"{current_path} (blocked-key:{key})")
                continue

            if isinstance(value, dict):
                detections.extend(cls.scan(value, current_path))
                continue

            if isinstance(value, list):
                for i, item in enumerate(value):
                    if isinstance(item, dict):
                        detections.extend(cls.scan(item, f"{current_path}[{i}]"))
                    elif isinstance(item, str):
                        if cls.UUID_PATTERN.match(item) or cls.ACTION_ID_PATTERN.match(item):
                            continue
                        for pattern, name in cls._patterns:
                            if pattern.search(item):
                                detections.append(f"{current_path}[{i}] ({name})")
                                break
                continue

            if isinstance(value, str):
                if cls.UUID_PATTERN.match(value) or cls.ACTION_ID_PATTERN.match(value):
                    continue
                for pattern, name in cls._patterns:
                    if pattern.search(value):
                        detections.append(f"{current_path} ({name})")
                        break

        return detections

    @classmethod
    def redact_error_message(cls, error_msg: str) -> str:
        if not error_msg:
            return error_msg
        redacted = error_msg
        for pattern, name in cls._patterns:
            redacted = pattern.sub(f"[REDACTED:{name}]", redacted)
        return redacted


class SecretRedactor:
    SECRET_KEYS = {
        "password",
        "passwd",
        "secret",
        "token",
        "api_key",
        "apikey",
        "authorization",
        "bearer",
        "credential",
        "private_key",
        "client_secret",
    }
    REDACTED = "[REDACTED]"
    MAX_FIELD_SIZE = 10_000

    @classmethod
    def redact(cls, data: Any) -> Any:
        if isinstance(data, dict):
            out: Dict[str, Any] = {}
            for key, value in data.items():
                k = str(key)
                if any(sk in k.lower() for sk in cls.SECRET_KEYS):
                    out[k] = cls.REDACTED
                else:
                    out[k] = cls.redact(value)
            return out
        if isinstance(data, list):
            return [cls.redact(v) for v in data]
        if isinstance(data, str) and len(data) > cls.MAX_FIELD_SIZE:
            hash_ref = hashlib.sha256(data.encode("utf-8")).hexdigest()[:12]
            return f"[TRUNCATED:{len(data)}bytes:sha256:{hash_ref}]"
        return data


class SSRFProtection:
    BLOCKED_RANGES = [
        ipaddress.ip_network("127.0.0.0/8"),
        ipaddress.ip_network("10.0.0.0/8"),
        ipaddress.ip_network("172.16.0.0/12"),
        ipaddress.ip_network("192.168.0.0/16"),
        ipaddress.ip_network("169.254.0.0/16"),
        ipaddress.ip_network("::1/128"),
        ipaddress.ip_network("fc00::/7"),
        ipaddress.ip_network("fe80::/10"),
    ]

    @classmethod
    def check_url(cls, url: str) -> tuple[bool, str]:
        parsed = urlparse(url)
        hostname = parsed.hostname
        if not hostname:
            return False, "No hostname"

        try:
            ip_str = socket.gethostbyname(hostname)
            ip = ipaddress.ip_address(ip_str)
        except Exception as e:
            return False, f"Cannot resolve hostname: {e}"

        for blocked in cls.BLOCKED_RANGES:
            if ip in blocked:
                return False, f"IP {ip} in blocked range {blocked}"
        return True, "OK"


class ToolAuditLogger:
    def __init__(self, db_path: str):
        self.db_path = db_path
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self._ensure_tables()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("PRAGMA synchronous=NORMAL;")
        conn.execute("PRAGMA busy_timeout=5000;")
        return conn

    def _ensure_tables(self) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS tool_invocation_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    invocation_id TEXT UNIQUE NOT NULL,
                    tool_name TEXT NOT NULL,
                    provider TEXT NOT NULL,
                    runtime_mode TEXT,

                    action_id TEXT NOT NULL,
                    deal_id TEXT,
                    user_id TEXT,
                    session_id TEXT,

                    input_args_redacted TEXT,
                    input_size_bytes INTEGER,

                    success INTEGER NOT NULL,
                    error_code TEXT NOT NULL,
                    error_message TEXT,
                    output_redacted TEXT,
                    output_size_bytes INTEGER,

                    run_started_at TEXT NOT NULL,
                    run_completed_at TEXT,

                    attempt_number INTEGER NOT NULL,
                    attempt_started_at TEXT NOT NULL,
                    attempt_completed_at TEXT NOT NULL,
                    attempt_duration_ms INTEGER NOT NULL,
                    retry_after_seconds INTEGER,

                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
                """
            )
            conn.execute("CREATE INDEX IF NOT EXISTS idx_tool_log_action ON tool_invocation_log(action_id)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_tool_log_deal ON tool_invocation_log(deal_id)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_tool_log_tool ON tool_invocation_log(tool_name)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_tool_log_attempt ON tool_invocation_log(attempt_started_at)")
            conn.commit()

    def log_attempt(
        self,
        *,
        invocation_id: str,
        tool_name: str,
        provider: str,
        runtime_mode: str,
        context: ToolInvocationContext,
        input_args: Dict[str, Any],
        result: ToolResult,
        run_started_at: str,
        run_completed_at: Optional[str],
        attempt_number: int,
        attempt_started_at: str,
        attempt_completed_at: str,
        attempt_duration_ms: int,
    ) -> None:
        input_redacted_obj = SecretRedactor.redact(input_args)
        output_redacted_obj = SecretRedactor.redact(result.output or {})

        input_redacted = json.dumps(input_redacted_obj, ensure_ascii=False)
        output_redacted = json.dumps(output_redacted_obj, ensure_ascii=False)

        # Correct byte sizes (UTF-8)
        input_size = len(json.dumps(input_args, ensure_ascii=False).encode("utf-8"))
        output_size = len(json.dumps(result.output or {}, ensure_ascii=False).encode("utf-8"))

        err_msg = SecretScanner.redact_error_message(result.error_message or "") if result.error_message else None

        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO tool_invocation_log (
                    invocation_id, tool_name, provider, runtime_mode,
                    action_id, deal_id, user_id, session_id,
                    input_args_redacted, input_size_bytes,
                    success, error_code, error_message,
                    output_redacted, output_size_bytes,
                    run_started_at, run_completed_at,
                    attempt_number, attempt_started_at, attempt_completed_at, attempt_duration_ms,
                    retry_after_seconds
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    invocation_id,
                    tool_name,
                    provider,
                    runtime_mode,
                    context.action_id,
                    context.deal_id,
                    context.user_id,
                    context.session_id,
                    input_redacted,
                    int(input_size),
                    1 if result.success else 0,
                    result.error_code,
                    err_msg,
                    output_redacted,
                    int(output_size),
                    run_started_at,
                    run_completed_at,
                    int(attempt_number),
                    attempt_started_at,
                    attempt_completed_at,
                    int(attempt_duration_ms),
                    result.retry_after_seconds,
                ),
            )
            conn.commit()


@dataclass(frozen=True)
class ToolGatewayConfig:
    enabled: bool = False
    require_allowlist: bool = True
    allowed_tools: List[str] = field(default_factory=list)  # required when enabled
    denied_tools: List[str] = field(default_factory=list)

    default_timeout_ms: int = 30_000
    tool_timeouts: Dict[str, int] = field(default_factory=dict)

    max_retries: int = 3
    retry_base_delay_ms: int = 1000
    retry_max_delay_ms: int = 30_000

    mcp_runtime_mode: str = "stdio"  # stdio|docker

    audit_db_path: str = os.getenv("ZAKOPS_STATE_DB", "/home/zaks/DataRoom/.deal-registry/ingest_state.db")

    @classmethod
    def from_env(cls) -> "ToolGatewayConfig":
        enabled = os.getenv("ZAKOPS_TOOL_GATEWAY_ENABLED", "false").lower() == "true"
        require_allowlist = os.getenv("ZAKOPS_TOOL_REQUIRE_ALLOWLIST", "true").lower() == "true"
        allow = [t.strip() for t in os.getenv("ZAKOPS_TOOL_ALLOWLIST", "").split(",") if t.strip()]
        deny = [t.strip() for t in os.getenv("ZAKOPS_TOOL_DENYLIST", "").split(",") if t.strip()]
        return cls(
            enabled=enabled,
            require_allowlist=require_allowlist,
            allowed_tools=allow,
            denied_tools=deny,
            mcp_runtime_mode=os.getenv("ZAKOPS_MCP_RUNTIME_MODE", "stdio"),
            audit_db_path=os.getenv("ZAKOPS_STATE_DB", cls.audit_db_path),
        )


class ToolGateway:
    MAX_STDOUT_BYTES = 10 * 1024 * 1024
    MAX_STDERR_BYTES = 1 * 1024 * 1024

    def __init__(self, *, config: Optional[ToolGatewayConfig] = None, tool_registry=None, action_store=None):
        self.config = config or ToolGatewayConfig.from_env()
        self.tool_registry = tool_registry or get_tool_registry()
        self.action_store = action_store or ActionStore()
        self.audit_logger = ToolAuditLogger(self.config.audit_db_path)
        self._docker_last_used: Dict[str, tuple[float, int]] = {}

    def _check_permissions(self, tool_name: str) -> ToolResult:
        if tool_name in self.config.denied_tools:
            return ToolResult(success=False, error_code=ToolErrorCode.TOOL_DENIED, error_message=f"Tool denied: {tool_name}")

        if self.config.enabled:
            if self.config.require_allowlist and not self.config.allowed_tools:
                return ToolResult(
                    success=False,
                    error_code=ToolErrorCode.TOOL_NOT_ALLOWED,
                    error_message="Tool gateway requires explicit allowlist (ZAKOPS_TOOL_ALLOWLIST)",
                )
            if self.config.allowed_tools and tool_name not in self.config.allowed_tools:
                return ToolResult(
                    success=False,
                    error_code=ToolErrorCode.TOOL_NOT_ALLOWED,
                    error_message=f"Tool not allowlisted: {tool_name}",
                )

        return ToolResult(success=True, error_code=ToolErrorCode.SUCCESS)

    def _check_approval_from_db(self, context: ToolInvocationContext) -> ToolResult:
        if context.bypass_db_approval:
            return ToolResult(success=True, error_code=ToolErrorCode.SUCCESS)

        action = self.action_store.get_action(context.action_id)
        if not action:
            return ToolResult(
                success=False,
                error_code=ToolErrorCode.ACTION_NOT_APPROVED,
                error_message="Action not found in DB for tool invocation",
            )

        if action.status not in {"READY", "PROCESSING"}:
            return ToolResult(
                success=False,
                error_code=ToolErrorCode.ACTION_NOT_APPROVED,
                error_message=f"Action status '{action.status}' not allowed for tool invocation",
            )

        return ToolResult(success=True, error_code=ToolErrorCode.SUCCESS)

    async def invoke(
        self,
        *,
        tool_name: str,
        args: Dict[str, Any],
        context: ToolInvocationContext,
        timeout_ms: Optional[int] = None,
    ) -> ToolResult:
        run_started_at = datetime.now(timezone.utc).isoformat()

        if not self.config.enabled:
            return ToolResult(success=False, error_code=ToolErrorCode.GATEWAY_DISABLED, error_message="Tool gateway disabled")

        # Gate: allowlist/denylist
        perm = self._check_permissions(tool_name)
        if not perm.success:
            return perm

        # Gate: approval from DB
        appr = self._check_approval_from_db(context)
        if not appr.success:
            return appr

        # Gate: secret scan
        detections = SecretScanner.scan(args or {})
        if detections:
            return ToolResult(
                success=False,
                error_code=ToolErrorCode.SECRET_DETECTED,
                error_message=f"Secrets detected in tool args: {', '.join(detections[:3])}{'...' if len(detections) > 3 else ''}",
            )

        tool = self.tool_registry.get_tool(tool_name)
        if not tool:
            return ToolResult(success=False, error_code=ToolErrorCode.TOOL_NOT_FOUND, error_message=f"Tool not found: {tool_name}")

        timeout = timeout_ms or self.config.tool_timeouts.get(tool_name, self.config.default_timeout_ms)
        return await self._execute_with_retry(tool=tool, tool_name=tool_name, args=args, context=context, timeout_ms=int(timeout), run_started_at=run_started_at)

    async def _execute_with_retry(
        self,
        *,
        tool: ToolManifest,
        tool_name: str,
        args: Dict[str, Any],
        context: ToolInvocationContext,
        timeout_ms: int,
        run_started_at: str,
    ) -> ToolResult:
        attempt = 0
        last: Optional[ToolResult] = None

        while attempt < max(1, int(self.config.max_retries)):
            attempt += 1
            attempt_started_at = datetime.now(timezone.utc).isoformat()
            started = time.monotonic()

            try:
                output = await self._execute_single(tool=tool, tool_name=tool_name, args=args, timeout_ms=timeout_ms)
                duration_ms = int((time.monotonic() - started) * 1000)
                result = ToolResult(success=True, error_code=ToolErrorCode.SUCCESS, output=output, duration_ms=duration_ms)
            except asyncio.TimeoutError:
                duration_ms = int((time.monotonic() - started) * 1000)
                result = ToolResult(
                    success=False,
                    error_code=ToolErrorCode.TIMEOUT,
                    error_message=f"Tool timed out after {timeout_ms}ms",
                    duration_ms=duration_ms,
                )
            except Exception as e:
                duration_ms = int((time.monotonic() - started) * 1000)
                msg = str(e)
                result = ToolResult(
                    success=False,
                    error_code=ToolErrorCode.GATEWAY_ERROR,
                    error_message=msg,
                    duration_ms=duration_ms,
                )

            attempt_completed_at = datetime.now(timezone.utc).isoformat()
            run_completed_at = attempt_completed_at if (result.success or not result.should_retry()) else None

            invocation_id = f"{tool_name}:{context.action_id}:{run_started_at}:a{attempt}"
            self.audit_logger.log_attempt(
                invocation_id=invocation_id,
                tool_name=tool_name,
                provider=tool.provider,
                runtime_mode=self.config.mcp_runtime_mode,
                context=context,
                input_args=args or {},
                result=result,
                run_started_at=run_started_at,
                run_completed_at=run_completed_at,
                attempt_number=attempt,
                attempt_started_at=attempt_started_at,
                attempt_completed_at=attempt_completed_at,
                attempt_duration_ms=int(result.duration_ms),
            )

            if result.success or not result.should_retry():
                return result

            last = result
            delay_ms = self._calculate_backoff_ms(attempt=attempt, result=result)
            await asyncio.sleep(delay_ms / 1000.0)

        return last or ToolResult(success=False, error_code=ToolErrorCode.GATEWAY_ERROR, error_message="Max retries exceeded")

    def _calculate_backoff_ms(self, *, attempt: int, result: ToolResult) -> int:
        base = int(self.config.retry_base_delay_ms) * (2 ** max(0, attempt - 1))
        jitter = random.uniform(0.75, 1.25)
        return min(int(base * jitter), int(self.config.retry_max_delay_ms))

    async def _execute_single(self, *, tool: ToolManifest, tool_name: str, args: Dict[str, Any], timeout_ms: int) -> Dict[str, Any]:
        if tool.provider == "http":
            return await self._invoke_http(tool=tool, args=args, timeout_ms=timeout_ms)

        # provider == mcp
        if self.config.mcp_runtime_mode == "stdio":
            return await asyncio.wait_for(self._invoke_mcp_stdio(tool=tool, tool_name=tool_name, args=args), timeout=timeout_ms / 1000.0)
        if self.config.mcp_runtime_mode == "docker":
            return await asyncio.wait_for(self._invoke_mcp_docker(tool=tool, tool_name=tool_name, args=args), timeout=timeout_ms / 1000.0)

        raise RuntimeError(f"unknown_mcp_runtime_mode:{self.config.mcp_runtime_mode}")

    async def _invoke_http(self, *, tool: ToolManifest, args: Dict[str, Any], timeout_ms: int) -> Dict[str, Any]:
        endpoint = getattr(tool, "http_endpoint", None)
        if not endpoint:
            raise RuntimeError("http_endpoint_missing")

        is_safe, reason = SSRFProtection.check_url(endpoint)
        if not is_safe:
            raise RuntimeError(f"{ToolErrorCode.SSRF_BLOCKED}: {reason}")

        method = getattr(tool, "http_method", "POST") or "POST"
        headers = getattr(tool, "http_headers", None) or {}
        async with httpx.AsyncClient(timeout=timeout_ms / 1000.0) as client:
            resp = await client.request(method.upper(), endpoint, json=args, headers=headers)
            resp.raise_for_status()
            data = resp.json()
            if isinstance(data, dict):
                return data
            return {"result": data}

    async def _invoke_mcp_stdio(self, *, tool: ToolManifest, tool_name: str, args: Dict[str, Any]) -> Dict[str, Any]:
        if not tool.mcp_stdio_command:
            raise RuntimeError("mcp_stdio_command_missing")

        env = self._resolve_secrets(tool.secrets_refs or {})
        # Keep Gmail MCP env wiring consistent with upstream server naming.
        if (tool.mcp_server or "").strip().lower() == "gmail":
            if env.get("GMAIL_MCP_CREDENTIALS_PATH") and not env.get("GMAIL_CREDENTIALS_PATH"):
                env["GMAIL_CREDENTIALS_PATH"] = str(env["GMAIL_MCP_CREDENTIALS_PATH"])
            if env.get("GMAIL_CREDENTIALS_PATH") and not env.get("GMAIL_MCP_CREDENTIALS_PATH"):
                env["GMAIL_MCP_CREDENTIALS_PATH"] = str(env["GMAIL_CREDENTIALS_PATH"])
        cmd = self._resolve_mcp_stdio_command(tool=tool)

        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env={**os.environ, **env},
        )
        assert proc.stdin and proc.stdout and proc.stderr

        stdout_buf = bytearray()

        async def _request(*, request_id: int, method: str, params: Dict[str, Any]) -> Dict[str, Any]:
            req = {"jsonrpc": "2.0", "id": int(request_id), "method": method, "params": params or {}}
            proc.stdin.write((json.dumps(req, ensure_ascii=False) + "\n").encode("utf-8"))
            await proc.stdin.drain()

            while True:
                line = await self._read_mcp_stdout_line(proc.stdout, stdout_buf, max_bytes=self.MAX_STDOUT_BYTES)
                if not line:
                    raise RuntimeError(f"{ToolErrorCode.MCP_SPAWN_FAILED}: mcp_closed_stdout")
                try:
                    msg = json.loads(line.decode("utf-8", errors="replace"))
                except Exception:
                    continue
                if not isinstance(msg, dict):
                    continue
                if msg.get("id") != request_id:
                    continue
                if "error" in msg:
                    raise RuntimeError(f"mcp_error:{msg.get('error')}")
                result = msg.get("result", {})
                return result if isinstance(result, dict) else {"result": result}

        # MCP initialize handshake (many servers require this before tools/*).
        await _request(
            request_id=1,
            method="initialize",
            params={
                "protocolVersion": os.getenv("ZAKOPS_MCP_PROTOCOL_VERSION", "2024-11-05"),
                "capabilities": {},
                "clientInfo": {"name": "zakops-tool-gateway", "version": "1.0.0"},
            },
        )

        result = await _request(
            request_id=2,
            method="tools/call",
            params={"name": tool.mcp_tool_name or tool_name, "arguments": args or {}},
        )

        # Best-effort cleanup; avoid leaving zombie processes even if the server doesn't exit on stdin close.
        try:
            proc.stdin.close()
        except Exception:
            pass

        try:
            await asyncio.wait_for(proc.wait(), timeout=2.0)
        except Exception:
            try:
                proc.terminate()
            except Exception:
                pass
            try:
                await asyncio.wait_for(proc.wait(), timeout=2.0)
            except Exception:
                try:
                    proc.kill()
                except Exception:
                    pass

        if proc.returncode not in (0, None):
            stderr = await self._read_bounded(proc.stderr, self.MAX_STDERR_BYTES)
            stderr_text = SecretScanner.redact_error_message(stderr.decode(errors="replace"))
            raise RuntimeError(f"{ToolErrorCode.MCP_SPAWN_FAILED}: exit={proc.returncode} stderr={stderr_text[:500]}")

        return result

    def _resolve_mcp_stdio_command(self, *, tool: ToolManifest) -> List[str]:
        """
        Resolve the stdio command used to launch an MCP server.

        This supports env overrides to prevent "split-brain" between different
        call sites (triage, ToolGateway, executors).

        Overrides (highest priority first):
        - `MCP_STDIO_COMMAND_<SERVER>` (e.g. `MCP_STDIO_COMMAND_GMAIL`)
        - `GMAIL_MCP_COMMAND` (legacy convenience override for Gmail)
        - `tool.mcp_stdio_command` from the manifest
        """
        server = (tool.mcp_server or "").strip().lower()

        if server:
            raw = (os.getenv(f"MCP_STDIO_COMMAND_{server.upper()}") or "").strip()
            if raw:
                return shlex.split(raw)

        if server == "gmail":
            raw = (os.getenv("GMAIL_MCP_COMMAND") or "").strip()
            if raw:
                return shlex.split(raw)

        return list(tool.mcp_stdio_command or [])

    async def _read_mcp_stdout_line(self, stdout: asyncio.StreamReader, buf: bytearray, *, max_bytes: int) -> bytes:
        """
        Read a single newline-terminated MCP JSON-RPC message without StreamReader's 64KiB line cap.
        """
        while True:
            idx = buf.find(b"\n")
            if idx != -1:
                line = bytes(buf[: idx + 1])
                del buf[: idx + 1]
                return line
            chunk = await stdout.read(4096)
            if not chunk:
                return b""
            buf.extend(chunk)
            if len(buf) > int(max_bytes):
                raise RuntimeError(f"{ToolErrorCode.MALFORMED_RESPONSE}: mcp_stdout_line_too_large")

    async def _read_bounded(self, stream: asyncio.StreamReader, max_bytes: int) -> bytes:
        chunks: List[bytes] = []
        total = 0
        while True:
            chunk = await stream.read(8192)
            if not chunk:
                break
            total += len(chunk)
            if total > max_bytes:
                # truncate
                over = total - max_bytes
                chunks.append(chunk[: len(chunk) - over])
                break
            chunks.append(chunk)
        return b"".join(chunks)

    async def _invoke_mcp_docker(self, *, tool: ToolManifest, tool_name: str, args: Dict[str, Any]) -> Dict[str, Any]:
        if not tool.docker_image or not tool.docker_port:
            raise RuntimeError("docker_config_missing")

        container_name = f"mcp-{tool.mcp_server or tool.tool_id}"
        self._ensure_mcp_container(tool=tool, container_name=container_name)

        url = f"http://localhost:{int(tool.docker_port)}/call"
        async with httpx.AsyncClient(timeout=float(tool.timeout_ms or 30000) / 1000.0) as client:
            resp = await client.post(
                url,
                json={"name": tool.mcp_tool_name or tool_name, "arguments": args or {}},
            )
            resp.raise_for_status()
            data = resp.json()
            if isinstance(data, dict):
                result = data
            else:
                result = {"result": data}

        # Update last-used and opportunistically stop idle containers.
        self._docker_last_used[container_name] = (time.time(), int(tool.ttl_seconds or 0))
        self._stop_idle_containers()
        return result

    def _ensure_mcp_container(self, *, tool: ToolManifest, container_name: str) -> None:
        """
        Best-effort docker runtime support.

        This is intentionally conservative: it only starts the container if it's not running.
        """
        try:
            inspect = subprocess.run(
                ["docker", "inspect", "-f", "{{.State.Running}}", container_name],
                capture_output=True,
                text=True,
                check=False,
            )
            if inspect.returncode == 0 and inspect.stdout.strip() == "true":
                self._docker_last_used[container_name] = (time.time(), int(tool.ttl_seconds or 0))
                return
        except Exception:
            pass

        env = self._resolve_secrets(tool.secrets_refs or {})
        run_cmd: List[str] = [
            "docker",
            "run",
            "-d",
            "--name",
            container_name,
            "-p",
            f"{int(tool.docker_port)}:{int(tool.docker_port)}",
        ]
        for k, v in env.items():
            run_cmd.extend(["-e", f"{k}={v}"])
        run_cmd.append(str(tool.docker_image))

        res = subprocess.run(run_cmd, capture_output=True, text=True, check=False)
        if res.returncode != 0:
            raise RuntimeError(f"{ToolErrorCode.MCP_SPAWN_FAILED}: {res.stderr.strip()[:500]}")

        self._docker_last_used[container_name] = (time.time(), int(tool.ttl_seconds or 0))

    def _stop_idle_containers(self) -> None:
        now = time.time()
        for container_name, (last_used, ttl_seconds) in list(self._docker_last_used.items()):
            if ttl_seconds <= 0:
                continue
            if now - last_used < float(ttl_seconds):
                continue
            try:
                subprocess.run(["docker", "stop", container_name], capture_output=True, text=True, check=False)
                subprocess.run(["docker", "rm", "-f", container_name], capture_output=True, text=True, check=False)
            except Exception:
                pass
            self._docker_last_used.pop(container_name, None)


    def _resolve_secrets(self, refs: Dict[str, str]) -> Dict[str, str]:
        env: Dict[str, str] = {}
        for env_name, ref in refs.items():
            if ref.startswith("env:"):
                val = os.getenv(ref[4:], "").strip()
                if val:
                    env[env_name] = val
            elif ref.startswith("file:"):
                path = ref[5:]
                try:
                    if os.path.exists(path):
                        env[env_name] = Path(path).read_text(encoding="utf-8").strip()
                except Exception:
                    continue
            else:
                # Direct literal value (discouraged, but permitted for local stubs/tests).
                if ref:
                    env[env_name] = str(ref)
        return env


_GATEWAY: Optional[ToolGateway] = None


def get_tool_gateway() -> ToolGateway:
    global _GATEWAY
    if _GATEWAY is None:
        _GATEWAY = ToolGateway(tool_registry=get_tool_registry())
    return _GATEWAY
