"""Tooling infrastructure (ToolRegistry + ToolGateway) for ZakOps."""

