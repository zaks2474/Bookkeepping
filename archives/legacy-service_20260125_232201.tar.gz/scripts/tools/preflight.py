from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
from datetime import datetime, timezone

from tools.gateway import ToolGatewayConfig, get_tool_gateway
from tools.registry import get_tool_registry


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="ZakOps ToolGateway preflight")
    parser.add_argument("--check-health", action="store_true", help="Run tool health checks")
    parser.add_argument("--check-gmail-mcp", action="store_true", help="Smoke-check Gmail MCP stdio spawn + tools/list")
    parser.add_argument("--strict", action="store_true", help="Fail if any tool has missing secrets (even if gateway disabled)")
    args = parser.parse_args(argv)

    reg = get_tool_registry()
    cfg = ToolGatewayConfig.from_env()

    tools = reg.list_tools()
    missing = reg.validate_secrets()

    summary = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "gateway_enabled": bool(cfg.enabled),
        "tools_count": len(tools),
        "missing_secrets": missing,
    }

    errors: list[str] = []
    if missing and (args.strict or cfg.enabled):
        errors.append("missing_secrets")

    if args.check_gmail_mcp:
        try:
            from tools.mcp_health import check_gmail_mcp_health

            gmail = check_gmail_mcp_health(timeout_ms=5000)
        except Exception as e:
            gmail = {"ok": False, "reason": f"exception:{type(e).__name__}"}
        summary["gmail_mcp"] = gmail
        if not bool(gmail.get("ok")):
            errors.append("gmail_mcp_unhealthy")

    if args.check_health and cfg.enabled:
        async def _run() -> dict:
            results = await reg.check_all_health()
            return {
                tool_id: {
                    "healthy": bool(status.healthy),
                    "latency_ms": int(status.latency_ms),
                    "error": status.error,
                    "last_check": status.last_check.isoformat(),
                }
                for tool_id, status in results.items()
            }

        summary["health"] = asyncio.run(_run())
        if any(not v["healthy"] for v in summary["health"].values()):
            errors.append("unhealthy_tools")

    summary["errors"] = errors
    print(json.dumps(summary, indent=2, sort_keys=True))

    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
