from __future__ import annotations

import json
import os
import shlex
import subprocess
import select
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional


def now_utc_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


@dataclass(frozen=True)
class McpHealthResult:
    ok: bool
    reason: str
    checked_at: str
    command: List[str]
    tools_count: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "ok": bool(self.ok),
            "reason": str(self.reason),
            "checked_at": str(self.checked_at),
            "command": list(self.command or []),
            "tools_count": int(self.tools_count),
        }


DEFAULT_GMAIL_MCP_COMMAND = ["npx", "-y", "@gongrzhe/server-gmail-autoauth-mcp"]


def resolve_mcp_stdio_command(*, server: str, manifest_command: Optional[List[str]] = None) -> List[str]:
    server_norm = (server or "").strip().lower()
    if not server_norm:
        return list(manifest_command or [])

    raw = (os.getenv(f"MCP_STDIO_COMMAND_{server_norm.upper()}") or "").strip()
    if raw:
        return shlex.split(raw)

    if server_norm == "gmail":
        raw = (os.getenv("GMAIL_MCP_COMMAND") or "").strip()
        if raw:
            return shlex.split(raw)

    if manifest_command:
        return list(manifest_command)

    if server_norm == "gmail":
        return list(DEFAULT_GMAIL_MCP_COMMAND)

    return []


def _read_line_bounded(fd: int, buf: bytearray, *, timeout_s: float, max_bytes: int) -> bytes:
    deadline = time.monotonic() + max(0.01, float(timeout_s))
    while True:
        idx = buf.find(b"\n")
        if idx != -1:
            line = bytes(buf[: idx + 1])
            del buf[: idx + 1]
            return line

        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError("mcp_stdout_timeout")

        r, _, _ = select.select([fd], [], [], remaining)
        if not r:
            raise TimeoutError("mcp_stdout_timeout")
        chunk = os.read(fd, 4096)
        if not chunk:
            return b""
        buf.extend(chunk)
        if len(buf) > int(max_bytes):
            raise ValueError("mcp_stdout_line_too_large")


def _request_jsonrpc(
    *,
    proc: subprocess.Popen,
    stdout_fd: int,
    stdout_buf: bytearray,
    request_id: int,
    method: str,
    params: Dict[str, Any],
    timeout_s: float,
    max_line_bytes: int,
) -> Dict[str, Any]:
    payload = json.dumps({"jsonrpc": "2.0", "id": int(request_id), "method": method, "params": params or {}}, ensure_ascii=False).encode(
        "utf-8"
    )
    assert proc.stdin is not None
    proc.stdin.write(payload + b"\n")
    proc.stdin.flush()

    while True:
        line = _read_line_bounded(stdout_fd, stdout_buf, timeout_s=timeout_s, max_bytes=max_line_bytes)
        if not line:
            raise RuntimeError("mcp_closed_stdout")
        try:
            msg = json.loads(line.decode("utf-8", errors="replace"))
        except Exception:
            continue
        if not isinstance(msg, dict):
            continue
        if msg.get("id") != request_id:
            continue
        if "error" in msg:
            raise RuntimeError(f"mcp_error:{msg.get('error')}")
        result = msg.get("result", {})
        return result if isinstance(result, dict) else {"result": result}


def check_mcp_tools_list(*, command: List[str], env: Dict[str, str], timeout_ms: int = 5000) -> McpHealthResult:
    checked_at = now_utc_iso()
    if not command:
        return McpHealthResult(ok=False, reason="missing_command", checked_at=checked_at, command=[], tools_count=0)

    timeout_s = max(0.25, float(timeout_ms) / 1000.0)
    try:
        proc = subprocess.Popen(
            list(command),
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env={**os.environ, **(env or {})},
        )
    except FileNotFoundError:
        return McpHealthResult(ok=False, reason="spawn_failed:file_not_found", checked_at=checked_at, command=command, tools_count=0)
    except Exception as e:
        return McpHealthResult(ok=False, reason=f"spawn_failed:{type(e).__name__}", checked_at=checked_at, command=command, tools_count=0)

    assert proc.stdout is not None
    stdout_fd = proc.stdout.fileno()
    stdout_buf = bytearray()

    try:
        # Initialize first (required by most MCP servers).
        _request_jsonrpc(
            proc=proc,
            stdout_fd=stdout_fd,
            stdout_buf=stdout_buf,
            request_id=1,
            method="initialize",
            params={
                "protocolVersion": os.getenv("ZAKOPS_MCP_PROTOCOL_VERSION", "2024-11-05"),
                "capabilities": {},
                "clientInfo": {"name": "zakops-mcp-health", "version": "1.0.0"},
            },
            timeout_s=timeout_s,
            max_line_bytes=10 * 1024 * 1024,
        )

        result = _request_jsonrpc(
            proc=proc,
            stdout_fd=stdout_fd,
            stdout_buf=stdout_buf,
            request_id=2,
            method="tools/list",
            params={},
            timeout_s=timeout_s,
            max_line_bytes=10 * 1024 * 1024,
        )

        tools = (result or {}).get("tools") if isinstance(result, dict) else None
        if not isinstance(tools, list):
            return McpHealthResult(ok=False, reason="missing_tools_list", checked_at=checked_at, command=command, tools_count=0)

        return McpHealthResult(ok=True, reason="ok", checked_at=checked_at, command=command, tools_count=len(tools))
    except TimeoutError:
        return McpHealthResult(ok=False, reason="timeout", checked_at=checked_at, command=command, tools_count=0)
    except Exception as e:
        msg = str(e).strip().replace("\n", " ")[:200]
        return McpHealthResult(
            ok=False,
            reason=f"error:{type(e).__name__}:{msg}" if msg else f"error:{type(e).__name__}",
            checked_at=checked_at,
            command=command,
            tools_count=0,
        )
    finally:
        try:
            if proc.stdin:
                proc.stdin.close()
        except Exception:
            pass
        try:
            proc.terminate()
        except Exception:
            pass
        try:
            proc.wait(timeout=1.0)
        except Exception:
            try:
                proc.kill()
            except Exception:
                pass


def check_gmail_mcp_health(*, timeout_ms: int = 5000) -> Dict[str, Any]:
    """
    Best-effort Gmail MCP health check used for ops diagnostics.

    - Validates credentials env var + file existence
    - Starts the MCP server in stdio mode and requests tools/list
    """
    creds_env = "GMAIL_MCP_CREDENTIALS_PATH"
    creds = (os.getenv("GMAIL_MCP_CREDENTIALS_PATH") or "").strip()
    if not creds:
        creds_env = "GMAIL_CREDENTIALS_PATH"
        creds = (os.getenv("GMAIL_CREDENTIALS_PATH") or "").strip()
    if not creds:
        return {
            "ok": False,
            "reason": "missing_env:GMAIL_MCP_CREDENTIALS_PATH_or_GMAIL_CREDENTIALS_PATH",
            "checked_at": now_utc_iso(),
        }

    try:
        p = Path(creds)
        if not (p.exists() and p.is_file()):
            return {"ok": False, "reason": "credentials_not_found", "checked_at": now_utc_iso(), "credentials_path": creds}
    except Exception:
        return {"ok": False, "reason": "credentials_path_invalid", "checked_at": now_utc_iso()}

    cmd = resolve_mcp_stdio_command(server="gmail", manifest_command=DEFAULT_GMAIL_MCP_COMMAND)
    # Upstream server uses GMAIL_CREDENTIALS_PATH; keep our legacy/internal name too for compatibility.
    res = check_mcp_tools_list(
        command=cmd,
        env={"GMAIL_CREDENTIALS_PATH": creds, "GMAIL_MCP_CREDENTIALS_PATH": creds},
        timeout_ms=timeout_ms,
    )
    out = res.to_dict()
    out["credentials_path"] = creds
    out["credentials_env"] = creds_env
    return out
