from __future__ import annotations

import asyncio
import logging
import os
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml

logger = logging.getLogger(__name__)


DEFAULT_MANIFESTS_DIR = Path(os.getenv("ZAKOPS_TOOLS_DIR", "/home/zaks/scripts/tools/manifests"))


@dataclass
class HealthCheckConfig:
    enabled: bool = True
    endpoint: str = ""
    timeout_ms: int = 5000
    cache_ttl_seconds: int = 30


@dataclass
class HealthStatus:
    healthy: bool
    last_check: datetime
    latency_ms: int
    error: Optional[str] = None


@dataclass
class ToolManifest:
    tool_id: str
    version: str
    title: str
    description: str
    provider: str  # mcp|http

    # MCP config
    mcp_server: Optional[str] = None
    mcp_tool_name: Optional[str] = None
    mcp_stdio_command: Optional[List[str]] = None

    # Docker config
    docker_image: Optional[str] = None
    docker_port: Optional[int] = None
    docker_health_cmd: Optional[str] = None

    # HTTP config (provider=http)
    http_endpoint: Optional[str] = None
    http_method: str = "POST"
    http_headers: Dict[str, str] = field(default_factory=dict)

    # Runtime
    startup_time_ms: int = 5000
    timeout_ms: int = 30000
    ttl_seconds: int = 300

    # Health
    health_check: Optional[HealthCheckConfig] = None

    # Secrets
    secrets_refs: Dict[str, str] = field(default_factory=dict)

    # Safety
    risk_level: str = "medium"
    requires_approval: bool = True
    safety_class: str = "reversible"  # reversible|gated|irreversible
    irreversible: bool = False
    constraints: List[str] = field(default_factory=list)

    # Schema
    input_schema: Dict[str, Any] = field(default_factory=dict)
    output_schema: Dict[str, Any] = field(default_factory=dict)
    examples: List[Dict[str, Any]] = field(default_factory=list)

    # Meta
    tags: List[str] = field(default_factory=list)
    created: str = ""
    owner: str = ""


class ToolRegistry:
    def __init__(self, manifests_dir: Optional[Path] = None):
        self.manifests_dir = manifests_dir or DEFAULT_MANIFESTS_DIR
        self._tools: Dict[str, ToolManifest] = {}
        self._by_server: Dict[str, List[ToolManifest]] = {}
        self._by_tag: Dict[str, List[ToolManifest]] = {}
        self._health_cache: Dict[str, HealthStatus] = {}

    def load_from_directory(self) -> None:
        path = self.manifests_dir
        if not path.exists():
            logger.warning("Tools manifests dir not found: %s", path)
            return

        for yaml_file in sorted(path.glob("*.y*ml")):
            if yaml_file.name.upper() == "SCHEMA.MD":
                continue
            self._load_manifest(yaml_file)

        logger.info("Loaded %d tool manifests", len(self.list_tools()))

    def _load_manifest(self, yaml_path: Path) -> None:
        raw = yaml_path.read_text(encoding="utf-8")
        data = yaml.safe_load(raw) or {}
        if not isinstance(data, dict):
            raise ValueError(f"invalid_tool_manifest:{yaml_path}")

        hc_data = data.pop("health_check", None)
        health_check = None
        if isinstance(hc_data, dict):
            health_check = HealthCheckConfig(**hc_data)

        manifest = ToolManifest(health_check=health_check, **data)

        if manifest.tool_id in self._tools:
            raise ValueError(f"duplicate_tool_id:{manifest.tool_id} ({yaml_path})")
        self._tools[manifest.tool_id] = manifest
        if manifest.mcp_tool_name:
            self._tools[manifest.mcp_tool_name] = manifest

        if manifest.mcp_server:
            self._by_server.setdefault(manifest.mcp_server, []).append(manifest)
        for tag in manifest.tags:
            self._by_tag.setdefault(tag, []).append(manifest)

    def get_tool(self, tool_id: str) -> Optional[ToolManifest]:
        return self._tools.get((tool_id or "").strip())

    def list_tools(self) -> List[ToolManifest]:
        seen: set[str] = set()
        out: List[ToolManifest] = []
        for tool in self._tools.values():
            if tool.tool_id in seen:
                continue
            out.append(tool)
            seen.add(tool.tool_id)
        out.sort(key=lambda t: t.tool_id)
        return out

    def validate_secrets(self) -> Dict[str, List[str]]:
        missing: Dict[str, List[str]] = {}
        for tool in self.list_tools():
            tool_missing: List[str] = []
            for env_name, ref in (tool.secrets_refs or {}).items():
                if ref.startswith("env:"):
                    env_var = ref[4:]
                    if not os.getenv(env_var, "").strip():
                        tool_missing.append(f"{env_name} (env:{env_var})")
                elif ref.startswith("file:"):
                    path = ref[5:]
                    if not os.path.exists(path):
                        tool_missing.append(f"{env_name} (file:{path})")
            if tool_missing:
                missing[tool.tool_id] = tool_missing
        return missing

    async def check_health(self, tool_id: str) -> HealthStatus:
        tool = self.get_tool(tool_id)
        if not tool:
            return HealthStatus(healthy=False, last_check=datetime.now(timezone.utc), latency_ms=0, error="Tool not found")

        if not tool.health_check or not tool.health_check.enabled:
            return HealthStatus(healthy=True, last_check=datetime.now(timezone.utc), latency_ms=0, error=None)

        cached = self._health_cache.get(tool_id)
        if cached:
            age = (datetime.now(timezone.utc) - cached.last_check).total_seconds()
            if age < int(tool.health_check.cache_ttl_seconds or 0):
                return cached

        from tools.gateway import ToolInvocationContext, get_tool_gateway

        start = time.time()
        try:
            gateway = get_tool_gateway()
            ctx = ToolInvocationContext(
                action_id="tool_health_check",
                action_status="PROCESSING",
                approved=True,
                bypass_db_approval=True,
            )
            result = await gateway.invoke(
                tool_name=tool.health_check.endpoint,
                args={},
                context=ctx,
                timeout_ms=int(tool.health_check.timeout_ms or 5000),
            )
            latency = int((time.time() - start) * 1000)
            status = HealthStatus(
                healthy=bool(result.success),
                last_check=datetime.now(timezone.utc),
                latency_ms=latency,
                error=result.error_message if not result.success else None,
            )
        except Exception as e:
            status = HealthStatus(
                healthy=False,
                last_check=datetime.now(timezone.utc),
                latency_ms=int((time.time() - start) * 1000),
                error=str(e),
            )

        self._health_cache[tool_id] = status
        return status

    async def check_all_health(self) -> Dict[str, HealthStatus]:
        results: Dict[str, HealthStatus] = {}
        for tool in self.list_tools():
            results[tool.tool_id] = await self.check_health(tool.tool_id)
        return results


_REGISTRY: Optional[ToolRegistry] = None


def get_tool_registry() -> ToolRegistry:
    global _REGISTRY
    if _REGISTRY is None:
        reg = ToolRegistry()
        reg.load_from_directory()
        _REGISTRY = reg
    return _REGISTRY


def tool_registry_to_json(tool: ToolManifest) -> Dict[str, Any]:
    return {
        "tool_id": tool.tool_id,
        "version": tool.version,
        "title": tool.title,
        "description": tool.description,
        "provider": tool.provider,
        "mcp_server": tool.mcp_server,
        "mcp_tool_name": tool.mcp_tool_name,
        "http_endpoint": tool.http_endpoint,
        "http_method": tool.http_method,
        "risk_level": tool.risk_level,
        "requires_approval": bool(tool.requires_approval),
        "safety_class": str(getattr(tool, "safety_class", "reversible") or "reversible"),
        "irreversible": bool(getattr(tool, "irreversible", False)),
        "constraints": list(tool.constraints or []),
        "tags": list(tool.tags or []),
        "health_check": {
            "enabled": bool(tool.health_check.enabled),
            "endpoint": tool.health_check.endpoint,
            "timeout_ms": int(tool.health_check.timeout_ms),
            "cache_ttl_seconds": int(tool.health_check.cache_ttl_seconds),
        }
        if tool.health_check
        else None,
    }
