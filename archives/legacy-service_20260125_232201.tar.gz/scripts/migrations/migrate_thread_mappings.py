#!/usr/bin/env python3
"""
One-time migration: populate DealRegistry.thread_to_deal from existing Deal.email_thread_ids.

Safe behavior:
- Never overwrites existing thread_to_deal mappings.
- Does not modify thread_to_non_deal.
- Logs conflicts (same thread present in multiple deals) without forcing a choice.
"""

from __future__ import annotations

import argparse
import os
from pathlib import Path
from typing import Any, Dict, List

from deal_registry import DealRegistry


def default_registry_path() -> str:
    dataroom = Path(os.getenv("DATAROOM_ROOT", "/home/zaks/DataRoom")).resolve()
    return str(dataroom / ".deal-registry" / "deal_registry.json")


def migrate(*, registry_path: str) -> Dict[str, Any]:
    reg = DealRegistry(str(registry_path))

    migrated = 0
    conflict_samples: List[str] = []

    for deal_id, deal in (reg.deals or {}).items():
        for tid in (deal.email_thread_ids or []):
            thread_id = str(tid or "").strip()
            if not thread_id:
                continue

            existing = (reg.thread_to_deal or {}).get(thread_id)
            if existing and existing != deal_id:
                if len(conflict_samples) < 20:
                    conflict_samples.append(f"{thread_id}: {existing} vs {deal_id}")
                continue

            if thread_id not in (reg.thread_to_deal or {}):
                reg.thread_to_deal[thread_id] = deal_id
                migrated += 1

    if migrated:
        reg.save()

    return {"migrated": migrated, "conflicts": len(conflict_samples), "conflict_samples": conflict_samples}


def main(argv: List[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="ZakOps migration: populate thread_to_deal mappings")
    parser.add_argument("--registry-path", default=default_registry_path())
    args = parser.parse_args(argv)

    result = migrate(registry_path=str(args.registry_path))
    print(f"migrated={result['migrated']} conflicts={result['conflicts']}")
    for sample in result.get("conflict_samples") or []:
        print(f"conflict: {sample}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

