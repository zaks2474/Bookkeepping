#!/usr/bin/env python3
"""
Hybrid classifier for DFP routing.

Design goals:
- Local-first (vLLM / OpenAI-compatible API) for most cases
- Heuristics for very-high-confidence, low-latency decisions
- Optional cloud escalation (Gemini) gated behind explicit env vars
- Never log raw inputs (only hashes + metadata) when emitting run-ledger records
"""

from __future__ import annotations

import json
import os
import re
import time
import hashlib
from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Tuple

try:
    import requests  # type: ignore
except Exception:  # pragma: no cover
    requests = None  # type: ignore


def _approx_token_count(text: str) -> int:
    # Simple estimate: ~4 chars/token for English.
    return max(1, len(text) // 4)


def _sha256(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8", errors="ignore")).hexdigest()


def _coerce_bool(value: str) -> bool:
    return value.strip().lower() in {"1", "true", "yes", "y", "on"}


def _extract_first_json_object(text: str) -> Optional[dict]:
    """
    Best-effort JSON object extractor for LLM responses.

    Supports:
    - Raw JSON
    - Markdown fenced code blocks
    """
    text = text.strip()
    if not text:
        return None

    # Prefer fenced block content if present.
    fence = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, flags=re.DOTALL | re.IGNORECASE)
    if fence:
        candidate = fence.group(1).strip()
        try:
            return json.loads(candidate)
        except Exception:
            pass

    # Fallback: first {...} region.
    brace = re.search(r"(\{.*\})", text, flags=re.DOTALL)
    if brace:
        candidate = brace.group(1).strip()
        try:
            return json.loads(candidate)
        except Exception:
            return None

    return None


@dataclass(frozen=True)
class ClassificationResult:
    label: str
    confidence: float
    route: str  # heuristic|local|cloud|none
    model: str
    reason: str = ""
    alternatives: List[Dict[str, Any]] = field(default_factory=list)
    input_hash: str = ""
    input_tokens_est: int = 0
    latency_ms: int = 0

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        data["confidence"] = float(self.confidence)
        data["latency_ms"] = int(self.latency_ms)
        data["input_tokens_est"] = int(self.input_tokens_est)
        return data


class HybridClassifier:
    def __init__(
        self,
        *,
        prefer_local: Optional[bool] = None,
        local_token_limit: Optional[int] = None,
        heuristic_confidence_threshold: Optional[float] = None,
        local_api_base: Optional[str] = None,
        local_model: Optional[str] = None,
        allow_cloud: Optional[bool] = None,
    ) -> None:
        self.prefer_local = prefer_local if prefer_local is not None else _coerce_bool(os.getenv("CLASSIFICATION_PREFER_LOCAL", "true"))
        self.local_token_limit = local_token_limit if local_token_limit is not None else int(os.getenv("LOCAL_TOKEN_LIMIT", "2000").strip() or "2000")
        self.heuristic_confidence_threshold = (
            heuristic_confidence_threshold if heuristic_confidence_threshold is not None else float(os.getenv("HEURISTIC_CONFIDENCE_THRESHOLD", "0.95").strip() or "0.95")
        )
        self.local_api_base = (
            local_api_base
            or os.getenv("ZAKOPS_API_URL", "").strip()
            or os.getenv("OPENAI_API_BASE", "").strip()
            or "http://localhost:8000/v1"
        ).rstrip("/")
        self.local_model = local_model or os.getenv("ZAKOPS_CLASSIFICATION_MODEL", "").strip() or os.getenv("DEFAULT_MODEL", "").strip() or "Qwen/Qwen2.5-32B-Instruct-AWQ"

        # Cloud calls must be explicitly enabled; default off.
        self.allow_cloud = allow_cloud if allow_cloud is not None else _coerce_bool(os.getenv("CLASSIFICATION_ENABLE_CLOUD", "false"))

    def classify_one_of(
        self,
        *,
        text: str,
        labels: Sequence[str],
        patterns_by_label: Optional[Dict[str, Sequence[str]]] = None,
        context: str = "",
    ) -> ClassificationResult:
        started = time.monotonic()
        input_hash = _sha256(text)
        input_tokens_est = _approx_token_count(text)
        safe_model = self.local_model or "unknown"

        labels_list = [l for l in labels if l and l.strip()]
        if not labels_list:
            ended = time.monotonic()
            return ClassificationResult(
                label="unknown",
                confidence=0.0,
                route="none",
                model="none",
                reason="no_labels_provided",
                input_hash=input_hash,
                input_tokens_est=input_tokens_est,
                latency_ms=int((ended - started) * 1000),
            )

        heuristic = self._heuristic(text=text, labels=labels_list, patterns_by_label=patterns_by_label or {})
        if heuristic is not None:
            label, conf, reason = heuristic
            if conf >= self.heuristic_confidence_threshold:
                ended = time.monotonic()
                return ClassificationResult(
                    label=label,
                    confidence=conf,
                    route="heuristic",
                    model="heuristic",
                    reason=reason,
                    input_hash=input_hash,
                    input_tokens_est=input_tokens_est,
                    latency_ms=int((ended - started) * 1000),
                )

            # Only attempt local LLM if the heuristic already has some signal.
            if self.prefer_local and input_tokens_est <= self.local_token_limit and conf >= 0.80:
                try:
                    llm_res = self._classify_with_local_llm(text=text, labels=labels_list, context=context)
                    ended = time.monotonic()
                    return ClassificationResult(
                        label=llm_res.get("label", "unknown"),
                        confidence=float(llm_res.get("confidence", 0.0)),
                        route="local",
                        model=safe_model,
                        reason=str(llm_res.get("reason", "") or ""),
                        alternatives=list(llm_res.get("alternatives", []) or []),
                        input_hash=input_hash,
                        input_tokens_est=input_tokens_est,
                        latency_ms=int((ended - started) * 1000),
                    )
                except Exception:
                    # Fall back to heuristic result.
                    pass

        # If no heuristic match, attempt local if allowed and small enough.
        if self.prefer_local and input_tokens_est <= self.local_token_limit:
            try:
                llm_res = self._classify_with_local_llm(text=text, labels=labels_list, context=context)
                ended = time.monotonic()
                return ClassificationResult(
                    label=llm_res.get("label", "unknown"),
                    confidence=float(llm_res.get("confidence", 0.0)),
                    route="local",
                    model=safe_model,
                    reason=str(llm_res.get("reason", "") or ""),
                    alternatives=list(llm_res.get("alternatives", []) or []),
                    input_hash=input_hash,
                    input_tokens_est=input_tokens_est,
                    latency_ms=int((ended - started) * 1000),
                )
            except Exception:
                pass

        # Optional cloud escalation (explicit opt-in only).
        if self.allow_cloud:
            try:
                from gemini_classifier import GeminiClassifier  # local import to avoid dependency issues

                gem = GeminiClassifier()
                cloud_res = gem.classify_one_of(text=text, labels=labels_list, context=context)
                ended = time.monotonic()
                return ClassificationResult(
                    label=cloud_res.get("label", "unknown"),
                    confidence=float(cloud_res.get("confidence", 0.0)),
                    route="cloud",
                    model=str(cloud_res.get("model", "gemini")),
                    reason=str(cloud_res.get("reason", "") or ""),
                    alternatives=list(cloud_res.get("alternatives", []) or []),
                    input_hash=input_hash,
                    input_tokens_est=input_tokens_est,
                    latency_ms=int((ended - started) * 1000),
                )
            except Exception:
                pass

        ended = time.monotonic()
        return ClassificationResult(
            label=(heuristic[0] if heuristic is not None else "unknown"),
            confidence=(float(heuristic[1]) if heuristic is not None else 0.0),
            route=("heuristic_low_conf" if heuristic is not None else "none"),
            model=("heuristic" if heuristic is not None else "none"),
            reason=(heuristic[2] if heuristic is not None else "no_signal"),
            input_hash=input_hash,
            input_tokens_est=input_tokens_est,
            latency_ms=int((ended - started) * 1000),
        )

    def _heuristic(
        self,
        *,
        text: str,
        labels: Sequence[str],
        patterns_by_label: Dict[str, Sequence[str]],
    ) -> Optional[Tuple[str, float, str]]:
        if not patterns_by_label:
            return None

        haystack = text.lower()
        best_label: Optional[str] = None
        best_hits = 0
        best_patterns: List[str] = []

        for label in labels:
            patterns = [p for p in patterns_by_label.get(label, []) if p]
            if not patterns:
                continue
            hits = [p for p in patterns if p.lower() in haystack]
            if len(hits) > best_hits:
                best_hits = len(hits)
                best_label = label
                best_patterns = hits

        if best_label is None or best_hits == 0:
            return None

        # Confidence ladder: require multiple hits to reach >=0.95.
        if best_hits >= 4:
            conf = 0.96
        elif best_hits == 3:
            conf = 0.92
        elif best_hits == 2:
            conf = 0.85
        else:
            conf = 0.75

        reason = f"heuristic_hits={best_hits} patterns={','.join(best_patterns[:6])}"
        return best_label, conf, reason

    def _classify_with_local_llm(self, *, text: str, labels: Sequence[str], context: str) -> Dict[str, Any]:
        if requests is None:
            raise RuntimeError("requests_not_available")

        endpoint = f"{self.local_api_base}/chat/completions"
        labels_rendered = "\n".join([f"- {l}" for l in labels])
        system = (
            "You are a strict classifier.\n"
            "Return ONLY valid JSON (no markdown) matching this schema:\n"
            "{\n"
            '  "label": "<one of the provided labels>",\n'
            '  "confidence": <number 0.0-1.0>,\n'
            '  "reason": "<short>",\n'
            '  "alternatives": [{"label":"...","confidence":0.0}]\n'
            "}\n"
            "Rules:\n"
            "- Choose exactly one label from the provided list.\n"
            "- Keep reason under 20 words.\n"
            "- Never include secrets or raw credentials.\n"
        )
        user = (
            f"Labels:\n{labels_rendered}\n\n"
            f"Context (optional): {context.strip()}\n\n"
            "Text to classify:\n"
            f"{text}\n"
        )

        payload = {
            "model": self.local_model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "temperature": 0.0,
            "max_tokens": 300,
        }
        res = requests.post(endpoint, json=payload, timeout=45)
        res.raise_for_status()
        data = res.json()
        content = (((data.get("choices") or [{}])[0]).get("message") or {}).get("content") or ""
        parsed = _extract_first_json_object(content)
        if not parsed:
            raise RuntimeError("llm_returned_non_json")

        label = str(parsed.get("label", "")).strip()
        if label not in set(labels):
            raise RuntimeError("llm_label_not_in_set")
        confidence = float(parsed.get("confidence", 0.0))
        reason = str(parsed.get("reason", "") or "")
        alternatives = parsed.get("alternatives", [])
        if not isinstance(alternatives, list):
            alternatives = []
        return {
            "label": label,
            "confidence": max(0.0, min(1.0, confidence)),
            "reason": reason,
            "alternatives": alternatives[:5],
        }


if __name__ == "__main__":  # pragma: no cover
    # Minimal self-test (does not call any APIs).
    sample = "Confidential Information Memorandum (CIM) attached. EBITDA and revenue included."
    patterns = {
        "02-CIM": ["confidential information memorandum", "cim", "offering memorandum", "ebitda", "teaser"],
        "01-NDA": ["non-disclosure", "nda", "confidentiality"],
    }
    clf = HybridClassifier(prefer_local=False)
    result = clf.classify_one_of(text=sample, labels=list(patterns.keys()), patterns_by_label=patterns)
    print(json.dumps(result.to_dict(), indent=2))

