#!/usr/bin/env python3
"""
DataRoom Query CLI

Query DataRoom knowledge via RAG

Usage:
  ./query_dataroom.py "Show me all MSP deals with >$1M revenue"
  ./query_dataroom.py "What are the red flags in TeamLogic IT deal?"
  ./query_dataroom.py "Compare NIN IT Services vs Vertical MSP"
"""

import sys
import os
import requests
import json
from typing import Optional, List, Dict

RAG_QUERY_URL = os.getenv("RAG_QUERY_URL", "http://localhost:8052/rag/query")
DATAROOM_SOURCE = "dataroom.local"


def query(question: str, source: Optional[str] = DATAROOM_SOURCE, match_count: int = 10) -> Optional[List[Dict]]:
    """Query RAG system."""
    payload = {"query": question, "match_count": match_count}
    if source:
        payload["source"] = source

    try:
        response = requests.post(RAG_QUERY_URL, json=payload, timeout=30)

        if response.status_code == 200:
            data = response.json()
            return data.get("results", [])
        else:
            print(f"Error: {response.status_code} {response.text}")
            return None
    except requests.exceptions.ConnectionError:
        print(f"Error: Cannot connect to RAG API at {RAG_QUERY_URL}")
        print("Make sure the RAG service is running.")
        return None
    except Exception as e:
        print(f"Error: {e}")
        return None


def format_results(results: Optional[List[Dict]], verbose: bool = False):
    """Format and display results."""
    if results is None:
        return

    if not results:
        print("No results found.")
        return

    print(f"\n{'='*60}")
    print(f"Found {len(results)} relevant chunks:")
    print(f"{'='*60}\n")

    for i, result in enumerate(results, 1):
        metadata = result.get('metadata', {})
        filename = metadata.get('filename', 'Unknown')
        path = metadata.get('path', 'Unknown')
        similarity = result.get('similarity', 0)
        url = result.get('url', '')

        print(f"{i}. {filename}")
        print(f"   Path: {path}")
        if verbose:
            print(f"   URL: {url}")
        print(f"   Similarity: {similarity:.3f}")

        # Show deal/stage if available
        if metadata.get('deal'):
            print(f"   Deal: {metadata.get('deal')}")
        if metadata.get('stage'):
            print(f"   Stage: {metadata.get('stage')}")
        if metadata.get('doc_type'):
            print(f"   Doc Type: {metadata.get('doc_type')}")

        # Show snippet
        content = result.get('content', '')
        if content:
            snippet = content[:300].replace('\n', ' ')
            if len(content) > 300:
                snippet += "..."
            print(f"   Snippet: {snippet}")
        print()


def main():
    import argparse

    parser = argparse.ArgumentParser(description="Query DataRoom knowledge via RAG")
    parser.add_argument("question", nargs="?", help="Your question")
    parser.add_argument("-n", "--count", type=int, default=10, help="Number of results (default: 10)")
    parser.add_argument("-s", "--source", default=DATAROOM_SOURCE, help="Filter by source domain")
    parser.add_argument("-v", "--verbose", action="store_true", help="Show more details")
    parser.add_argument("-i", "--interactive", action="store_true", help="Interactive mode")

    args = parser.parse_args()

    if args.interactive:
        print("DataRoom Query CLI - Interactive Mode")
        print("Type 'quit' or 'exit' to stop\n")

        while True:
            try:
                question = input("Question: ").strip()
                if question.lower() in ('quit', 'exit', 'q'):
                    break
                if not question:
                    continue

                results = query(question, args.source, args.count)
                format_results(results, args.verbose)

            except KeyboardInterrupt:
                print("\n")
                break
            except EOFError:
                break

    elif args.question:
        print(f"\nQuerying: {args.question}")
        results = query(args.question, args.source, args.count)
        format_results(results, args.verbose)

    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
