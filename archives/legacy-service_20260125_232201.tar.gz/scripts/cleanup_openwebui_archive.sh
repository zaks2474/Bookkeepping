#!/bin/bash
# Remove OpenWebUI runtime from DataRoom, backup database separately

set -euo pipefail

DATAROOM="/home/zaks/DataRoom"
OPENWEBUI_ARCHIVE="$DATAROOM/08-ARCHIVE/openwebui-chats"
BACKUP_LOCATION="/home/zaks/backups/openwebui"
LOG_FILE="/home/zaks/logs/openwebui_cleanup_$(date +%Y%m%d_%H%M%S).log"

echo "=== OpenWebUI Archive Cleanup ===" | tee -a "$LOG_FILE"
echo "Date: $(date)" | tee -a "$LOG_FILE"
echo "" | tee -a "$LOG_FILE"

# Check current size
if [ -d "$OPENWEBUI_ARCHIVE" ]; then
    CURRENT_SIZE=$(du -sh "$OPENWEBUI_ARCHIVE" | cut -f1)
    echo "Current archive size: $CURRENT_SIZE" | tee -a "$LOG_FILE"
    echo "" | tee -a "$LOG_FILE"

    # Create backup directory
    mkdir -p "$BACKUP_LOCATION"

    # Backup all webui.db snapshots (archive uses dated subfolders)
    echo "Backing up webui.db snapshots..." | tee -a "$LOG_FILE"
    mapfile -t DB_FILES < <(find "$OPENWEBUI_ARCHIVE" -type f -name "webui.db" 2>/dev/null || true)
    if [ "${#DB_FILES[@]}" -eq 0 ]; then
        echo "⚠ No webui.db files found under $OPENWEBUI_ARCHIVE" | tee -a "$LOG_FILE"
        echo "⚠ Skipping deletion to avoid data loss (export chats first)" | tee -a "$LOG_FILE"
        exit 1
    fi

    for db in "${DB_FILES[@]}"; do
        stamp=$(basename "$(dirname "$db")")
        dest="$BACKUP_LOCATION/webui_${stamp}_$(date +%Y%m%d_%H%M%S).db"

        if [ ! -r "$db" ]; then
            echo "❌ Cannot read database snapshot: $db" | tee -a "$LOG_FILE"
            echo "❌ Aborting cleanup to avoid data loss. Run as root or fix permissions." | tee -a "$LOG_FILE"
            exit 1
        fi

        python3 - <<PY
import sqlite3
src = r"""$db"""
dst = r"""$dest"""
src_conn = sqlite3.connect(f"file:{src}?mode=ro", uri=True)
dst_conn = sqlite3.connect(dst)
src_conn.backup(dst_conn)
dst_conn.close()
src_conn.close()
PY

        chown zaks:zaks "$dest" || true
        chmod 600 "$dest" || true

        if [ ! -s "$dest" ]; then
            echo "❌ Backup failed (empty file): $dest" | tee -a "$LOG_FILE"
            echo "❌ Aborting cleanup to avoid data loss." | tee -a "$LOG_FILE"
            exit 1
        fi

        echo "✓ Backed up: $db → $dest" | tee -a "$LOG_FILE"
    done

    # Remove the entire archive directory
    echo "" | tee -a "$LOG_FILE"
    echo "Removing OpenWebUI runtime from DataRoom..." | tee -a "$LOG_FILE"
    rm -rf "$OPENWEBUI_ARCHIVE"
    echo "✓ Removed $OPENWEBUI_ARCHIVE" | tee -a "$LOG_FILE"

    # Create proper structure for future exports
    mkdir -p "$DATAROOM/06-KNOWLEDGE-BASE/AI-Sessions/OpenWebUI"
    echo "✓ Created proper export directory" | tee -a "$LOG_FILE"

    # Create README explaining the new structure
    cat > "$DATAROOM/06-KNOWLEDGE-BASE/AI-Sessions/OpenWebUI/README.md" << 'ENDOFREADME'
# OpenWebUI Chat Exports

This directory contains exported chat transcripts from OpenWebUI.

## Structure

```
OpenWebUI/
├── YYYY-MM-DD/
│   ├── chat-title-1.md          # Human-readable Markdown
│   ├── chat-title-1.json        # Structured data
│   ├── chat-title-2.md
│   └── chat-title-2.json
└── README.md                     # This file
```

## Export Process

Chats are exported daily via `/home/zaks/scripts/export_openwebui_chats.py`

## Notes

- Raw OpenWebUI database (`webui.db`) is backed up separately to `/home/zaks/backups/openwebui/`
- Model caches and vector stores are NOT stored here (ephemeral, can regenerate)
- These exports are synced to SharePoint and indexed in RAG
ENDOFREADME

    # Add date to README
    echo "" >> "$DATAROOM/06-KNOWLEDGE-BASE/AI-Sessions/OpenWebUI/README.md"
    echo "---" >> "$DATAROOM/06-KNOWLEDGE-BASE/AI-Sessions/OpenWebUI/README.md"
    echo "Last updated: $(date +%Y-%m-%d)" >> "$DATAROOM/06-KNOWLEDGE-BASE/AI-Sessions/OpenWebUI/README.md"

    echo "✓ Created README in export directory" | tee -a "$LOG_FILE"

else
    echo "OpenWebUI archive not found at $OPENWEBUI_ARCHIVE" | tee -a "$LOG_FILE"
fi

echo "" | tee -a "$LOG_FILE"
echo "=== Cleanup Complete ===" | tee -a "$LOG_FILE"

# Report new size
echo "" | tee -a "$LOG_FILE"
NEW_SIZE=$(du -sh "$DATAROOM" 2>/dev/null | cut -f1)
echo "New DataRoom size: $NEW_SIZE" | tee -a "$LOG_FILE"
