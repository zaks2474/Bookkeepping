#!/usr/bin/env python3
"""
Deferred Action Queue

Schedules and manages future actions for year-spanning deal workflows.
Enables:
- Follow-up reminders (e.g., "check back in 90 days")
- Milestone triggers (e.g., "review financials quarterly")
- Deadline enforcement (e.g., "LOI expires in 30 days")
- Integration checkpoints (e.g., "100-day review")

Storage: JSON file with atomic updates and file locking.
Execution: Separate cron job checks for due actions.
"""

from __future__ import annotations

import fcntl
import hashlib
import json
import os
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional


# Action types
ACTION_TYPES = {
    # Follow-up actions
    "follow_up": "Generic follow-up reminder",
    "check_status": "Check deal status with broker",
    "request_update": "Request update from counterparty",

    # Document actions
    "request_cim": "Request CIM/Teaser",
    "request_financials": "Request financial documents",
    "review_nda": "Review NDA status",

    # Milestone actions
    "quarterly_review": "Quarterly deal review",
    "monthly_check": "Monthly status check",
    "integration_milestone": "Integration milestone review",

    # Deadline actions
    "loi_expiration": "LOI expiration warning",
    "exclusivity_end": "Exclusivity period ending",
    "due_diligence_deadline": "DD deadline approaching",

    # AI actions
    "ai_analysis": "Trigger AI analysis",
    "market_update": "Check market conditions",
    "valuation_refresh": "Refresh valuation model",
}


def _gen_action_id() -> str:
    """Generate unique action ID"""
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")
    nonce = hashlib.sha256(f"{ts}:{os.getpid()}:{uuid.uuid4()}".encode()).hexdigest()[:8]
    return f"ACT-{ts}-{nonce}"


def _now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _parse_iso(s: str) -> datetime:
    """Parse ISO timestamp to datetime"""
    s = s.replace("Z", "+00:00")
    return datetime.fromisoformat(s)


@dataclass
class DeferredAction:
    """A scheduled future action"""
    action_id: str
    deal_id: str
    action_type: str
    scheduled_for: str  # ISO timestamp
    created_at: str
    priority: str = "normal"  # low, normal, high, critical
    data: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    status: str = "pending"  # pending, executed, cancelled, failed
    executed_at: Optional[str] = None
    result: Optional[Dict[str, Any]] = None
    recurrence: Optional[str] = None  # daily, weekly, monthly, quarterly, yearly, or cron expr

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "DeferredAction":
        return cls(
            action_id=d.get("action_id", ""),
            deal_id=d.get("deal_id", ""),
            action_type=d.get("action_type", ""),
            scheduled_for=d.get("scheduled_for", ""),
            created_at=d.get("created_at", ""),
            priority=d.get("priority", "normal"),
            data=d.get("data") or {},
            metadata=d.get("metadata") or {},
            status=d.get("status", "pending"),
            executed_at=d.get("executed_at"),
            result=d.get("result"),
            recurrence=d.get("recurrence"),
        )

    def is_due(self, as_of: Optional[datetime] = None) -> bool:
        """Check if action is due for execution"""
        if self.status != "pending":
            return False
        as_of = as_of or datetime.now(timezone.utc)
        scheduled = _parse_iso(self.scheduled_for)
        return scheduled <= as_of


class DeferredActionQueue:
    """
    Manages scheduled actions with persistent JSON storage.

    Thread-safe via file locking for concurrent access.
    """

    def __init__(self, storage_path: Optional[str] = None):
        self.storage_path = Path(
            storage_path or
            os.getenv("DEFERRED_ACTIONS_PATH", "/home/zaks/DataRoom/.deal-registry/deferred_actions.json")
        )
        self._ensure_storage()

    def _ensure_storage(self) -> None:
        """Initialize storage file if it doesn't exist"""
        self.storage_path.parent.mkdir(parents=True, exist_ok=True)
        if not self.storage_path.exists():
            self._save({"schema_version": "1.0", "updated_at": None, "actions": {}})

    def _load(self) -> Dict[str, Any]:
        """Load storage file"""
        try:
            with open(self.storage_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, FileNotFoundError):
            return {"schema_version": "1.0", "updated_at": None, "actions": {}}

    def _save(self, data: Dict[str, Any]) -> None:
        """Save to storage with atomic write"""
        data["updated_at"] = _now_iso()
        tmp_path = self.storage_path.with_suffix(".tmp")
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False, default=str)
            f.write("\n")
        os.replace(tmp_path, self.storage_path)

    def _with_lock(self, fn: Callable[[Dict[str, Any]], Dict[str, Any]]) -> Dict[str, Any]:
        """Execute function with file lock"""
        with open(self.storage_path, "r+", encoding="utf-8") as f:
            if fcntl:
                try:
                    fcntl.flock(f.fileno(), fcntl.LOCK_EX)
                except Exception:
                    pass

            f.seek(0)
            try:
                data = json.load(f)
            except json.JSONDecodeError:
                data = {"schema_version": "1.0", "updated_at": None, "actions": {}}

            result = fn(data)

            f.seek(0)
            f.truncate()
            result["updated_at"] = _now_iso()
            json.dump(result, f, indent=2, ensure_ascii=False, default=str)
            f.write("\n")
            return result

    def schedule(self, action: DeferredAction) -> str:
        """
        Schedule a new action.

        Returns the action ID.
        """
        def add_action(data: Dict[str, Any]) -> Dict[str, Any]:
            if "actions" not in data:
                data["actions"] = {}
            data["actions"][action.action_id] = action.to_dict()
            return data

        self._with_lock(add_action)
        return action.action_id

    def schedule_relative(
        self,
        deal_id: str,
        action_type: str,
        days_from_now: int,
        priority: str = "normal",
        data: Optional[Dict[str, Any]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        recurrence: Optional[str] = None,
    ) -> str:
        """
        Schedule an action relative to now.

        Returns the action ID.
        """
        scheduled_for = datetime.now(timezone.utc) + timedelta(days=days_from_now)
        action = DeferredAction(
            action_id=_gen_action_id(),
            deal_id=deal_id,
            action_type=action_type,
            scheduled_for=scheduled_for.isoformat().replace("+00:00", "Z"),
            created_at=_now_iso(),
            priority=priority,
            data=data or {},
            metadata=metadata or {},
            recurrence=recurrence,
        )
        return self.schedule(action)

    def schedule_at(
        self,
        deal_id: str,
        action_type: str,
        scheduled_for: datetime,
        priority: str = "normal",
        data: Optional[Dict[str, Any]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        recurrence: Optional[str] = None,
    ) -> str:
        """
        Schedule an action at a specific time.

        Returns the action ID.
        """
        if scheduled_for.tzinfo is None:
            scheduled_for = scheduled_for.replace(tzinfo=timezone.utc)

        action = DeferredAction(
            action_id=_gen_action_id(),
            deal_id=deal_id,
            action_type=action_type,
            scheduled_for=scheduled_for.isoformat().replace("+00:00", "Z"),
            created_at=_now_iso(),
            priority=priority,
            data=data or {},
            metadata=metadata or {},
            recurrence=recurrence,
        )
        return self.schedule(action)

    def get_due_actions(self, as_of: Optional[datetime] = None) -> List[DeferredAction]:
        """Get all actions that are due for execution"""
        as_of = as_of or datetime.now(timezone.utc)
        data = self._load()
        actions = data.get("actions", {})

        due: List[DeferredAction] = []
        for action_dict in actions.values():
            action = DeferredAction.from_dict(action_dict)
            if action.is_due(as_of):
                due.append(action)

        # Sort by priority and scheduled time
        priority_order = {"critical": 0, "high": 1, "normal": 2, "low": 3}
        due.sort(key=lambda a: (priority_order.get(a.priority, 2), a.scheduled_for))
        return due

    def get_action(self, action_id: str) -> Optional[DeferredAction]:
        """Get a specific action by ID"""
        data = self._load()
        action_dict = data.get("actions", {}).get(action_id)
        if action_dict:
            return DeferredAction.from_dict(action_dict)
        return None

    def get_actions_for_deal(
        self,
        deal_id: str,
        status: Optional[str] = None,
    ) -> List[DeferredAction]:
        """Get all actions for a deal"""
        data = self._load()
        actions = data.get("actions", {})

        result: List[DeferredAction] = []
        for action_dict in actions.values():
            action = DeferredAction.from_dict(action_dict)
            if action.deal_id == deal_id:
                if status is None or action.status == status:
                    result.append(action)

        result.sort(key=lambda a: a.scheduled_for)
        return result

    def mark_executed(
        self,
        action_id: str,
        result: Optional[Dict[str, Any]] = None,
    ) -> bool:
        """Mark an action as executed"""
        def update_action(data: Dict[str, Any]) -> Dict[str, Any]:
            actions = data.get("actions", {})
            if action_id not in actions:
                return data

            actions[action_id]["status"] = "executed"
            actions[action_id]["executed_at"] = _now_iso()
            if result:
                actions[action_id]["result"] = result

            # Handle recurrence
            action = DeferredAction.from_dict(actions[action_id])
            if action.recurrence:
                next_action = self._create_next_recurrence(action)
                if next_action:
                    actions[next_action.action_id] = next_action.to_dict()

            data["actions"] = actions
            return data

        self._with_lock(update_action)
        return True

    def mark_failed(
        self,
        action_id: str,
        error: str,
    ) -> bool:
        """Mark an action as failed"""
        def update_action(data: Dict[str, Any]) -> Dict[str, Any]:
            actions = data.get("actions", {})
            if action_id not in actions:
                return data

            actions[action_id]["status"] = "failed"
            actions[action_id]["executed_at"] = _now_iso()
            actions[action_id]["result"] = {"error": error}
            data["actions"] = actions
            return data

        self._with_lock(update_action)
        return True

    def cancel(self, action_id: str, reason: str = "") -> bool:
        """Cancel a pending action"""
        def update_action(data: Dict[str, Any]) -> Dict[str, Any]:
            actions = data.get("actions", {})
            if action_id not in actions:
                return data
            if actions[action_id].get("status") != "pending":
                return data

            actions[action_id]["status"] = "cancelled"
            actions[action_id]["result"] = {"cancelled_reason": reason, "cancelled_at": _now_iso()}
            data["actions"] = actions
            return data

        self._with_lock(update_action)
        return True

    def _create_next_recurrence(self, action: DeferredAction) -> Optional[DeferredAction]:
        """Create next occurrence for recurring actions"""
        if not action.recurrence:
            return None

        scheduled = _parse_iso(action.scheduled_for)

        if action.recurrence == "daily":
            next_time = scheduled + timedelta(days=1)
        elif action.recurrence == "weekly":
            next_time = scheduled + timedelta(weeks=1)
        elif action.recurrence == "monthly":
            # Approximate month
            next_time = scheduled + timedelta(days=30)
        elif action.recurrence == "quarterly":
            next_time = scheduled + timedelta(days=90)
        elif action.recurrence == "yearly":
            next_time = scheduled + timedelta(days=365)
        else:
            return None

        return DeferredAction(
            action_id=_gen_action_id(),
            deal_id=action.deal_id,
            action_type=action.action_type,
            scheduled_for=next_time.isoformat().replace("+00:00", "Z"),
            created_at=_now_iso(),
            priority=action.priority,
            data=action.data,
            metadata={**action.metadata, "recurrence_parent": action.action_id},
            recurrence=action.recurrence,
        )

    def stats(self) -> Dict[str, Any]:
        """Get queue statistics"""
        data = self._load()
        actions = data.get("actions", {})

        stats = {
            "total": len(actions),
            "by_status": {},
            "by_type": {},
            "by_priority": {},
            "due_now": 0,
        }

        now = datetime.now(timezone.utc)
        for action_dict in actions.values():
            action = DeferredAction.from_dict(action_dict)

            stats["by_status"][action.status] = stats["by_status"].get(action.status, 0) + 1
            stats["by_type"][action.action_type] = stats["by_type"].get(action.action_type, 0) + 1
            stats["by_priority"][action.priority] = stats["by_priority"].get(action.priority, 0) + 1

            if action.is_due(now):
                stats["due_now"] += 1

        return stats


# Convenience functions for common action patterns
def schedule_follow_up(
    queue: DeferredActionQueue,
    deal_id: str,
    days: int,
    message: str = "",
    priority: str = "normal",
) -> str:
    """Schedule a follow-up reminder"""
    return queue.schedule_relative(
        deal_id=deal_id,
        action_type="follow_up",
        days_from_now=days,
        priority=priority,
        data={"message": message},
    )


def schedule_quarterly_review(
    queue: DeferredActionQueue,
    deal_id: str,
    start_from: Optional[datetime] = None,
) -> str:
    """Schedule recurring quarterly review"""
    start = start_from or datetime.now(timezone.utc) + timedelta(days=90)
    return queue.schedule_at(
        deal_id=deal_id,
        action_type="quarterly_review",
        scheduled_for=start,
        priority="normal",
        recurrence="quarterly",
    )


def schedule_loi_expiration(
    queue: DeferredActionQueue,
    deal_id: str,
    expiration_date: datetime,
    warning_days: int = 7,
) -> str:
    """Schedule LOI expiration warning"""
    warning_date = expiration_date - timedelta(days=warning_days)
    return queue.schedule_at(
        deal_id=deal_id,
        action_type="loi_expiration",
        scheduled_for=warning_date,
        priority="high",
        data={
            "expiration_date": expiration_date.isoformat(),
            "warning_days": warning_days,
        },
    )


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Deferred Action Queue CLI")
    parser.add_argument("command", choices=["stats", "due", "list", "schedule", "execute", "cancel"])
    parser.add_argument("--deal-id", help="Deal ID")
    parser.add_argument("--action-id", help="Action ID")
    parser.add_argument("--action-type", default="follow_up", help="Action type")
    parser.add_argument("--days", type=int, default=30, help="Days from now")
    parser.add_argument("--message", default="", help="Action message")
    parser.add_argument("--priority", default="normal", choices=["low", "normal", "high", "critical"])
    args = parser.parse_args()

    queue = DeferredActionQueue()

    if args.command == "stats":
        stats = queue.stats()
        print(json.dumps(stats, indent=2))

    elif args.command == "due":
        due = queue.get_due_actions()
        print(f"Due actions: {len(due)}")
        for action in due:
            print(f"  [{action.priority}] {action.action_id}: {action.action_type} for {action.deal_id}")
            print(f"       Scheduled: {action.scheduled_for}")

    elif args.command == "list":
        if args.deal_id:
            actions = queue.get_actions_for_deal(args.deal_id)
            print(f"Actions for {args.deal_id}: {len(actions)}")
        else:
            data = queue._load()
            actions = [DeferredAction.from_dict(a) for a in data.get("actions", {}).values()]
            print(f"All actions: {len(actions)}")

        for action in sorted(actions, key=lambda a: a.scheduled_for):
            print(f"  [{action.status}] {action.action_id}: {action.action_type}")
            print(f"       Deal: {action.deal_id}, Scheduled: {action.scheduled_for}")

    elif args.command == "schedule":
        if not args.deal_id:
            print("Error: --deal-id required")
            raise SystemExit(1)

        action_id = queue.schedule_relative(
            deal_id=args.deal_id,
            action_type=args.action_type,
            days_from_now=args.days,
            priority=args.priority,
            data={"message": args.message} if args.message else {},
        )
        print(f"Scheduled action: {action_id}")

    elif args.command == "execute":
        if not args.action_id:
            print("Error: --action-id required")
            raise SystemExit(1)
        queue.mark_executed(args.action_id, {"executed_via": "cli"})
        print(f"Marked executed: {args.action_id}")

    elif args.command == "cancel":
        if not args.action_id:
            print("Error: --action-id required")
            raise SystemExit(1)
        queue.cancel(args.action_id, "Cancelled via CLI")
        print(f"Cancelled: {args.action_id}")
