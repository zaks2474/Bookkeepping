#!/usr/bin/env python3
"""
Deterministic CSV Patch Applier

Applies machine-readable patch JSON files produced by agents (proposal-only by default)
to CSV trackers such as:
  - /home/zaks/DataRoom/03-DEAL-SOURCES/BROKER-TRACKER.csv
  - /home/zaks/DataRoom/00-PIPELINE/MASTER-DEAL-TRACKER.csv

This tool is intentionally non-LLM and deterministic.

Patch JSON format (v1):
{
  "patch_version": "1.0",
  "generated_at": "2025-12-14T...",
  "target_csv_path": "/path/to/file.csv",
  "key_column": "Email",
  "operations": [
    {
      "op": "update" | "upsert",
      "key": "value in key_column",
      "changes": {"Column": "New Value", "...": "..."},
      "reason": "optional string"
    }
  ]
}
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Tuple


def read_patch(path: Path) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def read_csv(path: Path) -> Tuple[List[str], List[Dict[str, str]]]:
    with open(path, "r", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        fieldnames = reader.fieldnames or []
        rows = [{k: (v or "") for k, v in row.items()} for row in reader]
    return fieldnames, rows


def write_csv_atomic(path: Path, fieldnames: List[str], rows: List[Dict[str, str]]) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: row.get(k, "") for k in fieldnames})
    tmp.replace(path)


def normalize_value(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, (int, float)):
        return str(value)
    s = str(value)
    s = s.replace("\r", " ").replace("\n", " ").strip()
    return s


def apply_patch_to_rows(
    *,
    fieldnames: List[str],
    rows: List[Dict[str, str]],
    key_column: str,
    operations: List[Dict[str, Any]],
    allow_new_columns: bool,
) -> Tuple[List[str], List[Dict[str, str]], List[str]]:
    if key_column not in fieldnames:
        raise ValueError(f"key_column '{key_column}' not found in CSV headers: {fieldnames}")

    index = {}
    for i, row in enumerate(rows):
        k = (row.get(key_column) or "").strip()
        if k:
            index[k] = i

    warnings: List[str] = []

    for op in operations:
        if not isinstance(op, dict):
            warnings.append("Skipping non-dict operation")
            continue
        op_type = str(op.get("op") or "").strip().lower()
        key = normalize_value(op.get("key")).strip()
        changes = op.get("changes")
        if op_type not in {"update", "upsert"}:
            warnings.append(f"Skipping unsupported op: {op_type}")
            continue
        if not key:
            warnings.append("Skipping op with empty key")
            continue
        if not isinstance(changes, dict) or not changes:
            warnings.append(f"Skipping op with no changes for key={key}")
            continue

        # Filter/normalize changes
        norm_changes: Dict[str, str] = {}
        for col, val in changes.items():
            col_name = str(col).strip()
            if not col_name:
                continue
            if col_name not in fieldnames:
                if allow_new_columns:
                    fieldnames.append(col_name)
                else:
                    warnings.append(f"Ignoring unknown column '{col_name}' (use --allow-new-columns to add)")
                    continue
            norm_changes[col_name] = normalize_value(val)

        if not norm_changes:
            continue

        if key in index:
            row = rows[index[key]]
            for col_name, val in norm_changes.items():
                row[col_name] = val
        else:
            if op_type == "update":
                warnings.append(f"update skipped; key not found: {key}")
                continue
            # upsert: add row
            new_row = {fn: "" for fn in fieldnames}
            new_row[key_column] = key
            for col_name, val in norm_changes.items():
                new_row[col_name] = val
            rows.append(new_row)
            index[key] = len(rows) - 1

    return fieldnames, rows, warnings


def apply_patch_file(
    patch: Dict[str, Any],
    allow_new_columns: bool,
) -> Tuple[Path, List[str], List[str], List[Dict[str, str]]]:
    target = Path(str(patch.get("target_csv_path") or ""))
    if not target.exists():
        raise FileNotFoundError(f"target_csv_path not found: {target}")

    key_column = str(patch.get("key_column") or "").strip()
    if not key_column:
        raise ValueError("patch missing key_column")

    ops = patch.get("operations")
    if not isinstance(ops, list) or not ops:
        raise ValueError("patch.operations must be a non-empty list")

    fieldnames, rows = read_csv(target)
    fieldnames, rows, warnings = apply_patch_to_rows(
        fieldnames=fieldnames,
        rows=rows,
        key_column=key_column,
        operations=[op for op in ops if isinstance(op, dict)],
        allow_new_columns=allow_new_columns,
    )
    return target, warnings, fieldnames, rows


def main() -> None:
    parser = argparse.ArgumentParser(description="Apply deterministic CSV patch JSON")
    parser.add_argument("patch_file", help="Path to patch JSON file")
    parser.add_argument("--dry-run", action="store_true", help="Validate and show warnings without writing")
    parser.add_argument("--allow-new-columns", action="store_true", help="Allow patch to add new CSV columns")
    parser.add_argument("--no-backup", action="store_true", help="Do not create .bak-* backup file")
    args = parser.parse_args()

    patch_path = Path(args.patch_file)
    if not patch_path.exists():
        print(f"Patch file not found: {patch_path}", file=sys.stderr)
        sys.exit(2)

    patch = read_patch(patch_path)
    target = Path(str(patch.get("target_csv_path") or ""))

    if args.dry_run:
        try:
            _, warnings, _, _ = apply_patch_file(patch, allow_new_columns=args.allow_new_columns)
        except Exception as e:
            print(f"DRY RUN failed: {e}", file=sys.stderr)
            sys.exit(2)
        print(f"DRY RUN OK: {target}")
        if warnings:
            print("Warnings:")
            for w in warnings:
                print(f"- {w}")
        sys.exit(0)

    # Backup
    if not args.no_backup and target.exists():
        ts = datetime.now().strftime("%Y%m%d-%H%M%S")
        backup = target.with_suffix(target.suffix + f".bak-{ts}")
        backup.write_bytes(target.read_bytes())

    # Apply and write
    try:
        target2, warnings, fieldnames, rows = apply_patch_file(patch, allow_new_columns=args.allow_new_columns)
        write_csv_atomic(target2, fieldnames=fieldnames, rows=rows)
    except Exception as e:
        print(f"Apply failed: {e}", file=sys.stderr)
        sys.exit(1)

    print(f"Applied patch to: {target}")
    if warnings:
        print("Warnings:")
        for w in warnings:
            print(f"- {w}")


if __name__ == "__main__":
    main()
