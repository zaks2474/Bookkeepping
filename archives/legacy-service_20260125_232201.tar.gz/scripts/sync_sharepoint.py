#!/usr/bin/env python3
"""
SharePoint DataRoom Sync (Graph API) - Registry Integrated

Syncs DataRoom to SharePoint using Microsoft Graph API.
Integrates with Deal Registry to only sync active, non-junk content.

Features:
- Excludes archived and junk deal folders
- Uses deal registry for smart filtering
- Preserves exact dataroom folder structure
- Hash-based change detection for efficiency

Usage:
  ./sync_sharepoint.py              # Normal sync
  ./sync_sharepoint.py --dry-run    # Preview changes
  ./sync_sharepoint.py --force      # Force re-upload all files
  ./sync_sharepoint.py --active     # Only sync active pipeline deals
"""

import os
import sys
import json
import requests
import hashlib
import argparse
import logging
from pathlib import Path
from datetime import datetime
import time

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Best-effort secret scanning (prevents obvious secrets from being uploaded).
try:
    from zakops_secret_scan import scan_file_for_secrets
    SECRET_SCAN_AVAILABLE = True
except Exception:
    SECRET_SCAN_AVAILABLE = False

SECRET_SCAN_ENABLED = os.getenv("ZAKOPS_SHAREPOINT_SECRET_SCAN", "1").strip().lower() not in {
    "0",
    "false",
    "no",
    "off",
}
SECRET_SCAN_MAX_BYTES = int(os.getenv("ZAKOPS_SECRET_SCAN_MAX_BYTES", "2000000"))
SECRET_SCAN_EXTENSIONS = {".md", ".txt", ".csv", ".json", ".jsonl", ".yaml", ".yml"}


class SecretDetectedError(RuntimeError):
    def __init__(self, file_path: Path, findings: list[str]):
        super().__init__("secret_detected")
        self.file_path = file_path
        self.findings = findings


def ensure_no_secrets(file_path: Path) -> None:
    if not SECRET_SCAN_ENABLED or not SECRET_SCAN_AVAILABLE:
        return
    if file_path.suffix.lower() not in SECRET_SCAN_EXTENSIONS:
        return
    findings = scan_file_for_secrets(file_path, max_bytes=SECRET_SCAN_MAX_BYTES)
    if findings:
        raise SecretDetectedError(file_path, findings)

# Deal Registry integration
try:
    sys.path.insert(0, '/home/zaks/scripts')
    from deal_registry import DealRegistry
    REGISTRY_AVAILABLE = True
except ImportError:
    REGISTRY_AVAILABLE = False
    logger.warning("Deal registry not available, syncing all folders")

# Load config
CONFIG_PATH = "/home/zaks/Zaks-llm/sharepoint-mcp-server/config.json"
CACHE_PATH = "/home/zaks/.cache/sharepoint_sync_hashes.json"
REGISTRY_PATH = "/home/zaks/DataRoom/.deal-registry/deal_registry.json"

with open(CONFIG_PATH, 'r') as f:
    config = json.load(f)

TENANT_ID = config['azure']['tenant_id']
CLIENT_ID = config['azure']['client_id']
CLIENT_SECRET = config['azure']['client_secret']
SITE_NAME = "ZakOpsDataRoom"

# Directories to sync
SYNC_MAPPINGS = {
    "/home/zaks/DataRoom": "DataRoom",
}

# Files/patterns to exclude
EXCLUDE_PATTERNS = [
    ".git", "__pycache__", "node_modules", ".DS_Store", "Thumbs.db",
    ".pyc", ".log", ".tmp", ".db", ".pem", ".key", ".env",
    "vector_db", "/cache/", "openwebui-chats", "{", "}",
    # Exclude archive and junk folders
    "Archive/_JUNK", "_JUNK/", "/Archive/", "/.deal-registry/",
]

# Folder names to completely skip (case-insensitive)
EXCLUDE_FOLDER_NAMES = {
    "_junk", "archive", ".deal-registry",
    "registry_backup", "__pycache__", ".git", "node_modules"
}

EXCLUDE_EXTENSIONS = {".pyc", ".log", ".tmp", ".db", ".pem", ".key", ".sqlite", ".json.bak"}

MAX_FILE_SIZE_MB = 50

# Characters not allowed in SharePoint/OneDrive file names
INVALID_SP_CHARS = '<>:"\\|?*'
CONTROL_CHARS = '\r\n\t\x00\x01\x02\x03\x04\x05\x06\x07\x08\x0b\x0c\x0e\x0f'


def sanitize_sharepoint_path(path):
    """Sanitize path for SharePoint compatibility"""
    # Remove control characters
    for char in CONTROL_CHARS:
        path = path.replace(char, '')
    # Replace invalid characters with underscore
    for char in INVALID_SP_CHARS:
        path = path.replace(char, '_')
    # Remove leading/trailing spaces and dots from path components
    parts = path.split('/')
    sanitized_parts = []
    for part in parts:
        part = part.strip(' .')
        # Collapse multiple underscores
        while '__' in part:
            part = part.replace('__', '_')
        if part:
            sanitized_parts.append(part)
    return '/'.join(sanitized_parts)


def load_hash_cache():
    """Load previous file hashes"""
    if os.path.exists(CACHE_PATH):
        with open(CACHE_PATH, 'r') as f:
            return json.load(f)
    return {}


def save_hash_cache(cache):
    """Save file hashes"""
    os.makedirs(os.path.dirname(CACHE_PATH), exist_ok=True)
    with open(CACHE_PATH, 'w') as f:
        json.dump(cache, f, indent=2)


def file_hash(filepath):
    """Get file signature (size + mtime)"""
    stat = os.stat(filepath)
    return f"{stat.st_size}:{stat.st_mtime_ns}"


def should_exclude(filepath, junk_folders=None):
    """Check if file should be excluded"""
    path_str = str(filepath)
    path_lower = path_str.lower()

    # Check folder names in path
    path_parts = Path(filepath).parts
    for part in path_parts:
        if part.lower() in EXCLUDE_FOLDER_NAMES:
            return True

    # Check patterns
    for pattern in EXCLUDE_PATTERNS:
        if pattern.lower() in path_lower:
            return True

    # Check if this is inside a junk folder from registry
    if junk_folders:
        for junk_folder in junk_folders:
            if junk_folder.lower() in path_lower:
                return True

    # Check extensions
    if os.path.splitext(filepath)[1].lower() in EXCLUDE_EXTENSIONS:
        return True

    # Check file size
    if os.path.isfile(filepath):
        size_mb = os.path.getsize(filepath) / (1024 * 1024)
        if size_mb > MAX_FILE_SIZE_MB:
            return True

    return False


def get_junk_folders_from_registry():
    """Get list of junk deal folder names from registry"""
    if not REGISTRY_AVAILABLE:
        return set()

    try:
        registry = DealRegistry(REGISTRY_PATH)
        junk_folders = set()

        for deal in registry.deals.values():
            if deal.status in ('junk', 'archived', 'merged'):
                if deal.folder_path:
                    # Extract folder name from path
                    folder_name = Path(deal.folder_path).name
                    junk_folders.add(folder_name)

                # Also add related folders
                for related in deal.related_folders:
                    junk_folders.add(Path(related).name)

        logger.info(f"Loaded {len(junk_folders)} junk/archived folders from registry")
        return junk_folders

    except Exception as e:
        logger.warning(f"Failed to load registry: {e}")
        return set()


def get_active_deal_folders():
    """Get list of active deal folder paths from registry"""
    if not REGISTRY_AVAILABLE:
        return None  # None means sync all

    try:
        registry = DealRegistry(REGISTRY_PATH)
        active_folders = set()

        for deal in registry.deals.values():
            if deal.status == 'active' and deal.folder_path:
                active_folders.add(deal.folder_path)

        logger.info(f"Found {len(active_folders)} active deal folders")
        return active_folders

    except Exception as e:
        logger.warning(f"Failed to load registry: {e}")
        return None


def get_token():
    """Get Microsoft Graph API access token"""
    url = f"https://login.microsoftonline.com/{TENANT_ID}/oauth2/v2.0/token"
    data = {
        'client_id': CLIENT_ID,
        'client_secret': CLIENT_SECRET,
        'scope': 'https://graph.microsoft.com/.default',
        'grant_type': 'client_credentials'
    }

    response = requests.post(url, data=data)
    if response.status_code == 200:
        return response.json()['access_token']
    else:
        print(f"❌ Failed to get token: {response.text}")
        return None


def get_site_id(token):
    """Get SharePoint site ID"""
    hostname = "zaks24.sharepoint.com"
    url = f"https://graph.microsoft.com/v1.0/sites/{hostname}:/sites/{SITE_NAME}"
    headers = {'Authorization': f'Bearer {token}'}

    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        return response.json()['id']
    print(f"❌ Failed to get site ID: {response.text}")
    return None


def ensure_folder(token, site_id, folder_path):
    """Create folder if it doesn't exist"""
    if not folder_path or folder_path == '/':
        return True

    parts = folder_path.strip('/').split('/')
    current = ""

    for part in parts:
        parent = current if current else "root"
        current = f"{current}/{part}" if current else part

        # Check if exists
        check_url = f"https://graph.microsoft.com/v1.0/sites/{site_id}/drive/root:/{current}"
        headers = {'Authorization': f'Bearer {token}'}
        resp = requests.get(check_url, headers=headers)

        if resp.status_code == 404:
            # Create folder
            if parent == "root":
                create_url = f"https://graph.microsoft.com/v1.0/sites/{site_id}/drive/root/children"
            else:
                create_url = f"https://graph.microsoft.com/v1.0/sites/{site_id}/drive/root:/{parent}:/children"

            data = {
                'name': part,
                'folder': {},
                '@microsoft.graph.conflictBehavior': 'replace'
            }
            create_resp = requests.post(create_url, headers={
                'Authorization': f'Bearer {token}',
                'Content-Type': 'application/json'
            }, json=data)

            if create_resp.status_code not in [200, 201]:
                return False

    return True


def upload_file(token, site_id, local_path, sharepoint_path):
    """Upload a file to SharePoint"""
    if not os.path.exists(local_path):
        return False, "not found"

    # Ensure parent folder exists
    folder = os.path.dirname(sharepoint_path)
    if folder:
        ensure_folder(token, site_id, folder)

    # Upload file
    with open(local_path, 'rb') as f:
        file_content = f.read()

    url = f"https://graph.microsoft.com/v1.0/sites/{site_id}/drive/root:/{sharepoint_path}:/content"
    headers = {
        'Authorization': f'Bearer {token}',
        'Content-Type': 'application/octet-stream'
    }

    response = requests.put(url, headers=headers, data=file_content)

    if response.status_code in [200, 201]:
        return True, "uploaded"
    else:
        return False, f"error {response.status_code}"


def sync_directory(token, site_id, local_root, sp_root, hash_cache,
                   junk_folders=None, dry_run=False, force=False):
    """Recursively sync a directory to SharePoint"""
    stats = {'uploaded': 0, 'skipped': 0, 'errors': 0, 'unchanged': 0}
    new_hashes = {}

    local_root = Path(local_root)

    for filepath in local_root.rglob('*'):
        if not filepath.is_file():
            continue

        if should_exclude(filepath, junk_folders):
            stats['skipped'] += 1
            continue

        # Calculate relative path and SharePoint path
        rel_path = filepath.relative_to(local_root)
        sp_path = f"{sp_root}/{rel_path}".replace('\\', '/')
        sp_path = sanitize_sharepoint_path(sp_path)

        # Check if file changed
        current_hash = file_hash(filepath)
        cache_key = str(filepath)

        if not force and cache_key in hash_cache and hash_cache[cache_key] == current_hash:
            stats['unchanged'] += 1
            new_hashes[cache_key] = current_hash
            continue

        if dry_run:
            print(f"[DRY RUN] Would upload: {sp_path}")
            stats['uploaded'] += 1
            new_hashes[cache_key] = current_hash
            continue

        # Safety: refuse to upload files containing obvious secret-like material.
        ensure_no_secrets(filepath)

        # Upload file
        success, result = upload_file(token, site_id, str(filepath), sp_path)

        if success:
            print(f"✓ Uploaded: {sp_path}")
            stats['uploaded'] += 1
            new_hashes[cache_key] = current_hash
        else:
            print(f"✗ Error: {sp_path}: {result}")
            stats['errors'] += 1

        time.sleep(0.2)  # Rate limiting

    return stats, new_hashes


def main():
    parser = argparse.ArgumentParser(
        description="Sync DataRoom to SharePoint (Registry Integrated)"
    )
    parser.add_argument('--dry-run', action='store_true',
                        help='Preview changes without uploading')
    parser.add_argument('--force', action='store_true',
                        help='Force re-upload all files')
    parser.add_argument('--active', action='store_true',
                        help='Only sync active deal folders from registry')
    parser.add_argument('--no-registry', action='store_true',
                        help='Disable registry integration')
    args = parser.parse_args()

    started = datetime.now()
    print("=" * 60)
    print("SHAREPOINT DATAROOM SYNC (Registry Integrated)")
    print(f"   {started.strftime('%Y-%m-%d %H:%M:%S')}")
    if args.dry_run:
        print("   [DRY RUN MODE]")
    if args.force:
        print("   [FORCE MODE]")
    print("=" * 60)

    # Load junk folders from registry
    junk_folders = set()
    if not args.no_registry and REGISTRY_AVAILABLE:
        junk_folders = get_junk_folders_from_registry()
        print(f"Registry: {len(junk_folders)} junk/archived folders will be excluded")
    else:
        print("Registry: Disabled or not available")

    # Authenticate
    token = get_token()
    if not token:
        return 1
    print("Authenticated with Microsoft Graph API")

    # Get site ID
    site_id = get_site_id(token)
    if not site_id:
        return 1
    print(f"Site: {SITE_NAME}")
    print()

    # Load hash cache
    hash_cache = load_hash_cache() if not args.force else {}
    all_new_hashes = {}

    total_stats = {'uploaded': 0, 'skipped': 0, 'errors': 0, 'unchanged': 0}

    # Sync each directory
    for local_dir, sp_dir in SYNC_MAPPINGS.items():
        if not os.path.exists(local_dir):
            print(f"Warning: Skipping {local_dir} (not found)")
            continue

        print(f"Syncing: {local_dir} -> {sp_dir}/")
        try:
            stats, new_hashes = sync_directory(
                token, site_id, local_dir, sp_dir, hash_cache,
                junk_folders=junk_folders,
                dry_run=args.dry_run,
                force=args.force
            )
        except SecretDetectedError as exc:
            print("❌ Aborting SharePoint sync due to detected secret-like content.")
            print(f"   File: {exc.file_path}")
            print(f"   Findings: {', '.join(exc.findings)}")
            print("   Remediate the file(s) and rerun. This prevents accidental exfiltration.")
            return 2

        for key in stats:
            total_stats[key] += stats[key]
        all_new_hashes.update(new_hashes)
        print()

    # Save updated hash cache (unless dry run)
    if not args.dry_run:
        save_hash_cache(all_new_hashes)

    # Summary
    print("=" * 60)
    print("SYNC SUMMARY")
    print("=" * 60)
    print(f"Uploaded:   {total_stats['uploaded']}")
    print(f"Unchanged:  {total_stats['unchanged']}")
    print(f"Skipped:    {total_stats['skipped']} (junk/excluded)")
    print(f"Errors:     {total_stats['errors']}")
    print(f"Duration:   {(datetime.now() - started).seconds}s")
    print()
    print(f"SharePoint: https://zaks24.sharepoint.com/sites/ZakOpsDataRoom")

    return 0 if total_stats['errors'] == 0 else 1


if __name__ == "__main__":
    exit(main())
