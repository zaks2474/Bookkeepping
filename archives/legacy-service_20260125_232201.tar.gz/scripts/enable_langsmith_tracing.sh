#!/usr/bin/env bash
#
# Enable LangSmith tracing in safe mode for ZakOps
#
# Usage:
#   source /home/zaks/scripts/enable_langsmith_tracing.sh
#
# This sets environment variables for safe LangSmith tracing.
# IMPORTANT: You must set LANGCHAIN_API_KEY separately (not stored here).
#
# To permanently enable, add to /home/zaks/.bashrc or systemd env file:
#   source /home/zaks/scripts/enable_langsmith_tracing.sh

set -e

echo "Enabling LangSmith safe tracing..."

# Enable tracing
export LANGCHAIN_TRACING_V2=true
export LANGCHAIN_ENDPOINT=https://api.smith.langchain.com

# Project name (traces will appear under this project in LangSmith)
export LANGCHAIN_PROJECT=zakops-production

# Safe mode: hide inputs/outputs by default
export LANGCHAIN_HIDE_INPUTS=true
export LANGCHAIN_HIDE_OUTPUTS=true

# Do NOT allow unredacted content
export ZAKOPS_LANGSMITH_ALLOW_UNREDACTED=false

# Environment tag for filtering traces
export LANGSMITH_ENVIRONMENT=production
export ZAKOPS_ENVIRONMENT=production

# Check if API key is set
if [ -z "$LANGCHAIN_API_KEY" ]; then
    echo "WARNING: LANGCHAIN_API_KEY is not set."
    echo "Set it with: export LANGCHAIN_API_KEY=your-key-here"
    echo ""
    echo "Tracing is configured but will fail without the API key."
else
    echo "LANGCHAIN_API_KEY is set."
fi

echo ""
echo "LangSmith tracing enabled with:"
echo "  LANGCHAIN_TRACING_V2=$LANGCHAIN_TRACING_V2"
echo "  LANGCHAIN_PROJECT=$LANGCHAIN_PROJECT"
echo "  LANGCHAIN_HIDE_INPUTS=$LANGCHAIN_HIDE_INPUTS"
echo "  LANGCHAIN_HIDE_OUTPUTS=$LANGCHAIN_HIDE_OUTPUTS"
echo "  ZAKOPS_LANGSMITH_ALLOW_UNREDACTED=$ZAKOPS_LANGSMITH_ALLOW_UNREDACTED"
echo ""
echo "View traces at: https://smith.langchain.com"
