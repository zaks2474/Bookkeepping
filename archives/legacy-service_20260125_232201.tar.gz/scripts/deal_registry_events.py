#!/usr/bin/env python3
"""
Deal Registry Event Integration

Provides event-enabled wrappers for DealRegistry mutations.
Emits events to the DealEventStore for every registry change.

Usage:
    from deal_registry_events import EventEnabledRegistry

    registry = EventEnabledRegistry("/path/to/registry.json")
    registry.create_deal(...)  # Emits deal_created event
    registry.update_stage(...)  # Emits stage_changed event
"""

from __future__ import annotations

import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

# Add scripts to path
sys.path.insert(0, str(Path(__file__).resolve().parent))

from deal_registry import DealRegistry, Deal, BrokerInfo
from deal_events import (
    DealEventStore,
    emit_deal_created,
    emit_stage_changed,
    emit_document_attached,
    emit_email_received,
)


DEFAULT_REGISTRY_PATH = os.getenv(
    "ZAKOPS_DEAL_REGISTRY_PATH",
    "/home/zaks/DataRoom/.deal-registry/deal_registry.json"
)


class EventEnabledRegistry(DealRegistry):
    """
    DealRegistry with automatic event emission on mutations.

    All mutations are recorded as events in the DealEventStore,
    enabling audit trails and state replay.
    """

    def __init__(
        self,
        registry_path: str = DEFAULT_REGISTRY_PATH,
        event_store: Optional[DealEventStore] = None,
        emit_events: bool = True,
    ):
        super().__init__(registry_path)
        self.event_store = event_store or DealEventStore()
        self.emit_events = emit_events

    def create_deal(
        self,
        deal_id: str,
        canonical_name: str,
        folder_path: str,
        broker: Optional[BrokerInfo] = None,
        source: str = "email_sync",
        actor: str = "system",
        **extra_data,
    ) -> Deal:
        """Create a new deal and emit deal_created event"""
        deal = super().create_deal(
            deal_id=deal_id,
            canonical_name=canonical_name,
            folder_path=folder_path,
            broker=broker,
            source=source,
        )

        if self.emit_events:
            emit_deal_created(
                self.event_store,
                deal_id=deal_id,
                canonical_name=canonical_name,
                stage=deal.stage,
                status=deal.status,
                actor=actor,
                folder_path=folder_path,
                broker_name=broker.name if broker else None,
                source=source,
                **extra_data,
            )

        return deal

    def update_stage(
        self,
        deal_id: str,
        new_stage: str,
        source: str = "manual",
        actor: str = "operator",
        reason: str = "",
    ) -> bool:
        """Update deal stage and emit stage_changed event"""
        deal = self.deals.get(deal_id)
        if not deal:
            return False

        old_stage = deal.stage
        if old_stage == new_stage:
            return True  # No change needed

        deal.stage = new_stage
        deal.updated_at = datetime.now().isoformat()
        deal.add_audit("stage_changed", source, f"Stage: {old_stage} -> {new_stage}. {reason}")

        if self.emit_events:
            emit_stage_changed(
                self.event_store,
                deal_id=deal_id,
                old_stage=old_stage,
                new_stage=new_stage,
                actor=actor,
                reason=reason,
            )

        return True

    def update_status(
        self,
        deal_id: str,
        new_status: str,
        source: str = "manual",
        actor: str = "operator",
        reason: str = "",
    ) -> bool:
        """Update deal status and emit status_changed event"""
        deal = self.deals.get(deal_id)
        if not deal:
            return False

        old_status = deal.status
        if old_status == new_status:
            return True

        deal.status = new_status
        deal.updated_at = datetime.now().isoformat()
        deal.add_audit("status_changed", source, f"Status: {old_status} -> {new_status}. {reason}")

        if self.emit_events:
            self.event_store.create_event(
                deal_id=deal_id,
                event_type="status_changed",
                actor=actor,
                data={
                    "old_status": old_status,
                    "new_status": new_status,
                    "reason": reason,
                },
            )

        return True

    def add_alias(
        self,
        deal_id: str,
        alias: str,
        alias_type: str,
        confidence: float = 1.0,
        source: str = "manual",
        actor: str = "system",
    ) -> bool:
        """Add alias to deal and emit alias_added event"""
        added = super().add_alias(deal_id, alias, alias_type, confidence, source)

        if added and self.emit_events:
            self.event_store.create_event(
                deal_id=deal_id,
                event_type="alias_added",
                actor=actor,
                data={
                    "alias": alias,
                    "alias_type": alias_type,
                    "confidence": confidence,
                },
            )

        return added

    def archive_deal(
        self,
        deal_id: str,
        reason: str = "",
        source: str = "manual",
        actor: str = "operator",
    ):
        """Archive deal and emit status_changed event"""
        deal = self.deals.get(deal_id)
        if not deal:
            return

        old_status = deal.status
        old_stage = deal.stage
        super().archive_deal(deal_id, reason, source)

        if self.emit_events:
            self.event_store.create_event(
                deal_id=deal_id,
                event_type="status_changed",
                actor=actor,
                data={
                    "old_status": old_status,
                    "new_status": "archived",
                    "old_stage": old_stage,
                    "new_stage": "archive",
                    "reason": reason,
                },
            )

    def mark_junk(
        self,
        deal_id: str,
        reason: str = "",
        source: str = "manual",
        actor: str = "operator",
    ):
        """Mark deal as junk and emit status_changed event"""
        deal = self.deals.get(deal_id)
        if not deal:
            return

        old_status = deal.status
        old_stage = deal.stage
        super().mark_junk(deal_id, reason, source)

        if self.emit_events:
            self.event_store.create_event(
                deal_id=deal_id,
                event_type="status_changed",
                actor=actor,
                data={
                    "old_status": old_status,
                    "new_status": "junk",
                    "old_stage": old_stage,
                    "new_stage": "archive",
                    "junk_reason": reason,
                },
            )

    def merge_deals(
        self,
        source_deal_id: str,
        target_deal_id: str,
        source: str = "manual",
        actor: str = "operator",
    ) -> dict:
        """Merge deals and emit folder_merged events"""
        result = super().merge_deals(source_deal_id, target_deal_id, source)

        if result.get("success") and self.emit_events:
            # Event for source deal (being merged)
            self.event_store.create_event(
                deal_id=source_deal_id,
                event_type="folder_merged",
                actor=actor,
                data={
                    "merge_direction": "source",
                    "target_deal_id": target_deal_id,
                    "aliases_transferred": result.get("aliases_merged", 0),
                },
            )

            # Event for target deal (receiving merge)
            self.event_store.create_event(
                deal_id=target_deal_id,
                event_type="folder_merged",
                actor=actor,
                data={
                    "merge_direction": "target",
                    "source_deal_id": source_deal_id,
                    "aliases_received": result.get("aliases_merged", 0),
                    "source_folder": result.get("source_folder"),
                },
            )

        return result

    def attach_document(
        self,
        deal_id: str,
        document_path: str,
        doc_type: str,
        actor: str = "system",
        **extra_data,
    ) -> bool:
        """Attach document to deal and emit document_attached event"""
        deal = self.deals.get(deal_id)
        if not deal:
            return False

        # Update metadata based on doc type
        if doc_type.lower() in ("cim", "teaser", "executive_summary"):
            deal.metadata.cim_received = True
            deal.add_audit("cim_received", "document_attach", f"CIM received: {document_path}")
        elif doc_type.lower() == "nda":
            if deal.metadata.nda_status == "none":
                deal.metadata.nda_status = "pending"
            deal.add_audit("nda_attached", "document_attach", f"NDA attached: {document_path}")

        deal.updated_at = datetime.now().isoformat()

        if self.emit_events:
            emit_document_attached(
                self.event_store,
                deal_id=deal_id,
                path=document_path,
                doc_type=doc_type,
                actor=actor,
                **extra_data,
            )

        return True

    def record_email(
        self,
        deal_id: str,
        message_id: str,
        subject: str,
        sender: str,
        actor: str = "email_sync",
        **extra_data,
    ) -> bool:
        """Record email receipt and emit email_received event"""
        deal = self.deals.get(deal_id)
        if not deal:
            return False

        # Add to email thread IDs if not present
        if message_id and message_id not in deal.email_thread_ids:
            deal.email_thread_ids.append(message_id)

        # Update email-to-deal mapping
        if message_id:
            self.email_to_deal[message_id] = deal_id

        deal.updated_at = datetime.now().isoformat()

        if self.emit_events:
            emit_email_received(
                self.event_store,
                deal_id=deal_id,
                message_id=message_id,
                subject=subject,
                sender=sender,
                actor=actor,
                **extra_data,
            )

        return True

    def add_note(
        self,
        deal_id: str,
        content: str,
        actor: str = "operator",
    ) -> bool:
        """Add a note to a deal and emit note_added event"""
        deal = self.deals.get(deal_id)
        if not deal:
            return False

        deal.add_audit("note_added", "manual", content[:200])
        deal.updated_at = datetime.now().isoformat()

        if self.emit_events:
            self.event_store.create_event(
                deal_id=deal_id,
                event_type="note_added",
                actor=actor,
                data={"content": content[:500]},
            )

        return True

    def update_financials(
        self,
        deal_id: str,
        asking_price: Optional[str] = None,
        ebitda: Optional[str] = None,
        revenue: Optional[str] = None,
        actor: str = "operator",
    ) -> bool:
        """Update financial metrics and emit valuation_updated event"""
        deal = self.deals.get(deal_id)
        if not deal:
            return False

        changes = {}
        if asking_price is not None:
            changes["asking_price"] = {"old": deal.metadata.asking_price, "new": asking_price}
            deal.metadata.asking_price = asking_price
        if ebitda is not None:
            changes["ebitda"] = {"old": deal.metadata.ebitda, "new": ebitda}
            deal.metadata.ebitda = ebitda
        if revenue is not None:
            changes["revenue"] = {"old": deal.metadata.revenue, "new": revenue}
            deal.metadata.revenue = revenue

        if not changes:
            return True

        deal.add_audit("financials_updated", "manual", f"Updated: {list(changes.keys())}")
        deal.updated_at = datetime.now().isoformat()

        if self.emit_events:
            self.event_store.create_event(
                deal_id=deal_id,
                event_type="valuation_updated",
                actor=actor,
                data={"changes": changes},
            )

        return True

    def update_nda_status(
        self,
        deal_id: str,
        status: str,
        actor: str = "operator",
    ) -> bool:
        """Update NDA status and emit nda_status_changed event"""
        deal = self.deals.get(deal_id)
        if not deal:
            return False

        old_status = deal.metadata.nda_status
        if old_status == status:
            return True

        deal.metadata.nda_status = status
        deal.add_audit("nda_status_changed", "manual", f"NDA: {old_status} -> {status}")
        deal.updated_at = datetime.now().isoformat()

        if self.emit_events:
            self.event_store.create_event(
                deal_id=deal_id,
                event_type="nda_status_changed",
                actor=actor,
                data={
                    "old_status": old_status,
                    "new_status": status,
                },
            )

        return True

    def get_deal_events(
        self,
        deal_id: str,
        limit: int = 100,
    ) -> List[Dict[str, Any]]:
        """Get events for a deal"""
        events = self.event_store.get_events(deal_id, limit=limit)
        return [e.to_dict() for e in events]

    def get_deal_state_at(
        self,
        deal_id: str,
        timestamp: str,
    ) -> Dict[str, Any]:
        """Get deal state at a specific point in time"""
        return self.event_store.get_state_at(deal_id, timestamp)


def get_registry(emit_events: bool = True) -> EventEnabledRegistry:
    """Get the default event-enabled registry instance"""
    return EventEnabledRegistry(emit_events=emit_events)


if __name__ == "__main__":
    import argparse
    import json

    parser = argparse.ArgumentParser(description="Event-Enabled Deal Registry CLI")
    parser.add_argument("command", choices=["test", "events", "state"])
    parser.add_argument("--deal-id", help="Deal ID")
    parser.add_argument("--timestamp", help="Timestamp for state replay")
    args = parser.parse_args()

    registry = EventEnabledRegistry()

    if args.command == "test":
        # Create a test deal
        test_id = registry.generate_deal_id()
        deal = registry.create_deal(
            deal_id=test_id,
            canonical_name="Test Company Inc",
            folder_path="/home/zaks/DataRoom/01-ACTIVE-DEALS/Test-Company",
            source="cli_test",
            actor="test_operator",
        )
        print(f"Created test deal: {test_id}")

        # Update stage
        registry.update_stage(test_id, "screening", actor="test_operator", reason="Initial review")
        print(f"Updated stage to screening")

        # Add note
        registry.add_note(test_id, "This is a test note", actor="test_operator")
        print(f"Added note")

        # Show events
        events = registry.get_deal_events(test_id)
        print(f"\nEvents for {test_id}:")
        for e in events:
            print(f"  [{e['timestamp']}] {e['event_type']} by {e['actor']}")

        # Don't save - this is just a test
        print("\n(Test deal not saved to registry)")

    elif args.command == "events":
        if not args.deal_id:
            print("Error: --deal-id required")
            raise SystemExit(1)
        events = registry.get_deal_events(args.deal_id)
        print(f"Events for {args.deal_id}: {len(events)}")
        for e in events:
            print(f"  [{e['timestamp']}] {e['event_type']} by {e['actor']}")
            if e.get('data'):
                print(f"       Data: {json.dumps(e['data'], default=str)[:100]}")

    elif args.command == "state":
        if not args.deal_id:
            print("Error: --deal-id required")
            raise SystemExit(1)
        if args.timestamp:
            state = registry.get_deal_state_at(args.deal_id, args.timestamp)
            print(f"State at {args.timestamp}:")
        else:
            state = registry.event_store.get_current_state(args.deal_id)
            print(f"Current state:")
        print(json.dumps(state, indent=2, default=str))
