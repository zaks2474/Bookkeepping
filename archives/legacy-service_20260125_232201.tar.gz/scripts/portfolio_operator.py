#!/usr/bin/env python3
"""
Portfolio Operator Agent

Mission: "Post-close cadence."
- Manage 30/60/90 day integration milestones
- Schedule and track quarterly KPI reviews
- Coordinate annual strategy reviews
- Maintain multi-year operational cadence

Inputs:
- Deal context (registry, events, case file)
- Integration milestones
- KPI data

Outputs:
- Deferred actions (review reminders, milestone checks)
- Operations artifacts (integration tracker, KPI summaries)
- Events (milestone_completed, review_scheduled, kpi_updated)

Hard Boundaries:
- Never changes production systems
- Advisory only - does not make operational decisions
- No direct counterparty contact

Usage:
    python3 portfolio_operator.py init-integration DEAL-2025-001
    python3 portfolio_operator.py check-milestones DEAL-2025-001
    python3 portfolio_operator.py schedule-quarterly DEAL-2025-001
    python3 portfolio_operator.py annual-review DEAL-2025-001
    python3 portfolio_operator.py status DEAL-2025-001
"""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional

# Add paths
sys.path.insert(0, str(Path(__file__).parent))
sys.path.insert(0, str(Path("/home/zaks/Zaks-llm/src")))

from deal_registry import DealRegistry
from deal_events import DealEventStore
from deal_case_manager import DealCaseManagerAgent, DealContext
from deferred_actions import DeferredActionQueue


@dataclass
class OperatorResult:
    """Result of a portfolio operator invocation"""
    success: bool
    message: str
    actions_taken: List[str] = field(default_factory=list)
    artifacts: List[str] = field(default_factory=list)
    data: Optional[Dict[str, Any]] = None

# Configuration
REGISTRY_PATH = "/home/zaks/DataRoom/.deal-registry/deal_registry.json"
CASE_FILES_DIR = Path("/home/zaks/DataRoom/.deal-registry/case_files")
ARTIFACTS_DIR = Path("/home/zaks/DataRoom/.deal-registry/artifacts")
INTEGRATION_DIR = Path("/home/zaks/DataRoom/.deal-registry/integration")
RUN_LEDGER_PATH = Path("/home/zaks/logs/run-ledger.jsonl")

# Ensure directories exist
ARTIFACTS_DIR.mkdir(parents=True, exist_ok=True)
INTEGRATION_DIR.mkdir(parents=True, exist_ok=True)


@dataclass
class IntegrationMilestone:
    """A milestone in the post-close integration process"""
    name: str
    description: str
    due_day: int  # Days after closing
    category: str  # "30-day", "60-day", "90-day", "ongoing"
    status: str = "pending"  # pending, in_progress, completed, overdue
    completed_date: Optional[str] = None
    notes: str = ""


@dataclass
class KPISnapshot:
    """Point-in-time KPI data"""
    date: str
    revenue: Optional[float] = None
    mrr: Optional[float] = None
    customer_count: Optional[int] = None
    churn_rate: Optional[float] = None
    nps_score: Optional[float] = None
    employee_count: Optional[int] = None
    gross_margin: Optional[float] = None
    notes: str = ""


# Standard Integration Milestones (30/60/90 day)
STANDARD_MILESTONES: List[Dict[str, Any]] = [
    # Day 0 (Closing)
    {"name": "closing_complete", "description": "Deal officially closed", "due_day": 0, "category": "closing"},

    # 30-day milestones (Stabilize)
    {"name": "access_transferred", "description": "All system access transferred to new ownership", "due_day": 7, "category": "30-day"},
    {"name": "team_intro_complete", "description": "Introductions with all key employees completed", "due_day": 14, "category": "30-day"},
    {"name": "customer_notification", "description": "Key customers notified of ownership change", "due_day": 14, "category": "30-day"},
    {"name": "vendor_contracts_reviewed", "description": "All vendor contracts reviewed and updated", "due_day": 21, "category": "30-day"},
    {"name": "financial_baseline", "description": "Baseline financial metrics established", "due_day": 30, "category": "30-day"},
    {"name": "30_day_review", "description": "30-day integration review completed", "due_day": 30, "category": "30-day"},

    # 60-day milestones (Optimize)
    {"name": "ops_playbook_documented", "description": "Standard operating procedures documented", "due_day": 45, "category": "60-day"},
    {"name": "quick_wins_identified", "description": "Quick win opportunities identified and prioritized", "due_day": 45, "category": "60-day"},
    {"name": "first_improvements", "description": "First operational improvements implemented", "due_day": 60, "category": "60-day"},
    {"name": "60_day_review", "description": "60-day integration review completed", "due_day": 60, "category": "60-day"},

    # 90-day milestones (Growth Foundation)
    {"name": "kpi_dashboard_live", "description": "KPI tracking dashboard operational", "due_day": 75, "category": "90-day"},
    {"name": "growth_plan_drafted", "description": "12-month growth plan drafted", "due_day": 85, "category": "90-day"},
    {"name": "integration_complete", "description": "Integration phase formally complete", "due_day": 90, "category": "90-day"},
    {"name": "90_day_review", "description": "90-day integration review completed", "due_day": 90, "category": "90-day"},
]


class PortfolioOperatorAgent:
    """
    Portfolio Operator Agent

    Manages post-close operations including:
    - Integration milestone tracking (30/60/90 days)
    - Quarterly KPI reviews
    - Annual strategy reviews
    - Multi-year operational cadence
    """

    def __init__(self):
        self.registry = DealRegistry(REGISTRY_PATH)
        self.case_manager = DealCaseManagerAgent()
        self.action_queue = DeferredActionQueue()

    def _get_deal_context(self, deal_id: str) -> Optional[DealContext]:
        """Get full deal context"""
        return self.case_manager.load_context(deal_id)

    def _load_integration_tracker(self, deal_id: str) -> Dict[str, Any]:
        """Load or create integration tracker for a deal"""
        tracker_path = INTEGRATION_DIR / f"{deal_id}_integration.json"
        if tracker_path.exists():
            with open(tracker_path) as f:
                return json.load(f)
        return {
            "deal_id": deal_id,
            "created": datetime.now(timezone.utc).isoformat(),
            "closing_date": None,
            "milestones": [],
            "kpi_history": [],
            "quarterly_reviews": [],
            "annual_reviews": [],
            "status": "not_started"
        }

    def _save_integration_tracker(self, deal_id: str, tracker: Dict[str, Any]):
        """Save integration tracker"""
        tracker_path = INTEGRATION_DIR / f"{deal_id}_integration.json"
        tracker["last_updated"] = datetime.now(timezone.utc).isoformat()
        with open(tracker_path, "w") as f:
            json.dump(tracker, f, indent=2)

    def _log_run(self, operation: str, deal_id: str, result: Dict[str, Any]):
        """Log to run ledger"""
        entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "agent": "portfolio_operator",
            "operation": operation,
            "deal_id": deal_id,
            "result": result
        }
        with open(RUN_LEDGER_PATH, "a") as f:
            f.write(json.dumps(entry) + "\n")

    def initialize_integration(self, deal_id: str, closing_date: Optional[str] = None) -> OperatorResult:
        """
        Initialize integration tracking for a newly closed deal.
        Sets up 30/60/90 day milestones and schedules reviews.

        Args:
            deal_id: Deal identifier
            closing_date: ISO date of closing (defaults to today)

        Returns:
            OperatorResult with initialization status
        """
        ctx = self._get_deal_context(deal_id)
        if not ctx:
            return OperatorResult(
                success=False,
                message=f"Deal {deal_id} not found",
                actions_taken=[],
                artifacts=[]
            )

        # Check deal is in appropriate stage
        if ctx.stage.upper() not in ["CLOSING", "INTEGRATION", "OPERATIONS"]:
            return OperatorResult(
                success=False,
                message=f"Deal {deal_id} is in stage {ctx.stage}, not ready for integration",
                actions_taken=[],
                artifacts=[]
            )

        # Parse closing date
        if closing_date:
            close_dt = datetime.fromisoformat(closing_date.replace("Z", "+00:00"))
        else:
            close_dt = datetime.now(timezone.utc)

        # Create integration tracker
        tracker = self._load_integration_tracker(deal_id)
        tracker["closing_date"] = close_dt.isoformat()
        tracker["status"] = "active"

        # Initialize milestones
        milestones = []
        for m in STANDARD_MILESTONES:
            due_date = close_dt + timedelta(days=m["due_day"])
            milestone = {
                "name": m["name"],
                "description": m["description"],
                "category": m["category"],
                "due_day": m["due_day"],
                "due_date": due_date.isoformat(),
                "status": "pending",
                "completed_date": None,
                "notes": ""
            }
            milestones.append(milestone)
        tracker["milestones"] = milestones

        # Save tracker
        self._save_integration_tracker(deal_id, tracker)

        # Schedule deferred actions for major reviews
        actions_scheduled = []

        # 30-day review
        review_30 = close_dt + timedelta(days=30)
        self.action_queue.add_action(
            deal_id=deal_id,
            action_type="integration_review_30",
            scheduled_for=review_30.isoformat(),
            context={"review_type": "30-day", "closing_date": close_dt.isoformat()}
        )
        actions_scheduled.append("integration_review_30")

        # 60-day review
        review_60 = close_dt + timedelta(days=60)
        self.action_queue.add_action(
            deal_id=deal_id,
            action_type="integration_review_60",
            scheduled_for=review_60.isoformat(),
            context={"review_type": "60-day", "closing_date": close_dt.isoformat()}
        )
        actions_scheduled.append("integration_review_60")

        # 90-day review
        review_90 = close_dt + timedelta(days=90)
        self.action_queue.add_action(
            deal_id=deal_id,
            action_type="integration_review_90",
            scheduled_for=review_90.isoformat(),
            context={"review_type": "90-day", "closing_date": close_dt.isoformat()}
        )
        actions_scheduled.append("integration_review_90")

        # First quarterly review (after 90 days)
        quarterly_1 = close_dt + timedelta(days=120)  # Q1 after close
        self.action_queue.add_action(
            deal_id=deal_id,
            action_type="quarterly_kpi_review",
            scheduled_for=quarterly_1.isoformat(),
            context={"quarter": 1, "closing_date": close_dt.isoformat()}
        )
        actions_scheduled.append("quarterly_kpi_review_q1")

        # Log event
        events_dir = Path("/home/zaks/DataRoom/.deal-registry/events")
        event_store = DealEventStore(events_dir)
        event_store.append_event(deal_id, {
            "event_type": "integration_initialized",
            "closing_date": close_dt.isoformat(),
            "milestones_count": len(milestones),
            "agent": "portfolio_operator"
        })

        # Log run
        self._log_run("initialize_integration", deal_id, {
            "closing_date": close_dt.isoformat(),
            "milestones": len(milestones),
            "actions_scheduled": actions_scheduled
        })

        return OperatorResult(
            success=True,
            message=f"Integration tracking initialized for {deal_id}",
            actions_taken=[
                f"Created integration tracker with {len(milestones)} milestones",
                f"Scheduled 30/60/90 day reviews",
                f"Scheduled first quarterly review"
            ],
            artifacts=[str(INTEGRATION_DIR / f"{deal_id}_integration.json")]
        )

    def check_milestones(self, deal_id: str) -> OperatorResult:
        """
        Check milestone status and identify overdue items.

        Args:
            deal_id: Deal identifier

        Returns:
            OperatorResult with milestone status
        """
        tracker = self._load_integration_tracker(deal_id)

        if not tracker.get("milestones"):
            return OperatorResult(
                success=False,
                message=f"No integration tracker found for {deal_id}",
                actions_taken=[],
                artifacts=[]
            )

        now = datetime.now(timezone.utc)
        pending = []
        overdue = []
        completed = []

        for m in tracker["milestones"]:
            if m["status"] == "completed":
                completed.append(m)
            else:
                due_date = datetime.fromisoformat(m["due_date"].replace("Z", "+00:00"))
                if due_date < now:
                    m["status"] = "overdue"
                    overdue.append(m)
                else:
                    pending.append(m)

        # Save updated statuses
        self._save_integration_tracker(deal_id, tracker)

        # Build summary
        summary = {
            "deal_id": deal_id,
            "total_milestones": len(tracker["milestones"]),
            "completed": len(completed),
            "pending": len(pending),
            "overdue": len(overdue),
            "completion_pct": round(len(completed) / len(tracker["milestones"]) * 100, 1),
            "overdue_items": [{"name": m["name"], "due_date": m["due_date"]} for m in overdue],
            "next_due": [{"name": m["name"], "due_date": m["due_date"]} for m in sorted(pending, key=lambda x: x["due_date"])[:3]]
        }

        # Log run
        self._log_run("check_milestones", deal_id, summary)

        message = f"Milestones: {len(completed)}/{len(tracker['milestones'])} complete ({summary['completion_pct']}%)"
        if overdue:
            message += f", {len(overdue)} OVERDUE"

        return OperatorResult(
            success=True,
            message=message,
            actions_taken=[
                f"Checked {len(tracker['milestones'])} milestones",
                f"Found {len(overdue)} overdue items"
            ],
            artifacts=[],
            data=summary
        )

    def complete_milestone(self, deal_id: str, milestone_name: str, notes: str = "") -> OperatorResult:
        """
        Mark a milestone as completed.

        Args:
            deal_id: Deal identifier
            milestone_name: Name of milestone to complete
            notes: Optional completion notes

        Returns:
            OperatorResult with update status
        """
        tracker = self._load_integration_tracker(deal_id)

        if not tracker.get("milestones"):
            return OperatorResult(
                success=False,
                message=f"No integration tracker found for {deal_id}",
                actions_taken=[],
                artifacts=[]
            )

        # Find and update milestone
        found = False
        for m in tracker["milestones"]:
            if m["name"] == milestone_name:
                m["status"] = "completed"
                m["completed_date"] = datetime.now(timezone.utc).isoformat()
                m["notes"] = notes
                found = True
                break

        if not found:
            return OperatorResult(
                success=False,
                message=f"Milestone '{milestone_name}' not found",
                actions_taken=[],
                artifacts=[]
            )

        self._save_integration_tracker(deal_id, tracker)

        # Log event
        events_dir = Path("/home/zaks/DataRoom/.deal-registry/events")
        event_store = DealEventStore(events_dir)
        event_store.append_event(deal_id, {
            "event_type": "milestone_completed",
            "milestone": milestone_name,
            "notes": notes,
            "agent": "portfolio_operator"
        })

        self._log_run("complete_milestone", deal_id, {
            "milestone": milestone_name,
            "notes": notes
        })

        return OperatorResult(
            success=True,
            message=f"Milestone '{milestone_name}' marked complete",
            actions_taken=[f"Updated milestone status to completed"],
            artifacts=[]
        )

    def schedule_quarterly_review(self, deal_id: str, quarter_offset: int = 1) -> OperatorResult:
        """
        Schedule next quarterly KPI review.

        Args:
            deal_id: Deal identifier
            quarter_offset: Number of quarters from now (default 1)

        Returns:
            OperatorResult with scheduling status
        """
        ctx = self._get_deal_context(deal_id)
        if not ctx:
            return OperatorResult(
                success=False,
                message=f"Deal {deal_id} not found",
                actions_taken=[],
                artifacts=[]
            )

        # Calculate next quarter
        now = datetime.now(timezone.utc)
        days_to_add = quarter_offset * 90
        review_date = now + timedelta(days=days_to_add)

        # Get quarter number
        tracker = self._load_integration_tracker(deal_id)
        existing_reviews = len(tracker.get("quarterly_reviews", []))
        quarter_num = existing_reviews + 1

        # Schedule action
        self.action_queue.add_action(
            deal_id=deal_id,
            action_type="quarterly_kpi_review",
            scheduled_for=review_date.isoformat(),
            context={
                "quarter": quarter_num,
                "review_type": "quarterly"
            }
        )

        self._log_run("schedule_quarterly_review", deal_id, {
            "quarter": quarter_num,
            "scheduled_for": review_date.isoformat()
        })

        return OperatorResult(
            success=True,
            message=f"Quarterly review Q{quarter_num} scheduled for {review_date.strftime('%Y-%m-%d')}",
            actions_taken=[f"Created deferred action for quarterly_kpi_review"],
            artifacts=[]
        )

    def record_kpi_snapshot(self, deal_id: str, kpi_data: Dict[str, Any]) -> OperatorResult:
        """
        Record a KPI snapshot for tracking.

        Args:
            deal_id: Deal identifier
            kpi_data: Dictionary with KPI values (revenue, mrr, customer_count, etc.)

        Returns:
            OperatorResult with recording status
        """
        tracker = self._load_integration_tracker(deal_id)

        snapshot = {
            "date": datetime.now(timezone.utc).isoformat(),
            **kpi_data
        }

        if "kpi_history" not in tracker:
            tracker["kpi_history"] = []
        tracker["kpi_history"].append(snapshot)

        self._save_integration_tracker(deal_id, tracker)

        # Log event
        events_dir = Path("/home/zaks/DataRoom/.deal-registry/events")
        event_store = DealEventStore(events_dir)
        event_store.append_event(deal_id, {
            "event_type": "kpi_recorded",
            "kpi_data": kpi_data,
            "agent": "portfolio_operator"
        })

        self._log_run("record_kpi_snapshot", deal_id, {"snapshot": snapshot})

        return OperatorResult(
            success=True,
            message=f"KPI snapshot recorded ({len(tracker['kpi_history'])} total)",
            actions_taken=["Added KPI snapshot to history"],
            artifacts=[]
        )

    def run_quarterly_review(self, deal_id: str) -> OperatorResult:
        """
        Run a quarterly KPI review.
        Analyzes trends, flags concerns, schedules next review.

        Args:
            deal_id: Deal identifier

        Returns:
            OperatorResult with review summary
        """
        tracker = self._load_integration_tracker(deal_id)

        kpi_history = tracker.get("kpi_history", [])

        if len(kpi_history) < 2:
            return OperatorResult(
                success=False,
                message="Need at least 2 KPI snapshots for trend analysis",
                actions_taken=[],
                artifacts=[]
            )

        # Analyze trends (simple comparison)
        latest = kpi_history[-1]
        previous = kpi_history[-2]

        trends = {}
        concerns = []
        highlights = []

        for key in ["revenue", "mrr", "customer_count", "gross_margin"]:
            if key in latest and key in previous and latest[key] and previous[key]:
                change = (latest[key] - previous[key]) / previous[key] * 100
                trends[key] = round(change, 1)

                if key == "revenue" and change < 0:
                    concerns.append(f"Revenue declined {abs(change):.1f}%")
                elif key == "revenue" and change > 10:
                    highlights.append(f"Revenue grew {change:.1f}%")

                if key == "customer_count" and change < -5:
                    concerns.append(f"Customer count down {abs(change):.1f}%")

        if "churn_rate" in latest and latest["churn_rate"]:
            if latest["churn_rate"] > 0.05:  # 5%
                concerns.append(f"High churn rate: {latest['churn_rate']*100:.1f}%")

        # Record review
        review = {
            "date": datetime.now(timezone.utc).isoformat(),
            "quarter": len(tracker.get("quarterly_reviews", [])) + 1,
            "latest_kpis": latest,
            "trends": trends,
            "concerns": concerns,
            "highlights": highlights
        }

        if "quarterly_reviews" not in tracker:
            tracker["quarterly_reviews"] = []
        tracker["quarterly_reviews"].append(review)

        self._save_integration_tracker(deal_id, tracker)

        # Schedule next quarterly
        self.schedule_quarterly_review(deal_id, quarter_offset=1)

        # Log event
        events_dir = Path("/home/zaks/DataRoom/.deal-registry/events")
        event_store = DealEventStore(events_dir)
        event_store.append_event(deal_id, {
            "event_type": "quarterly_review_completed",
            "quarter": review["quarter"],
            "trends": trends,
            "concerns_count": len(concerns),
            "agent": "portfolio_operator"
        })

        self._log_run("run_quarterly_review", deal_id, review)

        message = f"Q{review['quarter']} Review: "
        if concerns:
            message += f"{len(concerns)} concerns, "
        if highlights:
            message += f"{len(highlights)} highlights"
        else:
            message += "stable"

        return OperatorResult(
            success=True,
            message=message,
            actions_taken=[
                "Analyzed KPI trends",
                f"Identified {len(concerns)} concerns",
                "Scheduled next quarterly review"
            ],
            artifacts=[],
            data=review
        )

    def schedule_annual_review(self, deal_id: str) -> OperatorResult:
        """
        Schedule annual strategy review.

        Args:
            deal_id: Deal identifier

        Returns:
            OperatorResult with scheduling status
        """
        tracker = self._load_integration_tracker(deal_id)

        # Calculate next annual review (1 year from closing or last annual)
        if tracker.get("annual_reviews"):
            last_review = tracker["annual_reviews"][-1]
            last_date = datetime.fromisoformat(last_review["date"].replace("Z", "+00:00"))
            next_date = last_date + timedelta(days=365)
        elif tracker.get("closing_date"):
            closing = datetime.fromisoformat(tracker["closing_date"].replace("Z", "+00:00"))
            next_date = closing + timedelta(days=365)
        else:
            next_date = datetime.now(timezone.utc) + timedelta(days=365)

        year_num = len(tracker.get("annual_reviews", [])) + 1

        self.action_queue.add_action(
            deal_id=deal_id,
            action_type="annual_strategy_review",
            scheduled_for=next_date.isoformat(),
            context={
                "year": year_num,
                "review_type": "annual"
            }
        )

        self._log_run("schedule_annual_review", deal_id, {
            "year": year_num,
            "scheduled_for": next_date.isoformat()
        })

        return OperatorResult(
            success=True,
            message=f"Year {year_num} review scheduled for {next_date.strftime('%Y-%m-%d')}",
            actions_taken=[f"Created deferred action for annual_strategy_review"],
            artifacts=[]
        )

    def get_portfolio_status(self, deal_id: str) -> OperatorResult:
        """
        Get comprehensive portfolio status for a deal.

        Args:
            deal_id: Deal identifier

        Returns:
            OperatorResult with full status
        """
        ctx = self._get_deal_context(deal_id)
        if not ctx:
            return OperatorResult(
                success=False,
                message=f"Deal {deal_id} not found",
                actions_taken=[],
                artifacts=[]
            )

        tracker = self._load_integration_tracker(deal_id)

        # Check milestones
        milestone_result = self.check_milestones(deal_id)

        # Get latest KPIs
        latest_kpis = tracker.get("kpi_history", [{}])[-1] if tracker.get("kpi_history") else {}

        # Get pending actions for this deal
        deal_actions = self.action_queue.get_actions_for_deal(deal_id)
        deal_actions = [a for a in deal_actions if a.status == "pending"]

        status = {
            "deal_id": deal_id,
            "deal_name": ctx.deal.display_name or ctx.deal.canonical_name,
            "stage": ctx.stage,
            "integration_status": tracker.get("status", "not_started"),
            "closing_date": tracker.get("closing_date"),
            "milestones": milestone_result.data if milestone_result.success else {},
            "latest_kpis": latest_kpis,
            "quarterly_reviews_count": len(tracker.get("quarterly_reviews", [])),
            "annual_reviews_count": len(tracker.get("annual_reviews", [])),
            "pending_actions": [{"type": a.action_type, "due": str(a.scheduled_for) if a.scheduled_for else None} for a in deal_actions[:5]]
        }

        self._log_run("get_portfolio_status", deal_id, {"status": "retrieved"})

        return OperatorResult(
            success=True,
            message=f"Portfolio status for {deal_id}",
            actions_taken=["Retrieved comprehensive status"],
            artifacts=[],
            data=status
        )


def main():
    parser = argparse.ArgumentParser(description="Portfolio Operator Agent")
    subparsers = parser.add_subparsers(dest="command", help="Commands")

    # init-integration
    init_parser = subparsers.add_parser("init-integration", help="Initialize integration tracking")
    init_parser.add_argument("deal_id", help="Deal ID")
    init_parser.add_argument("--closing-date", help="Closing date (ISO format)")

    # check-milestones
    check_parser = subparsers.add_parser("check-milestones", help="Check milestone status")
    check_parser.add_argument("deal_id", help="Deal ID")

    # complete-milestone
    complete_parser = subparsers.add_parser("complete-milestone", help="Mark milestone complete")
    complete_parser.add_argument("deal_id", help="Deal ID")
    complete_parser.add_argument("milestone", help="Milestone name")
    complete_parser.add_argument("--notes", default="", help="Completion notes")

    # schedule-quarterly
    quarterly_parser = subparsers.add_parser("schedule-quarterly", help="Schedule quarterly review")
    quarterly_parser.add_argument("deal_id", help="Deal ID")

    # run-quarterly
    run_quarterly_parser = subparsers.add_parser("run-quarterly", help="Run quarterly review")
    run_quarterly_parser.add_argument("deal_id", help="Deal ID")

    # record-kpi
    kpi_parser = subparsers.add_parser("record-kpi", help="Record KPI snapshot")
    kpi_parser.add_argument("deal_id", help="Deal ID")
    kpi_parser.add_argument("--revenue", type=float, help="Revenue")
    kpi_parser.add_argument("--mrr", type=float, help="MRR")
    kpi_parser.add_argument("--customers", type=int, help="Customer count")
    kpi_parser.add_argument("--churn", type=float, help="Churn rate (decimal)")

    # annual-review
    annual_parser = subparsers.add_parser("annual-review", help="Schedule annual review")
    annual_parser.add_argument("deal_id", help="Deal ID")

    # status
    status_parser = subparsers.add_parser("status", help="Get portfolio status")
    status_parser.add_argument("deal_id", help="Deal ID")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return

    agent = PortfolioOperatorAgent()

    if args.command == "init-integration":
        result = agent.initialize_integration(args.deal_id, args.closing_date)
    elif args.command == "check-milestones":
        result = agent.check_milestones(args.deal_id)
    elif args.command == "complete-milestone":
        result = agent.complete_milestone(args.deal_id, args.milestone, args.notes)
    elif args.command == "schedule-quarterly":
        result = agent.schedule_quarterly_review(args.deal_id)
    elif args.command == "run-quarterly":
        result = agent.run_quarterly_review(args.deal_id)
    elif args.command == "record-kpi":
        kpi_data = {}
        if args.revenue:
            kpi_data["revenue"] = args.revenue
        if args.mrr:
            kpi_data["mrr"] = args.mrr
        if args.customers:
            kpi_data["customer_count"] = args.customers
        if args.churn:
            kpi_data["churn_rate"] = args.churn
        result = agent.record_kpi_snapshot(args.deal_id, kpi_data)
    elif args.command == "annual-review":
        result = agent.schedule_annual_review(args.deal_id)
    elif args.command == "status":
        result = agent.get_portfolio_status(args.deal_id)
    else:
        parser.print_help()
        return

    # Output result
    print(f"\n{'='*60}")
    print(f"Portfolio Operator: {args.command}")
    print(f"{'='*60}")
    print(f"Status: {'SUCCESS' if result.success else 'FAILED'}")
    print(f"Message: {result.message}")

    if result.actions_taken:
        print(f"\nActions Taken:")
        for action in result.actions_taken:
            print(f"  • {action}")

    if result.artifacts:
        print(f"\nArtifacts:")
        for artifact in result.artifacts:
            print(f"  • {artifact}")

    if result.data:
        print(f"\nData:")
        print(json.dumps(result.data, indent=2))


if __name__ == "__main__":
    main()
