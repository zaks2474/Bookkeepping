#!/usr/bin/env python3
"""
ZakOps - Continuous Improvement Proposals (Deterministic)

Generates a professional, shareable markdown proposal document based on:
  - Email-to-DataRoom sync reports (email_sync_report_*.json)
  - ZakOps analyzer document classification outputs (DOCUMENT-CLASSIFICATION.json)

This script is deterministic (no LLM required) and safe to run on cron.
"""

from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Tuple


DEFAULT_LOG_DIR = Path("/home/zaks/logs")
DEFAULT_INBOUND_DIR = Path("/home/zaks/DataRoom/00-PIPELINE/Inbound")
DEFAULT_OUTPUT_DIR = Path("/home/zaks/bookkeeping/docs/PROPOSALS")


def read_json(path: Path) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def recent_files(paths: List[Path], since: datetime) -> List[Path]:
    out: List[Path] = []
    for p in paths:
        try:
            if datetime.fromtimestamp(p.stat().st_mtime) >= since:
                out.append(p)
        except FileNotFoundError:
            continue
    return sorted(out, key=lambda p: p.stat().st_mtime, reverse=True)


def load_email_sync_reports(log_dir: Path, since: datetime) -> List[Dict[str, Any]]:
    reports = recent_files(list(log_dir.glob("email_sync_report_*.json")), since=since)
    data: List[Dict[str, Any]] = []
    for r in reports:
        try:
            obj = read_json(r)
            obj["_path"] = str(r)
            data.append(obj)
        except Exception:
            continue
    return data


def load_doc_classifications(inbound_dir: Path, since: datetime) -> List[Dict[str, Any]]:
    files = recent_files(list(inbound_dir.rglob("DOCUMENT-CLASSIFICATION.json")), since=since)
    data: List[Dict[str, Any]] = []
    for p in files:
        try:
            obj = read_json(p)
            obj["_path"] = str(p)
            data.append(obj)
        except Exception:
            continue
    return data


def propose_from_reports(reports: List[Dict[str, Any]]) -> Tuple[List[str], List[str]]:
    observations: List[str] = []
    proposals: List[str] = []

    if not reports:
        observations.append("- No recent `email_sync_report_*.json` found; cannot compute operational trends.")
        return observations, proposals

    errors = Counter()
    lock_busy = 0
    total_runs = len(reports)
    failed_runs = 0

    for r in reports:
        errs = r.get("errors") or []
        if isinstance(errs, list):
            for e in errs:
                errors[str(e)] += 1
                if str(e) == "lock_busy":
                    lock_busy += 1
        if int(r.get("emails_failed") or 0) > 0:
            failed_runs += 1

    observations.append(f"- Total runs (window): {total_runs}")
    observations.append(f"- Runs with email failures: {failed_runs}")
    if errors:
        top = errors.most_common(5)
        observations.append("- Top errors:")
        for msg, n in top:
            observations.append(f"  - {msg}: {n}")

    if lock_busy > 0:
        proposals.append(
            "### Reduce lock contention\n"
            "- **Issue:** Overlapping runs detected (`lock_busy`).\n"
            "- **Proposal:** Keep the lock (already implemented) and increase the cron interval or ensure the run time stays < interval.\n"
            "- **Action:** If runs regularly exceed 2 hours, either optimize IMAP search size or move Stage B to a separate cron (every 30–60 minutes) with its own lock.\n"
        )

    if failed_runs > 0:
        proposals.append(
            "### Improve failure visibility\n"
            "- **Issue:** Some runs report `emails_failed > 0`.\n"
            "- **Proposal:** Add a lightweight alerting hook (e.g., write a `FAILED` marker file or emit a summary line suitable for log monitoring).\n"
            "- **Action:** In `sync_acquisition_emails.py`, log a single-line summary with Run ID + failures, and consider a separate watchdog that tails logs.\n"
        )

    return observations, proposals


def propose_from_classifications(classifications: List[Dict[str, Any]]) -> Tuple[List[str], List[str]]:
    observations: List[str] = []
    proposals: List[str] = []

    if not classifications:
        observations.append("- No recent `DOCUMENT-CLASSIFICATION.json` found; cannot infer document routing quality.")
        return observations, proposals

    move_counts = Counter()
    doc_type_counts = Counter()

    for c in classifications:
        for d in c.get("documents") or []:
            if not isinstance(d, dict):
                continue
            doc_type_counts[str(d.get("doc_type") or "Unknown")] += 1
        for m in c.get("move_proposals") or []:
            if not isinstance(m, dict):
                continue
            move_counts[f"{m.get('from')} -> {m.get('to')}"] += 1

    observations.append("- Document type mix (observed):")
    for k, n in doc_type_counts.most_common(8):
        observations.append(f"  - {k}: {n}")

    if move_counts:
        top_moves = move_counts.most_common(5)
        observations.append("- Top move proposals (routing drift):")
        for move, n in top_moves:
            observations.append(f"  - {move}: {n}")

        proposals.append(
            "### Reduce misclassification between Stage A and Stage B\n"
            "- **Issue:** Stage B is proposing frequent file moves (meaning Stage A foldering rules are missing content signals).\n"
            "- **Proposal:** Extend Stage A’s keyword-based foldering rules using the top move patterns.\n"
            "- **Action:** Add the recurring content terms into the Stage A subfolder patterns so files land correctly on first write.\n"
        )

    return observations, proposals


def render_markdown(
    *,
    window_days: int,
    report_obs: List[str],
    report_props: List[str],
    class_obs: List[str],
    class_props: List[str],
) -> str:
    now = datetime.now().strftime("%Y-%m-%d")
    lines: List[str] = []
    lines.append("# Sync Pipeline Improvement Proposals")
    lines.append("")
    lines.append(f"**Generated:** {now}")
    lines.append(f"**Window:** last {window_days} day(s)")
    lines.append("")
    lines.append("## Observations (Email Sync Reports)")
    lines.extend(report_obs or ["- None"])
    lines.append("")
    lines.append("## Observations (Document Classification)")
    lines.extend(class_obs or ["- None"])
    lines.append("")
    lines.append("## Proposals")
    if not (report_props or class_props):
        lines.append("- No proposals generated (insufficient signals).")
    else:
        lines.extend(report_props)
        lines.extend(class_props)
    lines.append("")
    lines.append("---")
    lines.append("*Generated by `scripts/zakops_improvement_proposals.py` (deterministic).*")
    lines.append("")
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate improvement proposals for Email-to-DataRoom + ZakOps pipeline")
    parser.add_argument("--days", type=int, default=7, help="Look back window in days (default: 7)")
    parser.add_argument("--log-dir", type=str, default=str(DEFAULT_LOG_DIR), help="Directory containing email_sync_report_*.json")
    parser.add_argument("--inbound-dir", type=str, default=str(DEFAULT_INBOUND_DIR), help="Inbound directory to scan for DOCUMENT-CLASSIFICATION.json")
    parser.add_argument("--output-dir", type=str, default=str(DEFAULT_OUTPUT_DIR), help="Where to write proposals markdown")
    args = parser.parse_args()

    since = datetime.now() - timedelta(days=max(1, int(args.days)))
    log_dir = Path(args.log_dir)
    inbound_dir = Path(args.inbound_dir)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    reports = load_email_sync_reports(log_dir, since=since)
    classifications = load_doc_classifications(inbound_dir, since=since)

    report_obs, report_props = propose_from_reports(reports)
    class_obs, class_props = propose_from_classifications(classifications)

    md = render_markdown(
        window_days=int(args.days),
        report_obs=report_obs,
        report_props=report_props,
        class_obs=class_obs,
        class_props=class_props,
    )

    out_path = output_dir / f"email_sync_improvements_{datetime.now().strftime('%Y%m%d')}.md"
    out_path.write_text(md, encoding="utf-8")
    print(str(out_path))


if __name__ == "__main__":
    main()

