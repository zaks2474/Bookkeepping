#!/usr/bin/env bash
set -euo pipefail

PYTHONPATH="/home/zaks/.venvs/zakops-orchestration/lib/python3.12/site-packages${PYTHONPATH:+:$PYTHONPATH}"
export PYTHONPATH

python3 -m unittest discover -s /home/zaks/scripts/tests -p 'test_*.py'
