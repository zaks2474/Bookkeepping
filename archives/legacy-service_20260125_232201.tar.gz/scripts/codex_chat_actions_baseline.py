#!/usr/bin/env python3
"""
ZakOps Chat + Actions Baseline Evidence Collector (safe)

Goal:
  Collect concrete evidence about the current running system BEFORE changes.

Safety:
  - Does NOT print email bodies or attachment contents.
  - Does NOT print secrets/keys.
  - Only captures counts, statuses, and stable contract shapes.
"""

from __future__ import annotations

import argparse
import json
import os
import platform
import subprocess
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


def _now_utc_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _http_json(url: str, *, method: str = "GET", body: Optional[Dict[str, Any]] = None, timeout_s: float = 10.0) -> Tuple[int, Any]:
    data: Optional[bytes] = None
    headers = {"Accept": "application/json"}
    if body is not None:
        data = json.dumps(body).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = Request(url, method=method, data=data, headers=headers)
    try:
        with urlopen(req, timeout=timeout_s) as resp:
            raw = resp.read()
            status = int(getattr(resp, "status", 0) or 0)
            try:
                parsed = json.loads(raw.decode("utf-8", errors="replace") or "null")
            except Exception:
                parsed = {"_non_json": True, "raw_prefix": raw[:200].decode("utf-8", errors="replace")}
            return status, parsed
    except HTTPError as exc:
        # urllib treats non-2xx as exceptions; still capture status and body.
        try:
            raw = exc.read()  # type: ignore[attr-defined]
        except Exception:
            raw = b""
        status = int(getattr(exc, "code", 0) or 0)
        try:
            parsed = json.loads(raw.decode("utf-8", errors="replace") or "null")
        except Exception:
            parsed = {"_non_json": True, "raw_prefix": raw[:200].decode("utf-8", errors="replace")}
        return status, parsed
    except URLError as exc:
        return 0, {"error": f"URLError: {exc}"}
    except Exception as exc:
        return 0, {"error": f"{type(exc).__name__}: {exc}"}


def _run(cmd: List[str]) -> Tuple[int, str]:
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, check=False)
        out = (p.stdout or "") + (("\n" + p.stderr) if p.stderr else "")
        return int(p.returncode), out.strip()
    except Exception as exc:
        return 127, f"{type(exc).__name__}: {exc}"


def _ss_ports() -> str:
    # Best-effort port evidence (avoid failing if ss/grep not available).
    cmd = ["bash", "-lc", r"ss -ltnp 2>/dev/null | rg -n ':(3003|8090|8000|8080)\b' || true"]
    code, out = _run(cmd)
    if code != 0 and not out:
        return f"(unavailable; exit={code})"
    return out or "(no matches)"


def _systemd_unit_state(unit: str) -> Dict[str, Any]:
    code, active = _run(["systemctl", "is-active", unit])
    _, enabled = _run(["systemctl", "is-enabled", unit])
    return {"unit": unit, "active": (active or "").strip(), "enabled": (enabled or "").strip(), "rc": code}


def _summarize_chat_complete(resp: Any) -> Dict[str, Any]:
    if not isinstance(resp, dict):
        return {"_invalid": True, "type": str(type(resp))}
    proposals = resp.get("proposals") if isinstance(resp.get("proposals"), list) else []
    citations = resp.get("citations") if isinstance(resp.get("citations"), list) else []
    return {
        "keys": sorted(resp.keys()),
        "content_len": len(str(resp.get("content") or "")),
        "proposals_count": len(proposals),
        "proposal_types": sorted({str(p.get("type") or "") for p in proposals if isinstance(p, dict)}),
        "citations_count": len(citations),
        "model_used": resp.get("model_used"),
        "latency_ms": resp.get("latency_ms"),
        "warnings_count": len(resp.get("warnings") or []) if isinstance(resp.get("warnings"), list) else None,
    }


def _summarize_actions_debug(resp: Any, *, keys: List[str]) -> Dict[str, Any]:
    if not isinstance(resp, dict):
        return {"_invalid": True, "type": str(type(resp))}
    for key in keys:
        items = resp.get(key)
        if isinstance(items, list):
            return {
                "count": len(items),
                "sample": items[:5],
            }
    # No recognized list key found; return keys only.
    return {"keys": sorted(resp.keys())}


def _chat_execute_summary(*, status: int, payload: Any) -> Dict[str, Any]:
    if not isinstance(payload, dict):
        return {"status": status, "_invalid": True, "type": str(type(payload))}
    return {
        "status": status,
        "keys": sorted(payload.keys()),
        "success": payload.get("success"),
        "reason": payload.get("reason"),
        "error": payload.get("error"),
    }


def _write_markdown(path: str, report: Dict[str, Any]) -> None:
    # Keep it intentionally high-level to avoid leaking sensitive data (email bodies, snippets).
    lines: List[str] = []
    lines.append("# CODEX Chat + Actions Verification Baseline")
    lines.append("")
    lines.append(f"- Generated: `{report.get('generated_at')}`")
    lines.append(f"- Host: `{report.get('host')}`")
    lines.append("")

    lines.append("## Ports")
    lines.append("```")
    lines.append(str(report.get("ports", "")))
    lines.append("```")
    lines.append("")

    lines.append("## Versions")
    v8090 = report.get("api_8090_version", {})
    v3003 = report.get("api_3003_proxy_version", {})
    lines.append(f"- `8090 /api/version`: commit `{v8090.get('git_commit')}` pid `{v8090.get('server_pid')}` allow_cloud_default `{(v8090.get('config') or {}).get('allow_cloud_default')}`")
    lines.append(f"- `3003 /api/version` (proxy): commit `{v3003.get('git_commit')}` pid `{v3003.get('server_pid')}`")
    lines.append("")

    lines.append("## LLM Health (shape)")
    llm = report.get("llm_health", {})
    lines.append(f"- status: `{llm.get('status')}` primary: `{llm.get('primary_provider')}`")
    providers = (llm.get("providers") or {}) if isinstance(llm, dict) else {}
    if isinstance(providers, dict) and providers:
        for name, pdata in providers.items():
            if not isinstance(pdata, dict):
                continue
            lines.append(f"  - {name}: `{pdata.get('status')}` model `{pdata.get('model')}` latency_ms `{pdata.get('latency_ms')}`")
    lines.append("")

    lines.append("## Chat Contract Snapshots (sanitized)")
    lines.append("- `POST /api/chat/complete` hello: " + json.dumps(report.get("chat_complete_hello_summary", {}), ensure_ascii=False))
    lines.append("- `POST /api/chat/complete` draft_email: " + json.dumps(report.get("chat_complete_draft_email_summary", {}), ensure_ascii=False))
    lines.append("- `POST /api/chat/execute-proposal` invalid id: " + json.dumps(report.get("chat_execute_invalid_summary", {}), ensure_ascii=False))
    lines.append("")

    lines.append("## Actions Engine")
    caps = report.get("capabilities_summary", {})
    lines.append(f"- capabilities count: `{caps.get('count')}`")
    missing = report.get("missing_executors_summary", {})
    mism = report.get("capability_mismatches_summary", {})
    lines.append(f"- missing executors: `{missing.get('count')}`")
    lines.append(f"- capability mismatches: `{mism.get('count')}`")
    lines.append("")

    lines.append("## Systemd Units")
    for u in report.get("systemd_units", []) or []:
        if not isinstance(u, dict):
            continue
        lines.append(f"- `{u.get('unit')}` active=`{u.get('active')}` enabled=`{u.get('enabled')}`")
    lines.append("")

    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines).rstrip() + "\n")


def main() -> int:
    parser = argparse.ArgumentParser(description="ZakOps Chat + Actions baseline evidence collector (safe)")
    parser.add_argument("--api-base", default="http://localhost:8090", help="Deal Lifecycle API base URL")
    parser.add_argument("--dashboard-base", default="http://localhost:3003", help="Dashboard base URL (proxy)")
    parser.add_argument("--vllm-base", default="http://localhost:8000", help="vLLM base URL")
    parser.add_argument("--markdown", default="", help="Write sanitized markdown report to this path")
    args = parser.parse_args()

    api = str(args.api_base).rstrip("/")
    dash = str(args.dashboard_base).rstrip("/")
    vllm = str(args.vllm_base).rstrip("/")

    report: Dict[str, Any] = {
        "generated_at": _now_utc_iso(),
        "host": platform.node(),
        "ports": _ss_ports(),
    }

    # Versions
    _, api_ver = _http_json(f"{api}/api/version")
    _, dash_ver = _http_json(f"{dash}/api/version")
    report["api_8090_version"] = api_ver
    report["api_3003_proxy_version"] = dash_ver

    # vLLM models (only IDs)
    status, models = _http_json(f"{vllm}/v1/models")
    if status == 200 and isinstance(models, dict) and isinstance(models.get("data"), list):
        report["vllm_models"] = [m.get("id") for m in models["data"] if isinstance(m, dict) and m.get("id")]
    else:
        report["vllm_models"] = {"status": status, "error": models}

    # LLM health
    _, llm = _http_json(f"{api}/api/chat/llm-health")
    report["llm_health"] = llm

    # Chat contract snapshots (summaries only)
    _, hello = _http_json(
        f"{api}/api/chat/complete",
        method="POST",
        body={"query": "Say hello and propose no actions.", "scope": {"type": "global"}},
        timeout_s=60.0,
    )
    report["chat_complete_hello_summary"] = _summarize_chat_complete(hello)

    _, draft = _http_json(
        f"{api}/api/chat/complete",
        method="POST",
        body={"query": "Draft an email to a broker requesting the CIM. Do not send it.", "scope": {"type": "global"}},
        timeout_s=60.0,
    )
    report["chat_complete_draft_email_summary"] = _summarize_chat_complete(draft)

    status_exec, invalid_exec = _http_json(
        f"{api}/api/chat/execute-proposal",
        method="POST",
        body={"proposal_id": "DOES_NOT_EXIST", "approved_by": "operator", "session_id": "NOPE", "action": "approve"},
        timeout_s=30.0,
    )
    report["chat_execute_invalid_summary"] = _chat_execute_summary(status=status_exec, payload=invalid_exec)

    # Actions engine summaries (avoid listing actions which may include email subjects)
    _, caps = _http_json(f"{api}/api/actions/capabilities")
    if isinstance(caps, dict) and isinstance(caps.get("capabilities"), list):
        report["capabilities_summary"] = {"count": len(caps["capabilities"])}
    else:
        report["capabilities_summary"] = {"_invalid": True, "type": str(type(caps)), "keys": sorted(caps.keys()) if isinstance(caps, dict) else None}

    _, missing = _http_json(f"{api}/api/actions/debug/missing-executors")
    report["missing_executors_summary"] = _summarize_actions_debug(missing, keys=["missing", "missing_types", "missing_executors"])

    _, mism = _http_json(f"{api}/api/actions/debug/capability-mismatches")
    report["capability_mismatches_summary"] = _summarize_actions_debug(mism, keys=["mismatches", "items"])

    # Runner status (shape only)
    _, runner = _http_json(f"{api}/api/actions/runner-status")
    if isinstance(runner, dict):
        report["runner_status_summary"] = {
            "keys": sorted(runner.keys()),
            "runner_alive": runner.get("runner_alive"),
        }
    else:
        report["runner_status_summary"] = {"_invalid": True, "type": str(type(runner))}

    # systemd unit states
    units = [
        "kinetic-actions-runner.service",
        "zakops-email-triage.timer",
        "zakops-deal-lifecycle-controller.timer",
    ]
    report["systemd_units"] = [_systemd_unit_state(u) for u in units]

    if args.markdown:
        _write_markdown(str(args.markdown), report)

    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
