#!/usr/bin/env python3
"""
ZakOps - Draft Approval Helper (Safe Outbox)

This tool is an approval workflow that does NOT send emails.
Instead, it converts `_DRAFT_broker_reply.md` into an RFC822 `.eml` file
under the deal's `07-Correspondence/OUTBOX/` folder so you can review and
send using your email client.

Why:
  - Keeps automation safe (no auto-send, no SMTP secrets required)
  - Still gives a deterministic "approve" action and audit trail
"""

from __future__ import annotations

import argparse
import json
import re
from datetime import datetime
from email.message import EmailMessage
from pathlib import Path
from typing import Any, Dict, Optional, Tuple


def read_json(path: Path) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def normalize_sender_email(sender: str) -> str:
    if not sender:
        return ""
    match = re.search(r"<([^>]+)>", sender)
    if match:
        return match.group(1).strip().lower()
    sender = sender.strip().strip('"').strip().lower()
    if "@" in sender and " " not in sender:
        return sender
    return ""


def find_latest_manifest(deal_folder: Path) -> Optional[Path]:
    corr = deal_folder / "07-Correspondence"
    manifests = sorted(corr.glob("*_manifest.json"), key=lambda p: p.stat().st_mtime, reverse=True)
    return manifests[0] if manifests else None


def load_email_context(deal_folder: Path) -> Tuple[str, str]:
    """
    Returns (to_email, subject)
    """
    mf = find_latest_manifest(deal_folder)
    if not mf:
        return "", ""
    data = read_json(mf)
    to_email = normalize_sender_email(str(data.get("sender") or ""))
    subject = str(data.get("subject") or "").strip()
    return to_email, subject


def markdown_to_text(md: str) -> str:
    # Keep it simple: strip leading markdown formatting that hurts plain email.
    lines = []
    for line in md.splitlines():
        line = re.sub(r"^#+\\s*", "", line)
        line = re.sub(r"^\\s*[-*]\\s+", "- ", line)
        lines.append(line.rstrip())
    return "\n".join(lines).strip() + "\n"


def main() -> None:
    parser = argparse.ArgumentParser(description="Approve ZakOps drafts by generating .eml outbox files (no sending)")
    parser.add_argument("deal_folder", help="Path to deal folder (e.g., /home/zaks/DataRoom/00-PIPELINE/Inbound/<Deal>)")
    parser.add_argument("--approve", action="store_true", help="Required to actually write .eml files")
    parser.add_argument("--force", action="store_true", help="Overwrite existing outbox .eml")
    args = parser.parse_args()

    deal_folder = Path(args.deal_folder)
    if not deal_folder.exists():
        raise SystemExit(f"Deal folder not found: {deal_folder}")

    draft_path = deal_folder / "_DRAFT_broker_reply.md"
    if not draft_path.exists():
        raise SystemExit(f"Draft not found: {draft_path}")

    to_email, original_subject = load_email_context(deal_folder)
    if not to_email:
        raise SystemExit("Could not determine broker email from latest manifest (missing sender)")

    subject = original_subject
    if subject and not subject.lower().startswith("re:"):
        subject = f"RE: {subject}"

    outbox_dir = deal_folder / "07-Correspondence" / "OUTBOX"
    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    out_eml = outbox_dir / f"{ts}_broker_reply.eml"

    if out_eml.exists() and not args.force:
        raise SystemExit(f"Outbox file already exists: {out_eml} (use --force)")

    if not args.approve:
        print("DRY RUN (no files written).")
        print(f"- Would write: {out_eml}")
        print(f"- To: {to_email}")
        print(f"- Subject: {subject}")
        return

    outbox_dir.mkdir(parents=True, exist_ok=True)

    msg = EmailMessage()
    msg["To"] = to_email
    msg["Subject"] = subject or "RE: Deal Opportunity"
    msg.set_content(markdown_to_text(draft_path.read_text(encoding="utf-8", errors="ignore")))

    out_eml.write_bytes(msg.as_bytes())

    # Audit log
    log_path = outbox_dir / "APPROVAL-LOG.md"
    entry = f"- {datetime.now().isoformat()} approved `{draft_path.name}` -> `{out_eml.name}`\n"
    if log_path.exists():
        log_path.write_text(log_path.read_text(encoding="utf-8") + entry, encoding="utf-8")
    else:
        log_path.write_text("# Outbox Approval Log\n\n" + entry, encoding="utf-8")

    print(str(out_eml))


if __name__ == "__main__":
    main()

