#!/usr/bin/env python3
"""
LangSmith Tool Binder - Programmatically bind ZakOps MCP tools to LangGraph agent.

This script uses the LangGraph SDK to add ZakOps MCP tools to the agent's
bound tool list, bypassing the UI limitation where tools appear in TOOLBOX
but don't bind to the LLM runtime.

Usage:
    python langsmith_tool_binder.py inspect   - View current tools
    python langsmith_tool_binder.py bind      - Add ZakOps tools
    python langsmith_tool_binder.py dump      - Dump full assistant config (debug)

Environment:
    LANGSMITH_API_KEY - Your LangSmith API key (required)
"""

import asyncio
import json
import os
import sys

from langgraph_sdk import get_client

# Configuration
DEPLOYMENT_URL = "https://prod-deepagents-agent-build-d4c1479ed8ce53fbb8c3eefc91f0aa7d.us.langgraph.app"
AGENT_ID = "2416e0fb-228f-45f4-af3a-e7b0c4618bb9"
API_KEY = os.getenv("LANGSMITH_API_KEY")

# MCP Server name as configured in LangSmith (check exact spelling/case)
MCP_SERVER_NAME = "ZakOps"  # Adjust if different

# ZakOps tool names (from your MCP server's tools/list)
ZAKOPS_TOOLS = [
    "ZakOps_check_system_health",
    "ZakOps_list_deals",
    "ZakOps_get_deal",
    "ZakOps_create_deal",
    "ZakOps_transition_deal",
    "ZakOps_get_pipeline_summary",
    "ZakOps_list_quarantine",
    "ZakOps_approve_quarantine",
    "ZakOps_list_actions",
    "ZakOps_approve_action",
]


def check_api_key():
    """Verify API key is set."""
    if not API_KEY:
        print("ERROR: LANGSMITH_API_KEY environment variable not set!")
        print("")
        print("To set it:")
        print("  export LANGSMITH_API_KEY='lsv2_pt_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'")
        print("")
        print("Get your API key from: https://smith.langchain.com → Settings → API Keys")
        sys.exit(1)


async def inspect_agent():
    """Inspect current agent configuration and bound tools."""
    check_api_key()
    client = get_client(url=DEPLOYMENT_URL, api_key=API_KEY)

    print("=" * 60)
    print("INSPECTING AGENT CONFIGURATION")
    print("=" * 60)

    # Search for assistants
    assistants = await client.assistants.search()

    if not assistants:
        print("ERROR: No assistants found!")
        return None

    print(f"\nFound {len(assistants)} assistant(s):\n")

    for i, assistant in enumerate(assistants):
        print(f"--- Assistant {i+1} ---")
        assistant_id = assistant.get('assistant_id')
        print(f"  ID: {assistant_id}")
        print(f"  Name: {assistant.get('name', 'N/A')}")
        print(f"  Graph ID: {assistant.get('graph_id', 'N/A')}")

        # Check if this is our target agent
        if assistant_id == AGENT_ID:
            print(f"  >>> THIS IS THE TARGET AGENT <<<")

        # Try multiple places where tools might be stored
        context = assistant.get("config", {}).get("configurable", {})
        if not context:
            context = assistant.get("context", {})

        current_tools = context.get("tools", [])

        # Also check metadata
        metadata = assistant.get("metadata", {})
        if metadata.get("tools"):
            current_tools = metadata.get("tools", [])

        print(f"  Current Tools ({len(current_tools)}):")
        if current_tools:
            for tool in current_tools:
                print(f"    - {tool}")
        else:
            print("    (none bound)")
        print()

    return assistants


async def dump_assistant():
    """Dump full assistant configuration for debugging."""
    check_api_key()
    client = get_client(url=DEPLOYMENT_URL, api_key=API_KEY)

    print("=" * 60)
    print("DUMPING FULL ASSISTANT CONFIGURATION")
    print("=" * 60)

    try:
        assistant = await client.assistants.get(AGENT_ID)
        print(f"\nAssistant ID: {AGENT_ID}\n")
        print(json.dumps(assistant, indent=2, default=str))
    except Exception as e:
        print(f"ERROR getting assistant by ID: {e}")
        print("\nFalling back to search...")
        assistants = await client.assistants.search()
        for assistant in assistants:
            print(f"\n--- {assistant.get('assistant_id')} ---")
            print(json.dumps(assistant, indent=2, default=str))


async def add_zakops_tools():
    """Add ZakOps MCP tools to the agent's bound tool list."""
    check_api_key()
    client = get_client(url=DEPLOYMENT_URL, api_key=API_KEY)

    print("=" * 60)
    print("ADDING ZAKOPS TOOLS TO AGENT")
    print("=" * 60)

    # Use the known Agent ID directly
    assistant_id = AGENT_ID
    print(f"\nTarget Assistant ID: {assistant_id}")

    # Get the assistant details
    try:
        assistant = await client.assistants.get(assistant_id)
    except Exception as e:
        print(f"ERROR: Could not get assistant: {e}")
        print("Falling back to search...")
        assistants = await client.assistants.search()
        if not assistants:
            print("ERROR: No assistants found!")
            return
        assistant = assistants[0]
        assistant_id = assistant["assistant_id"]

    print(f"Name: {assistant.get('name', 'N/A')}")

    # Get current context from various possible locations
    current_config = assistant.get("config", {})
    current_configurable = current_config.get("configurable", {})
    current_context = assistant.get("context", {})
    current_metadata = assistant.get("metadata", {})

    # Find current tools from any location
    current_tools = (
        current_configurable.get("tools", []) or
        current_context.get("tools", []) or
        current_metadata.get("tools", []) or
        []
    )

    print(f"\nCurrent tools ({len(current_tools)}):")
    for tool in current_tools:
        print(f"  - {tool}")

    # Build MCP tool IDs - try multiple formats
    # Format 1: mcp__{server_name}__{tool_name}
    mcp_tools_format1 = [
        f"mcp__{MCP_SERVER_NAME}__{tool_name}"
        for tool_name in ZAKOPS_TOOLS
    ]

    # Format 2: Just the tool name (some systems use this)
    mcp_tools_format2 = ZAKOPS_TOOLS.copy()

    print(f"\nMCP tool IDs to add (Format 1: mcp__server__tool):")
    for tool_id in mcp_tools_format1:
        print(f"  - {tool_id}")

    # Combine existing tools with new ones (avoid duplicates)
    # Use format 1 as primary
    updated_tool_list = list(set(current_tools + mcp_tools_format1))

    print(f"\nUpdated tool list ({len(updated_tool_list)} total):")
    for tool in sorted(updated_tool_list):
        print(f"  - {tool}")

    # Update the assistant - try multiple methods
    print("\n" + "-" * 40)
    print("Attempting to update assistant configuration...")
    print("-" * 40)

    success = False

    # Method 1: Update via context
    try:
        print("\nMethod 1: Updating via context...")
        updated_context = {
            **current_context,
            "tools": updated_tool_list
        }

        await client.assistants.update(
            assistant_id,
            context=updated_context
        )
        print("SUCCESS: Updated via context!")
        success = True

    except Exception as e1:
        print(f"Method 1 failed: {e1}")

    # Method 2: Update via config.configurable
    if not success:
        try:
            print("\nMethod 2: Updating via config.configurable...")
            updated_configurable = {
                **current_configurable,
                "tools": updated_tool_list
            }
            updated_config = {
                **current_config,
                "configurable": updated_configurable
            }

            await client.assistants.update(
                assistant_id,
                config=updated_config
            )
            print("SUCCESS: Updated via config.configurable!")
            success = True

        except Exception as e2:
            print(f"Method 2 failed: {e2}")

    # Method 3: Update via metadata
    if not success:
        try:
            print("\nMethod 3: Updating via metadata...")
            updated_metadata = {
                **current_metadata,
                "tools": updated_tool_list
            }

            await client.assistants.update(
                assistant_id,
                metadata=updated_metadata
            )
            print("SUCCESS: Updated via metadata!")
            success = True

        except Exception as e3:
            print(f"Method 3 failed: {e3}")

    if not success:
        print("\n" + "=" * 60)
        print("ERROR: All update methods failed!")
        print("=" * 60)
        print("\nPossible causes:")
        print("  1. API key doesn't have write permissions")
        print("  2. Agent Builder uses a different configuration model")
        print("  3. Tool binding is managed differently in Agent Builder")
        print("\nNext steps:")
        print("  1. Run 'dump' command to see full assistant structure")
        print("  2. Check LangSmith documentation for tool binding API")
        print("  3. Contact LangChain support if needed")
        return

    print("\n" + "=" * 60)
    print("DONE! Next steps:")
    print("=" * 60)
    print("  1. Start a NEW chat thread in Agent Builder")
    print("     (old threads won't pick up the changes)")
    print("  2. Ask: 'Run ZakOps_check_system_health'")
    print("  3. Check MCP server logs for tools/call request:")
    print("     tail -f /tmp/mcp-requests.log")
    print("=" * 60)


async def main():
    """Main entry point."""
    if len(sys.argv) < 2:
        print("LangSmith Tool Binder - Bind ZakOps MCP tools to LangGraph agent")
        print("")
        print("Usage:")
        print("  python langsmith_tool_binder.py inspect   - View current tools")
        print("  python langsmith_tool_binder.py bind      - Add ZakOps tools")
        print("  python langsmith_tool_binder.py dump      - Dump full config (debug)")
        print("")
        print("Environment:")
        print("  LANGSMITH_API_KEY - Your LangSmith API key (required)")
        return

    command = sys.argv[1].lower()

    if command == "inspect":
        await inspect_agent()
    elif command == "bind":
        await add_zakops_tools()
    elif command == "dump":
        await dump_assistant()
    else:
        print(f"Unknown command: {command}")
        print("Use: inspect, bind, or dump")


if __name__ == "__main__":
    asyncio.run(main())
