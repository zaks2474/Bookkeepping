#!/usr/bin/env python3
"""
Automated Deal Scoring

Uses RAG to analyze deal against buy box criteria and generate score

Usage:
  ./score_deal.py "TeamLogic-IT-MSP-2025"
  ./score_deal.py "NIN-IT-Services-2025" --verbose
"""

import sys
import os
import requests
import json
import argparse
from typing import Dict, List, Optional

RAG_QUERY_URL = os.getenv("RAG_QUERY_URL", "http://localhost:8052/rag/query")

# Buy Box Criteria (adjust weights and targets as needed)
BUY_BOX_CRITERIA = {
    "sector": {
        "weight": 0.25,
        "target": "MSP, IT Services, Cybersecurity, SaaS",
        "keywords": ["msp", "managed service", "it services", "cybersecurity", "saas", "software"]
    },
    "revenue": {
        "weight": 0.20,
        "target": "$1M-$5M annual",
        "min": 1000000,
        "max": 5000000
    },
    "ebitda": {
        "weight": 0.20,
        "target": "$350K+ or 15%+ margin",
        "min": 350000
    },
    "location": {
        "weight": 0.10,
        "target": "Texas preferred, US acceptable",
        "preferred": ["texas", "tx", "houston", "dallas", "austin", "san antonio"],
        "acceptable": ["us", "united states", "usa"]
    },
    "retention": {
        "weight": 0.15,
        "target": ">85% annual customer retention",
        "min": 85
    },
    "growth": {
        "weight": 0.10,
        "target": ">10% YoY growth",
        "min": 10
    },
}


def query_rag(question: str, deal_name: str) -> List[Dict]:
    """Query RAG for deal information."""
    full_query = f"{question} for {deal_name}"
    payload = {
        "query": full_query,
        "match_count": 15,
        "source": "dataroom.local",
    }

    try:
        response = requests.post(RAG_QUERY_URL, json=payload, timeout=30)
        if response.status_code == 200:
            return response.json().get("results", [])
    except Exception as e:
        print(f"⚠ RAG query error: {e}")

    return []


def extract_deal_facts(deal_name: str, verbose: bool = False) -> Dict:
    """Extract key facts about deal from RAG."""
    facts = {}

    # Query for different aspects
    queries = [
        ("sector", "What sector or industry is this business in"),
        ("revenue", "What is the annual revenue"),
        ("ebitda", "What is the EBITDA or profit margin"),
        ("location", "Where is this business located"),
        ("retention", "What is the customer retention rate"),
        ("growth", "What is the revenue growth rate"),
        ("summary", "Summarize this deal opportunity"),
    ]

    all_content = []

    for fact_type, query in queries:
        results = query_rag(query, deal_name)
        if results:
            # Combine all content for this query
            content = "\n".join([r.get("content", "") for r in results[:5]])
            facts[fact_type] = content
            all_content.append(content)

            if verbose:
                print(f"  {fact_type}: Found {len(results)} relevant chunks")

    facts["_raw_content"] = "\n\n".join(all_content)
    return facts


def score_criterion(criterion_name: str, facts: Dict) -> tuple:
    """Score a single criterion based on extracted facts."""
    criterion = BUY_BOX_CRITERIA[criterion_name]
    content = facts.get(criterion_name, "").lower()
    raw_content = facts.get("_raw_content", "").lower()

    score = 0.5  # Default middle score if unclear
    reason = "Insufficient data"

    if criterion_name == "sector":
        # Check for target keywords
        keywords_found = []
        for keyword in criterion["keywords"]:
            if keyword in content or keyword in raw_content:
                keywords_found.append(keyword)

        if keywords_found:
            score = min(1.0, 0.6 + 0.1 * len(keywords_found))
            reason = f"Found: {', '.join(keywords_found)}"
        else:
            score = 0.3
            reason = "No target sector keywords found"

    elif criterion_name == "location":
        # Check for preferred/acceptable locations
        for loc in criterion["preferred"]:
            if loc in content or loc in raw_content:
                score = 1.0
                reason = f"Preferred location: {loc}"
                break

        if score < 1.0:
            for loc in criterion["acceptable"]:
                if loc in content or loc in raw_content:
                    score = 0.7
                    reason = f"Acceptable location: {loc}"
                    break

    else:
        # For numeric criteria, try to extract numbers
        import re
        numbers = re.findall(r'[\$]?([\d,]+(?:\.\d+)?)[%KMBkmb]?', content + " " + raw_content)

        if numbers:
            # Take the largest reasonable number
            parsed_numbers = []
            for n in numbers:
                try:
                    val = float(n.replace(',', ''))
                    parsed_numbers.append(val)
                except ValueError:
                    pass

            if parsed_numbers:
                # Use heuristics based on criterion type
                if criterion_name == "revenue":
                    # Look for values in millions
                    candidates = [n for n in parsed_numbers if 100000 < n < 100000000]
                    if candidates:
                        val = max(candidates)
                        if val >= criterion["min"] and val <= criterion["max"]:
                            score = 1.0
                            reason = f"${val:,.0f} within target range"
                        elif val >= criterion["min"]:
                            score = 0.7
                            reason = f"${val:,.0f} above minimum"
                        else:
                            score = 0.4
                            reason = f"${val:,.0f} below target"

                elif criterion_name == "retention" or criterion_name == "growth":
                    # Look for percentages
                    candidates = [n for n in parsed_numbers if 0 < n < 100]
                    if candidates:
                        val = max(candidates)
                        if val >= criterion["min"]:
                            score = 1.0
                            reason = f"{val}% meets target"
                        else:
                            score = val / criterion["min"]
                            reason = f"{val}% below {criterion['min']}% target"

    return score, reason


def score_deal(deal_name: str, verbose: bool = False) -> Dict:
    """Score deal against buy box criteria."""
    print(f"\n{'='*60}")
    print(f"Deal Scoring: {deal_name}")
    print(f"{'='*60}\n")

    # Extract facts from RAG
    print("Extracting deal facts from DataRoom...")
    facts = extract_deal_facts(deal_name, verbose)

    if not facts.get("_raw_content"):
        print(f"\n⚠ No information found for deal: {deal_name}")
        print("Make sure the deal exists in DataRoom and has been indexed.")
        return {}

    # Score each criterion
    print("\nScoring against buy box criteria:\n")
    scores = {}
    total_score = 0

    for criterion_name, criterion_config in BUY_BOX_CRITERIA.items():
        score, reason = score_criterion(criterion_name, facts)
        weight = criterion_config["weight"]
        weighted_score = score * weight * 100

        scores[criterion_name] = {
            "score": score,
            "weight": weight,
            "weighted": weighted_score,
            "reason": reason,
            "target": criterion_config["target"]
        }

        total_score += weighted_score

        # Display
        bar = "█" * int(score * 10) + "░" * (10 - int(score * 10))
        print(f"  {criterion_name.capitalize():12} [{bar}] {weighted_score:5.1f}/{weight*100:.0f}")
        if verbose:
            print(f"                 Target: {criterion_config['target']}")
            print(f"                 {reason}")
            print()

    # Final score
    print(f"\n{'─'*60}")
    print(f"FINAL SCORE: {total_score:.0f}/100")
    print(f"{'─'*60}")

    # Recommendation
    if total_score >= 80:
        recommendation = "STRONG PURSUE"
        emoji = "🟢"
    elif total_score >= 70:
        recommendation = "PURSUE"
        emoji = "🟡"
    elif total_score >= 60:
        recommendation = "REVIEW FURTHER"
        emoji = "🟠"
    else:
        recommendation = "PASS"
        emoji = "🔴"

    print(f"\nRecommendation: {emoji} {recommendation}")
    print(f"{'='*60}\n")

    return {
        "deal": deal_name,
        "total_score": total_score,
        "recommendation": recommendation,
        "criteria_scores": scores
    }


def main():
    parser = argparse.ArgumentParser(description="Score a deal against buy box criteria")
    parser.add_argument("deal_name", help="Deal folder name (e.g., TeamLogic-IT-MSP-2025)")
    parser.add_argument("-v", "--verbose", action="store_true", help="Show detailed scoring")
    parser.add_argument("-o", "--output", help="Save results to JSON file")

    args = parser.parse_args()

    results = score_deal(args.deal_name, args.verbose)

    if args.output and results:
        with open(args.output, 'w') as f:
            json.dump(results, f, indent=2)
        print(f"Results saved to: {args.output}")


if __name__ == "__main__":
    main()
