#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import sqlite3
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional


def _now_utc_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


@dataclass(frozen=True)
class CheckResult:
    ok: bool
    name: str
    details: Dict[str, Any]
    error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "ok": bool(self.ok),
            "name": self.name,
            "details": self.details,
            "error": self.error,
        }


def _is_writable_dir(path: Path) -> bool:
    try:
        if not path.exists() or not path.is_dir():
            return False
        return os.access(str(path), os.W_OK | os.X_OK)
    except Exception:
        return False


def _check_dataroom_root() -> CheckResult:
    dataroom = Path(os.getenv("DATAROOM_ROOT", "/home/zaks/DataRoom")).resolve()
    details = {"path": str(dataroom), "exists": dataroom.exists(), "is_dir": dataroom.is_dir() if dataroom.exists() else False}
    if not dataroom.exists() or not dataroom.is_dir():
        return CheckResult(ok=False, name="dataroom_root", details=details, error="missing_or_not_dir")
    if not _is_writable_dir(dataroom):
        return CheckResult(ok=False, name="dataroom_root", details=details, error="not_writable")
    return CheckResult(ok=True, name="dataroom_root", details=details)


def _check_registry_dirs() -> CheckResult:
    dataroom = Path(os.getenv("DATAROOM_ROOT", "/home/zaks/DataRoom")).resolve()
    registry_root = dataroom / ".deal-registry"
    events_dir = registry_root / "events"
    details = {"registry_root": str(registry_root), "events_dir": str(events_dir)}
    try:
        registry_root.mkdir(parents=True, exist_ok=True)
        events_dir.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        return CheckResult(ok=False, name="registry_dirs", details=details, error=f"mkdir_failed:{type(e).__name__}")
    if not _is_writable_dir(registry_root):
        return CheckResult(ok=False, name="registry_dirs", details=details, error="registry_root_not_writable")
    if not _is_writable_dir(events_dir):
        return CheckResult(ok=False, name="registry_dirs", details=details, error="events_dir_not_writable")
    return CheckResult(ok=True, name="registry_dirs", details=details)


def _check_state_db() -> CheckResult:
    db_path = Path(os.getenv("ZAKOPS_STATE_DB", "/home/zaks/DataRoom/.deal-registry/ingest_state.db")).resolve()
    details = {"path": str(db_path), "parent": str(db_path.parent)}
    try:
        db_path.parent.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        return CheckResult(ok=False, name="state_db", details=details, error=f"mkdir_parent_failed:{type(e).__name__}")

    if not _is_writable_dir(db_path.parent):
        return CheckResult(ok=False, name="state_db", details=details, error="parent_not_writable")

    try:
        conn = sqlite3.connect(str(db_path))
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("PRAGMA synchronous=NORMAL;")
        conn.execute("PRAGMA busy_timeout=5000;")
        conn.execute("SELECT 1;")
        conn.commit()
        conn.close()
    except Exception as e:
        return CheckResult(ok=False, name="state_db", details=details, error=f"sqlite_open_failed:{type(e).__name__}:{e}")

    details["exists"] = db_path.exists()
    return CheckResult(ok=True, name="state_db", details=details)


def main() -> int:
    checks: List[CheckResult] = [
        _check_dataroom_root(),
        _check_registry_dirs(),
        _check_state_db(),
    ]
    ok = all(c.ok for c in checks)
    report = {
        "timestamp": _now_utc_iso(),
        "ok": ok,
        "checks": [c.to_dict() for c in checks],
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if ok else 2


if __name__ == "__main__":
    raise SystemExit(main())

