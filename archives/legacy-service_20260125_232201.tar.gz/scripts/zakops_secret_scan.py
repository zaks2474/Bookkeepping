#!/usr/bin/env python3
"""
ZakOps Secret Scanner (best-effort, no-exfil)

Purpose:
  - Detect obvious credential/token/private-key patterns before content is:
    - uploaded externally (e.g., SharePoint),
    - indexed into RAG,
    - or stored as agent traces/datasets.

Notes:
  - Returns *labels only*; never returns matched substrings.
  - Designed to avoid common placeholder examples like `sk-proj-...` by requiring
    realistic token shapes/lengths.
"""

from __future__ import annotations

import argparse
import os
import re
import sys
from pathlib import Path
from typing import Iterable


_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    (
        "langsmith_api_key",
        re.compile(r"\blsv2_pt_[A-Za-z0-9]{16,}_[A-Za-z0-9]{8,}\b"),
    ),
    (
        "openai_api_key",
        re.compile(r"\bsk-[A-Za-z0-9]{20,}\b"),
    ),
    (
        "openai_project_key",
        re.compile(r"\bsk-proj-[A-Za-z0-9_-]{20,}\b"),
    ),
    (
        "github_token",
        re.compile(r"\bghp_[A-Za-z0-9]{30,}\b"),
    ),
    (
        "slack_token",
        re.compile(r"\bxox[baprs]-[A-Za-z0-9-]{20,}\b"),
    ),
    (
        "aws_access_key_id",
        re.compile(r"\b(?:AKIA|ASIA)[0-9A-Z]{16}\b"),
    ),
    (
        "google_api_key",
        re.compile(r"\bAIza[0-9A-Za-z\-_]{20,}\b"),
    ),
    (
        "linkedin_cookie_li_at",
        re.compile(r"\bli_at=[A-Za-z0-9_%\-]{20,}\b"),
    ),
    (
        "private_key_block",
        re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    ),
    (
        "bearer_token",
        re.compile(r"\bBearer\s+[A-Za-z0-9\-._~+/]{20,}={0,2}\b"),
    ),
]


def find_secrets_in_text(text: str) -> list[str]:
    """Return labels of detected secret-like patterns found in text."""
    found: list[str] = []
    for label, pattern in _PATTERNS:
        if pattern.search(text):
            found.append(label)
    return sorted(set(found))


def should_scan_extension(path: Path, allowed_extensions: Iterable[str]) -> bool:
    return path.suffix.lower() in {ext.lower() for ext in allowed_extensions}


def scan_file_for_secrets(path: Path, *, max_bytes: int = 2_000_000) -> list[str]:
    """
    Scan a file (best-effort) for secret-like patterns.

    - Skips likely-binary files (NUL byte present in the sampled bytes).
    - Scans up to max_bytes from the start of the file (fast path).
    """
    try:
        with open(path, "rb") as fh:
            sample = fh.read(max_bytes)
    except Exception:
        return []

    if b"\x00" in sample:
        return []

    try:
        text = sample.decode("utf-8", errors="ignore")
    except Exception:
        return []

    return find_secrets_in_text(text)


def _iter_files(paths: list[Path], *, extensions: set[str], exclude_dirs: set[str]) -> Iterable[Path]:
    for root in paths:
        if root.is_file():
            yield root
            continue
        if not root.is_dir():
            continue

        for p in root.rglob("*"):
            if p.is_dir():
                continue
            if exclude_dirs and any(part in exclude_dirs for part in p.parts):
                continue
            if extensions and p.suffix.lower() not in extensions:
                continue
            yield p


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="ZakOps secret scanner (labels only; no exfil)")
    parser.add_argument(
        "paths",
        nargs="*",
        help="Files/directories to scan (default: current directory)",
    )
    parser.add_argument(
        "--max-bytes",
        type=int,
        default=int(os.getenv("ZAKOPS_SECRET_SCAN_MAX_BYTES", "2000000")),
        help="Max bytes to scan per file (default: 2000000 or ZAKOPS_SECRET_SCAN_MAX_BYTES)",
    )
    parser.add_argument(
        "--ext",
        action="append",
        default=[],
        help="File extension to include (repeatable). Default scans common text/code extensions.",
    )
    parser.add_argument(
        "--exclude-dir",
        action="append",
        default=[],
        help="Directory name to skip during recursive scans (repeatable).",
    )

    args = parser.parse_args(argv)

    default_exts = {
        ".md",
        ".txt",
        ".csv",
        ".json",
        ".jsonl",
        ".yaml",
        ".yml",
        ".py",
        ".sh",
        ".toml",
        ".ini",
        ".cfg",
        ".conf",
        ".env",
    }
    extensions = {e if e.startswith(".") else f".{e}" for e in (args.ext or [])} or default_exts
    exclude_dirs = set(args.exclude_dir or [])
    if not exclude_dirs:
        exclude_dirs = {
            ".git",
            "__pycache__",
            "node_modules",
            ".cache",
            ".aws",
            ".azure",
            ".ssh",
            "snapshots",
            "logs",
            "backups",
            "venv",
            ".venv",
        }

    scan_roots = [Path(p) for p in (args.paths or ["."])]

    scanned = 0
    flagged: list[tuple[str, list[str]]] = []

    for path in _iter_files(scan_roots, extensions=extensions, exclude_dirs=exclude_dirs):
        scanned += 1
        findings = scan_file_for_secrets(path, max_bytes=args.max_bytes)
        if findings:
            flagged.append((str(path), findings))

    if flagged:
        for file_path, findings in flagged:
            print(f"{file_path}: {', '.join(findings)}")
        print(f"\nFound secret-like patterns in {len(flagged)} file(s) (scanned {scanned}).", file=sys.stderr)
        return 1

    print(f"No secret-like patterns found (scanned {scanned}).", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
