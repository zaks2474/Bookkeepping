#!/usr/bin/env python3
"""
Deal Underwriter Agent

Mission: "Turn docs into financial picture."
- Extract key financial metrics from documents
- Calculate buy-box fit score
- Identify risks and concerns
- Generate open questions
- Produce structured analysis artifacts

Inputs:
- Deal context (registry, events, case file)
- Document inventory
- Buy-box criteria (from config)

Outputs:
- Analysis artifacts (financial memo, buy-box score)
- ai_recommendation events
- Case file updates (key_facts, buy_box_fit, risk_flags, open_questions)

Hard Boundaries:
- No LOI/price commitments without approval
- Advisory only - does not make decisions
- No direct counterparty contact

Usage:
    python3 deal_underwriter.py analyze DEAL-2025-001
    python3 deal_underwriter.py score DEAL-2025-001
    python3 deal_underwriter.py questions DEAL-2025-001
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

# Add paths
sys.path.insert(0, str(Path(__file__).parent))
sys.path.insert(0, str(Path("/home/zaks/Zaks-llm/src")))

from deal_registry import DealRegistry
from deal_events import DealEventStore
from deal_case_manager import DealCaseManagerAgent, AgentResult, DealContext

# Configuration
REGISTRY_PATH = "/home/zaks/DataRoom/.deal-registry/deal_registry.json"
CASE_FILES_DIR = Path("/home/zaks/DataRoom/.deal-registry/case_files")
ARTIFACTS_DIR = Path("/home/zaks/DataRoom/.deal-registry/artifacts")
RUN_LEDGER_PATH = Path("/home/zaks/logs/run-ledger.jsonl")

# Buy-Box Criteria (configurable)
BUY_BOX_CRITERIA = {
    "revenue": {
        "min": 1_000_000,  # $1M minimum
        "max": 10_000_000,  # $10M maximum
        "weight": 20,
    },
    "ebitda_margin": {
        "min": 0.15,  # 15% minimum
        "target": 0.25,  # 25% target
        "weight": 20,
    },
    "recurring_revenue_pct": {
        "min": 0.5,  # 50% minimum recurring
        "target": 0.8,  # 80% target
        "weight": 15,
    },
    "customer_concentration": {
        "max": 0.25,  # No customer > 25%
        "weight": 15,
    },
    "growth_rate": {
        "min": 0.05,  # 5% minimum
        "target": 0.15,  # 15% target
        "weight": 10,
    },
    "employees": {
        "min": 5,
        "max": 50,
        "weight": 10,
    },
    "industry_fit": {
        "preferred": ["B2B SaaS", "IT Services", "MSP", "Software"],
        "weight": 10,
    },
}


@dataclass
class FinancialMetrics:
    """Extracted financial metrics"""
    revenue: Optional[float] = None
    revenue_type: str = "unknown"  # ARR, MRR, annual, etc.
    ebitda: Optional[float] = None
    ebitda_margin: Optional[float] = None
    gross_margin: Optional[float] = None
    growth_rate: Optional[float] = None
    recurring_revenue_pct: Optional[float] = None
    customer_count: Optional[int] = None
    largest_customer_pct: Optional[float] = None
    employee_count: Optional[int] = None
    asking_price: Optional[float] = None
    asking_multiple: Optional[float] = None

    def to_dict(self) -> Dict[str, Any]:
        return {k: v for k, v in self.__dict__.items() if v is not None}


@dataclass
class BuyBoxScore:
    """Buy-box fit assessment"""
    total_score: int  # 0-100
    meets_criteria: List[str]
    concerns: List[str]
    disqualifying_factors: List[str]
    component_scores: Dict[str, int]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "score": self.total_score,
            "meets_criteria": self.meets_criteria,
            "concerns": self.concerns,
            "disqualifying_factors": self.disqualifying_factors,
            "component_scores": self.component_scores,
        }


class UnderwriterAgent:
    """
    Underwriter Agent - financial analysis and buy-box scoring.
    """

    def __init__(self, llm_router=None):
        self.registry = DealRegistry(REGISTRY_PATH)
        self.event_store = DealEventStore()
        self.case_manager = DealCaseManagerAgent(llm_router)
        self.llm_router = llm_router
        self._ensure_dirs()

    def _ensure_dirs(self) -> None:
        """Ensure required directories exist"""
        ARTIFACTS_DIR.mkdir(parents=True, exist_ok=True)

    def _log_run(self, deal_id: str, task: str, result: AgentResult) -> None:
        """Log agent run to ledger"""
        entry = {
            "timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "agent": "underwriter",
            "deal_id": deal_id,
            "task": task,
            "success": result.success,
            "summary": result.summary[:200],
            "confidence": result.confidence,
        }
        with open(RUN_LEDGER_PATH, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry) + "\n")

    def analyze(self, deal_id: str) -> AgentResult:
        """
        Perform full financial analysis on a deal.

        Extracts metrics, scores buy-box fit, identifies risks.
        """
        context = self.case_manager.load_context(deal_id)
        if not context:
            return AgentResult(
                success=False,
                summary=f"Deal not found: {deal_id}",
                errors=[f"Deal {deal_id} not found in registry"],
            )

        # Extract metrics from available data
        metrics = self._extract_metrics(context)

        # Calculate buy-box score
        score = self._calculate_buy_box_score(metrics, context)

        # Generate questions
        questions = self._generate_questions(metrics, context)

        # Identify risks
        risks = self._identify_risks(metrics, score, context)

        # Update case file
        case_file = context.case_file or {"deal_id": deal_id}
        case_file["key_facts"] = metrics.to_dict()
        case_file["buy_box_fit"] = score.to_dict()
        case_file["open_questions"] = questions
        case_file["risk_flags"] = risks
        case_file["last_updated"] = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        case_file["updated_by"] = "underwriter_agent"

        self.case_manager._save_case_file(deal_id, case_file)

        # Emit recommendation event
        recommendation = self._generate_recommendation(metrics, score, context)
        self.event_store.create_event(
            deal_id=deal_id,
            event_type="ai_recommendation",
            actor="underwriter",
            data={
                "agent": "underwriter",
                "recommendation_type": recommendation["type"],
                "summary": recommendation["summary"],
                "confidence": recommendation["confidence"],
                "supporting_data": {
                    "buy_box_score": score.total_score,
                    "metrics": metrics.to_dict(),
                },
            },
        )

        # Save analysis artifact
        artifact = {
            "deal_id": deal_id,
            "analysis_date": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "metrics": metrics.to_dict(),
            "buy_box_score": score.to_dict(),
            "questions": questions,
            "risks": risks,
            "recommendation": recommendation,
        }
        artifact_path = ARTIFACTS_DIR / f"{deal_id}_underwriter_analysis.json"
        with open(artifact_path, "w") as f:
            json.dump(artifact, f, indent=2)

        result = AgentResult(
            success=True,
            summary=f"Analysis complete: Buy-box score {score.total_score}/100, {len(risks)} risks, {len(questions)} questions",
            events=[{"type": "ai_recommendation", "data": recommendation}],
            case_file_update=case_file,
            confidence=0.8 if metrics.revenue else 0.5,
        )
        self._log_run(deal_id, "analyze", result)
        return result

    def _extract_metrics(self, context: DealContext) -> FinancialMetrics:
        """Extract financial metrics from deal context"""
        metrics = FinancialMetrics()
        deal = context.deal

        # From registry metadata
        if deal.metadata.asking_price:
            metrics.asking_price = self._parse_money(deal.metadata.asking_price)

        if deal.metadata.ebitda:
            metrics.ebitda = self._parse_money(deal.metadata.ebitda)

        # From case file if exists
        if context.case_file:
            kf = context.case_file.get("key_facts", {})
            if kf.get("revenue"):
                metrics.revenue = self._parse_money(kf["revenue"])
            if kf.get("ebitda"):
                metrics.ebitda = self._parse_money(kf["ebitda"])
            if kf.get("employees"):
                metrics.employee_count = int(kf["employees"]) if isinstance(kf["employees"], (int, float)) else None
            if kf.get("gross_margin"):
                metrics.gross_margin = self._parse_percentage(kf["gross_margin"])

        # Calculate derived metrics
        if metrics.revenue and metrics.ebitda:
            metrics.ebitda_margin = metrics.ebitda / metrics.revenue

        if metrics.asking_price and metrics.ebitda:
            metrics.asking_multiple = metrics.asking_price / metrics.ebitda

        return metrics

    def _parse_money(self, value: str) -> Optional[float]:
        """Parse money string to float"""
        if isinstance(value, (int, float)):
            return float(value)
        if not isinstance(value, str):
            return None

        # Remove common formatting
        value = value.upper().replace(",", "").replace("$", "").strip()

        # Handle suffixes
        multiplier = 1
        if value.endswith("M"):
            multiplier = 1_000_000
            value = value[:-1]
        elif value.endswith("K"):
            multiplier = 1_000
            value = value[:-1]
        elif value.endswith("MM"):
            multiplier = 1_000_000
            value = value[:-2]

        try:
            return float(value) * multiplier
        except ValueError:
            return None

    def _parse_percentage(self, value: str) -> Optional[float]:
        """Parse percentage string to float (0-1 range)"""
        if isinstance(value, (int, float)):
            return float(value) if value <= 1 else float(value) / 100
        if not isinstance(value, str):
            return None

        value = value.replace("%", "").strip()
        try:
            pct = float(value)
            return pct / 100 if pct > 1 else pct
        except ValueError:
            return None

    def _calculate_buy_box_score(self, metrics: FinancialMetrics, context: DealContext) -> BuyBoxScore:
        """Calculate buy-box fit score"""
        component_scores = {}
        meets = []
        concerns = []
        disqualifying = []
        total_weight = 0
        weighted_score = 0

        # Revenue check
        if metrics.revenue:
            weight = BUY_BOX_CRITERIA["revenue"]["weight"]
            total_weight += weight
            min_rev = BUY_BOX_CRITERIA["revenue"]["min"]
            max_rev = BUY_BOX_CRITERIA["revenue"]["max"]

            if min_rev <= metrics.revenue <= max_rev:
                component_scores["revenue"] = 100
                weighted_score += weight * 100
                meets.append("revenue")
            elif metrics.revenue < min_rev:
                component_scores["revenue"] = 50
                weighted_score += weight * 50
                concerns.append("revenue_below_minimum")
            else:
                component_scores["revenue"] = 70
                weighted_score += weight * 70
                concerns.append("revenue_above_target")

        # EBITDA margin check
        if metrics.ebitda_margin:
            weight = BUY_BOX_CRITERIA["ebitda_margin"]["weight"]
            total_weight += weight
            min_margin = BUY_BOX_CRITERIA["ebitda_margin"]["min"]
            target_margin = BUY_BOX_CRITERIA["ebitda_margin"]["target"]

            if metrics.ebitda_margin >= target_margin:
                component_scores["ebitda_margin"] = 100
                weighted_score += weight * 100
                meets.append("ebitda_margin")
            elif metrics.ebitda_margin >= min_margin:
                component_scores["ebitda_margin"] = 75
                weighted_score += weight * 75
                meets.append("ebitda_margin")
            else:
                component_scores["ebitda_margin"] = 25
                weighted_score += weight * 25
                concerns.append("low_ebitda_margin")

        # Employee count check
        if metrics.employee_count:
            weight = BUY_BOX_CRITERIA["employees"]["weight"]
            total_weight += weight
            min_emp = BUY_BOX_CRITERIA["employees"]["min"]
            max_emp = BUY_BOX_CRITERIA["employees"]["max"]

            if min_emp <= metrics.employee_count <= max_emp:
                component_scores["employees"] = 100
                weighted_score += weight * 100
                meets.append("employee_count")
            else:
                component_scores["employees"] = 50
                weighted_score += weight * 50
                concerns.append("employee_count_outside_range")

        # Industry fit
        deal = context.deal
        if deal.company_info.sector:
            weight = BUY_BOX_CRITERIA["industry_fit"]["weight"]
            total_weight += weight
            preferred = BUY_BOX_CRITERIA["industry_fit"]["preferred"]

            sector_lower = deal.company_info.sector.lower()
            matched = any(p.lower() in sector_lower for p in preferred)

            if matched:
                component_scores["industry_fit"] = 100
                weighted_score += weight * 100
                meets.append("industry_fit")
            else:
                component_scores["industry_fit"] = 50
                weighted_score += weight * 50
                concerns.append("non_preferred_industry")

        # Calculate total score
        total_score = int(weighted_score / total_weight) if total_weight > 0 else 50

        return BuyBoxScore(
            total_score=total_score,
            meets_criteria=meets,
            concerns=concerns,
            disqualifying_factors=disqualifying,
            component_scores=component_scores,
        )

    def _generate_questions(self, metrics: FinancialMetrics, context: DealContext) -> List[str]:
        """Generate open questions based on analysis"""
        questions = []

        # Missing data questions
        if not metrics.revenue:
            questions.append("What is the annual revenue (ARR or annual)?")
        if not metrics.ebitda:
            questions.append("What is the EBITDA or SDE?")
        if not metrics.customer_count:
            questions.append("How many customers does the business have?")
        if not metrics.largest_customer_pct:
            questions.append("What percentage of revenue comes from the largest customer?")
        if not metrics.recurring_revenue_pct:
            questions.append("What percentage of revenue is recurring?")
        if not metrics.growth_rate:
            questions.append("What is the year-over-year growth rate?")
        if not metrics.employee_count:
            questions.append("How many employees does the business have?")

        # Valuation questions
        if metrics.asking_multiple and metrics.asking_multiple > 5:
            questions.append(f"Asking multiple is {metrics.asking_multiple:.1f}x - what justifies premium valuation?")

        # Concentration questions
        if metrics.largest_customer_pct and metrics.largest_customer_pct > 0.2:
            questions.append("Customer concentration is high - what is retention history with top customers?")

        return questions[:10]  # Limit to top 10

    def _identify_risks(self, metrics: FinancialMetrics, score: BuyBoxScore, context: DealContext) -> List[str]:
        """Identify risk flags"""
        risks = []

        # From score concerns
        if "low_ebitda_margin" in score.concerns:
            risks.append("low_margins")
        if "revenue_below_minimum" in score.concerns:
            risks.append("below_target_size")

        # Customer concentration
        if metrics.largest_customer_pct and metrics.largest_customer_pct > 0.3:
            risks.append("customer_concentration_high")

        # Valuation
        if metrics.asking_multiple and metrics.asking_multiple > 6:
            risks.append("high_asking_multiple")

        # Key person risk (heuristic)
        if metrics.employee_count and metrics.employee_count < 10:
            risks.append("key_person_risk")

        return risks

    def _generate_recommendation(
        self,
        metrics: FinancialMetrics,
        score: BuyBoxScore,
        context: DealContext,
    ) -> Dict[str, Any]:
        """Generate recommendation based on analysis"""
        if score.disqualifying_factors:
            return {
                "type": "risk_alert",
                "summary": f"Disqualifying factors identified: {', '.join(score.disqualifying_factors)}",
                "confidence": 0.9,
                "action": "close_lost",
            }

        if score.total_score >= 80:
            return {
                "type": "opportunity",
                "summary": f"Strong buy-box fit ({score.total_score}/100). Recommend advancing to qualified/LOI.",
                "confidence": 0.85,
                "action": "advance",
            }

        if score.total_score >= 60:
            return {
                "type": "action_needed",
                "summary": f"Moderate fit ({score.total_score}/100). Gather more info on: {', '.join(score.concerns[:3])}",
                "confidence": 0.75,
                "action": "investigate",
            }

        return {
            "type": "risk_alert",
            "summary": f"Weak buy-box fit ({score.total_score}/100). Consider closing if concerns cannot be addressed.",
            "confidence": 0.7,
            "action": "review",
        }

    def score(self, deal_id: str) -> AgentResult:
        """Quick buy-box scoring without full analysis"""
        context = self.case_manager.load_context(deal_id)
        if not context:
            return AgentResult(
                success=False,
                summary=f"Deal not found: {deal_id}",
                errors=[f"Deal {deal_id} not found in registry"],
            )

        metrics = self._extract_metrics(context)
        score = self._calculate_buy_box_score(metrics, context)

        result = AgentResult(
            success=True,
            summary=f"Buy-box score: {score.total_score}/100. Meets: {', '.join(score.meets_criteria) or 'none'}. Concerns: {', '.join(score.concerns) or 'none'}",
            confidence=0.8,
        )
        self._log_run(deal_id, "score", result)
        return result


def main():
    parser = argparse.ArgumentParser(description="Underwriter Agent CLI")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # analyze
    analyze_p = subparsers.add_parser("analyze", help="Full financial analysis")
    analyze_p.add_argument("deal_id", help="Deal ID")
    analyze_p.add_argument("--json", action="store_true", help="Output as JSON")

    # score
    score_p = subparsers.add_parser("score", help="Quick buy-box score")
    score_p.add_argument("deal_id", help="Deal ID")
    score_p.add_argument("--json", action="store_true", help="Output as JSON")

    args = parser.parse_args()

    agent = UnderwriterAgent()

    if args.command == "analyze":
        result = agent.analyze(args.deal_id)
    elif args.command == "score":
        result = agent.score(args.deal_id)
    else:
        parser.print_help()
        return

    if hasattr(args, 'json') and args.json:
        print(json.dumps(result.to_dict(), indent=2))
    else:
        print(f"\n{'=' * 60}")
        print(f"Underwriter: {args.command}")
        print(f"{'=' * 60}")
        print(f"Success: {result.success}")
        print(f"Summary: {result.summary}")
        if result.errors:
            print(f"Errors: {', '.join(result.errors)}")


if __name__ == "__main__":
    main()
