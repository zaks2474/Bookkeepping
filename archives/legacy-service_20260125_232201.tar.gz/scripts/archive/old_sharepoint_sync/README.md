# Archived SharePoint Sync Scripts

These scripts were replaced by the unified `sharepoint_sync_v2.py` on $(date +%Y-%m-%d).

**Reason for archival:**
- Multiple competing scripts created conflicting SharePoint structures
- No exclusion logic (synced caches, binaries, secrets)
- Manual file list maintenance required
- No incremental sync (always uploaded everything)

**New master script:**
`/home/zaks/Zaks-llm/scripts/sharepoint_sync_v2.py`

**Do not use these archived scripts.**
