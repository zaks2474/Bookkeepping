#!/usr/bin/env python3
"""
Sync DataRoom, Deal Origination Engine, and Implementation Plans to SharePoint
"""

import os
import json
import requests
from pathlib import Path
import time

# Load config
config_path = "/home/zaks/Zaks-llm/sharepoint-mcp-server/config.json"
with open(config_path, 'r') as f:
    config = json.load(f)

TENANT_ID = config['azure']['tenant_id']
CLIENT_ID = config['azure']['client_id']
CLIENT_SECRET = config['azure']['client_secret']
SITE_NAME = "ZakOpsDataRoom"

# Get access token
def get_token():
    url = f"https://login.microsoftonline.com/{TENANT_ID}/oauth2/v2.0/token"
    data = {
        'client_id': CLIENT_ID,
        'client_secret': CLIENT_SECRET,
        'scope': 'https://graph.microsoft.com/.default',
        'grant_type': 'client_credentials'
    }

    response = requests.post(url, data=data)
    if response.status_code == 200:
        return response.json()['access_token']
    else:
        print(f"✗ Failed to get token: {response.text}")
        return None

# Get site ID
def get_site_id(token):
    hostname = "zaks24.sharepoint.com"
    url = f"https://graph.microsoft.com/v1.0/sites/{hostname}:/sites/{SITE_NAME}"
    headers = {'Authorization': f'Bearer {token}'}

    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        return response.json()['id']
    print(f"✗ Failed to get site ID: {response.text}")
    return None

# Create folder
def create_folder(token, site_id, folder_path):
    """Create folder structure recursively"""
    folders = folder_path.strip('/').split('/')
    current_path = ''

    for folder in folders:
        current_path += folder

        # Check if folder exists
        url = f"https://graph.microsoft.com/v1.0/sites/{site_id}/drive/root:/{current_path}:/children"
        headers = {'Authorization': f'Bearer {token}'}

        response = requests.get(url, headers=headers)
        if response.status_code != 200:
            # Create folder
            create_url = f"https://graph.microsoft.com/v1.0/sites/{site_id}/drive/root/children"
            headers = {
                'Authorization': f'Bearer {token}',
                'Content-Type': 'application/json'
            }
            data = {
                'name': folder,
                'folder': {},
                '@microsoft.graph.conflictBehavior': 'rename'
            }

            create_response = requests.post(create_url, headers=headers, json=data)
            if create_response.status_code not in [200, 201]:
                print(f"✗ Failed to create {current_path}: {create_response.text}")
                return False
            print(f"📁 Created folder: {current_path}")

        current_path += '/'

    return True

# Upload file
def upload_file(token, site_id, local_path, sharepoint_path):
    """Upload a file to SharePoint"""

    if not os.path.exists(local_path):
        print(f"⏭️  Skipped (not found): {local_path}")
        return False

    filename = os.path.basename(local_path)

    # Ensure folder exists
    folder = os.path.dirname(sharepoint_path)
    if folder and folder != '/':
        create_folder(token, site_id, folder)

    # Upload file
    with open(local_path, 'rb') as f:
        file_content = f.read()

    url = f"https://graph.microsoft.com/v1.0/sites/{site_id}/drive/root:/{sharepoint_path}:/content"
    headers = {
        'Authorization': f'Bearer {token}',
        'Content-Type': 'application/octet-stream'
    }

    response = requests.put(url, headers=headers, data=file_content)

    if response.status_code in [200, 201]:
        print(f"✅ Uploaded: {sharepoint_path}")
        return True
    else:
        print(f"❌ Failed: {filename} - {response.status_code}")
        return False

def main():
    print("=" * 70)
    print("🚀 SYNCING TO SHAREPOINT: ZakOpsDataRoom")
    print("=" * 70)
    print()

    # Authenticate
    print("🔐 Authenticating...")
    token = get_token()
    if not token:
        return
    print("✅ Authenticated")
    print()

    # Get site ID
    print("📍 Getting site ID...")
    site_id = get_site_id(token)
    if not site_id:
        return
    print(f"✅ Site ID: {site_id}")
    print()

    # Define files to upload
    files_to_upload = [
        # ========================================
        # DATAROOM - Core Documents
        # ========================================
        ("/home/zaks/DataRoom/OPERATOR-BIO.md",
         "DataRoom/OPERATOR-BIO.md"),
        ("/home/zaks/DataRoom/OPERATOR-BIO.pdf",
         "DataRoom/OPERATOR-BIO.pdf"),
        ("/home/zaks/DataRoom/MASTER-DASHBOARD.md",
         "DataRoom/MASTER-DASHBOARD.md"),
        ("/home/zaks/DataRoom/DIRECTORY-MAP.md",
         "DataRoom/DIRECTORY-MAP.md"),
        ("/home/zaks/DataRoom/README.md",
         "DataRoom/README.md"),
        ("/home/zaks/DataRoom/QUICK-REFERENCE.md",
         "DataRoom/QUICK-REFERENCE.md"),

        # ========================================
        # DATAROOM - Pipeline
        # ========================================
        ("/home/zaks/DataRoom/00-PIPELINE/MASTER-DEAL-TRACKER.csv",
         "DataRoom/00-PIPELINE/MASTER-DEAL-TRACKER.csv"),
        ("/home/zaks/DataRoom/00-PIPELINE/Inbound/NEW-DEALS-2025-12-11.md",
         "DataRoom/00-PIPELINE/Inbound/NEW-DEALS-2025-12-11.md"),
        ("/home/zaks/DataRoom/00-PIPELINE/Inbound/ABB25034-Confidential-Business-Summary.doc",
         "DataRoom/00-PIPELINE/Inbound/ABB25034-Confidential-Business-Summary.doc"),

        # Deal Origination Engine Docs
        ("/home/zaks/DataRoom/00-PIPELINE/DEAL-ORIGINATION-ENGINE-ARCHITECTURE.md",
         "DataRoom/00-PIPELINE/DEAL-ORIGINATION-ENGINE-ARCHITECTURE.md"),
        ("/home/zaks/DataRoom/00-PIPELINE/DEAL-ORIGINATION-ENGINE-IMPLEMENTATION.md",
         "DataRoom/00-PIPELINE/DEAL-ORIGINATION-ENGINE-IMPLEMENTATION.md"),
        ("/home/zaks/DataRoom/00-PIPELINE/DEAL-ORIGINATION-ENGINE-SUMMARY.md",
         "DataRoom/00-PIPELINE/DEAL-ORIGINATION-ENGINE-SUMMARY.md"),

        # ========================================
        # DATAROOM - Frameworks
        # ========================================
        ("/home/zaks/DataRoom/04-FRAMEWORKS/Playbooks/DEAL-ORIGINATION-PLAYBOOK.md",
         "DataRoom/04-FRAMEWORKS/Playbooks/DEAL-ORIGINATION-PLAYBOOK.md"),
        ("/home/zaks/DataRoom/04-FRAMEWORKS/Templates/Deal-Scorecard-Template.txt",
         "DataRoom/04-FRAMEWORKS/Templates/Deal-Scorecard-Template.txt"),
        ("/home/zaks/DataRoom/04-FRAMEWORKS/Templates/DD-Checklist.md",
         "DataRoom/04-FRAMEWORKS/Templates/DD-Checklist.md"),
        ("/home/zaks/DataRoom/04-FRAMEWORKS/Criteria/Investment-Thesis.md",
         "DataRoom/04-FRAMEWORKS/Criteria/Investment-Thesis.md"),

        # ========================================
        # DATAROOM - Deal Sources
        # ========================================
        ("/home/zaks/DataRoom/03-DEAL-SOURCES/BROKER-TRACKER.csv",
         "DataRoom/03-DEAL-SOURCES/BROKER-TRACKER.csv"),
        ("/home/zaks/DataRoom/03-DEAL-SOURCES/Brokers/WebsiteClosers/Contacts/WebsiteClosers-Contact-Sheet.md",
         "DataRoom/03-DEAL-SOURCES/Brokers/WebsiteClosers/Contacts/WebsiteClosers-Contact-Sheet.md"),

        # ========================================
        # DATAROOM - Screening Deals (Dec 11, 2025)
        # ========================================
        ("/home/zaks/DataRoom/00-PIPELINE/Screening/TeamLogic-IT-MSP-2025/README.md",
         "DataRoom/00-PIPELINE/Screening/TeamLogic-IT-MSP-2025/README.md"),
        ("/home/zaks/DataRoom/00-PIPELINE/Screening/NIN-IT-Services-2025/README.md",
         "DataRoom/00-PIPELINE/Screening/NIN-IT-Services-2025/README.md"),
        ("/home/zaks/DataRoom/00-PIPELINE/Screening/Microsoft-Licensing-2025/README.md",
         "DataRoom/00-PIPELINE/Screening/Microsoft-Licensing-2025/README.md"),
        ("/home/zaks/DataRoom/00-PIPELINE/Screening/Vertical-MSP-2025/README.md",
         "DataRoom/00-PIPELINE/Screening/Vertical-MSP-2025/README.md"),

        # ========================================
        # DATAROOM - Work Log
        # ========================================
        ("/home/zaks/DataRoom/WORK-LOG.md",
         "DataRoom/WORK-LOG.md"),

        # ========================================
        # IMPLEMENTATION PLANS
        # ========================================
        ("/home/zaks/bookkeeping/docs/LINKEDIN-MCP-IMPLEMENTATION.md",
         "Implementation-Plans/LINKEDIN-MCP-IMPLEMENTATION.md"),
        ("/home/zaks/bookkeeping/docs/AUTOMATED-JOB-APPLICATION-WORKFLOW.md",
         "Implementation-Plans/AUTOMATED-JOB-APPLICATION-WORKFLOW.md"),
        ("/home/zaks/bookkeeping/docs/SHAREPOINT-SYNC-GUIDE.md",
         "Implementation-Plans/SHAREPOINT-SYNC-GUIDE.md"),

        # ========================================
        # DEAL ORIGINATION ENGINE (Dedicated Folder)
        # ========================================
        ("/home/zaks/DataRoom/00-PIPELINE/DEAL-ORIGINATION-ENGINE-ARCHITECTURE.md",
         "Deal-Origination-Engine/ARCHITECTURE.md"),
        ("/home/zaks/DataRoom/00-PIPELINE/DEAL-ORIGINATION-ENGINE-IMPLEMENTATION.md",
         "Deal-Origination-Engine/IMPLEMENTATION.md"),
        ("/home/zaks/DataRoom/00-PIPELINE/DEAL-ORIGINATION-ENGINE-SUMMARY.md",
         "Deal-Origination-Engine/SUMMARY.md"),
        ("/home/zaks/DataRoom/04-FRAMEWORKS/Playbooks/DEAL-ORIGINATION-PLAYBOOK.md",
         "Deal-Origination-Engine/PLAYBOOK.md"),
    ]

    print(f"📤 Uploading {len(files_to_upload)} files...")
    print("-" * 70)
    print()

    success_count = 0
    skipped_count = 0

    for local_path, sharepoint_path in files_to_upload:
        if not os.path.exists(local_path):
            print(f"⏭️  Skipped: {os.path.basename(local_path)} (not found)")
            skipped_count += 1
        elif upload_file(token, site_id, local_path, sharepoint_path):
            success_count += 1
        time.sleep(0.3)  # Rate limiting

    print()
    print("=" * 70)
    print("📊 SYNC SUMMARY")
    print("=" * 70)
    print(f"✅ Uploaded:  {success_count} files")
    print(f"⏭️  Skipped:   {skipped_count} files")
    print(f"❌ Failed:    {len(files_to_upload) - success_count - skipped_count} files")
    print()
    print("✅ Sync complete!")
    print(f"🔗 View at: https://zaks24.sharepoint.com/sites/ZakOpsDataRoom")
    print()

if __name__ == "__main__":
    main()
