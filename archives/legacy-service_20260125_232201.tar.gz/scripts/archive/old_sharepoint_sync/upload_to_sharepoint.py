#!/usr/bin/env python3
"""
Direct upload to SharePoint using Microsoft Graph API
"""

import os
import json
import requests
from pathlib import Path
import time

# Load config
config_path = "/home/zaks/Zaks-llm/sharepoint-mcp-server/config.json"
with open(config_path, 'r') as f:
    config = json.load(f)

TENANT_ID = config['azure']['tenant_id']
CLIENT_ID = config['azure']['client_id']
CLIENT_SECRET = config['azure']['client_secret']
SITE_URL = config['sharepoint']['site_url']

# Extract site ID from URL
SITE_NAME = "ZakOpsDataRoom"

# Get access token
def get_token():
    url = f"https://login.microsoftonline.com/{TENANT_ID}/oauth2/v2.0/token"
    data = {
        'client_id': CLIENT_ID,
        'client_secret': CLIENT_SECRET,
        'scope': 'https://graph.microsoft.com/.default',
        'grant_type': 'client_credentials'
    }

    response = requests.post(url, data=data)
    if response.status_code == 200:
        return response.json()['access_token']
    else:
        print(f"✗ Failed to get token: {response.text}")
        return None

# Get site ID
def get_site_id(token):
    # Try different hostname patterns
    hostnames = [
        "zaks24.sharepoint.com",
        f"{TENANT_ID}.sharepoint.com"
    ]

    for hostname in hostnames:
        url = f"https://graph.microsoft.com/v1.0/sites/{hostname}:/sites/{SITE_NAME}"
        headers = {'Authorization': f'Bearer {token}'}

        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            print(f"✓ Using hostname: {hostname}")
            return response.json()['id']

    print(f"✗ Failed to get site ID with any hostname")
    return None

# Create folder
def create_folder(token, site_id, folder_path):
    """Create folder structure recursively"""
    folders = folder_path.strip('/').split('/')
    current_path = ''

    for folder in folders:
        current_path += folder

        # Check if folder exists first
        url = f"https://graph.microsoft.com/v1.0/sites/{site_id}/drive/root:/{current_path}:/children"
        headers = {'Authorization': f'Bearer {token}'}

        response = requests.get(url, headers=headers)
        if response.status_code != 200:
            # Folder doesn't exist, create it
            create_url = f"https://graph.microsoft.com/v1.0/sites/{site_id}/drive/root/children"
            headers = {
                'Authorization': f'Bearer {token}',
                'Content-Type': 'application/json'
            }
            data = {
                'name': folder,
                'folder': {},
                '@microsoft.graph.conflictBehavior': 'rename'
            }

            create_response = requests.post(create_url, headers=headers, json=data)
            if create_response.status_code not in [200, 201]:
                print(f"✗ Failed to create {current_path}: {create_response.text}")
                return False
            print(f"✓ Created folder: {current_path}")

        current_path += '/'

    return True

# Upload file
def upload_file(token, site_id, local_path, sharepoint_path):
    """Upload a file to SharePoint"""

    if not os.path.exists(local_path):
        print(f"✗ File not found: {local_path}")
        return False

    filename = os.path.basename(local_path)

    # Ensure folder exists
    folder = os.path.dirname(sharepoint_path)
    if folder and folder != '/':
        create_folder(token, site_id, folder)

    # Upload file
    with open(local_path, 'rb') as f:
        file_content = f.read()

    url = f"https://graph.microsoft.com/v1.0/sites/{site_id}/drive/root:/{sharepoint_path}:/content"
    headers = {
        'Authorization': f'Bearer {token}',
        'Content-Type': 'application/octet-stream'
    }

    response = requests.put(url, headers=headers, data=file_content)

    if response.status_code in [200, 201]:
        print(f"✓ Uploaded: {sharepoint_path}")
        return True
    else:
        print(f"✗ Failed to upload {filename}: {response.status_code} - {response.text}")
        return False

# Main upload process
def main():
    print("🚀 Starting SharePoint Upload...")
    print()

    # Get token
    print("🔐 Authenticating...")
    token = get_token()
    if not token:
        return
    print("✓ Authenticated")
    print()

    # Get site ID
    print("📍 Getting site ID...")
    site_id = get_site_id(token)
    if not site_id:
        return
    print(f"✓ Site ID: {site_id}")
    print()

    # Define files to upload
    base_path = "/home/zaks/SHAREPOINT-UPLOAD-PACKAGE"

    files_to_upload = [
        # Master README
        (f"{base_path}/05-ZAKOPS-PLAYBOOKS/Deal-Management-SOP/README.md",
         "05-ZAKOPS-PLAYBOOKS/Deal-Management-SOP/README.md"),

        # Quick Start
        (f"{base_path}/05-ZAKOPS-PLAYBOOKS/Deal-Management-SOP/QUICK-START-GUIDE.md",
         "05-ZAKOPS-PLAYBOOKS/Deal-Management-SOP/QUICK-START-GUIDE.md"),

        # Email Templates
        (f"{base_path}/05-ZAKOPS-PLAYBOOKS/Deal-Management-SOP/Email-Response-Templates.md",
         "05-ZAKOPS-PLAYBOOKS/Deal-Management-SOP/Email-Response-Templates.md"),

        # Deal Scoring
        (f"{base_path}/03-CONSOLIDATED-PORTFOLIO/Deal-Analysis-Workbench/Deal-Scoring-Criteria.md",
         "03-CONSOLIDATED-PORTFOLIO/Deal-Analysis-Workbench/Deal-Scoring-Criteria.md"),

        # Master Tracker
        (f"{base_path}/03-CONSOLIDATED-PORTFOLIO/Active-Deals-Pipeline.xlsx",
         "03-CONSOLIDATED-PORTFOLIO/Active-Deals-Pipeline.xlsx"),

        # Deal Files
        (f"{base_path}/01-DEAL-PIPELINE/Active-Deals/TFSource/Deal-Summary.md",
         "01-DEAL-PIPELINE/Active-Deals/TFSource/Deal-Summary.md"),

        (f"{base_path}/01-DEAL-PIPELINE/Active-Deals/StoryXpress/Deal-Summary.md",
         "01-DEAL-PIPELINE/Active-Deals/StoryXpress/Deal-Summary.md"),

        (f"{base_path}/01-DEAL-PIPELINE/Active-Deals/Marianne-Coordination/Broker-Relationship-Notes.md",
         "01-DEAL-PIPELINE/Active-Deals/Marianne-Coordination/Broker-Relationship-Notes.md"),

        # Playbooks
        (f"{base_path}/04-HOLDCO-OPERATIONS/Deal-Playbooks/SaaS-Acquisition-Playbook.md",
         "04-HOLDCO-OPERATIONS/Deal-Playbooks/SaaS-Acquisition-Playbook.md"),

        (f"{base_path}/04-HOLDCO-OPERATIONS/Deal-Playbooks/Marketplace-Acquisition-Playbook.md",
         "04-HOLDCO-OPERATIONS/Deal-Playbooks/Marketplace-Acquisition-Playbook.md"),

        (f"{base_path}/04-HOLDCO-OPERATIONS/Deal-Playbooks/MSP-Acquisition-Playbook.md",
         "04-HOLDCO-OPERATIONS/Deal-Playbooks/MSP-Acquisition-Playbook.md"),

        (f"{base_path}/04-HOLDCO-OPERATIONS/Deal-Playbooks/E-Commerce-Acquisition-Playbook.md",
         "04-HOLDCO-OPERATIONS/Deal-Playbooks/E-Commerce-Acquisition-Playbook.md"),

        (f"{base_path}/04-HOLDCO-OPERATIONS/Deal-Playbooks/Services-Acquisition-Playbook.md",
         "04-HOLDCO-OPERATIONS/Deal-Playbooks/Services-Acquisition-Playbook.md"),
    ]

    print(f"📤 Uploading {len(files_to_upload)} files...")
    print()

    success_count = 0
    for local_path, sharepoint_path in files_to_upload:
        if upload_file(token, site_id, local_path, sharepoint_path):
            success_count += 1
        time.sleep(0.5)  # Rate limiting

    print()
    print(f"✅ Upload Complete: {success_count}/{len(files_to_upload)} files uploaded successfully")
    print()
    print("📍 Verify at: https://zaks24.sharepoint.com/sites/ZakOpsDataRoom")

if __name__ == "__main__":
    main()
