#!/usr/bin/env python3
"""
Exit Strategist Agent

Mission: "Exit readiness assessment."
- Assess deal readiness for exit
- Identify exit preparation tasks
- Evaluate potential exit multiples
- Generate exit preparation checklist
- Produce exit plan artifacts

Inputs:
- Deal context at EXIT_PLANNING stage
- Historical KPIs and financials
- Portfolio performance data

Outputs:
- Exit readiness assessment
- Exit preparation checklist
- Value enhancement recommendations
- Exit plan artifacts + events

Hard Boundaries:
- Advisory only - does not make exit decisions
- No commitments to buyers/brokers
- No confidential information disclosure

Usage:
    python3 exit_strategist.py assess DEAL-2025-001
    python3 exit_strategist.py checklist DEAL-2025-001
    python3 exit_strategist.py value-drivers DEAL-2025-001
    python3 exit_strategist.py timeline DEAL-2025-001
"""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional

# Add paths
sys.path.insert(0, str(Path(__file__).parent))
sys.path.insert(0, str(Path("/home/zaks/Zaks-llm/src")))

from deal_registry import DealRegistry
from deal_events import DealEventStore
from deal_case_manager import DealCaseManagerAgent, DealContext
from deferred_actions import DeferredActionQueue


@dataclass
class StrategistResult:
    """Result of an exit strategist invocation"""
    success: bool
    message: str
    actions_taken: List[str] = field(default_factory=list)
    artifacts: List[str] = field(default_factory=list)
    data: Optional[Dict[str, Any]] = None

# Configuration
REGISTRY_PATH = "/home/zaks/DataRoom/.deal-registry/deal_registry.json"
CASE_FILES_DIR = Path("/home/zaks/DataRoom/.deal-registry/case_files")
ARTIFACTS_DIR = Path("/home/zaks/DataRoom/.deal-registry/artifacts")
INTEGRATION_DIR = Path("/home/zaks/DataRoom/.deal-registry/integration")
EXIT_PLANS_DIR = Path("/home/zaks/DataRoom/.deal-registry/exit_plans")
RUN_LEDGER_PATH = Path("/home/zaks/logs/run-ledger.jsonl")

# Ensure directories exist
ARTIFACTS_DIR.mkdir(parents=True, exist_ok=True)
EXIT_PLANS_DIR.mkdir(parents=True, exist_ok=True)


# Exit Readiness Criteria
EXIT_READINESS_CRITERIA = {
    "financial_performance": {
        "weight": 25,
        "items": [
            {"name": "revenue_growth_3yr", "description": "3+ years of consistent revenue growth", "threshold": 0.10},
            {"name": "ebitda_margin", "description": "EBITDA margin above target", "threshold": 0.20},
            {"name": "revenue_predictability", "description": "Recurring revenue > 70%", "threshold": 0.70},
            {"name": "customer_retention", "description": "Net revenue retention > 100%", "threshold": 1.0},
        ]
    },
    "operational_maturity": {
        "weight": 20,
        "items": [
            {"name": "documented_processes", "description": "All key processes documented"},
            {"name": "team_stability", "description": "Key employees retained with succession plans"},
            {"name": "tech_debt_managed", "description": "Technical debt under control"},
            {"name": "compliance_current", "description": "All regulatory compliance current"},
        ]
    },
    "market_position": {
        "weight": 20,
        "items": [
            {"name": "market_share", "description": "Defensible market position"},
            {"name": "competitive_moat", "description": "Clear competitive advantages"},
            {"name": "customer_concentration", "description": "No customer > 20% of revenue"},
            {"name": "growth_runway", "description": "Clear path for continued growth"},
        ]
    },
    "exit_preparation": {
        "weight": 20,
        "items": [
            {"name": "clean_financials", "description": "Audited or audit-ready financials"},
            {"name": "legal_clean", "description": "No pending litigation or IP issues"},
            {"name": "contracts_transferable", "description": "Key contracts assignable"},
            {"name": "data_room_ready", "description": "Virtual data room prepared"},
        ]
    },
    "timing_market": {
        "weight": 15,
        "items": [
            {"name": "market_conditions", "description": "Favorable M&A market conditions"},
            {"name": "sector_multiples", "description": "Sector trading at attractive multiples"},
            {"name": "buyer_interest", "description": "Strategic or financial buyer interest present"},
            {"name": "economic_cycle", "description": "Economic conditions supportive"},
        ]
    },
}

# Exit Preparation Checklist
EXIT_PREPARATION_CHECKLIST = [
    # Financial Preparation
    {"category": "Financial", "item": "Complete 3-year financial audit", "timeline": "6-12 months before", "priority": "high"},
    {"category": "Financial", "item": "Normalize financials (add-backs documented)", "timeline": "6 months before", "priority": "high"},
    {"category": "Financial", "item": "Prepare quality of earnings analysis", "timeline": "3-6 months before", "priority": "high"},
    {"category": "Financial", "item": "Document revenue recognition policies", "timeline": "6 months before", "priority": "medium"},
    {"category": "Financial", "item": "Prepare monthly financial packages", "timeline": "Ongoing", "priority": "medium"},

    # Legal Preparation
    {"category": "Legal", "item": "Review all material contracts", "timeline": "6 months before", "priority": "high"},
    {"category": "Legal", "item": "Confirm IP ownership and registrations", "timeline": "6-12 months before", "priority": "high"},
    {"category": "Legal", "item": "Resolve any pending litigation", "timeline": "12+ months before", "priority": "high"},
    {"category": "Legal", "item": "Update corporate records", "timeline": "3 months before", "priority": "medium"},
    {"category": "Legal", "item": "Prepare key employee retention agreements", "timeline": "3-6 months before", "priority": "medium"},

    # Operational Preparation
    {"category": "Operational", "item": "Document all key processes", "timeline": "6-12 months before", "priority": "high"},
    {"category": "Operational", "item": "Identify and mitigate key person dependencies", "timeline": "12+ months before", "priority": "high"},
    {"category": "Operational", "item": "Prepare organizational chart with roles", "timeline": "3 months before", "priority": "medium"},
    {"category": "Operational", "item": "Document technology stack and architecture", "timeline": "3 months before", "priority": "medium"},
    {"category": "Operational", "item": "Clean up customer/vendor relationships", "timeline": "6 months before", "priority": "medium"},

    # Data Room
    {"category": "Data Room", "item": "Set up virtual data room", "timeline": "2-3 months before", "priority": "high"},
    {"category": "Data Room", "item": "Organize historical financials", "timeline": "2 months before", "priority": "high"},
    {"category": "Data Room", "item": "Compile all material contracts", "timeline": "2 months before", "priority": "high"},
    {"category": "Data Room", "item": "Prepare customer analysis", "timeline": "2 months before", "priority": "medium"},
    {"category": "Data Room", "item": "Document employee information", "timeline": "1 month before", "priority": "medium"},

    # Go-to-Market
    {"category": "GTM", "item": "Engage M&A advisor/broker", "timeline": "6+ months before", "priority": "high"},
    {"category": "GTM", "item": "Prepare confidential information memorandum", "timeline": "2-3 months before", "priority": "high"},
    {"category": "GTM", "item": "Identify potential buyers list", "timeline": "3 months before", "priority": "medium"},
    {"category": "GTM", "item": "Prepare management presentation", "timeline": "1-2 months before", "priority": "medium"},
    {"category": "GTM", "item": "Develop key talking points", "timeline": "1 month before", "priority": "medium"},
]


@dataclass
class ExitReadinessScore:
    """Exit readiness assessment score"""
    overall_score: float  # 0-100
    category_scores: Dict[str, float]
    met_criteria: List[str]
    gaps: List[str]
    recommendation: str  # "ready", "almost_ready", "needs_work", "not_ready"


class ExitStrategistAgent:
    """
    Exit Strategist Agent

    Advisory agent invoked at EXIT_PLANNING stage to:
    - Assess exit readiness
    - Identify preparation tasks
    - Estimate potential valuations
    - Generate exit preparation plan
    """

    def __init__(self):
        self.registry = DealRegistry(REGISTRY_PATH)
        self.case_manager = DealCaseManagerAgent()
        self.action_queue = DeferredActionQueue()

    def _get_deal_context(self, deal_id: str) -> Optional[DealContext]:
        """Get full deal context"""
        return self.case_manager.load_context(deal_id)

    def _load_integration_tracker(self, deal_id: str) -> Dict[str, Any]:
        """Load integration tracker for historical data"""
        tracker_path = INTEGRATION_DIR / f"{deal_id}_integration.json"
        if tracker_path.exists():
            with open(tracker_path) as f:
                return json.load(f)
        return {}

    def _load_exit_plan(self, deal_id: str) -> Dict[str, Any]:
        """Load or create exit plan for a deal"""
        plan_path = EXIT_PLANS_DIR / f"{deal_id}_exit_plan.json"
        if plan_path.exists():
            with open(plan_path) as f:
                return json.load(f)
        return {
            "deal_id": deal_id,
            "created": datetime.now(timezone.utc).isoformat(),
            "assessments": [],
            "checklist_items": [],
            "target_exit_date": None,
            "estimated_value_range": None,
            "status": "planning"
        }

    def _save_exit_plan(self, deal_id: str, plan: Dict[str, Any]):
        """Save exit plan"""
        plan_path = EXIT_PLANS_DIR / f"{deal_id}_exit_plan.json"
        plan["last_updated"] = datetime.now(timezone.utc).isoformat()
        with open(plan_path, "w") as f:
            json.dump(plan, f, indent=2)

    def _log_run(self, operation: str, deal_id: str, result: Dict[str, Any]):
        """Log to run ledger"""
        entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "agent": "exit_strategist",
            "operation": operation,
            "deal_id": deal_id,
            "result": result
        }
        with open(RUN_LEDGER_PATH, "a") as f:
            f.write(json.dumps(entry) + "\n")

    def assess_exit_readiness(self, deal_id: str, criteria_status: Optional[Dict[str, bool]] = None) -> StrategistResult:
        """
        Assess exit readiness for a deal.

        Args:
            deal_id: Deal identifier
            criteria_status: Optional dict of criteria name -> met (True/False)

        Returns:
            StrategistResult with readiness assessment
        """
        ctx = self._get_deal_context(deal_id)
        if not ctx:
            return StrategistResult(
                success=False,
                message=f"Deal {deal_id} not found",
                actions_taken=[],
                artifacts=[]
            )

        # Verify deal is in appropriate stage
        if ctx.stage.upper() not in ["OPERATIONS", "GROWTH", "EXIT_PLANNING"]:
            return StrategistResult(
                success=False,
                message=f"Deal {deal_id} is in stage {ctx.stage}, not ready for exit assessment",
                actions_taken=[],
                artifacts=[]
            )

        # Load historical data
        integration_data = self._load_integration_tracker(deal_id)
        kpi_history = integration_data.get("kpi_history", [])

        # Calculate scores per category
        category_scores = {}
        met_criteria = []
        gaps = []
        total_weighted_score = 0
        total_weight = 0

        for category, config in EXIT_READINESS_CRITERIA.items():
            weight = config["weight"]
            items = config["items"]
            category_met = 0

            for item in items:
                item_name = item["name"]

                # Check if criteria is provided or can be inferred
                is_met = False

                if criteria_status and item_name in criteria_status:
                    is_met = criteria_status[item_name]
                else:
                    # Try to infer from KPI history
                    if kpi_history and len(kpi_history) >= 2:
                        latest = kpi_history[-1]
                        if item_name == "ebitda_margin" and "gross_margin" in latest:
                            is_met = latest.get("gross_margin", 0) >= item.get("threshold", 0.20)
                        elif item_name == "revenue_predictability" and "mrr" in latest and "revenue" in latest:
                            if latest["revenue"] > 0:
                                recurring_pct = (latest["mrr"] * 12) / latest["revenue"]
                                is_met = recurring_pct >= item.get("threshold", 0.70)

                if is_met:
                    met_criteria.append(f"{category}: {item['description']}")
                    category_met += 1
                else:
                    gaps.append(f"{category}: {item['description']}")

            # Category score (0-100 for this category)
            category_score = (category_met / len(items)) * 100 if items else 0
            category_scores[category] = round(category_score, 1)

            # Weighted contribution
            total_weighted_score += category_score * weight
            total_weight += weight

        # Overall score
        overall_score = total_weighted_score / total_weight if total_weight > 0 else 0
        overall_score = round(overall_score, 1)

        # Determine recommendation
        if overall_score >= 80:
            recommendation = "ready"
            recommendation_text = "Ready for exit process. Consider engaging advisors."
        elif overall_score >= 60:
            recommendation = "almost_ready"
            recommendation_text = "Nearly ready. Address key gaps in next 3-6 months."
        elif overall_score >= 40:
            recommendation = "needs_work"
            recommendation_text = "Significant preparation needed. Plan 6-12 month runway."
        else:
            recommendation = "not_ready"
            recommendation_text = "Not ready for exit. Focus on value building first."

        assessment = {
            "date": datetime.now(timezone.utc).isoformat(),
            "overall_score": overall_score,
            "category_scores": category_scores,
            "met_criteria_count": len(met_criteria),
            "gaps_count": len(gaps),
            "recommendation": recommendation,
            "recommendation_text": recommendation_text,
            "top_gaps": gaps[:5]
        }

        # Save to exit plan
        exit_plan = self._load_exit_plan(deal_id)
        exit_plan["assessments"].append(assessment)
        self._save_exit_plan(deal_id, exit_plan)

        # Log event
        events_dir = Path("/home/zaks/DataRoom/.deal-registry/events")
        event_store = DealEventStore(events_dir)
        event_store.append_event(deal_id, {
            "event_type": "exit_readiness_assessed",
            "overall_score": overall_score,
            "recommendation": recommendation,
            "agent": "exit_strategist"
        })

        self._log_run("assess_exit_readiness", deal_id, assessment)

        return StrategistResult(
            success=True,
            message=f"Exit Readiness: {overall_score}/100 - {recommendation_text}",
            actions_taken=[
                f"Assessed {len(met_criteria) + len(gaps)} criteria",
                f"Identified {len(gaps)} gaps",
                f"Recommendation: {recommendation}"
            ],
            artifacts=[str(EXIT_PLANS_DIR / f"{deal_id}_exit_plan.json")],
            data=assessment
        )

    def generate_exit_checklist(self, deal_id: str, target_exit_months: int = 12) -> StrategistResult:
        """
        Generate customized exit preparation checklist.

        Args:
            deal_id: Deal identifier
            target_exit_months: Target months until exit (default 12)

        Returns:
            StrategistResult with checklist
        """
        ctx = self._get_deal_context(deal_id)
        if not ctx:
            return StrategistResult(
                success=False,
                message=f"Deal {deal_id} not found",
                actions_taken=[],
                artifacts=[]
            )

        now = datetime.now(timezone.utc)
        target_exit_date = now + timedelta(days=target_exit_months * 30)

        # Generate checklist with due dates
        checklist = []
        for item in EXIT_PREPARATION_CHECKLIST:
            # Parse timeline to calculate due date
            timeline = item["timeline"]
            if "12+ months" in timeline:
                months_before = 12
            elif "6-12 months" in timeline:
                months_before = 9
            elif "6 months" in timeline:
                months_before = 6
            elif "3-6 months" in timeline:
                months_before = 4
            elif "3 months" in timeline:
                months_before = 3
            elif "2-3 months" in timeline:
                months_before = 2
            elif "2 months" in timeline:
                months_before = 2
            elif "1-2 months" in timeline:
                months_before = 1
            elif "1 month" in timeline:
                months_before = 1
            else:
                months_before = 3  # default

            due_date = target_exit_date - timedelta(days=months_before * 30)

            checklist_item = {
                "category": item["category"],
                "item": item["item"],
                "timeline": item["timeline"],
                "priority": item["priority"],
                "due_date": due_date.isoformat(),
                "status": "pending",
                "notes": ""
            }
            checklist.append(checklist_item)

        # Sort by due date
        checklist.sort(key=lambda x: x["due_date"])

        # Save to exit plan
        exit_plan = self._load_exit_plan(deal_id)
        exit_plan["checklist_items"] = checklist
        exit_plan["target_exit_date"] = target_exit_date.isoformat()
        self._save_exit_plan(deal_id, exit_plan)

        # Schedule key milestone reminders
        actions_scheduled = []
        for item in checklist[:5]:  # Schedule reminders for top 5 urgent items
            if item["priority"] == "high":
                due = datetime.fromisoformat(item["due_date"].replace("Z", "+00:00"))
                # Schedule reminder 2 weeks before due
                reminder_date = due - timedelta(days=14)
                if reminder_date > now:
                    self.action_queue.add_action(
                        deal_id=deal_id,
                        action_type="exit_prep_reminder",
                        scheduled_for=reminder_date.isoformat(),
                        context={
                            "checklist_item": item["item"],
                            "due_date": item["due_date"],
                            "category": item["category"]
                        }
                    )
                    actions_scheduled.append(item["item"])

        self._log_run("generate_exit_checklist", deal_id, {
            "items_count": len(checklist),
            "target_exit_date": target_exit_date.isoformat(),
            "actions_scheduled": len(actions_scheduled)
        })

        # Group by category for summary
        by_category = {}
        for item in checklist:
            cat = item["category"]
            if cat not in by_category:
                by_category[cat] = []
            by_category[cat].append(item)

        return StrategistResult(
            success=True,
            message=f"Generated {len(checklist)}-item exit checklist targeting {target_exit_date.strftime('%Y-%m-%d')}",
            actions_taken=[
                f"Created checklist with {len(checklist)} items",
                f"Scheduled {len(actions_scheduled)} prep reminders",
                f"Organized across {len(by_category)} categories"
            ],
            artifacts=[str(EXIT_PLANS_DIR / f"{deal_id}_exit_plan.json")],
            data={
                "target_exit_date": target_exit_date.isoformat(),
                "total_items": len(checklist),
                "by_category": {k: len(v) for k, v in by_category.items()},
                "high_priority_count": len([i for i in checklist if i["priority"] == "high"]),
                "next_5_items": [{"item": i["item"], "due": i["due_date"][:10]} for i in checklist[:5]]
            }
        )

    def analyze_value_drivers(self, deal_id: str) -> StrategistResult:
        """
        Analyze value drivers and enhancement opportunities.

        Args:
            deal_id: Deal identifier

        Returns:
            StrategistResult with value analysis
        """
        ctx = self._get_deal_context(deal_id)
        if not ctx:
            return StrategistResult(
                success=False,
                message=f"Deal {deal_id} not found",
                actions_taken=[],
                artifacts=[]
            )

        # Load historical data
        integration_data = self._load_integration_tracker(deal_id)
        kpi_history = integration_data.get("kpi_history", [])

        # Value drivers analysis
        value_drivers = []
        enhancement_opportunities = []
        risks_to_value = []

        # Analyze available KPIs
        if kpi_history:
            latest = kpi_history[-1]

            # Revenue-based drivers
            if latest.get("revenue"):
                value_drivers.append({
                    "driver": "Revenue Base",
                    "current": f"${latest['revenue']:,.0f}",
                    "importance": "high",
                    "note": "Primary valuation anchor"
                })

            if latest.get("mrr"):
                mrr = latest["mrr"]
                arr = mrr * 12
                value_drivers.append({
                    "driver": "Recurring Revenue (ARR)",
                    "current": f"${arr:,.0f}",
                    "importance": "high",
                    "note": "Recurring revenue typically valued at premium"
                })

            # Growth analysis
            if len(kpi_history) >= 4:
                old_rev = kpi_history[-4].get("revenue", 0)
                new_rev = latest.get("revenue", 0)
                if old_rev > 0:
                    growth = (new_rev - old_rev) / old_rev
                    if growth > 0.20:
                        value_drivers.append({
                            "driver": "Growth Rate",
                            "current": f"{growth*100:.1f}% YoY",
                            "importance": "high",
                            "note": "Strong growth commands premium multiples"
                        })
                    elif growth < 0.05:
                        risks_to_value.append({
                            "risk": "Low Growth",
                            "current": f"{growth*100:.1f}% YoY",
                            "impact": "medium",
                            "mitigation": "Develop clear growth initiatives"
                        })

            # Margin analysis
            if latest.get("gross_margin"):
                margin = latest["gross_margin"]
                if margin > 0.70:
                    value_drivers.append({
                        "driver": "Gross Margin",
                        "current": f"{margin*100:.1f}%",
                        "importance": "medium",
                        "note": "Strong margins indicate pricing power"
                    })
                elif margin < 0.50:
                    enhancement_opportunities.append({
                        "opportunity": "Margin Improvement",
                        "current": f"{margin*100:.1f}%",
                        "potential": "Could add 0.5-1x to multiple",
                        "actions": ["Review pricing", "Optimize costs", "Improve mix"]
                    })

            # Churn analysis
            if latest.get("churn_rate"):
                churn = latest["churn_rate"]
                if churn > 0.10:
                    risks_to_value.append({
                        "risk": "High Churn",
                        "current": f"{churn*100:.1f}% monthly",
                        "impact": "high",
                        "mitigation": "Implement retention programs before exit"
                    })
                elif churn < 0.02:
                    value_drivers.append({
                        "driver": "Low Churn",
                        "current": f"{churn*100:.1f}% monthly",
                        "importance": "high",
                        "note": "Sticky customers = predictable revenue"
                    })

        # Standard enhancement opportunities
        enhancement_opportunities.extend([
            {
                "opportunity": "Recurring Revenue Mix",
                "potential": "Each 10% increase in recurring = 0.5x multiple improvement",
                "actions": ["Convert one-time to subscription", "Add maintenance contracts"]
            },
            {
                "opportunity": "Customer Concentration",
                "potential": "No customer >15% = reduced risk discount",
                "actions": ["Diversify customer base", "Land new logos"]
            },
            {
                "opportunity": "Documentation & Processes",
                "potential": "Reduces transition risk, improves buyer confidence",
                "actions": ["Document all key processes", "Create training materials"]
            }
        ])

        analysis = {
            "date": datetime.now(timezone.utc).isoformat(),
            "value_drivers": value_drivers,
            "enhancement_opportunities": enhancement_opportunities,
            "risks_to_value": risks_to_value,
            "summary": {
                "drivers_count": len(value_drivers),
                "opportunities_count": len(enhancement_opportunities),
                "risks_count": len(risks_to_value)
            }
        }

        # Save to exit plan
        exit_plan = self._load_exit_plan(deal_id)
        if "value_analyses" not in exit_plan:
            exit_plan["value_analyses"] = []
        exit_plan["value_analyses"].append(analysis)
        self._save_exit_plan(deal_id, exit_plan)

        self._log_run("analyze_value_drivers", deal_id, analysis["summary"])

        return StrategistResult(
            success=True,
            message=f"Identified {len(value_drivers)} value drivers, {len(enhancement_opportunities)} opportunities, {len(risks_to_value)} risks",
            actions_taken=[
                "Analyzed historical KPIs",
                "Identified value drivers",
                "Flagged enhancement opportunities",
                "Assessed risks to value"
            ],
            artifacts=[],
            data=analysis
        )

    def estimate_exit_timeline(self, deal_id: str, target_close_months: int = 12) -> StrategistResult:
        """
        Estimate and plan exit timeline.

        Args:
            deal_id: Deal identifier
            target_close_months: Target months to close (default 12)

        Returns:
            StrategistResult with timeline
        """
        ctx = self._get_deal_context(deal_id)
        if not ctx:
            return StrategistResult(
                success=False,
                message=f"Deal {deal_id} not found",
                actions_taken=[],
                artifacts=[]
            )

        now = datetime.now(timezone.utc)

        # Standard M&A timeline phases
        phases = [
            {
                "phase": "Preparation",
                "duration_months": 3,
                "activities": [
                    "Engage advisors",
                    "Prepare financials",
                    "Build data room",
                    "Draft CIM"
                ]
            },
            {
                "phase": "Marketing",
                "duration_months": 2,
                "activities": [
                    "Identify buyers",
                    "Initial outreach",
                    "Management presentations",
                    "Receive IOIs"
                ]
            },
            {
                "phase": "Due Diligence",
                "duration_months": 3,
                "activities": [
                    "Negotiate LOI",
                    "Buyer due diligence",
                    "Management meetings",
                    "Working capital analysis"
                ]
            },
            {
                "phase": "Documentation & Close",
                "duration_months": 2,
                "activities": [
                    "Draft purchase agreement",
                    "Negotiate terms",
                    "Regulatory approvals",
                    "Closing"
                ]
            },
            {
                "phase": "Post-Close Transition",
                "duration_months": 2,
                "activities": [
                    "Transition support",
                    "Knowledge transfer",
                    "Earnout tracking (if applicable)"
                ]
            }
        ]

        # Calculate dates
        timeline = []
        current_date = now
        for phase in phases:
            start_date = current_date
            end_date = current_date + timedelta(days=phase["duration_months"] * 30)
            timeline.append({
                "phase": phase["phase"],
                "start_date": start_date.isoformat(),
                "end_date": end_date.isoformat(),
                "duration_months": phase["duration_months"],
                "activities": phase["activities"]
            })
            current_date = end_date

        target_close = now + timedelta(days=target_close_months * 30)
        estimated_close = timeline[-2]["end_date"]  # Documentation & Close end

        result = {
            "date": datetime.now(timezone.utc).isoformat(),
            "target_close": target_close.isoformat(),
            "estimated_close": estimated_close,
            "total_duration_months": sum(p["duration_months"] for p in phases) - 2,  # Exclude post-close
            "phases": timeline,
            "key_milestones": [
                {"milestone": "Advisors Engaged", "date": (now + timedelta(days=30)).isoformat()},
                {"milestone": "CIM Complete", "date": (now + timedelta(days=75)).isoformat()},
                {"milestone": "IOIs Received", "date": (now + timedelta(days=120)).isoformat()},
                {"milestone": "LOI Signed", "date": (now + timedelta(days=150)).isoformat()},
                {"milestone": "Due Diligence Complete", "date": (now + timedelta(days=240)).isoformat()},
                {"milestone": "Closing", "date": estimated_close}
            ]
        }

        # Save to exit plan
        exit_plan = self._load_exit_plan(deal_id)
        exit_plan["timeline"] = result
        self._save_exit_plan(deal_id, exit_plan)

        # Schedule key milestone reminders
        for ms in result["key_milestones"][:3]:
            ms_date = datetime.fromisoformat(ms["date"].replace("Z", "+00:00"))
            reminder_date = ms_date - timedelta(days=7)
            if reminder_date > now:
                self.action_queue.add_action(
                    deal_id=deal_id,
                    action_type="exit_milestone_reminder",
                    scheduled_for=reminder_date.isoformat(),
                    context={"milestone": ms["milestone"], "target_date": ms["date"]}
                )

        self._log_run("estimate_exit_timeline", deal_id, {
            "target_close": target_close.isoformat(),
            "estimated_close": estimated_close,
            "phases_count": len(phases)
        })

        return StrategistResult(
            success=True,
            message=f"Exit timeline: {sum(p['duration_months'] for p in phases)-2} months to close (target: {target_close.strftime('%Y-%m-%d')})",
            actions_taken=[
                f"Mapped {len(phases)} exit phases",
                f"Identified {len(result['key_milestones'])} key milestones",
                "Scheduled milestone reminders"
            ],
            artifacts=[str(EXIT_PLANS_DIR / f"{deal_id}_exit_plan.json")],
            data=result
        )

    def get_exit_status(self, deal_id: str) -> StrategistResult:
        """
        Get comprehensive exit planning status.

        Args:
            deal_id: Deal identifier

        Returns:
            StrategistResult with full status
        """
        ctx = self._get_deal_context(deal_id)
        if not ctx:
            return StrategistResult(
                success=False,
                message=f"Deal {deal_id} not found",
                actions_taken=[],
                artifacts=[]
            )

        exit_plan = self._load_exit_plan(deal_id)

        # Latest assessment
        latest_assessment = exit_plan.get("assessments", [{}])[-1] if exit_plan.get("assessments") else {}

        # Checklist progress
        checklist = exit_plan.get("checklist_items", [])
        completed_items = [i for i in checklist if i.get("status") == "completed"]
        overdue_items = []
        now = datetime.now(timezone.utc)
        for item in checklist:
            if item.get("status") != "completed":
                due = datetime.fromisoformat(item["due_date"].replace("Z", "+00:00"))
                if due < now:
                    overdue_items.append(item)

        status = {
            "deal_id": deal_id,
            "deal_name": ctx.deal.display_name or ctx.deal.canonical_name,
            "stage": ctx.stage,
            "exit_plan_status": exit_plan.get("status", "not_started"),
            "target_exit_date": exit_plan.get("target_exit_date"),
            "latest_readiness_score": latest_assessment.get("overall_score"),
            "readiness_recommendation": latest_assessment.get("recommendation"),
            "checklist_progress": {
                "total": len(checklist),
                "completed": len(completed_items),
                "overdue": len(overdue_items),
                "completion_pct": round(len(completed_items) / len(checklist) * 100, 1) if checklist else 0
            },
            "assessments_count": len(exit_plan.get("assessments", [])),
            "value_analyses_count": len(exit_plan.get("value_analyses", []))
        }

        self._log_run("get_exit_status", deal_id, {"status": "retrieved"})

        return StrategistResult(
            success=True,
            message=f"Exit status for {deal_id}: {status['readiness_recommendation'] or 'Not assessed'}",
            actions_taken=["Retrieved exit planning status"],
            artifacts=[],
            data=status
        )


def main():
    parser = argparse.ArgumentParser(description="Exit Strategist Agent")
    subparsers = parser.add_subparsers(dest="command", help="Commands")

    # assess
    assess_parser = subparsers.add_parser("assess", help="Assess exit readiness")
    assess_parser.add_argument("deal_id", help="Deal ID")

    # checklist
    checklist_parser = subparsers.add_parser("checklist", help="Generate exit checklist")
    checklist_parser.add_argument("deal_id", help="Deal ID")
    checklist_parser.add_argument("--months", type=int, default=12, help="Target months to exit")

    # value-drivers
    value_parser = subparsers.add_parser("value-drivers", help="Analyze value drivers")
    value_parser.add_argument("deal_id", help="Deal ID")

    # timeline
    timeline_parser = subparsers.add_parser("timeline", help="Estimate exit timeline")
    timeline_parser.add_argument("deal_id", help="Deal ID")
    timeline_parser.add_argument("--months", type=int, default=12, help="Target months to close")

    # status
    status_parser = subparsers.add_parser("status", help="Get exit planning status")
    status_parser.add_argument("deal_id", help="Deal ID")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return

    agent = ExitStrategistAgent()

    if args.command == "assess":
        result = agent.assess_exit_readiness(args.deal_id)
    elif args.command == "checklist":
        result = agent.generate_exit_checklist(args.deal_id, args.months)
    elif args.command == "value-drivers":
        result = agent.analyze_value_drivers(args.deal_id)
    elif args.command == "timeline":
        result = agent.estimate_exit_timeline(args.deal_id, args.months)
    elif args.command == "status":
        result = agent.get_exit_status(args.deal_id)
    else:
        parser.print_help()
        return

    # Output result
    print(f"\n{'='*60}")
    print(f"Exit Strategist: {args.command}")
    print(f"{'='*60}")
    print(f"Status: {'SUCCESS' if result.success else 'FAILED'}")
    print(f"Message: {result.message}")

    if result.actions_taken:
        print(f"\nActions Taken:")
        for action in result.actions_taken:
            print(f"  - {action}")

    if result.artifacts:
        print(f"\nArtifacts:")
        for artifact in result.artifacts:
            print(f"  - {artifact}")

    if result.data:
        print(f"\nData:")
        print(json.dumps(result.data, indent=2))


if __name__ == "__main__":
    main()
