#!/usr/bin/env python3
"""
Durable Checkpointing Module

Provides crash recovery for long-running operations by persisting
operation state at regular intervals.

Use cases:
- Email sync processing 1000+ emails
- Bulk document classification
- SharePoint sync with many files
- RAG re-indexing operations

Design:
- Atomic checkpoint writes (tmp + rename)
- Per-operation checkpoint files
- Automatic cleanup of old checkpoints
- Resume capability after crash/restart
"""

from __future__ import annotations

import hashlib
import json
import os
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional


def _gen_operation_id(prefix: str = "OP") -> str:
    """Generate unique operation ID"""
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")
    nonce = hashlib.sha256(f"{ts}:{os.getpid()}:{uuid.uuid4()}".encode()).hexdigest()[:8]
    return f"{prefix}-{ts}-{nonce}"


def _now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


@dataclass
class Checkpoint:
    """Checkpoint state for a long-running operation"""
    operation_id: str
    operation_type: str
    status: str = "in_progress"  # in_progress, completed, failed, cancelled
    started_at: str = ""
    updated_at: str = ""
    completed_at: Optional[str] = None
    total_items: Optional[int] = None
    processed_items: int = 0
    failed_items: int = 0
    skipped_items: int = 0
    last_processed_key: Optional[str] = None  # For resumption
    state: Dict[str, Any] = field(default_factory=dict)  # Custom operation state
    errors: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "Checkpoint":
        return cls(
            operation_id=d.get("operation_id", ""),
            operation_type=d.get("operation_type", ""),
            status=d.get("status", "in_progress"),
            started_at=d.get("started_at", ""),
            updated_at=d.get("updated_at", ""),
            completed_at=d.get("completed_at"),
            total_items=d.get("total_items"),
            processed_items=d.get("processed_items", 0),
            failed_items=d.get("failed_items", 0),
            skipped_items=d.get("skipped_items", 0),
            last_processed_key=d.get("last_processed_key"),
            state=d.get("state") or {},
            errors=d.get("errors") or [],
            metadata=d.get("metadata") or {},
        )

    @property
    def progress_pct(self) -> float:
        """Calculate progress percentage"""
        if not self.total_items:
            return 0.0
        return (self.processed_items / self.total_items) * 100

    @property
    def is_resumable(self) -> bool:
        """Check if operation can be resumed"""
        return self.status == "in_progress" and self.last_processed_key is not None


class CheckpointManager:
    """
    Manages durable checkpoints for long-running operations.

    Usage:
        manager = CheckpointManager()

        # Start new operation
        cp = manager.start("email_sync", total_items=1000)

        # Update periodically
        for i, email in enumerate(emails):
            process(email)
            if i % 100 == 0:
                manager.update(cp.operation_id, processed=i, last_key=email.id)

        # Mark complete
        manager.complete(cp.operation_id)

        # Or resume after crash
        cp = manager.get_latest_incomplete("email_sync")
        if cp:
            resume_from = cp.last_processed_key
    """

    def __init__(self, checkpoint_dir: Optional[str] = None):
        self.checkpoint_dir = Path(
            checkpoint_dir or
            os.getenv("CHECKPOINT_DIR", "/home/zaks/DataRoom/.deal-registry/checkpoints")
        )
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)

        # How often to auto-save checkpoints (items processed)
        self.auto_save_interval = int(os.getenv("CHECKPOINT_INTERVAL", "100"))

        # Max checkpoints to keep per operation type
        self.max_completed_checkpoints = int(os.getenv("CHECKPOINT_MAX_COMPLETED", "10"))

    def _checkpoint_path(self, operation_id: str) -> Path:
        """Get path to checkpoint file"""
        return self.checkpoint_dir / f"{operation_id}.json"

    def _atomic_write(self, path: Path, data: Dict[str, Any]) -> None:
        """Write checkpoint atomically"""
        tmp_path = path.with_suffix(".tmp")
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False, default=str)
            f.write("\n")
        os.replace(tmp_path, path)

    def start(
        self,
        operation_type: str,
        total_items: Optional[int] = None,
        metadata: Optional[Dict[str, Any]] = None,
        operation_id: Optional[str] = None,
    ) -> Checkpoint:
        """
        Start a new checkpointed operation.

        Returns Checkpoint object.
        """
        operation_id = operation_id or _gen_operation_id(operation_type.upper()[:4])
        now = _now_iso()

        checkpoint = Checkpoint(
            operation_id=operation_id,
            operation_type=operation_type,
            status="in_progress",
            started_at=now,
            updated_at=now,
            total_items=total_items,
            metadata=metadata or {},
        )

        self._atomic_write(self._checkpoint_path(operation_id), checkpoint.to_dict())
        return checkpoint

    def update(
        self,
        operation_id: str,
        processed: Optional[int] = None,
        failed: Optional[int] = None,
        skipped: Optional[int] = None,
        last_key: Optional[str] = None,
        state: Optional[Dict[str, Any]] = None,
        error: Optional[str] = None,
    ) -> Optional[Checkpoint]:
        """
        Update checkpoint with progress.

        Returns updated Checkpoint or None if not found.
        """
        path = self._checkpoint_path(operation_id)
        if not path.exists():
            return None

        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)

        checkpoint = Checkpoint.from_dict(data)

        if checkpoint.status != "in_progress":
            return checkpoint

        if processed is not None:
            checkpoint.processed_items = processed
        if failed is not None:
            checkpoint.failed_items = failed
        if skipped is not None:
            checkpoint.skipped_items = skipped
        if last_key is not None:
            checkpoint.last_processed_key = last_key
        if state is not None:
            checkpoint.state.update(state)
        if error:
            checkpoint.errors.append(f"[{_now_iso()}] {error}")
            # Keep only last 100 errors
            checkpoint.errors = checkpoint.errors[-100:]

        checkpoint.updated_at = _now_iso()

        self._atomic_write(path, checkpoint.to_dict())
        return checkpoint

    def increment(
        self,
        operation_id: str,
        processed: int = 1,
        failed: int = 0,
        skipped: int = 0,
        last_key: Optional[str] = None,
        state: Optional[Dict[str, Any]] = None,
    ) -> Optional[Checkpoint]:
        """
        Increment checkpoint counters.

        More efficient than update() for simple progress tracking.
        """
        path = self._checkpoint_path(operation_id)
        if not path.exists():
            return None

        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)

        checkpoint = Checkpoint.from_dict(data)

        if checkpoint.status != "in_progress":
            return checkpoint

        checkpoint.processed_items += processed
        checkpoint.failed_items += failed
        checkpoint.skipped_items += skipped

        if last_key is not None:
            checkpoint.last_processed_key = last_key
        if state is not None:
            checkpoint.state.update(state)

        checkpoint.updated_at = _now_iso()

        # Only write every N items to reduce I/O
        if checkpoint.processed_items % self.auto_save_interval == 0:
            self._atomic_write(path, checkpoint.to_dict())

        return checkpoint

    def complete(
        self,
        operation_id: str,
        state: Optional[Dict[str, Any]] = None,
    ) -> Optional[Checkpoint]:
        """
        Mark operation as completed.

        Returns completed Checkpoint.
        """
        path = self._checkpoint_path(operation_id)
        if not path.exists():
            return None

        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)

        checkpoint = Checkpoint.from_dict(data)
        checkpoint.status = "completed"
        checkpoint.completed_at = _now_iso()
        checkpoint.updated_at = checkpoint.completed_at

        if state:
            checkpoint.state.update(state)

        self._atomic_write(path, checkpoint.to_dict())
        self._cleanup_old_checkpoints(checkpoint.operation_type)
        return checkpoint

    def fail(
        self,
        operation_id: str,
        error: str,
        state: Optional[Dict[str, Any]] = None,
    ) -> Optional[Checkpoint]:
        """
        Mark operation as failed.

        Returns failed Checkpoint.
        """
        path = self._checkpoint_path(operation_id)
        if not path.exists():
            return None

        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)

        checkpoint = Checkpoint.from_dict(data)
        checkpoint.status = "failed"
        checkpoint.completed_at = _now_iso()
        checkpoint.updated_at = checkpoint.completed_at
        checkpoint.errors.append(f"[{_now_iso()}] FATAL: {error}")

        if state:
            checkpoint.state.update(state)

        self._atomic_write(path, checkpoint.to_dict())
        return checkpoint

    def cancel(self, operation_id: str, reason: str = "") -> Optional[Checkpoint]:
        """
        Cancel an in-progress operation.

        Returns cancelled Checkpoint.
        """
        path = self._checkpoint_path(operation_id)
        if not path.exists():
            return None

        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)

        checkpoint = Checkpoint.from_dict(data)

        if checkpoint.status != "in_progress":
            return checkpoint

        checkpoint.status = "cancelled"
        checkpoint.completed_at = _now_iso()
        checkpoint.updated_at = checkpoint.completed_at
        if reason:
            checkpoint.errors.append(f"[{_now_iso()}] Cancelled: {reason}")

        self._atomic_write(path, checkpoint.to_dict())
        return checkpoint

    def get(self, operation_id: str) -> Optional[Checkpoint]:
        """Get checkpoint by operation ID"""
        path = self._checkpoint_path(operation_id)
        if not path.exists():
            return None

        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)

        return Checkpoint.from_dict(data)

    def get_latest_incomplete(self, operation_type: str) -> Optional[Checkpoint]:
        """
        Get the most recent incomplete (in_progress) checkpoint for an operation type.

        Use this to resume after crash.
        """
        checkpoints = []

        for path in self.checkpoint_dir.glob("*.json"):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                cp = Checkpoint.from_dict(data)
                if cp.operation_type == operation_type and cp.status == "in_progress":
                    checkpoints.append(cp)
            except Exception:
                continue

        if not checkpoints:
            return None

        # Return most recent by started_at
        checkpoints.sort(key=lambda c: c.started_at, reverse=True)
        return checkpoints[0]

    def list_checkpoints(
        self,
        operation_type: Optional[str] = None,
        status: Optional[str] = None,
        limit: int = 50,
    ) -> List[Checkpoint]:
        """List checkpoints with optional filters"""
        checkpoints: List[Checkpoint] = []

        for path in self.checkpoint_dir.glob("*.json"):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                cp = Checkpoint.from_dict(data)

                if operation_type and cp.operation_type != operation_type:
                    continue
                if status and cp.status != status:
                    continue

                checkpoints.append(cp)
            except Exception:
                continue

        # Sort by updated_at descending
        checkpoints.sort(key=lambda c: c.updated_at, reverse=True)
        return checkpoints[:limit]

    def _cleanup_old_checkpoints(self, operation_type: str) -> int:
        """
        Clean up old completed checkpoints, keeping only the most recent N.

        Returns number of checkpoints deleted.
        """
        completed = self.list_checkpoints(
            operation_type=operation_type,
            status="completed",
            limit=1000,
        )

        if len(completed) <= self.max_completed_checkpoints:
            return 0

        # Delete oldest
        to_delete = completed[self.max_completed_checkpoints:]
        deleted = 0

        for cp in to_delete:
            path = self._checkpoint_path(cp.operation_id)
            try:
                path.unlink()
                deleted += 1
            except Exception:
                pass

        return deleted

    def stats(self) -> Dict[str, Any]:
        """Get checkpoint statistics"""
        checkpoints = self.list_checkpoints(limit=10000)

        stats = {
            "total": len(checkpoints),
            "by_status": {},
            "by_type": {},
            "in_progress": [],
        }

        for cp in checkpoints:
            stats["by_status"][cp.status] = stats["by_status"].get(cp.status, 0) + 1
            stats["by_type"][cp.operation_type] = stats["by_type"].get(cp.operation_type, 0) + 1

            if cp.status == "in_progress":
                stats["in_progress"].append({
                    "operation_id": cp.operation_id,
                    "operation_type": cp.operation_type,
                    "progress": f"{cp.progress_pct:.1f}%",
                    "started_at": cp.started_at,
                })

        return stats


# Context manager for checkpointed operations
class CheckpointedOperation:
    """
    Context manager for checkpointed operations.

    Usage:
        with CheckpointedOperation("email_sync", total=1000) as op:
            for email in emails:
                process(email)
                op.progress(email.id)
    """

    def __init__(
        self,
        operation_type: str,
        total: Optional[int] = None,
        manager: Optional[CheckpointManager] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ):
        self.manager = manager or CheckpointManager()
        self.operation_type = operation_type
        self.total = total
        self.metadata = metadata
        self.checkpoint: Optional[Checkpoint] = None
        self._processed = 0
        self._failed = 0
        self._skipped = 0

    def __enter__(self) -> "CheckpointedOperation":
        self.checkpoint = self.manager.start(
            self.operation_type,
            total_items=self.total,
            metadata=self.metadata,
        )
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        if not self.checkpoint:
            return

        if exc_type:
            self.manager.fail(
                self.checkpoint.operation_id,
                error=f"{exc_type.__name__}: {exc_val}",
            )
        else:
            self.manager.complete(self.checkpoint.operation_id)

    def progress(
        self,
        last_key: Optional[str] = None,
        state: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Record progress on one item"""
        self._processed += 1
        if self.checkpoint:
            self.manager.increment(
                self.checkpoint.operation_id,
                processed=1,
                last_key=last_key,
                state=state,
            )

    def failed(self, error: str = "") -> None:
        """Record a failed item"""
        self._failed += 1
        if self.checkpoint:
            self.manager.update(
                self.checkpoint.operation_id,
                failed=self._failed,
                error=error if error else None,
            )

    def skipped(self) -> None:
        """Record a skipped item"""
        self._skipped += 1
        if self.checkpoint:
            self.manager.increment(
                self.checkpoint.operation_id,
                skipped=1,
            )

    @property
    def operation_id(self) -> str:
        return self.checkpoint.operation_id if self.checkpoint else ""


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Checkpoint Manager CLI")
    parser.add_argument("command", choices=["stats", "list", "get", "cancel", "cleanup"])
    parser.add_argument("--operation-id", help="Operation ID")
    parser.add_argument("--operation-type", help="Operation type filter")
    parser.add_argument("--status", choices=["in_progress", "completed", "failed", "cancelled"])
    args = parser.parse_args()

    manager = CheckpointManager()

    if args.command == "stats":
        stats = manager.stats()
        print(json.dumps(stats, indent=2))

    elif args.command == "list":
        checkpoints = manager.list_checkpoints(
            operation_type=args.operation_type,
            status=args.status,
        )
        print(f"Checkpoints: {len(checkpoints)}")
        for cp in checkpoints:
            print(f"  [{cp.status}] {cp.operation_id}: {cp.operation_type}")
            print(f"       Progress: {cp.processed_items}/{cp.total_items or '?'} ({cp.progress_pct:.1f}%)")
            print(f"       Updated: {cp.updated_at}")

    elif args.command == "get":
        if not args.operation_id:
            print("Error: --operation-id required")
            raise SystemExit(1)
        cp = manager.get(args.operation_id)
        if cp:
            print(json.dumps(cp.to_dict(), indent=2))
        else:
            print(f"Checkpoint not found: {args.operation_id}")

    elif args.command == "cancel":
        if not args.operation_id:
            print("Error: --operation-id required")
            raise SystemExit(1)
        cp = manager.cancel(args.operation_id, "Cancelled via CLI")
        if cp:
            print(f"Cancelled: {cp.operation_id}")
        else:
            print(f"Checkpoint not found: {args.operation_id}")

    elif args.command == "cleanup":
        if not args.operation_type:
            print("Error: --operation-type required for cleanup")
            raise SystemExit(1)
        deleted = manager._cleanup_old_checkpoints(args.operation_type)
        print(f"Deleted {deleted} old checkpoints for {args.operation_type}")
