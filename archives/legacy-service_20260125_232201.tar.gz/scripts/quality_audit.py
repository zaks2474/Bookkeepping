#!/usr/bin/env python3
"""
Quality Audit System

Tracks and audits system quality for Phase 6 evaluation:
- Classification accuracy validation
- Agent output quality checks
- Data consistency audits
- Monthly quality report generation
- Golden dataset management for offline evaluation

Usage:
    python3 quality_audit.py classification-audit
    python3 quality_audit.py data-consistency
    python3 quality_audit.py agent-audit --agent underwriter
    python3 quality_audit.py monthly-report
    python3 quality_audit.py golden-set --action list
"""

from __future__ import annotations

import argparse
import json
import re
import hashlib
from collections import defaultdict
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# Configuration
REGISTRY_PATH = Path("/home/zaks/DataRoom/.deal-registry/deal_registry.json")
EVENTS_DIR = Path("/home/zaks/DataRoom/.deal-registry/events")
CASE_FILES_DIR = Path("/home/zaks/DataRoom/.deal-registry/case_files")
QUARANTINE_PATH = Path("/home/zaks/DataRoom/.deal-registry/quarantine.json")
ARTIFACTS_DIR = Path("/home/zaks/DataRoom/.deal-registry/artifacts")
AUDIT_DIR = Path("/home/zaks/DataRoom/.deal-registry/audits")
GOLDEN_SET_DIR = Path("/home/zaks/DataRoom/.deal-registry/golden_sets")
RUN_LEDGER_PATH = Path("/home/zaks/logs/run-ledger.jsonl")

# Ensure directories exist
AUDIT_DIR.mkdir(parents=True, exist_ok=True)
GOLDEN_SET_DIR.mkdir(parents=True, exist_ok=True)


@dataclass
class QualityIssue:
    """A quality issue found during audit"""
    category: str  # classification, consistency, agent, data
    severity: str  # critical, high, medium, low
    deal_id: Optional[str]
    description: str
    evidence: Dict[str, Any] = field(default_factory=dict)
    suggestion: str = ""


@dataclass
class AuditResult:
    """Result of an audit operation"""
    audit_type: str
    timestamp: str
    items_checked: int = 0
    issues_found: int = 0
    issues: List[QualityIssue] = field(default_factory=list)
    metrics: Dict[str, Any] = field(default_factory=dict)
    summary: str = ""


@dataclass
class GoldenTestCase:
    """A test case in the golden dataset"""
    test_id: str
    category: str  # classification, extraction, scoring
    input_data: Dict[str, Any]
    expected_output: Dict[str, Any]
    created_at: str
    tags: List[str] = field(default_factory=list)
    notes: str = ""


class QualityAuditor:
    """
    Quality audit system for deal lifecycle operations.
    """

    def __init__(self):
        self.registry = self._load_registry()
        self.quarantine = self._load_quarantine()

    def _load_registry(self) -> Dict[str, Any]:
        """Load deal registry"""
        if REGISTRY_PATH.exists():
            with open(REGISTRY_PATH) as f:
                return json.load(f)
        return {"deals": {}}

    def _load_quarantine(self) -> List[Dict[str, Any]]:
        """Load quarantine items"""
        if QUARANTINE_PATH.exists():
            with open(QUARANTINE_PATH) as f:
                data = json.load(f)
                return data.get("items", []) if isinstance(data, dict) else data
        return []

    def _load_events(self, deal_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Load events, optionally for a specific deal"""
        events = []
        if EVENTS_DIR.exists():
            if deal_id:
                safe_id = deal_id.replace("/", "_").replace("\\", "_")
                event_file = EVENTS_DIR / f"{safe_id}.jsonl"
                files = [event_file] if event_file.exists() else []
            else:
                files = list(EVENTS_DIR.glob("*.jsonl"))

            for event_file in files:
                with open(event_file) as f:
                    for line in f:
                        line = line.strip()
                        if line:
                            try:
                                events.append(json.loads(line))
                            except json.JSONDecodeError:
                                continue
        return events

    def _load_run_ledger(self, since: Optional[datetime] = None) -> List[Dict[str, Any]]:
        """Load run ledger entries"""
        entries = []
        if RUN_LEDGER_PATH.exists():
            with open(RUN_LEDGER_PATH) as f:
                for line in f:
                    line = line.strip()
                    if line:
                        try:
                            entry = json.loads(line)
                            if since:
                                ts_str = entry.get("timestamp", "")
                                if ts_str:
                                    ts = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
                                    if ts < since:
                                        continue
                            entries.append(entry)
                        except (json.JSONDecodeError, ValueError):
                            continue
        return entries

    def _save_audit(self, audit: AuditResult) -> Path:
        """Save audit result"""
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        filename = f"audit_{audit.audit_type}_{timestamp}.json"
        filepath = AUDIT_DIR / filename

        data = {
            "audit_type": audit.audit_type,
            "timestamp": audit.timestamp,
            "items_checked": audit.items_checked,
            "issues_found": audit.issues_found,
            "issues": [asdict(i) for i in audit.issues],
            "metrics": audit.metrics,
            "summary": audit.summary
        }

        with open(filepath, "w") as f:
            json.dump(data, f, indent=2)

        return filepath

    def audit_classification_accuracy(self) -> AuditResult:
        """
        Audit classification accuracy by analyzing quarantine resolutions.

        Returns:
            AuditResult with classification quality metrics
        """
        audit = AuditResult(
            audit_type="classification",
            timestamp=datetime.now(timezone.utc).isoformat()
        )

        # Analyze resolved quarantine items
        resolved_to_deal = 0
        resolved_discard = 0
        false_positives = 0  # Discarded items that probably should have matched
        false_negatives = 0  # Estimated from patterns

        for item in self.quarantine:
            audit.items_checked += 1
            status = item.get("status", "pending")

            if status == "resolved":
                resolution = item.get("resolution", {})
                action = resolution.get("action")

                if action == "link_to_deal":
                    resolved_to_deal += 1
                    # Check if confidence was high but still quarantined
                    confidence = item.get("confidence", 0)
                    if confidence > 0.8:
                        audit.issues.append(QualityIssue(
                            category="classification",
                            severity="medium",
                            deal_id=item.get("matched_deal_id"),
                            description=f"High confidence ({confidence:.2f}) item was quarantined unnecessarily",
                            evidence={"quarantine_id": item.get("id"), "confidence": confidence},
                            suggestion="Consider lowering quarantine threshold"
                        ))
                else:
                    resolved_discard += 1

        # Calculate metrics
        total_resolved = resolved_to_deal + resolved_discard
        if total_resolved > 0:
            precision = resolved_to_deal / total_resolved
            audit.metrics["precision"] = round(precision, 3)
        else:
            audit.metrics["precision"] = None

        audit.metrics["resolved_to_deal"] = resolved_to_deal
        audit.metrics["resolved_discard"] = resolved_discard
        audit.metrics["pending"] = len([i for i in self.quarantine if i.get("status") == "pending"])

        # Check for classification events
        events = self._load_events()
        classification_events = [e for e in events if e.get("event_type") in ["document_classified", "email_classified"]]

        confidence_distribution = defaultdict(int)
        for event in classification_events:
            conf = event.get("data", {}).get("confidence", 0)
            if conf >= 0.9:
                confidence_distribution["high"] += 1
            elif conf >= 0.7:
                confidence_distribution["medium"] += 1
            else:
                confidence_distribution["low"] += 1

        audit.metrics["classification_events"] = len(classification_events)
        audit.metrics["confidence_distribution"] = dict(confidence_distribution)

        audit.issues_found = len(audit.issues)
        audit.summary = f"Classification audit: {audit.items_checked} items checked, {audit.issues_found} issues found, precision: {audit.metrics.get('precision', 'N/A')}"

        return audit

    def audit_data_consistency(self) -> AuditResult:
        """
        Audit data consistency across registry, events, and case files.

        Returns:
            AuditResult with consistency check results
        """
        audit = AuditResult(
            audit_type="data_consistency",
            timestamp=datetime.now(timezone.utc).isoformat()
        )

        deals = self.registry.get("deals", {})

        for deal_id, deal in deals.items():
            audit.items_checked += 1

            # Check 1: Stage consistency
            stage = deal.get("stage", "").lower()
            status = deal.get("status", "")

            if status == "active" and stage in ["closed_won", "closed_lost"]:
                audit.issues.append(QualityIssue(
                    category="consistency",
                    severity="high",
                    deal_id=deal_id,
                    description=f"Active deal has terminal stage: {stage}",
                    suggestion="Update status to reflect closed state"
                ))

            # Check 2: Required fields
            if not deal.get("canonical_name"):
                audit.issues.append(QualityIssue(
                    category="consistency",
                    severity="medium",
                    deal_id=deal_id,
                    description="Missing canonical_name",
                    suggestion="Add canonical name to deal"
                ))

            # Check 3: Case file exists for active deals
            if status == "active":
                case_path = CASE_FILES_DIR / f"{deal_id}.json"
                if not case_path.exists():
                    audit.issues.append(QualityIssue(
                        category="consistency",
                        severity="low",
                        deal_id=deal_id,
                        description="Active deal missing case file",
                        suggestion=f"Run: python3 case_file_rebuilder.py rebuild {deal_id}"
                    ))
                else:
                    # Check case file stage matches registry
                    with open(case_path) as f:
                        case = json.load(f)
                    case_stage = case.get("key_facts", {}).get("stage", "").lower()
                    if case_stage and case_stage != stage:
                        audit.issues.append(QualityIssue(
                            category="consistency",
                            severity="medium",
                            deal_id=deal_id,
                            description=f"Case file stage ({case_stage}) != registry stage ({stage})",
                            suggestion=f"Run: python3 case_file_rebuilder.py rebuild {deal_id}"
                        ))

            # Check 4: Timestamp validity
            created = deal.get("created_at")
            updated = deal.get("updated_at")

            if created and updated:
                try:
                    created_dt = datetime.fromisoformat(created.replace("Z", "+00:00"))
                    updated_dt = datetime.fromisoformat(updated.replace("Z", "+00:00"))
                    if updated_dt < created_dt:
                        audit.issues.append(QualityIssue(
                            category="consistency",
                            severity="medium",
                            deal_id=deal_id,
                            description="updated_at is before created_at",
                            evidence={"created": created, "updated": updated}
                        ))
                except (ValueError, TypeError):
                    audit.issues.append(QualityIssue(
                        category="consistency",
                        severity="low",
                        deal_id=deal_id,
                        description="Invalid timestamp format"
                    ))

            # Check 5: Orphaned events
            events = self._load_events(deal_id)
            for event in events:
                if event.get("deal_id") != deal_id:
                    audit.issues.append(QualityIssue(
                        category="consistency",
                        severity="high",
                        deal_id=deal_id,
                        description=f"Event in {deal_id}.jsonl has wrong deal_id: {event.get('deal_id')}",
                        evidence={"event_id": event.get("event_id")}
                    ))

        # Summary metrics
        audit.metrics["total_deals"] = len(deals)
        audit.metrics["active_deals"] = len([d for d in deals.values() if d.get("status") == "active"])

        by_severity = defaultdict(int)
        for issue in audit.issues:
            by_severity[issue.severity] += 1

        audit.metrics["issues_by_severity"] = dict(by_severity)
        audit.issues_found = len(audit.issues)
        audit.summary = f"Data consistency audit: {audit.items_checked} deals checked, {audit.issues_found} issues found"

        return audit

    def audit_agent_outputs(self, agent_name: Optional[str] = None, days: int = 30) -> AuditResult:
        """
        Audit agent outputs for quality.

        Args:
            agent_name: Specific agent to audit (or all if None)
            days: Number of days to analyze

        Returns:
            AuditResult with agent quality metrics
        """
        audit = AuditResult(
            audit_type="agent_outputs",
            timestamp=datetime.now(timezone.utc).isoformat()
        )

        since = datetime.now(timezone.utc) - timedelta(days=days)
        ledger = self._load_run_ledger(since)

        # Filter by agent if specified
        if agent_name:
            ledger = [e for e in ledger if e.get("agent") == agent_name]

        agent_stats = defaultdict(lambda: {
            "total": 0, "success": 0, "failed": 0, "warnings": 0
        })

        for entry in ledger:
            audit.items_checked += 1
            agent = entry.get("agent", "unknown")
            result = entry.get("result", {})

            agent_stats[agent]["total"] += 1

            # Check success/failure
            success = result.get("success", True)
            if success:
                agent_stats[agent]["success"] += 1
            else:
                agent_stats[agent]["failed"] += 1
                audit.issues.append(QualityIssue(
                    category="agent",
                    severity="medium",
                    deal_id=entry.get("deal_id"),
                    description=f"Agent {agent} operation failed",
                    evidence={
                        "operation": entry.get("operation"),
                        "error": result.get("error", result.get("message", "Unknown error"))
                    }
                ))

            # Check for warnings
            warnings = result.get("warnings", [])
            if warnings:
                agent_stats[agent]["warnings"] += len(warnings)

            # Check for suspicious outputs
            if agent == "underwriter":
                # Check buy-box scores are reasonable
                score = result.get("buy_box_score")
                if score is not None:
                    if score < 0 or score > 100:
                        audit.issues.append(QualityIssue(
                            category="agent",
                            severity="high",
                            deal_id=entry.get("deal_id"),
                            description=f"Underwriter produced invalid score: {score}",
                            suggestion="Review underwriter scoring logic"
                        ))

            elif agent == "case_manager":
                # Check for empty summaries
                summary = result.get("summary", "")
                if not summary or len(summary) < 10:
                    audit.issues.append(QualityIssue(
                        category="agent",
                        severity="low",
                        deal_id=entry.get("deal_id"),
                        description="Case manager produced empty or very short summary",
                        suggestion="Review summarization quality"
                    ))

        # Calculate metrics
        for agent, stats in agent_stats.items():
            if stats["total"] > 0:
                stats["success_rate"] = round(stats["success"] / stats["total"], 3)

        audit.metrics["agent_stats"] = dict(agent_stats)
        audit.metrics["period_days"] = days
        audit.issues_found = len(audit.issues)
        audit.summary = f"Agent audit ({agent_name or 'all'}): {audit.items_checked} operations checked, {audit.issues_found} issues found"

        return audit

    def generate_monthly_report(self) -> Dict[str, Any]:
        """
        Generate comprehensive monthly quality report.

        Returns:
            Monthly report with all quality metrics
        """
        now = datetime.now(timezone.utc)
        month_ago = now - timedelta(days=30)

        report = {
            "report_type": "monthly_quality",
            "generated_at": now.isoformat(),
            "period": {
                "start": month_ago.isoformat(),
                "end": now.isoformat()
            },
            "audits": {},
            "summary": {},
            "recommendations": []
        }

        # Run all audits
        classification_audit = self.audit_classification_accuracy()
        report["audits"]["classification"] = {
            "items_checked": classification_audit.items_checked,
            "issues_found": classification_audit.issues_found,
            "metrics": classification_audit.metrics
        }

        consistency_audit = self.audit_data_consistency()
        report["audits"]["data_consistency"] = {
            "items_checked": consistency_audit.items_checked,
            "issues_found": consistency_audit.issues_found,
            "metrics": consistency_audit.metrics
        }

        agent_audit = self.audit_agent_outputs(days=30)
        report["audits"]["agent_outputs"] = {
            "items_checked": agent_audit.items_checked,
            "issues_found": agent_audit.issues_found,
            "metrics": agent_audit.metrics
        }

        # Generate summary
        total_issues = (
            classification_audit.issues_found +
            consistency_audit.issues_found +
            agent_audit.issues_found
        )

        # Categorize by severity
        all_issues = (
            classification_audit.issues +
            consistency_audit.issues +
            agent_audit.issues
        )

        by_severity = defaultdict(int)
        for issue in all_issues:
            by_severity[issue.severity] += 1

        report["summary"] = {
            "total_issues": total_issues,
            "critical_issues": by_severity.get("critical", 0),
            "high_issues": by_severity.get("high", 0),
            "medium_issues": by_severity.get("medium", 0),
            "low_issues": by_severity.get("low", 0),
            "classification_precision": classification_audit.metrics.get("precision"),
            "data_consistency_score": 1 - (consistency_audit.issues_found / max(consistency_audit.items_checked, 1))
        }

        # Generate recommendations
        if by_severity.get("critical", 0) > 0:
            report["recommendations"].append({
                "priority": "immediate",
                "action": "Address critical issues immediately",
                "count": by_severity["critical"]
            })

        precision = classification_audit.metrics.get("precision")
        if precision is not None and precision < 0.8:
            report["recommendations"].append({
                "priority": "high",
                "action": "Review and tune classification thresholds",
                "detail": f"Current precision: {classification_audit.metrics.get('precision', 'N/A')}"
            })

        pending_quarantine = classification_audit.metrics.get("pending", 0)
        if pending_quarantine > 10:
            report["recommendations"].append({
                "priority": "medium",
                "action": f"Review {pending_quarantine} pending quarantine items",
                "detail": "Large quarantine backlog may indicate classification issues"
            })

        # Save report
        filename = f"monthly_report_{now.strftime('%Y%m')}.json"
        filepath = AUDIT_DIR / filename
        with open(filepath, "w") as f:
            json.dump(report, f, indent=2)

        report["saved_to"] = str(filepath)
        return report

    def manage_golden_set(self, action: str, **kwargs) -> Dict[str, Any]:
        """
        Manage golden test datasets for offline evaluation.

        Args:
            action: list, add, run, export
            **kwargs: Additional arguments based on action

        Returns:
            Result of the operation
        """
        if action == "list":
            # List all golden test cases
            test_cases = []
            for file in GOLDEN_SET_DIR.glob("*.json"):
                with open(file) as f:
                    data = json.load(f)
                    test_cases.append({
                        "test_id": data.get("test_id"),
                        "category": data.get("category"),
                        "tags": data.get("tags", []),
                        "created_at": data.get("created_at")
                    })
            return {"action": "list", "test_cases": test_cases, "count": len(test_cases)}

        elif action == "add":
            # Add a new golden test case
            category = kwargs.get("category", "classification")
            input_data = kwargs.get("input_data", {})
            expected_output = kwargs.get("expected_output", {})
            tags = kwargs.get("tags", [])

            test_id = f"GOLD-{category[:4].upper()}-{datetime.now().strftime('%Y%m%d%H%M%S')}"

            test_case = GoldenTestCase(
                test_id=test_id,
                category=category,
                input_data=input_data,
                expected_output=expected_output,
                created_at=datetime.now(timezone.utc).isoformat(),
                tags=tags
            )

            filepath = GOLDEN_SET_DIR / f"{test_id}.json"
            with open(filepath, "w") as f:
                json.dump(asdict(test_case), f, indent=2)

            return {"action": "add", "test_id": test_id, "saved_to": str(filepath)}

        elif action == "run":
            # Run golden set tests (placeholder - would need actual test runners)
            results = {
                "action": "run",
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "tests_run": 0,
                "passed": 0,
                "failed": 0,
                "details": []
            }

            for file in GOLDEN_SET_DIR.glob("*.json"):
                with open(file) as f:
                    test = json.load(f)

                results["tests_run"] += 1
                # Placeholder - actual test execution would go here
                results["passed"] += 1
                results["details"].append({
                    "test_id": test.get("test_id"),
                    "status": "passed",
                    "note": "Test execution not implemented - placeholder pass"
                })

            return results

        elif action == "export":
            # Export golden set for offline use
            export_data = []
            for file in GOLDEN_SET_DIR.glob("*.json"):
                with open(file) as f:
                    export_data.append(json.load(f))

            export_path = AUDIT_DIR / f"golden_set_export_{datetime.now().strftime('%Y%m%d')}.json"
            with open(export_path, "w") as f:
                json.dump(export_data, f, indent=2)

            return {"action": "export", "count": len(export_data), "exported_to": str(export_path)}

        return {"error": f"Unknown action: {action}"}


def main():
    parser = argparse.ArgumentParser(description="Quality Audit System")
    subparsers = parser.add_subparsers(dest="command", help="Commands")

    # classification-audit
    class_parser = subparsers.add_parser("classification-audit", help="Audit classification accuracy")

    # data-consistency
    consistency_parser = subparsers.add_parser("data-consistency", help="Audit data consistency")

    # agent-audit
    agent_parser = subparsers.add_parser("agent-audit", help="Audit agent outputs")
    agent_parser.add_argument("--agent", help="Specific agent to audit")
    agent_parser.add_argument("--days", type=int, default=30, help="Days to analyze")

    # monthly-report
    monthly_parser = subparsers.add_parser("monthly-report", help="Generate monthly quality report")

    # golden-set
    golden_parser = subparsers.add_parser("golden-set", help="Manage golden test datasets")
    golden_parser.add_argument("--action", choices=["list", "add", "run", "export"], default="list")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return

    auditor = QualityAuditor()

    if args.command == "classification-audit":
        audit = auditor.audit_classification_accuracy()
        filepath = auditor._save_audit(audit)
        print(f"\n{'='*60}")
        print("CLASSIFICATION ACCURACY AUDIT")
        print(f"{'='*60}")
        print(f"Items Checked: {audit.items_checked}")
        print(f"Issues Found: {audit.issues_found}")
        print(f"\nMetrics:")
        for key, value in audit.metrics.items():
            print(f"  {key}: {value}")
        if audit.issues:
            print(f"\nTop Issues:")
            for issue in audit.issues[:5]:
                print(f"  [{issue.severity}] {issue.description}")
        print(f"\nSaved to: {filepath}")

    elif args.command == "data-consistency":
        audit = auditor.audit_data_consistency()
        filepath = auditor._save_audit(audit)
        print(f"\n{'='*60}")
        print("DATA CONSISTENCY AUDIT")
        print(f"{'='*60}")
        print(f"Deals Checked: {audit.items_checked}")
        print(f"Issues Found: {audit.issues_found}")
        print(f"\nIssues by Severity:")
        for sev, count in audit.metrics.get("issues_by_severity", {}).items():
            print(f"  {sev}: {count}")
        if audit.issues:
            print(f"\nTop Issues:")
            for issue in audit.issues[:10]:
                print(f"  [{issue.severity}] {issue.deal_id}: {issue.description}")
        print(f"\nSaved to: {filepath}")

    elif args.command == "agent-audit":
        audit = auditor.audit_agent_outputs(agent_name=args.agent, days=args.days)
        filepath = auditor._save_audit(audit)
        print(f"\n{'='*60}")
        print(f"AGENT OUTPUT AUDIT ({args.agent or 'all agents'})")
        print(f"{'='*60}")
        print(f"Operations Checked: {audit.items_checked}")
        print(f"Issues Found: {audit.issues_found}")
        print(f"\nAgent Statistics:")
        for agent, stats in audit.metrics.get("agent_stats", {}).items():
            print(f"  {agent}:")
            print(f"    Total: {stats['total']}, Success: {stats['success']}, Failed: {stats['failed']}")
            if "success_rate" in stats:
                print(f"    Success Rate: {stats['success_rate']*100:.1f}%")
        print(f"\nSaved to: {filepath}")

    elif args.command == "monthly-report":
        report = auditor.generate_monthly_report()
        print(f"\n{'='*60}")
        print("MONTHLY QUALITY REPORT")
        print(f"{'='*60}")
        print(f"Period: {report['period']['start'][:10]} to {report['period']['end'][:10]}")
        print(f"\nSummary:")
        for key, value in report["summary"].items():
            print(f"  {key}: {value}")
        if report.get("recommendations"):
            print(f"\nRecommendations:")
            for rec in report["recommendations"]:
                print(f"  [{rec['priority']}] {rec['action']}")
        print(f"\nSaved to: {report.get('saved_to')}")

    elif args.command == "golden-set":
        result = auditor.manage_golden_set(args.action)
        print(f"\n{'='*60}")
        print(f"GOLDEN SET: {args.action.upper()}")
        print(f"{'='*60}")
        print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
