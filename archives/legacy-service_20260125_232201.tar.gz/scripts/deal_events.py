#!/usr/bin/env python3
"""
Deal Event Sourcing Module

Append-only event log for deal lifecycle tracking.
Every deal mutation is recorded as an immutable event enabling:
- Full audit trail (compliance)
- State replay at any point in time
- Cross-deal analytics
- Integration with run ledger

Design:
- One JSONL file per deal: events/DEAL-2025-001.jsonl
- Events are immutable and append-only
- State is derived by replaying events
"""

from __future__ import annotations

import fcntl
import hashlib
import json
import os
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence


# Event type constants
EVENT_TYPES = {
    # Lifecycle events
    "deal_created": "Deal was created in registry",
    "stage_changed": "Deal stage was updated",
    "status_changed": "Deal status changed (active/junk/merged/archived)",

    # Document events
    "document_attached": "Document was attached to deal",
    "document_classified": "Document classification completed",
    "cim_received": "CIM/Teaser received",
    "nda_status_changed": "NDA status updated",

    # Communication events
    "email_received": "Email received and linked to deal",
    "email_sent": "Email sent regarding deal",
    "meeting_scheduled": "Meeting/call scheduled",
    "note_added": "Manual note added by operator",

    # Financial events
    "valuation_updated": "Financial metrics updated",
    "offer_submitted": "LOI/Offer submitted",
    "offer_received": "Counter-offer received",

    # Administrative events
    "alias_added": "New alias registered for deal",
    "folder_merged": "Deal folders merged",
    "broker_assigned": "Broker information updated",
    "priority_changed": "Deal priority changed",

    # AI events
    "ai_recommendation": "AI provided recommendation",
    "ai_analysis_completed": "AI analysis task completed",
}


@dataclass
class DealEvent:
    """Immutable event record"""
    event_id: str
    deal_id: str
    event_type: str
    timestamp: str
    actor: str  # user/system/ai-agent
    data: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "DealEvent":
        return cls(
            event_id=d.get("event_id", ""),
            deal_id=d.get("deal_id", ""),
            event_type=d.get("event_type", ""),
            timestamp=d.get("timestamp", ""),
            actor=d.get("actor", "system"),
            data=d.get("data") or {},
            metadata=d.get("metadata") or {},
        )


def _gen_event_id() -> str:
    """Generate unique event ID"""
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")
    nonce = hashlib.sha256(f"{ts}:{os.getpid()}:{uuid.uuid4()}".encode()).hexdigest()[:12]
    return f"EVT-{ts}-{nonce}"


def _now_iso() -> str:
    """Current UTC timestamp in ISO format"""
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


class DealEventStore:
    """
    Append-only event store for deal events.

    Events are stored in per-deal JSONL files for efficient retrieval
    and to support per-deal event replay.
    """

    def __init__(self, events_dir: Optional[str] = None):
        self.events_dir = Path(
            events_dir or
            os.getenv("DEAL_EVENTS_DIR", "/home/zaks/DataRoom/.deal-registry/events")
        )
        self.events_dir.mkdir(parents=True, exist_ok=True)

    def _event_file(self, deal_id: str) -> Path:
        """Get path to deal's event file"""
        safe_id = deal_id.replace("/", "_").replace("\\", "_")
        return self.events_dir / f"{safe_id}.jsonl"

    def append(self, event: DealEvent) -> None:
        """
        Append an event to the deal's event log.

        Thread-safe via file locking.
        """
        event_file = self._event_file(event.deal_id)
        line = json.dumps(event.to_dict(), ensure_ascii=False, default=str) + "\n"

        with open(event_file, "a", encoding="utf-8") as f:
            if fcntl:
                try:
                    fcntl.flock(f.fileno(), fcntl.LOCK_EX)
                except Exception:
                    pass
            f.write(line)

    def create_event(
        self,
        deal_id: str,
        event_type: str,
        actor: str = "system",
        data: Optional[Dict[str, Any]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> DealEvent:
        """Create and append a new event"""
        event = DealEvent(
            event_id=_gen_event_id(),
            deal_id=deal_id,
            event_type=event_type,
            timestamp=_now_iso(),
            actor=actor,
            data=data or {},
            metadata=metadata or {},
        )
        self.append(event)
        return event

    def get_events(
        self,
        deal_id: str,
        event_types: Optional[Sequence[str]] = None,
        since: Optional[str] = None,
        until: Optional[str] = None,
        limit: int = 1000,
    ) -> List[DealEvent]:
        """
        Retrieve events for a deal.

        Args:
            deal_id: Deal identifier
            event_types: Filter by event types (optional)
            since: ISO timestamp to filter events after (inclusive)
            until: ISO timestamp to filter events before (inclusive)
            limit: Maximum number of events to return
        """
        event_file = self._event_file(deal_id)
        if not event_file.exists():
            return []

        events: List[DealEvent] = []
        event_types_set = set(event_types) if event_types else None

        with open(event_file, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    d = json.loads(line)
                    event = DealEvent.from_dict(d)

                    # Apply filters
                    if event_types_set and event.event_type not in event_types_set:
                        continue
                    if since and event.timestamp < since:
                        continue
                    if until and event.timestamp > until:
                        continue

                    events.append(event)
                    if len(events) >= limit:
                        break
                except json.JSONDecodeError:
                    continue

        return events

    def get_latest_event(
        self,
        deal_id: str,
        event_type: Optional[str] = None,
    ) -> Optional[DealEvent]:
        """Get the most recent event for a deal"""
        events = self.get_events(deal_id, event_types=[event_type] if event_type else None)
        return events[-1] if events else None

    def get_state_at(
        self,
        deal_id: str,
        timestamp: str,
    ) -> Dict[str, Any]:
        """
        Replay events to reconstruct state at a specific point in time.

        Returns derived state dictionary.
        """
        events = self.get_events(deal_id, until=timestamp)
        return self._replay_events(events)

    def get_current_state(self, deal_id: str) -> Dict[str, Any]:
        """Get current derived state by replaying all events"""
        events = self.get_events(deal_id)
        return self._replay_events(events)

    def _replay_events(self, events: List[DealEvent]) -> Dict[str, Any]:
        """
        Replay events to derive current state.

        State schema:
        {
            "deal_id": str,
            "stage": str,
            "status": str,
            "documents": List[Dict],
            "emails": List[Dict],
            "notes": List[Dict],
            "last_activity": str,
            "created_at": str,
            "event_count": int,
        }
        """
        if not events:
            return {}

        state: Dict[str, Any] = {
            "deal_id": events[0].deal_id if events else "",
            "stage": "inbound",
            "status": "active",
            "documents": [],
            "emails": [],
            "notes": [],
            "aliases": [],
            "ai_recommendations": [],
            "last_activity": "",
            "created_at": "",
            "event_count": 0,
        }

        for event in events:
            state["event_count"] += 1
            state["last_activity"] = event.timestamp

            if event.event_type == "deal_created":
                state["created_at"] = event.timestamp
                state["stage"] = event.data.get("stage", "inbound")
                state["status"] = event.data.get("status", "active")

            elif event.event_type == "stage_changed":
                state["stage"] = event.data.get("new_stage", state["stage"])

            elif event.event_type == "status_changed":
                state["status"] = event.data.get("new_status", state["status"])

            elif event.event_type == "document_attached":
                state["documents"].append({
                    "path": event.data.get("path"),
                    "type": event.data.get("doc_type"),
                    "attached_at": event.timestamp,
                })

            elif event.event_type == "email_received":
                state["emails"].append({
                    "message_id": event.data.get("message_id"),
                    "subject": event.data.get("subject"),
                    "received_at": event.timestamp,
                })

            elif event.event_type == "note_added":
                state["notes"].append({
                    "content": event.data.get("content"),
                    "added_by": event.actor,
                    "added_at": event.timestamp,
                })

            elif event.event_type == "alias_added":
                state["aliases"].append({
                    "alias": event.data.get("alias"),
                    "type": event.data.get("alias_type"),
                })

            elif event.event_type == "ai_recommendation":
                state["ai_recommendations"].append({
                    "recommendation": event.data.get("recommendation"),
                    "confidence": event.data.get("confidence"),
                    "model": event.data.get("model"),
                    "timestamp": event.timestamp,
                })

        return state

    def list_deals_with_events(self) -> List[str]:
        """List all deal IDs that have event files"""
        deals = []
        for f in self.events_dir.glob("*.jsonl"):
            deal_id = f.stem
            deals.append(deal_id)
        return sorted(deals)

    def count_events(self, deal_id: str) -> int:
        """Count events for a deal"""
        event_file = self._event_file(deal_id)
        if not event_file.exists():
            return 0

        count = 0
        with open(event_file, "r", encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    count += 1
        return count


# Convenience functions for common events
def emit_deal_created(
    store: DealEventStore,
    deal_id: str,
    canonical_name: str,
    stage: str = "inbound",
    status: str = "active",
    actor: str = "system",
    **extra_data,
) -> DealEvent:
    """Emit deal_created event"""
    return store.create_event(
        deal_id=deal_id,
        event_type="deal_created",
        actor=actor,
        data={
            "canonical_name": canonical_name,
            "stage": stage,
            "status": status,
            **extra_data,
        },
    )


def emit_stage_changed(
    store: DealEventStore,
    deal_id: str,
    old_stage: str,
    new_stage: str,
    actor: str = "system",
    reason: str = "",
) -> DealEvent:
    """Emit stage_changed event"""
    return store.create_event(
        deal_id=deal_id,
        event_type="stage_changed",
        actor=actor,
        data={
            "old_stage": old_stage,
            "new_stage": new_stage,
            "reason": reason,
        },
    )


def emit_document_attached(
    store: DealEventStore,
    deal_id: str,
    path: str,
    doc_type: str,
    actor: str = "system",
    **extra_data,
) -> DealEvent:
    """Emit document_attached event"""
    return store.create_event(
        deal_id=deal_id,
        event_type="document_attached",
        actor=actor,
        data={
            "path": path,
            "doc_type": doc_type,
            **extra_data,
        },
    )


def emit_email_received(
    store: DealEventStore,
    deal_id: str,
    message_id: str,
    subject: str,
    sender: str,
    actor: str = "email_sync",
    **extra_data,
) -> DealEvent:
    """Emit email_received event"""
    return store.create_event(
        deal_id=deal_id,
        event_type="email_received",
        actor=actor,
        data={
            "message_id": message_id,
            "subject": subject,
            "sender": sender,
            **extra_data,
        },
    )


def emit_ai_recommendation(
    store: DealEventStore,
    deal_id: str,
    recommendation: str,
    confidence: float,
    model: str,
    context: str = "",
    actor: str = "ai-advisor",
) -> DealEvent:
    """Emit ai_recommendation event"""
    return store.create_event(
        deal_id=deal_id,
        event_type="ai_recommendation",
        actor=actor,
        data={
            "recommendation": recommendation,
            "confidence": confidence,
            "model": model,
            "context": context,
        },
    )


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Deal Event Store CLI")
    parser.add_argument("command", choices=["list", "events", "state", "count"])
    parser.add_argument("--deal-id", help="Deal ID for events/state commands")
    parser.add_argument("--since", help="Filter events since timestamp")
    parser.add_argument("--limit", type=int, default=100, help="Max events to return")
    args = parser.parse_args()

    store = DealEventStore()

    if args.command == "list":
        deals = store.list_deals_with_events()
        print(f"Deals with events: {len(deals)}")
        for d in deals:
            count = store.count_events(d)
            print(f"  {d}: {count} events")

    elif args.command == "events":
        if not args.deal_id:
            print("Error: --deal-id required")
            raise SystemExit(1)
        events = store.get_events(args.deal_id, since=args.since, limit=args.limit)
        print(f"Events for {args.deal_id}: {len(events)}")
        for e in events:
            print(f"  [{e.timestamp}] {e.event_type} by {e.actor}")

    elif args.command == "state":
        if not args.deal_id:
            print("Error: --deal-id required")
            raise SystemExit(1)
        state = store.get_current_state(args.deal_id)
        print(json.dumps(state, indent=2, default=str))

    elif args.command == "count":
        if args.deal_id:
            count = store.count_events(args.deal_id)
            print(f"{args.deal_id}: {count} events")
        else:
            deals = store.list_deals_with_events()
            total = sum(store.count_events(d) for d in deals)
            print(f"Total: {total} events across {len(deals)} deals")
