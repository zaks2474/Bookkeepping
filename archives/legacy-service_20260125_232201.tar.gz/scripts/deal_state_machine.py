#!/usr/bin/env python3
"""
Deal Lifecycle State Machine

Enforces valid stage transitions for deals, preventing invalid states
and requiring approvals for critical transitions.

Stages (full M&A lifecycle):
- INBOUND: Initial contact, unqualified lead
- SCREENING: Initial evaluation, basic fit check
- QUALIFIED: Passed screening, worth pursuing
- LOI: Letter of Intent stage (requires approval)
- DILIGENCE: Due diligence in progress
- CLOSING: Transaction closing (requires approval)
- INTEGRATION: Post-close integration
- OPERATIONS: Ongoing operations
- GROWTH: Value creation phase
- EXIT_PLANNING: Planning exit strategy (requires approval)
- CLOSED_WON: Deal completed successfully
- CLOSED_LOST: Deal rejected/abandoned
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
from typing import Dict, Optional, Set, Tuple


class DealStage(str, Enum):
    """Valid deal lifecycle stages"""
    INBOUND = "inbound"
    SCREENING = "screening"
    QUALIFIED = "qualified"
    LOI = "loi"
    DILIGENCE = "diligence"
    CLOSING = "closing"
    INTEGRATION = "integration"
    OPERATIONS = "operations"
    GROWTH = "growth"
    EXIT_PLANNING = "exit_planning"
    CLOSED_WON = "closed_won"
    CLOSED_LOST = "closed_lost"

    @classmethod
    def from_str(cls, s: str) -> "DealStage":
        """Convert string to DealStage, with fallback to INBOUND"""
        s_lower = s.lower().strip()
        for stage in cls:
            if stage.value == s_lower:
                return stage
        # Legacy mappings
        legacy_map = {
            "archive": cls.CLOSED_LOST,
            "archived": cls.CLOSED_LOST,
            "rejected": cls.CLOSED_LOST,
            "junk": cls.CLOSED_LOST,
            "active": cls.INBOUND,
            "new": cls.INBOUND,
        }
        return legacy_map.get(s_lower, cls.INBOUND)


# Valid transitions: from_stage -> set of allowed to_stages
TRANSITIONS: Dict[DealStage, Set[DealStage]] = {
    DealStage.INBOUND: {
        DealStage.SCREENING,
        DealStage.CLOSED_LOST,  # Quick reject
    },
    DealStage.SCREENING: {
        DealStage.QUALIFIED,
        DealStage.INBOUND,  # Back to inbox for more info
        DealStage.CLOSED_LOST,
    },
    DealStage.QUALIFIED: {
        DealStage.LOI,
        DealStage.SCREENING,  # Back to screening
        DealStage.CLOSED_LOST,
    },
    DealStage.LOI: {
        DealStage.DILIGENCE,
        DealStage.QUALIFIED,  # LOI rejected, back to qualified
        DealStage.CLOSED_LOST,
    },
    DealStage.DILIGENCE: {
        DealStage.CLOSING,
        DealStage.LOI,  # Issues found, renegotiate LOI
        DealStage.CLOSED_LOST,
    },
    DealStage.CLOSING: {
        DealStage.INTEGRATION,  # Closed successfully
        DealStage.CLOSED_WON,  # For deals that don't need integration
        DealStage.DILIGENCE,  # Back to DD
        DealStage.CLOSED_LOST,
    },
    DealStage.INTEGRATION: {
        DealStage.OPERATIONS,
        DealStage.CLOSED_WON,
    },
    DealStage.OPERATIONS: {
        DealStage.GROWTH,
        DealStage.EXIT_PLANNING,
        DealStage.CLOSED_WON,
    },
    DealStage.GROWTH: {
        DealStage.EXIT_PLANNING,
        DealStage.OPERATIONS,  # Back to steady state
        DealStage.CLOSED_WON,
    },
    DealStage.EXIT_PLANNING: {
        DealStage.CLOSED_WON,  # Exit complete
        DealStage.GROWTH,  # Continue growth instead
    },
    # Terminal states - no transitions out
    DealStage.CLOSED_WON: set(),
    DealStage.CLOSED_LOST: set(),
}

# Stages requiring explicit approval before transition
APPROVAL_REQUIRED: Set[DealStage] = {
    DealStage.LOI,
    DealStage.CLOSING,
    DealStage.EXIT_PLANNING,
    DealStage.CLOSED_WON,
}

# Stages where AI advisory is particularly valuable
AI_ADVISORY_STAGES: Dict[DealStage, str] = {
    DealStage.INBOUND: "Initial assessment, broker reputation, sector fit",
    DealStage.SCREENING: "Financial quick-look, red flags, comparable analysis",
    DealStage.QUALIFIED: "Valuation sanity check, deal structure suggestions",
    DealStage.LOI: "LOI terms review, negotiation points",
    DealStage.DILIGENCE: "DD checklist, risk identification, expert suggestions",
    DealStage.CLOSING: "Final checklist, integration planning",
    DealStage.INTEGRATION: "Integration playbook, milestone tracking",
    DealStage.OPERATIONS: "KPI monitoring, improvement suggestions",
    DealStage.GROWTH: "Growth opportunities, market analysis",
    DealStage.EXIT_PLANNING: "Valuation optimization, timing analysis",
}


@dataclass
class TransitionResult:
    """Result of a transition attempt"""
    success: bool
    message: str
    from_stage: DealStage
    to_stage: DealStage
    approval_required: bool = False
    approved: bool = False
    timestamp: str = ""

    def to_dict(self) -> dict:
        return {
            "success": self.success,
            "message": self.message,
            "from_stage": self.from_stage.value,
            "to_stage": self.to_stage.value,
            "approval_required": self.approval_required,
            "approved": self.approved,
            "timestamp": self.timestamp,
        }


class DealStateMachine:
    """
    State machine for deal lifecycle management.

    Usage:
        sm = DealStateMachine(current_stage="screening")
        can = sm.can_transition_to(DealStage.QUALIFIED)  # True
        result = sm.transition(DealStage.LOI, approved=True)  # LOI needs approval
    """

    def __init__(
        self,
        current_stage: str | DealStage = DealStage.INBOUND,
        deal_id: str = "",
    ):
        if isinstance(current_stage, str):
            self.current_stage = DealStage.from_str(current_stage)
        else:
            self.current_stage = current_stage
        self.deal_id = deal_id
        self.transition_history: list[TransitionResult] = []

        # Load config from environment
        self._load_config()

    def _load_config(self) -> None:
        """Load configuration from environment"""
        self.enabled = os.getenv("DEAL_STATE_MACHINE_ENABLED", "true").lower() in {"true", "1", "yes"}

        # Parse approval required stages from env (comma-separated)
        approval_stages_str = os.getenv("DEAL_APPROVAL_REQUIRED_STAGES", "")
        if approval_stages_str.strip():
            self.approval_stages = {
                DealStage.from_str(s.strip())
                for s in approval_stages_str.split(",")
                if s.strip()
            }
        else:
            self.approval_stages = APPROVAL_REQUIRED

    def can_transition_to(self, target: DealStage) -> bool:
        """Check if transition to target stage is valid"""
        if not self.enabled:
            return True  # Bypass when disabled
        allowed = TRANSITIONS.get(self.current_stage, set())
        return target in allowed

    def get_allowed_transitions(self) -> Set[DealStage]:
        """Get set of stages we can transition to from current stage"""
        return TRANSITIONS.get(self.current_stage, set()).copy()

    def requires_approval(self, target: DealStage) -> bool:
        """Check if transitioning to target requires approval"""
        return target in self.approval_stages

    def get_advisory_context(self) -> str:
        """Get AI advisory context for current stage"""
        return AI_ADVISORY_STAGES.get(self.current_stage, "")

    def is_terminal(self) -> bool:
        """Check if current stage is terminal (no transitions out)"""
        return len(self.get_allowed_transitions()) == 0

    def transition(
        self,
        target: DealStage,
        approved: bool = False,
        force: bool = False,
    ) -> TransitionResult:
        """
        Attempt to transition to a new stage.

        Args:
            target: Target stage
            approved: Whether transition has been approved (for stages requiring approval)
            force: Bypass validation (use with caution)

        Returns:
            TransitionResult with success status and message
        """
        timestamp = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        approval_required = self.requires_approval(target)

        # Validation
        if not force and not self.can_transition_to(target):
            result = TransitionResult(
                success=False,
                message=f"Invalid transition: {self.current_stage.value} -> {target.value}",
                from_stage=self.current_stage,
                to_stage=target,
                approval_required=approval_required,
                approved=approved,
                timestamp=timestamp,
            )
            self.transition_history.append(result)
            return result

        if approval_required and not approved and not force:
            result = TransitionResult(
                success=False,
                message=f"Transition to {target.value} requires approval",
                from_stage=self.current_stage,
                to_stage=target,
                approval_required=True,
                approved=False,
                timestamp=timestamp,
            )
            self.transition_history.append(result)
            return result

        # Execute transition
        old_stage = self.current_stage
        self.current_stage = target

        result = TransitionResult(
            success=True,
            message=f"Transitioned from {old_stage.value} to {target.value}",
            from_stage=old_stage,
            to_stage=target,
            approval_required=approval_required,
            approved=approved,
            timestamp=timestamp,
        )
        self.transition_history.append(result)
        return result

    def get_stage_info(self) -> dict:
        """Get information about current stage"""
        return {
            "current_stage": self.current_stage.value,
            "allowed_transitions": [s.value for s in self.get_allowed_transitions()],
            "is_terminal": self.is_terminal(),
            "advisory_context": self.get_advisory_context(),
            "deal_id": self.deal_id,
        }


def validate_stage_sequence(stages: list[str]) -> Tuple[bool, str]:
    """
    Validate a sequence of stage transitions.

    Returns (is_valid, error_message)
    """
    if not stages:
        return True, ""

    sm = DealStateMachine(stages[0])

    for i, next_stage_str in enumerate(stages[1:], start=1):
        next_stage = DealStage.from_str(next_stage_str)
        if not sm.can_transition_to(next_stage):
            return False, f"Invalid transition at step {i}: {sm.current_stage.value} -> {next_stage.value}"
        sm.transition(next_stage, approved=True, force=True)

    return True, ""


def get_path_to_stage(
    from_stage: str | DealStage,
    to_stage: str | DealStage,
) -> Optional[list[DealStage]]:
    """
    Find shortest valid path between two stages using BFS.

    Returns list of stages (excluding from_stage) or None if no path exists.
    """
    if isinstance(from_stage, str):
        from_stage = DealStage.from_str(from_stage)
    if isinstance(to_stage, str):
        to_stage = DealStage.from_str(to_stage)

    if from_stage == to_stage:
        return []

    from collections import deque

    visited: Set[DealStage] = {from_stage}
    queue: deque[Tuple[DealStage, list[DealStage]]] = deque([(from_stage, [])])

    while queue:
        current, path = queue.popleft()

        for next_stage in TRANSITIONS.get(current, set()):
            if next_stage == to_stage:
                return path + [next_stage]

            if next_stage not in visited:
                visited.add(next_stage)
                queue.append((next_stage, path + [next_stage]))

    return None  # No valid path


if __name__ == "__main__":
    import argparse
    import json

    parser = argparse.ArgumentParser(description="Deal State Machine CLI")
    parser.add_argument("command", choices=["info", "can-transition", "path", "stages"])
    parser.add_argument("--from-stage", default="inbound", help="Current stage")
    parser.add_argument("--to-stage", help="Target stage")
    args = parser.parse_args()

    if args.command == "stages":
        print("Available stages:")
        for stage in DealStage:
            advisory = AI_ADVISORY_STAGES.get(stage, "")
            approval = "* (requires approval)" if stage in APPROVAL_REQUIRED else ""
            print(f"  {stage.value}{approval}")
            if advisory:
                print(f"    AI: {advisory}")

    elif args.command == "info":
        sm = DealStateMachine(args.from_stage)
        print(json.dumps(sm.get_stage_info(), indent=2))

    elif args.command == "can-transition":
        if not args.to_stage:
            print("Error: --to-stage required")
            raise SystemExit(1)
        sm = DealStateMachine(args.from_stage)
        target = DealStage.from_str(args.to_stage)
        can = sm.can_transition_to(target)
        needs_approval = sm.requires_approval(target)
        print(f"Can transition {args.from_stage} -> {args.to_stage}: {can}")
        if needs_approval:
            print(f"Note: Transition to {args.to_stage} requires approval")

    elif args.command == "path":
        if not args.to_stage:
            print("Error: --to-stage required")
            raise SystemExit(1)
        path = get_path_to_stage(args.from_stage, args.to_stage)
        if path is None:
            print(f"No valid path from {args.from_stage} to {args.to_stage}")
        else:
            stages = [args.from_stage] + [s.value for s in path]
            print(f"Path: {' -> '.join(stages)}")
