#!/usr/bin/env python3
"""
Export OpenWebUI chats to Markdown and JSON

Reads webui.db and exports chats to:
  DataRoom/06-KNOWLEDGE-BASE/AI-Sessions/OpenWebUI/YYYY-MM-DD/

Each chat exported as:
  - chat-title.md (human-readable Markdown)
  - chat-title.json (structured data for analysis)
"""

import os
import sys
import json
import sqlite3
import glob
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Optional
import re

# Configuration
WEBUI_DB = os.getenv("OPENWEBUI_DB", "")  # If empty, auto-detect
OUTPUT_BASE = "/home/zaks/DataRoom/06-KNOWLEDGE-BASE/AI-Sessions/OpenWebUI"
EXPORT_DATE = datetime.now().strftime("%Y-%m-%d")
REDACT_SECRETS = os.getenv("OPENWEBUI_EXPORT_REDACT", "1") not in {"0", "false", "False", "no", "NO"}
DB_GLOBS = [
    "/home/zaks/backups/openwebui/**/*.db",
    "/home/zaks/backups/openwebui/webui_latest.db",
    # Common Docker volume names (no glob needed; works without listing permissions)
    "/var/lib/docker/volumes/zaks-llm_open-webui/_data/webui.db",
    "/var/lib/docker/volumes/open-webui/_data/webui.db",
    "/var/lib/docker/volumes/zaks_open-webui/_data/webui.db",
    "/var/lib/docker/volumes/*open-webui*/_data/webui.db",
    "/var/lib/docker/volumes/*openwebui*/_data/webui.db",
    "/opt/open-webui/data/webui.db",
    "/opt/open-webui/webui.db",
]

# Common secret patterns (best-effort redaction for safer SharePoint/Git/RAG handling).
_REDACTIONS: list[tuple[re.Pattern[str], str]] = [
    # OpenAI-style keys (sk-..., sk-proj-...)
    (re.compile(r"\bsk-[A-Za-z0-9]{20,}\b"), "sk-REDACTED"),
    (re.compile(r"\bsk-proj-[A-Za-z0-9_-]{20,}\b"), "sk-proj-REDACTED"),
    # Google API key
    (re.compile(r"\bAIza[0-9A-Za-z\-_]{20,}\b"), "AIza-REDACTED"),
    # Bearer tokens
    (re.compile(r"\bBearer\s+[A-Za-z0-9\-._~+/]+=*\b"), "Bearer REDACTED"),
]


def _redact_text(text: str) -> str:
    if not REDACT_SECRETS:
        return text
    redacted = text
    for pattern, replacement in _REDACTIONS:
        redacted = pattern.sub(replacement, redacted)
    return redacted


def _redact_messages(messages):
    if not REDACT_SECRETS:
        return messages
    if isinstance(messages, list):
        redacted_list = []
        for msg in messages:
            redacted_list.append(_redact_messages(msg))
        return redacted_list
    if isinstance(messages, dict):
        redacted_dict = {}
        for key, value in messages.items():
            if isinstance(value, str):
                redacted_dict[key] = _redact_text(value)
            else:
                redacted_dict[key] = _redact_messages(value)
        return redacted_dict
    return messages


class OpenWebUIExporter:
    def __init__(self):
        self.db_path = WEBUI_DB
        self.output_dir = Path(OUTPUT_BASE) / EXPORT_DATE
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.conn = None

    def connect(self):
        """Connect to OpenWebUI database."""
        if not self.db_path or not Path(self.db_path).exists():
            candidates = []
            for pattern in DB_GLOBS:
                candidates.extend(glob.glob(pattern, recursive=True))

            candidates = [c for c in candidates if Path(c).is_file()]
            if not candidates:
                raise FileNotFoundError(
                    "OpenWebUI database not found. Set OPENWEBUI_DB or place backups under /home/zaks/backups/openwebui/."
                )

            # Prefer an explicit "latest" symlink/copy if present, otherwise use most recently modified DB.
            preferred = Path("/home/zaks/backups/openwebui/webui_latest.db")
            if preferred.is_file():
                self.db_path = str(preferred)
            else:
                self.db_path = max(candidates, key=os.path.getmtime)
            print(f"ℹ Using detected database: {self.db_path}")

        # Read-only connection for safety (works for SQLite file paths).
        self.conn = sqlite3.connect(f"file:{self.db_path}?mode=ro", uri=True)
        self.conn.row_factory = sqlite3.Row
        print(f"✓ Connected to {self.db_path}")

    def get_chats(self) -> List[Dict]:
        """Get all chats from database."""
        cursor = self.conn.cursor()

        # Try different schema patterns
        try:
            # OpenWebUI schema with 'chat' column containing JSON
            query = """
                SELECT id, title, created_at, updated_at, user_id, chat
                FROM chat
                ORDER BY updated_at DESC
            """
            cursor.execute(query)
        except sqlite3.OperationalError:
            # Alternative schema
            try:
                query = """
                    SELECT id, title, created_at, updated_at, user_id, messages
                    FROM conversations
                    ORDER BY updated_at DESC
                """
                cursor.execute(query)
            except sqlite3.OperationalError as e:
                print(f"Could not find chat table: {e}")
                # List tables for debugging
                cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
                tables = cursor.fetchall()
                print(f"Available tables: {[t[0] for t in tables]}")
                return []

        chats = []

        for row in cursor.fetchall():
            try:
                # Get column names
                cols = [description[0] for description in cursor.description]
                row_dict = dict(zip(cols, row))

                chat_data = {
                    "id": row_dict.get("id", "unknown"),
                    "title": row_dict.get("title", "Untitled Chat"),
                    "created_at": row_dict.get("created_at", ""),
                    "updated_at": row_dict.get("updated_at", ""),
                    "user_id": row_dict.get("user_id", ""),
                    "messages": []
                }

                # Parse messages from chat/messages column
                chat_content = row_dict.get("chat") or row_dict.get("messages")
                if chat_content:
                    try:
                        if isinstance(chat_content, str):
                            parsed = json.loads(chat_content)
                        else:
                            parsed = chat_content

                        # Handle different message formats
                        if isinstance(parsed, dict) and "messages" in parsed:
                            chat_data["messages"] = parsed["messages"]
                        elif isinstance(parsed, list):
                            chat_data["messages"] = parsed
                        else:
                            chat_data["messages"] = [parsed]
                    except json.JSONDecodeError:
                        chat_data["messages"] = []

                chats.append(chat_data)
            except Exception as e:
                print(f"⚠ Error parsing chat row: {e}")
                continue

        print(f"✓ Found {len(chats)} chats")
        return chats

    def sanitize_filename(self, title: str) -> str:
        """Convert chat title to safe filename."""
        # Remove special characters
        safe = re.sub(r'[^\w\s-]', '', title)
        # Replace spaces with hyphens
        safe = re.sub(r'\s+', '-', safe)
        # Lowercase and trim
        safe = safe.lower().strip('-')
        # Limit length
        safe = safe[:100]
        return safe or "untitled"

    def export_chat_markdown(self, chat: Dict) -> str:
        """Export chat as Markdown."""
        md = []

        # Header
        md.append(f"# {_redact_text(chat['title'])}\n")
        md.append(f"**Chat ID:** {chat['id']}  ")
        md.append(f"**Created:** {chat['created_at']}  ")
        md.append(f"**Updated:** {chat['updated_at']}  ")
        md.append(f"\n---\n")

        # Messages
        for msg in chat.get("messages", []):
            if isinstance(msg, dict):
                role = msg.get("role", "unknown").upper()
                content = _redact_text(msg.get("content", ""))
                timestamp = msg.get("timestamp", "")

                md.append(f"\n## {role}")
                if timestamp:
                    md.append(f"*{timestamp}*\n")
                md.append(f"\n{content}\n")
            else:
                md.append(f"\n{str(msg)}\n")

        # Footer
        md.append(f"\n---\n")
        md.append(f"*Exported: {datetime.now().isoformat()}*\n")

        return "\n".join(md)

    def export_chat_json(self, chat: Dict) -> str:
        """Export chat as JSON."""
        messages = _redact_messages(chat["messages"])
        export_data = {
            "id": chat["id"],
            "title": _redact_text(chat["title"]),
            "created_at": chat["created_at"],
            "updated_at": chat["updated_at"],
            "user_id": chat["user_id"],
            "messages": messages,
            "exported_at": datetime.now().isoformat(),
            "source": "openwebui",
            "source_db": str(self.db_path),
            "redacted": REDACT_SECRETS,
        }
        return json.dumps(export_data, indent=2, default=str)

    def export_all(self):
        """Export all chats."""
        print(f"\n{'='*60}")
        print(f"OpenWebUI Chat Export")
        print(f"Output: {self.output_dir}")
        print(f"{'='*60}\n")

        # Connect
        try:
            self.connect()
        except FileNotFoundError as e:
            print(f"✗ {e}")
            return

        # Get chats
        chats = self.get_chats()

        if not chats:
            print("No chats found to export.")
            return

        # Export each chat
        exported_count = 0
        for chat in chats:
            try:
                # Create filename
                filename = self.sanitize_filename(chat["title"])

                # Handle duplicate filenames
                base_filename = filename
                counter = 1
                while (self.output_dir / f"{filename}.md").exists():
                    filename = f"{base_filename}-{counter}"
                    counter += 1

                # Export Markdown
                md_path = self.output_dir / f"{filename}.md"
                with open(md_path, 'w', encoding='utf-8') as f:
                    f.write(self.export_chat_markdown(chat))

                # Export JSON
                json_path = self.output_dir / f"{filename}.json"
                with open(json_path, 'w', encoding='utf-8') as f:
                    f.write(self.export_chat_json(chat))

                safe_title = _redact_text(chat.get("title", ""))[:50]
                print(f"✓ Exported: {safe_title}...")
                exported_count += 1

            except Exception as e:
                print(f"✗ Error exporting {chat.get('title', 'unknown')}: {str(e)}")

        print(f"\n{'='*60}")
        print(f"Export Complete: {exported_count}/{len(chats)} chats exported")
        print(f"{'='*60}\n")

        # Close connection
        if self.conn:
            self.conn.close()


def main():
    exporter = OpenWebUIExporter()
    exporter.export_all()


if __name__ == "__main__":
    main()
