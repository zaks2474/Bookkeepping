"""
Stage 2: Normalize raw emails into canonical records.

Creates stable identifiers and extracts key signals for matching.
"""

import hashlib
import html
import logging
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, List, Optional, Set, Tuple
from urllib.parse import urlparse

from ..config import get_config, IngestConfig
from ..state.sqlite_store import EmailRecord, get_state_store
from .stage_1_fetch import RawEmail

logger = logging.getLogger(__name__)


@dataclass
class NormalizedEmail:
    """Normalized email ready for matching."""
    # Identity
    message_id: str
    body_hash: str  # SHA256 of normalized body for dedup

    # Headers
    subject: str
    sender: str
    sender_email: str
    sender_domain: str
    received_date: str

    # Content
    body_text: str
    body_html: str

    # Extracted signals
    extracted_links: List[str] = field(default_factory=list)
    extracted_amounts: List[str] = field(default_factory=list)
    matched_keywords: List[str] = field(default_factory=list)
    company_mentions: List[str] = field(default_factory=list)

    # Attachments
    attachments: List[Dict] = field(default_factory=list)
    attachment_count: int = 0

    # Metadata
    raw_size: int = 0
    match_reason: str = ""

    def to_email_record(self, run_id: str) -> EmailRecord:
        """Convert to EmailRecord for SQLite storage."""
        return EmailRecord(
            message_id=self.message_id,
            body_hash=self.body_hash,
            subject=self.subject,
            sender=self.sender,
            sender_email=self.sender_email,
            received_date=self.received_date,
            deal_id=None,
            match_confidence=None,
            quarantine_id=None,
            status="pending",
            stage_completed=2,  # Normalize stage
            run_id=run_id,
            body_text=self.body_text[:50000] if self.body_text else None,  # Limit to 50KB
            body_html=self.body_html[:100000] if self.body_html else None,  # Limit to 100KB
        )


@dataclass
class NormalizeResult:
    """Result of normalize stage."""
    success: bool = True
    normalized: List[NormalizedEmail] = field(default_factory=list)
    skipped_duplicates: int = 0
    error: Optional[str] = None


class NormalizeStage:
    """
    Stage 2: Normalize raw emails.

    Creates canonical records with:
    - Stable body hash for deduplication
    - Extracted sender email/domain
    - Extracted links from body
    - Extracted financial amounts
    - Matched acquisition keywords
    """

    # Regex patterns
    EMAIL_PATTERN = re.compile(r'[\w\.-]+@[\w\.-]+\.\w+')
    URL_PATTERN = re.compile(
        r'https?://[^\s<>"\']+|www\.[^\s<>"\']+'
    )
    AMOUNT_PATTERN = re.compile(
        r'\$[\d,]+(?:\.\d{2})?(?:\s*(?:M|MM|K|B))?\b|'
        r'\b[\d,]+(?:\.\d{2})?\s*(?:USD|EUR|GBP)\b|'
        r'\b(?:ARR|EBITDA|SDE|Revenue)[\s:]*\$?[\d,]+(?:\.\d{2})?(?:\s*(?:M|MM|K|B))?\b',
        re.IGNORECASE
    )

    # HTML tag stripper
    HTML_TAG_PATTERN = re.compile(r'<[^>]+>')

    def __init__(self, config: Optional[IngestConfig] = None, check_duplicates: bool = True):
        self.config = config or get_config()
        self.check_duplicates = check_duplicates
        self._store = None

    @property
    def store(self):
        if self._store is None:
            self._store = get_state_store()
        return self._store

    def run(self, raw_emails: List[RawEmail], run_id: str) -> NormalizeResult:
        """
        Normalize a batch of raw emails.

        Args:
            raw_emails: List of RawEmail from fetch stage
            run_id: Current run ID for tracking

        Returns:
            NormalizeResult with normalized emails
        """
        result = NormalizeResult()

        for raw in raw_emails:
            try:
                normalized = self._normalize_email(raw)

                # Check for duplicates
                if self.check_duplicates:
                    if self.store.is_email_processed(normalized.message_id):
                        logger.debug(f"Skipping duplicate: {normalized.subject[:50]}")
                        result.skipped_duplicates += 1
                        continue

                    # Also check body hash (duplicate content from different message IDs)
                    if self._is_duplicate_body(normalized.body_hash, normalized.sender_email):
                        logger.debug(f"Skipping duplicate body: {normalized.subject[:50]}")
                        result.skipped_duplicates += 1
                        continue

                result.normalized.append(normalized)

            except Exception as e:
                logger.warning(f"Failed to normalize email: {e}")
                result.success = False

        logger.info(
            f"Normalize complete: {len(result.normalized)} normalized, "
            f"{result.skipped_duplicates} duplicates skipped"
        )

        return result

    def _normalize_email(self, raw: RawEmail) -> NormalizedEmail:
        """Normalize a single raw email."""
        # Extract sender info
        sender_email = self._extract_email(raw.sender)
        sender_domain = ""
        if "@" in sender_email:
            sender_domain = sender_email.split("@")[1]

        # Clean body text
        body_text = raw.body_text or ""
        if not body_text and raw.body_html:
            body_text = self._html_to_text(raw.body_html)

        # Compute body hash
        body_hash = self._compute_body_hash(body_text, raw.subject)

        # Extract signals
        links = self._extract_links(body_text, raw.body_html)
        amounts = self._extract_amounts(body_text, raw.subject)
        keywords = self._match_keywords(body_text, raw.subject)

        # Process attachments
        attachments = []
        for att in raw.attachments:
            attachments.append({
                "filename": att.get("filename", ""),
                "content_type": att.get("content_type", ""),
                "size": att.get("size", 0),
                # Don't store data in normalized record - will be saved in persist stage
            })

        return NormalizedEmail(
            message_id=raw.message_id,
            body_hash=body_hash,
            subject=raw.subject,
            sender=raw.sender,
            sender_email=sender_email,
            sender_domain=sender_domain,
            received_date=raw.date,
            body_text=body_text,
            body_html=raw.body_html,
            extracted_links=links,
            extracted_amounts=amounts,
            matched_keywords=keywords,
            attachments=attachments,
            attachment_count=len(attachments),
            raw_size=raw.raw_size,
            match_reason=raw.match_reason,
        )

    def _extract_email(self, sender: str) -> str:
        """Extract email address from sender string."""
        if "<" in sender and ">" in sender:
            start = sender.index("<") + 1
            end = sender.index(">")
            return sender[start:end].lower()

        # Try to find email pattern
        match = self.EMAIL_PATTERN.search(sender)
        if match:
            return match.group(0).lower()

        return sender.lower()

    def _compute_body_hash(self, body_text: str, subject: str) -> str:
        """
        Compute stable hash from email body.

        Uses subject + normalized body to detect duplicates
        even with slight formatting changes.
        """
        # Normalize: lowercase, strip whitespace, remove extra spaces
        normalized = f"{subject.lower()}:{body_text.lower()}"
        normalized = re.sub(r'\s+', ' ', normalized).strip()

        return hashlib.sha256(normalized.encode()).hexdigest()[:32]

    def _html_to_text(self, html_content: str) -> str:
        """Convert HTML to plain text."""
        # Remove script and style
        text = re.sub(r'<script[^>]*>.*?</script>', '', html_content, flags=re.DOTALL)
        text = re.sub(r'<style[^>]*>.*?</style>', '', text, flags=re.DOTALL)

        # Replace br and p with newlines
        text = re.sub(r'<br\s*/?>', '\n', text, flags=re.IGNORECASE)
        text = re.sub(r'</p>', '\n', text, flags=re.IGNORECASE)

        # Strip remaining tags
        text = self.HTML_TAG_PATTERN.sub('', text)

        # Decode entities
        text = html.unescape(text)

        # Normalize whitespace
        text = re.sub(r'\n\s*\n', '\n\n', text)
        text = re.sub(r'[ \t]+', ' ', text)

        return text.strip()

    def _extract_links(self, body_text: str, body_html: str) -> List[str]:
        """Extract unique URLs from email body."""
        links = set()

        # Extract from text
        for match in self.URL_PATTERN.finditer(body_text):
            url = match.group(0)
            links.add(self._normalize_url(url))

        # Extract href from HTML
        if body_html:
            href_pattern = re.compile(r'href=["\']([^"\']+)["\']', re.IGNORECASE)
            for match in href_pattern.finditer(body_html):
                url = match.group(1)
                if url.startswith(('http://', 'https://', 'www.')):
                    links.add(self._normalize_url(html.unescape(url)))

        return list(links)

    def _normalize_url(self, url: str) -> str:
        """Normalize URL for comparison."""
        if url.startswith('www.'):
            url = 'https://' + url

        # Remove tracking parameters
        try:
            parsed = urlparse(url)
            # Keep just scheme, netloc, path
            clean = f"{parsed.scheme}://{parsed.netloc}{parsed.path}"
            return clean.rstrip('/')
        except Exception:
            return url

    def _extract_amounts(self, body_text: str, subject: str) -> List[str]:
        """Extract financial amounts from email."""
        amounts = []
        combined = f"{subject} {body_text}"

        for match in self.AMOUNT_PATTERN.finditer(combined):
            amounts.append(match.group(0))

        return amounts[:10]  # Limit to avoid noise

    def _match_keywords(self, body_text: str, subject: str) -> List[str]:
        """Match acquisition keywords in email."""
        keywords = self.config.acquisition_keywords
        combined = f"{subject} {body_text}".lower()

        matched = []
        for kw in keywords:
            if kw.lower() in combined:
                matched.append(kw)

        return matched

    def _is_duplicate_body(self, body_hash: str, sender_email: str) -> bool:
        """Check if we've seen this body hash from this sender."""
        conn = self.store._get_connection()
        cursor = conn.execute(
            """
            SELECT COUNT(*) FROM processed_emails
            WHERE body_hash = ? AND sender = ?
            """,
            (body_hash, sender_email)
        )
        count = cursor.fetchone()[0]
        return count > 0
