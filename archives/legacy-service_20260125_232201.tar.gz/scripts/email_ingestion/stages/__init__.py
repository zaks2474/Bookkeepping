"""
Email ingestion pipeline stages.

Stage flow:
    0. Preflight - Check paths, dependencies, connectivity
    1. Fetch - IMAP email fetch
    2. Normalize - Create canonical EmailRecord with stable IDs
    3. Match - Broker matching, keyword matching, deal matching/creation
    4. Persist - Save attachments, email content, manifests
    5. Extract - Text extraction from documents
    6. Classify - Optional Gemini classification
    7. Index - RAG indexing
"""

from .stage_0_preflight import PreflightStage, preflight_check
from .stage_1_fetch import FetchStage
from .stage_2_normalize import NormalizeStage
from .stage_3_match import MatchStage
from .stage_7_index import IndexStage, RAGIndexer, check_rag_connectivity

__all__ = [
    "PreflightStage",
    "preflight_check",
    "FetchStage",
    "NormalizeStage",
    "MatchStage",
    "IndexStage",
    "RAGIndexer",
    "check_rag_connectivity",
]
