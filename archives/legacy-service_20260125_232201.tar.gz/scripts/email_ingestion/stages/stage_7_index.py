"""
Stage 7: RAG Indexing.

Indexes extracted text content to the RAG system with:
- Correct relative path computation from DATAROOM_ROOT
- Config-driven URL prefix
- Size limits and timeouts
- Bounded content chunking
"""

import json
import logging
import os
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple
import urllib.request
import urllib.error

from ..config import get_config, IngestConfig

logger = logging.getLogger(__name__)


@dataclass
class IndexResult:
    """Result of indexing a single file."""
    success: bool = False
    file_path: str = ""
    rel_path: str = ""
    url: str = ""
    chunks_indexed: int = 0
    content_chars: int = 0
    latency_ms: float = 0.0
    error: Optional[str] = None
    skipped_reason: Optional[str] = None


@dataclass
class IndexStageResult:
    """Result of the index stage."""
    success: bool = True
    files_attempted: int = 0
    files_indexed: int = 0
    files_skipped: int = 0
    files_failed: int = 0
    total_chars: int = 0
    total_chunks: int = 0
    results: List[IndexResult] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)


class RAGIndexer:
    """
    RAG indexer with proper path handling and bounds.

    Features:
    - Correct relative path computation from DATAROOM_ROOT
    - Config-driven URL prefix
    - Size limits (max file size, max content chars)
    - Timeout handling
    - Chunked content submission
    """

    def __init__(self, config: Optional[IngestConfig] = None):
        self.config = config or get_config()
        self.api_url = self.config.rag_api_url
        self.url_prefix = self.config.rag_url_prefix
        self.dataroom_root = self.config.dataroom_root
        self.max_file_size_mb = self.config.max_index_file_size_mb
        self.max_chars = self.config.max_extract_chars

    def compute_rel_path(self, file_path: str) -> str:
        """
        Compute relative path from DATAROOM_ROOT.

        Args:
            file_path: Absolute file path

        Returns:
            Relative path from DataRoom root
        """
        try:
            path = Path(file_path)
            rel = path.relative_to(self.dataroom_root)
            return str(rel)
        except ValueError:
            # Path is not under dataroom_root, use filename only
            logger.warning(f"Path not under dataroom: {file_path}")
            return Path(file_path).name

    def compute_url(self, rel_path: str) -> str:
        """
        Compute canonical URL for RAG storage.

        Args:
            rel_path: Relative path from DataRoom root

        Returns:
            Full URL for RAG reference
        """
        # Normalize path separators
        rel_path = rel_path.replace("\\", "/")
        # Remove leading slash if present
        rel_path = rel_path.lstrip("/")
        return f"{self.url_prefix}/{rel_path}"

    def should_index(self, file_path: str) -> Tuple[bool, Optional[str]]:
        """
        Check if file should be indexed.

        Args:
            file_path: Path to file

        Returns:
            Tuple of (should_index, skip_reason)
        """
        path = Path(file_path)

        # Check file exists
        if not path.exists():
            return False, "File not found"

        # Check file size
        size_mb = path.stat().st_size / (1024 * 1024)
        if size_mb > self.max_file_size_mb:
            return False, f"File too large ({size_mb:.1f}MB > {self.max_file_size_mb}MB)"

        # Check extension - only index text files
        ext = path.suffix.lower()
        text_extensions = {".txt", ".md", ".json", ".csv", ".xml", ".html", ".htm"}
        if ext not in text_extensions:
            return False, f"Non-text extension: {ext}"

        return True, None

    def read_content(self, file_path: str) -> Tuple[Optional[str], Optional[str]]:
        """
        Read file content with bounds.

        Args:
            file_path: Path to file

        Returns:
            Tuple of (content, error)
        """
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                content = f.read(self.max_chars + 1)

            # Truncate if too long
            if len(content) > self.max_chars:
                content = content[:self.max_chars]
                logger.info(f"Truncated content to {self.max_chars} chars: {file_path}")

            return content, None

        except UnicodeDecodeError:
            return None, "Cannot decode as UTF-8"
        except Exception as e:
            return None, str(e)

    def index_content(
        self,
        content: str,
        file_path: str,
        metadata: Optional[Dict[str, Any]] = None,
        timeout: int = 30
    ) -> IndexResult:
        """
        Index content to RAG API.

        Args:
            content: Text content to index
            file_path: Original file path
            metadata: Additional metadata
            timeout: Request timeout in seconds

        Returns:
            IndexResult with status
        """
        result = IndexResult(file_path=file_path)
        start_time = time.perf_counter()

        if not content or not content.strip():
            result.skipped_reason = "Empty content"
            return result

        # Compute paths
        rel_path = self.compute_rel_path(file_path)
        url = self.compute_url(rel_path)

        result.rel_path = rel_path
        result.url = url
        result.content_chars = len(content)

        # Build metadata
        full_metadata = {
            "source": "email_ingestion",
            "path": rel_path,
            "filename": Path(file_path).name,
            "indexed_at": datetime.now(timezone.utc).isoformat(),
        }
        if metadata:
            full_metadata.update(metadata)

        # Build payload
        payload = {
            "url": url,
            "content": content,
            "metadata": full_metadata,
            "chunk_size": 5000,
        }

        try:
            # Make request
            data = json.dumps(payload).encode("utf-8")
            req = urllib.request.Request(
                self.api_url,
                data=data,
                headers={"Content-Type": "application/json"},
                method="POST"
            )

            with urllib.request.urlopen(req, timeout=timeout) as response:
                response_data = response.read()
                result.success = response.status == 200

                # Try to parse chunk count from response
                try:
                    resp_json = json.loads(response_data)
                    result.chunks_indexed = resp_json.get("chunks", 1)
                except Exception:
                    result.chunks_indexed = 1

        except urllib.error.HTTPError as e:
            result.error = f"HTTP {e.code}: {e.reason}"
        except urllib.error.URLError as e:
            result.error = f"URL Error: {e.reason}"
        except TimeoutError:
            result.error = "Request timed out"
        except Exception as e:
            result.error = str(e)

        result.latency_ms = (time.perf_counter() - start_time) * 1000
        return result

    def index_file(
        self,
        file_path: str,
        metadata: Optional[Dict[str, Any]] = None,
        timeout: int = 30
    ) -> IndexResult:
        """
        Index a file to RAG.

        Args:
            file_path: Path to file to index
            metadata: Additional metadata
            timeout: Request timeout

        Returns:
            IndexResult with status
        """
        result = IndexResult(file_path=file_path)

        # Check if should index
        should, reason = self.should_index(file_path)
        if not should:
            result.skipped_reason = reason
            return result

        # Read content
        content, error = self.read_content(file_path)
        if error:
            result.error = error
            return result

        # Index
        return self.index_content(content, file_path, metadata, timeout)


class IndexStage:
    """
    Stage 7: Index content to RAG.

    Indexes extracted text files from deal folders.
    """

    def __init__(self, config: Optional[IngestConfig] = None):
        self.config = config or get_config()
        self.indexer = RAGIndexer(config)

    def run(
        self,
        files: List[str],
        deal_id: Optional[str] = None,
        doc_types: Optional[Dict[str, str]] = None,
        dry_run: bool = False
    ) -> IndexStageResult:
        """
        Index a list of files to RAG.

        Args:
            files: List of file paths to index
            deal_id: Associated deal ID for metadata
            doc_types: Dict mapping file paths to document types
            dry_run: If True, don't actually index

        Returns:
            IndexStageResult with results
        """
        result = IndexStageResult()
        doc_types = doc_types or {}

        for file_path in files:
            result.files_attempted += 1

            # Build metadata
            metadata = {}
            if deal_id:
                metadata["deal_id"] = deal_id
            if file_path in doc_types:
                metadata["doc_type"] = doc_types[file_path]

            if dry_run:
                # Check if would be indexed
                should, reason = self.indexer.should_index(file_path)
                idx_result = IndexResult(
                    file_path=file_path,
                    rel_path=self.indexer.compute_rel_path(file_path),
                    success=should,
                    skipped_reason=reason,
                )
                result.results.append(idx_result)
                if should:
                    result.files_indexed += 1
                else:
                    result.files_skipped += 1
                continue

            # Actually index
            idx_result = self.indexer.index_file(file_path, metadata)
            result.results.append(idx_result)

            if idx_result.success:
                result.files_indexed += 1
                result.total_chars += idx_result.content_chars
                result.total_chunks += idx_result.chunks_indexed
            elif idx_result.skipped_reason:
                result.files_skipped += 1
            else:
                result.files_failed += 1
                if idx_result.error:
                    result.errors.append(f"{file_path}: {idx_result.error}")

        logger.info(
            f"Index stage: {result.files_indexed} indexed, "
            f"{result.files_skipped} skipped, {result.files_failed} failed"
        )

        return result

    def index_deal_folder(
        self,
        deal_folder: Path,
        deal_id: str,
        dry_run: bool = False
    ) -> IndexStageResult:
        """
        Index all text files in a deal folder.

        Args:
            deal_folder: Path to deal folder
            deal_id: Deal ID for metadata
            dry_run: If True, don't actually index

        Returns:
            IndexStageResult with results
        """
        files = []

        # Find all .txt files (extracted text)
        for txt_file in deal_folder.rglob("*.txt"):
            # Skip hidden files and internal folders
            if any(part.startswith(".") or part.startswith("_") for part in txt_file.parts):
                continue
            files.append(str(txt_file))

        # Find markdown files
        for md_file in deal_folder.rglob("*.md"):
            if any(part.startswith(".") or part.startswith("_") for part in md_file.parts):
                continue
            files.append(str(md_file))

        if not files:
            logger.info(f"No indexable files found in {deal_folder}")
            return IndexStageResult()

        logger.info(f"Found {len(files)} files to index in {deal_folder}")
        return self.run(files, deal_id=deal_id, dry_run=dry_run)


def check_rag_connectivity(config: Optional[IngestConfig] = None) -> Tuple[bool, str]:
    """
    Check if RAG API is reachable.

    Returns:
        Tuple of (is_reachable, message)
    """
    config = config or get_config()

    try:
        from urllib.parse import urlparse
        parsed = urlparse(config.rag_api_url)
        host = parsed.hostname or "localhost"
        port = parsed.port or 80

        import socket
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(5)
        try:
            sock.connect((host, port))
            return True, f"RAG service reachable at {host}:{port}"
        except (socket.timeout, socket.error) as e:
            return False, f"RAG service not reachable at {host}:{port}: {e}"
        finally:
            sock.close()

    except Exception as e:
        return False, f"RAG connectivity check failed: {e}"
