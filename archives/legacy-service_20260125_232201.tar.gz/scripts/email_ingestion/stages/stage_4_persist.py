"""
Stage 4: Persist - Save emails and emit lifecycle events.

This stage:
1. Records email metadata to SQLite
2. Emits email_received events for matched deals
3. Tracks new deal candidates for manual review
"""

import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Any
import sys

# Add parent path for imports
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from deal_events import DealEventStore

from ..config import get_config, IngestConfig
from ..state.sqlite_store import get_state_store, EmailRecord
from .stage_2_normalize import NormalizedEmail
from .stage_3_match import MatchResult

logger = logging.getLogger(__name__)


@dataclass
class PersistResult:
    """Result of persist stage."""
    success: bool = True
    emails_persisted: int = 0
    events_emitted: int = 0
    errors: List[str] = field(default_factory=list)


class PersistStage:
    """
    Stage 4: Persist emails and emit lifecycle events.

    For each matched email:
    1. Insert/update email record in SQLite
    2. Emit email_received event to deal's event log

    For new deal candidates:
    1. Insert email record with status='new'
    2. (Future: Emit to new-deal queue)
    """

    def __init__(self, config: Optional[IngestConfig] = None):
        self.config = config or get_config()
        self._store = None
        self._event_store = None

    @property
    def store(self):
        if self._store is None:
            self._store = get_state_store()
        return self._store

    @property
    def event_store(self):
        if self._event_store is None:
            events_dir = self.config.dataroom_root / ".deal-registry" / "events"
            self._event_store = DealEventStore(str(events_dir))
        return self._event_store

    def run(
        self,
        matches: List[MatchResult],
        run_id: str,
        dry_run: bool = False
    ) -> PersistResult:
        """
        Persist matched emails and emit events.

        Args:
            matches: List of MatchResult from match stage
            run_id: Current pipeline run ID
            dry_run: If True, log but don't persist

        Returns:
            PersistResult with counts and errors
        """
        result = PersistResult()

        for match in matches:
            try:
                if dry_run:
                    self._log_dry_run(match)
                else:
                    persisted = self._persist_email(match, run_id)
                    if persisted:
                        result.emails_persisted += 1

                    # Emit event for matched emails (even if duplicate in DB)
                    # Events are idempotent via message_id in data
                    if match.matched and match.deal_id and not match.is_junk:
                        emitted = self._emit_email_event(match)
                        if emitted:
                            result.events_emitted += 1

            except Exception as e:
                error_msg = f"Failed to persist {match.email.subject[:50]}: {e}"
                logger.warning(error_msg)
                result.errors.append(error_msg)

        logger.info(
            f"Persist complete: {result.emails_persisted} emails, "
            f"{result.events_emitted} events emitted"
        )

        return result

    def _log_dry_run(self, match: MatchResult) -> None:
        """Log what would be persisted in dry-run mode."""
        if match.is_junk:
            return

        if match.matched:
            logger.info(f"  [DRY] Would persist: {match.email.subject[:50]} -> {match.deal_path}")
        else:
            logger.info(f"  [DRY] Would create new deal: {match.email.subject[:50]} -> {match.suggested_name}")

    def _persist_email(self, match: MatchResult, run_id: str) -> bool:
        """Persist email record to SQLite."""
        email_record = match.email.to_email_record(run_id)
        email_record.deal_id = match.deal_id
        email_record.match_confidence = match.confidence
        email_record.status = "junk" if match.is_junk else (
            "matched" if match.matched else "new"
        )
        email_record.stage_completed = 4

        try:
            self.store.insert_email(email_record)
            return True
        except Exception as e:
            if "UNIQUE constraint" in str(e):
                logger.debug(f"Email already exists: {match.email.message_id[:30]}")
            else:
                logger.warning(f"Failed to record email: {e}")
            return False

    def _emit_email_event(self, match: MatchResult) -> bool:
        """Emit email_received event for a matched email."""
        try:
            email = match.email

            # Build event data
            event_data = {
                "subject": email.subject,
                "sender": email.sender,  # Full sender string "Name <email>"
                "sender_email": email.sender_email,
                "received_date": email.received_date,
                "message_id": email.message_id,
                "match_type": match.match_type,
                "match_confidence": match.confidence,
                "has_attachments": email.attachment_count > 0,
                "attachment_count": email.attachment_count,
            }

            # Add extracted amounts if present
            if email.extracted_amounts:
                event_data["extracted_amounts"] = email.extracted_amounts

            # Emit event
            self.event_store.create_event(
                deal_id=match.deal_id,
                event_type="email_received",
                actor="email_ingestion",
                data=event_data,
                metadata={
                    "broker_domain": email.sender_domain,
                }
            )

            logger.debug(f"Emitted email_received event for {match.deal_id}")
            return True

        except Exception as e:
            logger.warning(f"Failed to emit event for {match.deal_id}: {e}")
            return False
