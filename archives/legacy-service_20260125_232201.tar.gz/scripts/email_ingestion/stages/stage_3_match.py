"""
Stage 3: Deal matching.

Matches emails to existing deals or queues for new deal creation.
Uses deterministic rules first, with optional Gemini fallback.
"""

import json
import re
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any

from ..config import get_config, IngestConfig
from ..state.sqlite_store import get_state_store
from .stage_2_normalize import NormalizedEmail

logger = logging.getLogger(__name__)


@dataclass
class DealIndicators:
    """Extracted signals for deal matching."""
    company_names: List[str] = field(default_factory=list)
    listing_ids: List[str] = field(default_factory=list)
    locations: List[str] = field(default_factory=list)
    sectors: List[str] = field(default_factory=list)
    financial_amounts: List[str] = field(default_factory=list)


@dataclass
class MatchResult:
    """Result of matching a single email."""
    email: NormalizedEmail
    matched: bool = False
    deal_id: Optional[str] = None
    deal_path: Optional[str] = None
    match_type: str = ""  # "registry", "broker", "keyword", "new"
    confidence: float = 0.0
    is_junk: bool = False
    indicators: Optional[DealIndicators] = None
    suggested_name: Optional[str] = None


@dataclass
class MatchStageResult:
    """Result of match stage for all emails."""
    success: bool = True
    matches: List[MatchResult] = field(default_factory=list)
    matched_existing: int = 0
    new_deals: int = 0
    junk_rejected: int = 0
    error: Optional[str] = None


class DealMatcher:
    """
    Deterministic deal matcher.

    Uses multiple strategies in order:
    1. Registry lookup by deal ID / thread ID
    2. Broker association
    3. Subject/keyword overlap with existing deals
    4. Create new deal if no match
    """

    # Sector detection patterns
    SECTOR_PATTERNS = [
        (r'\bmsp\b', 'MSP'),
        (r'\bmanaged service', 'MSP'),
        (r'\bit service', 'IT-Services'),
        (r'\bsaas\b', 'SaaS'),
        (r'\becommerce\b', 'Ecommerce'),
        (r'\be-commerce\b', 'Ecommerce'),
        (r'\bsoftware\b', 'Software'),
        (r'\bcybersecurity\b', 'Cybersecurity'),
        (r'\bdigital marketing\b', 'Digital-Marketing'),
        (r'\btech\b', 'Tech'),
        (r'\bfintech\b', 'Fintech'),
        (r'\bhealthcare\b', 'Healthcare'),
        (r'\bmanufacturing\b', 'Manufacturing'),
    ]

    # Location patterns
    LOCATION_PATTERNS = [
        (r'\btexas\b', 'Texas'), (r'\btx\b', 'Texas'),
        (r'\bcalifornia\b', 'California'), (r'\bca\b', 'California'),
        (r'\bflorida\b', 'Florida'), (r'\bfl\b', 'Florida'),
        (r'\bnew york\b', 'NewYork'), (r'\bny\b', 'NewYork'),
        (r'\bcolorado\b', 'Colorado'),
        (r'\bdallas\b', 'Dallas'),
        (r'\bdenver\b', 'Denver'),
    ]

    # Junk subject patterns
    JUNK_PATTERNS = [
        r'\bunsubscribe\b',
        r'\bnewsletter\b',
        r'\breal estate\b',
        r'\bproperty listing',
        r'\brealtor\.com\b',
        r'\bredfin\b',
        r'\bzillow\b',
    ]

    def __init__(self, config: Optional[IngestConfig] = None):
        self.config = config or get_config()
        self._registry = None
        self._existing_deals: Dict[str, str] = {}  # name -> path

    def load_registry(self) -> None:
        """Load deal registry if available."""
        registry_path = self.config.registry_path
        if registry_path.exists():
            try:
                with open(registry_path) as f:
                    data = json.load(f)
                    self._registry = data
                    logger.info(f"Loaded registry with {len(data.get('deals', []))} deals")
            except Exception as e:
                logger.warning(f"Failed to load registry: {e}")

    def load_existing_deals(self) -> None:
        """Scan DataRoom for existing deal folders."""
        dataroom = self.config.dataroom_root
        pipeline_dir = dataroom / "00-PIPELINE"

        if not pipeline_dir.exists():
            return

        # Scan Inbound and active deal folders
        scan_dirs = [
            pipeline_dir / "Inbound",
            pipeline_dir / "Active",
            dataroom / "01-ACTIVE-DEALS",
        ]

        for scan_dir in scan_dirs:
            if not scan_dir.exists():
                continue

            for folder in scan_dir.iterdir():
                if folder.is_dir():
                    name = folder.name
                    self._existing_deals[name.lower()] = str(folder)

        logger.info(f"Found {len(self._existing_deals)} existing deal folders")

    def extract_indicators(self, email: NormalizedEmail) -> DealIndicators:
        """Extract deal indicators from email content."""
        indicators = DealIndicators()

        text = f"{email.subject} {email.body_text[:2000]}".lower()

        # Extract listing IDs
        listing_matches = re.findall(r'listing\s*[#:]?\s*(\d{4,})', text, re.IGNORECASE)
        indicators.listing_ids = listing_matches

        # Extract sectors
        for pattern, sector in self.SECTOR_PATTERNS:
            if re.search(pattern, text, re.IGNORECASE):
                indicators.sectors.append(sector)

        # Extract locations
        for pattern, location in self.LOCATION_PATTERNS:
            if re.search(pattern, text, re.IGNORECASE):
                if location not in indicators.locations:
                    indicators.locations.append(location)

        # Use extracted amounts from normalize stage
        indicators.financial_amounts = email.extracted_amounts

        return indicators

    def is_junk(self, email: NormalizedEmail) -> bool:
        """Check if email should be rejected as junk."""
        text = f"{email.subject} {email.sender_domain}".lower()

        for pattern in self.JUNK_PATTERNS:
            if re.search(pattern, text, re.IGNORECASE):
                return True

        return False

    def match_to_existing(
        self,
        email: NormalizedEmail,
        indicators: DealIndicators
    ) -> Optional[Tuple[str, str, float]]:
        """
        Try to match email to existing deal.

        Returns:
            Tuple of (deal_id, deal_path, confidence) or None
        """
        # Try registry match first
        if self._registry:
            result = self._registry_match(email)
            if result:
                return result

        # Try keyword/subject overlap match
        result = self._keyword_match(email)
        if result:
            return result

        return None

    def _registry_match(self, email: NormalizedEmail) -> Optional[Tuple[str, str, float]]:
        """Match using deal registry."""
        if not self._registry:
            return None

        # Registry structure: {"deals": {deal_id: deal_data, ...}}
        deals = self._registry.get("deals", {})

        # Handle both list and dict formats
        if isinstance(deals, list):
            deals_iter = [(d.get("deal_id"), d) for d in deals]
        else:
            deals_iter = deals.items()

        for deal_id, deal in deals_iter:
            if not isinstance(deal, dict):
                continue

            folder_path = deal.get("folder_path")
            aliases = deal.get("aliases", [])

            # Check subject contains deal ID
            if deal_id and deal_id.lower() in email.subject.lower():
                return (deal_id, folder_path, 0.95)

            # Check aliases (format: {"alias": "...", "alias_type": "..."})
            for alias in aliases:
                if isinstance(alias, dict):
                    alias_val = alias.get("alias", "").lower()
                elif isinstance(alias, str):
                    alias_val = alias.lower()
                else:
                    continue

                if alias_val and alias_val in email.subject.lower():
                    return (deal_id, folder_path, 0.85)

        return None

    def _keyword_match(self, email: NormalizedEmail) -> Optional[Tuple[str, str, float]]:
        """Match using 2+ word overlap with existing deal names."""
        if not self._existing_deals:
            return None

        subject_lower = email.subject.lower()
        subject_words = set(re.findall(r'\w{3,}', subject_lower))

        best_match = None
        best_score = 0

        for deal_name, deal_path in self._existing_deals.items():
            deal_words = set(re.findall(r'\w{3,}', deal_name))

            # Calculate overlap
            overlap = subject_words & deal_words
            if len(overlap) >= 2:
                # Score based on overlap ratio
                score = len(overlap) / max(len(deal_words), 1)
                if score > best_score:
                    best_score = score
                    best_match = (deal_name, deal_path, min(score, 0.8))

        return best_match

    def generate_deal_name(
        self,
        email: NormalizedEmail,
        indicators: DealIndicators
    ) -> str:
        """Generate a new deal folder name."""
        parts = []

        # Clean subject
        subject = email.subject
        subject = re.sub(r'^(re:|fw:|fwd:)\s*', '', subject, flags=re.IGNORECASE)
        subject = re.sub(r'^(new listing|new opportunity|deal alert)[\s:-]*', '',
                        subject, flags=re.IGNORECASE)

        # Take first meaningful words
        clean_subject = re.sub(r'[^\w\s-]', '', subject)
        words = [w for w in clean_subject.split() if len(w) > 2][:4]
        if words:
            parts.append('-'.join(w.title() for w in words))

        # Add sector
        if indicators.sectors:
            parts.append(indicators.sectors[0])

        # Add year
        parts.append(str(datetime.now(timezone.utc).year))

        # Create name
        name = '-'.join(parts) if parts else f"NewDeal-{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M')}"
        name = re.sub(r'-+', '-', name).strip('-')

        return name


class MatchStage:
    """
    Stage 3: Match emails to deals.

    Uses deterministic matching with configurable thresholds.
    Emails that can't be matched confidently go to quarantine.
    """

    def __init__(self, config: Optional[IngestConfig] = None):
        self.config = config or get_config()
        self.matcher = DealMatcher(config)
        self._store = None

    @property
    def store(self):
        if self._store is None:
            self._store = get_state_store()
        return self._store

    def run(
        self,
        emails: List[NormalizedEmail],
        run_id: str,
        load_registry: bool = True
    ) -> MatchStageResult:
        """
        Match a batch of normalized emails to deals.

        Args:
            emails: List of NormalizedEmail from normalize stage
            run_id: Current run ID
            load_registry: Whether to load deal registry

        Returns:
            MatchStageResult with match results
        """
        result = MatchStageResult()

        # Load existing deals
        if load_registry:
            self.matcher.load_registry()
        self.matcher.load_existing_deals()

        for email in emails:
            match = self._match_email(email)
            result.matches.append(match)

            if match.is_junk:
                result.junk_rejected += 1
            elif match.matched and match.deal_path:
                result.matched_existing += 1
            else:
                result.new_deals += 1

        logger.info(
            f"Match complete: {result.matched_existing} matched existing, "
            f"{result.new_deals} new deals, {result.junk_rejected} junk"
        )

        return result

    def _match_email(self, email: NormalizedEmail) -> MatchResult:
        """Match a single email."""
        result = MatchResult(email=email)

        # Check for junk first
        if self.matcher.is_junk(email):
            result.is_junk = True
            result.match_type = "junk"
            logger.debug(f"Rejected as junk: {email.subject[:50]}")
            return result

        # Extract indicators
        indicators = self.matcher.extract_indicators(email)
        result.indicators = indicators

        # Try to match existing
        match = self.matcher.match_to_existing(email, indicators)

        if match:
            deal_id, deal_path, confidence = match
            result.matched = True
            result.deal_id = deal_id
            result.deal_path = deal_path
            result.confidence = confidence
            result.match_type = "registry" if deal_id and deal_id.startswith("DEAL-") else "keyword"
            logger.debug(f"Matched: {email.subject[:50]} -> {deal_path}")
        else:
            # Generate suggested name for new deal
            result.suggested_name = self.matcher.generate_deal_name(email, indicators)
            result.match_type = "new"
            logger.debug(f"New deal: {email.subject[:50]} -> {result.suggested_name}")

        return result
