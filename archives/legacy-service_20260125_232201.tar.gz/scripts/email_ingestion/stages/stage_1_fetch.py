"""
Stage 1: Email fetch from IMAP.

Fetches emails from Gmail IMAP using configured credentials.
Filters by broker emails, keywords, and date range.
"""

import imaplib
import email
import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from email.header import decode_header
from email.utils import parsedate_to_datetime
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple

from ..config import get_config, IngestConfig

logger = logging.getLogger(__name__)


@dataclass
class RawEmail:
    """Raw email data from IMAP fetch."""
    message_id: str
    thread_id: str
    subject: str
    sender: str
    date: str
    body_text: str
    body_html: str
    attachments: List[Dict[str, Any]]
    raw_size: int
    match_reason: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "message_id": self.message_id,
            "thread_id": self.thread_id,
            "subject": self.subject,
            "from": self.sender,
            "date": self.date,
            "body_text": self.body_text,
            "body_html": self.body_html,
            "attachments": self.attachments,
            "raw_size": self.raw_size,
            "match_reason": self.match_reason,
        }


@dataclass
class FetchResult:
    """Result of fetch stage."""
    success: bool = True
    emails: List[RawEmail] = field(default_factory=list)
    total_found: int = 0
    filtered_count: int = 0
    error: Optional[str] = None


class IMAPClient:
    """
    IMAP client for fetching emails from Gmail.

    Thread-safe connection handling with auto-reconnect.
    """

    def __init__(
        self,
        email_address: str,
        app_password: str,
        server: str = "imap.gmail.com",
        port: int = 993
    ):
        self.email_address = email_address
        self.app_password = app_password
        self.server = server
        self.port = port
        self.connection: Optional[imaplib.IMAP4_SSL] = None

    def connect(self) -> bool:
        """Connect to IMAP server."""
        try:
            self.connection = imaplib.IMAP4_SSL(self.server, self.port)
            self.connection.login(self.email_address, self.app_password)
            logger.info(f"Connected to {self.server} as {self.email_address}")
            return True
        except Exception as e:
            logger.error(f"Failed to connect to IMAP: {e}")
            return False

    def disconnect(self) -> None:
        """Disconnect from IMAP server."""
        if self.connection:
            try:
                self.connection.logout()
            except Exception:
                pass
            self.connection = None

    def __enter__(self) -> "IMAPClient":
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.disconnect()

    def search_emails(
        self,
        since_date: Optional[datetime] = None,
        hours_back: int = 72,
        max_results: int = 100,
        mailbox: str = "INBOX"
    ) -> List[bytes]:
        """
        Search for emails within date range.

        Args:
            since_date: Start date for search (overrides hours_back)
            hours_back: Hours to look back from now
            max_results: Maximum number of email IDs to return
            mailbox: IMAP mailbox to search

        Returns:
            List of message IDs
        """
        if not self.connection:
            if not self.connect():
                return []

        try:
            self.connection.select(mailbox)

            # Build date criteria
            if since_date:
                search_date = since_date
            else:
                search_date = datetime.now(timezone.utc) - timedelta(hours=hours_back)

            date_str = search_date.strftime("%d-%b-%Y")
            criteria = f'(SINCE {date_str})'

            _, message_ids = self.connection.search(None, criteria)

            if not message_ids[0]:
                logger.info("No emails found in date range")
                return []

            ids = message_ids[0].split()
            logger.info(f"Found {len(ids)} emails in date range")

            # Return most recent, limited
            return ids[-max_results:]

        except Exception as e:
            logger.error(f"Error searching emails: {e}")
            return []

    def fetch_email(self, msg_id: bytes) -> Optional[RawEmail]:
        """
        Fetch a single email by IMAP ID.

        Args:
            msg_id: IMAP message ID

        Returns:
            RawEmail or None if fetch failed
        """
        if not self.connection:
            return None

        try:
            _, msg_data = self.connection.fetch(msg_id, '(RFC822)')

            if not msg_data or not msg_data[0]:
                return None

            raw_email = msg_data[0][1]
            msg = email.message_from_bytes(raw_email)

            # Parse headers
            subject = self._decode_header(msg.get('Subject', ''))
            sender = self._decode_header(msg.get('From', ''))
            date_str = msg.get('Date', '')
            message_id = msg.get('Message-ID', str(msg_id))

            # Parse date
            try:
                received_date = parsedate_to_datetime(date_str).isoformat()
            except Exception:
                received_date = date_str

            # Extract body and attachments
            body_text, body_html, attachments = self._extract_content(msg)

            return RawEmail(
                message_id=message_id,
                thread_id=msg.get('Thread-Index', message_id),
                subject=subject,
                sender=sender,
                date=received_date,
                body_text=body_text,
                body_html=body_html,
                attachments=attachments,
                raw_size=len(raw_email),
            )

        except Exception as e:
            logger.warning(f"Failed to fetch email {msg_id}: {e}")
            return None

    def _decode_header(self, header: str) -> str:
        """Decode email header value."""
        if not header:
            return ""

        decoded_parts = decode_header(header)
        result = []
        for part, charset in decoded_parts:
            if isinstance(part, bytes):
                try:
                    result.append(part.decode(charset or 'utf-8', errors='replace'))
                except Exception:
                    result.append(part.decode('utf-8', errors='replace'))
            else:
                result.append(str(part))
        return ''.join(result)

    def _extract_content(self, msg: email.message.Message) -> Tuple[str, str, List[Dict]]:
        """
        Extract body text, HTML, and attachments from email message.

        Returns:
            Tuple of (body_text, body_html, attachments)
        """
        body_text = ""
        body_html = ""
        attachments = []

        if msg.is_multipart():
            for part in msg.walk():
                content_type = part.get_content_type()
                content_disposition = str(part.get('Content-Disposition', ''))

                if 'attachment' in content_disposition:
                    # Attachment
                    filename = part.get_filename()
                    if filename:
                        filename = self._decode_header(filename)
                        attachments.append({
                            'filename': filename,
                            'content_type': content_type,
                            'size': len(part.get_payload(decode=True) or b''),
                            'data': part.get_payload(decode=True),
                        })
                elif content_type == 'text/plain' and not body_text:
                    payload = part.get_payload(decode=True)
                    if payload:
                        charset = part.get_content_charset() or 'utf-8'
                        body_text = payload.decode(charset, errors='replace')
                elif content_type == 'text/html' and not body_html:
                    payload = part.get_payload(decode=True)
                    if payload:
                        charset = part.get_content_charset() or 'utf-8'
                        body_html = payload.decode(charset, errors='replace')
        else:
            # Simple message
            content_type = msg.get_content_type()
            payload = msg.get_payload(decode=True)
            if payload:
                charset = msg.get_content_charset() or 'utf-8'
                if content_type == 'text/plain':
                    body_text = payload.decode(charset, errors='replace')
                elif content_type == 'text/html':
                    body_html = payload.decode(charset, errors='replace')

        return body_text, body_html, attachments


class FetchStage:
    """
    Stage 1: Fetch emails from IMAP.

    Configuration:
    - IMAP server/port from config
    - Credentials from credentials file
    - Filter by broker domains and keywords
    """

    def __init__(self, config: Optional[IngestConfig] = None):
        self.config = config or get_config()
        self._credentials: Optional[Tuple[str, str]] = None

    def _load_credentials(self) -> Tuple[str, str]:
        """Load IMAP credentials from credentials file."""
        if self._credentials:
            return self._credentials

        creds_file = self.config.credentials_file
        if not creds_file.exists():
            raise FileNotFoundError(f"Credentials file not found: {creds_file}")

        creds = {}
        with open(creds_file) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, value = line.split("=", 1)
                    # Strip quotes
                    value = value.strip().strip('"').strip("'")
                    creds[key.strip()] = value

        # Use canonical var names from existing system
        email_addr = creds.get("GMAIL_EMAIL")
        password = creds.get("GMAIL_APP_PASSWORD")

        if not email_addr or not password:
            raise ValueError("Missing GMAIL_EMAIL or GMAIL_APP_PASSWORD in credentials")

        self._credentials = (email_addr, password)
        return self._credentials

    def run(
        self,
        since_date: Optional[datetime] = None,
        hours_back: int = 72,
        max_results: int = 100,
        broker_emails: Optional[List[str]] = None,
        broker_domains: Optional[List[str]] = None,
    ) -> FetchResult:
        """
        Execute fetch stage.

        Args:
            since_date: Fetch emails since this date
            hours_back: Hours to look back (if since_date not specified)
            max_results: Maximum emails to fetch
            broker_emails: List of broker email addresses to match
            broker_domains: List of broker domains to match

        Returns:
            FetchResult with fetched emails
        """
        result = FetchResult()

        try:
            email_addr, password = self._load_credentials()
        except Exception as e:
            result.success = False
            result.error = f"Failed to load credentials: {e}"
            return result

        keywords = self.config.acquisition_keywords
        keywords_lower = [k.lower() for k in keywords]

        # Normalize broker matching
        broker_emails_lower = set()
        broker_domains_set = set()

        if broker_emails:
            broker_emails_lower = {e.lower() for e in broker_emails}
            broker_domains_set = {
                e.split('@')[1] for e in broker_emails_lower if '@' in e
            }

        if broker_domains:
            broker_domains_set.update(d.lower() for d in broker_domains)

        try:
            with IMAPClient(
                email_addr,
                password,
                self.config.imap_server,
                self.config.imap_port
            ) as client:
                # Search for emails
                msg_ids = client.search_emails(
                    since_date=since_date,
                    hours_back=hours_back,
                    max_results=max_results * 2,  # Fetch extra for filtering
                )

                result.total_found = len(msg_ids)

                # Fetch and filter emails
                for msg_id in msg_ids:
                    raw = client.fetch_email(msg_id)
                    if not raw:
                        continue

                    # Extract sender info
                    sender_email = self._extract_email(raw.sender).lower()
                    sender_domain = ""
                    if '@' in sender_email:
                        sender_domain = sender_email.split('@')[1]

                    subject_lower = raw.subject.lower()

                    # Match by broker
                    broker_match = (
                        sender_email in broker_emails_lower or
                        sender_domain in broker_domains_set
                    )

                    # Match by keyword
                    keyword_match = any(kw in subject_lower for kw in keywords_lower)

                    # If we have broker filters, require broker or keyword match
                    # Otherwise, just use keyword match
                    if broker_emails_lower or broker_domains_set:
                        if broker_match or keyword_match:
                            raw.match_reason = "broker" if broker_match else "keyword"
                            result.emails.append(raw)
                    else:
                        # No broker filter, match keywords only
                        if keyword_match:
                            raw.match_reason = "keyword"
                            result.emails.append(raw)

                    if len(result.emails) >= max_results:
                        break

                result.filtered_count = len(result.emails)
                logger.info(
                    f"Fetch complete: {result.total_found} found, "
                    f"{result.filtered_count} matched filters"
                )

        except Exception as e:
            result.success = False
            result.error = str(e)
            logger.error(f"Fetch stage failed: {e}")

        return result

    def _extract_email(self, sender: str) -> str:
        """Extract email address from sender string like 'Name <email@domain.com>'."""
        if '<' in sender and '>' in sender:
            start = sender.index('<') + 1
            end = sender.index('>')
            return sender[start:end]
        return sender
