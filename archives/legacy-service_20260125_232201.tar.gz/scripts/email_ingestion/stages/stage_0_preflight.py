"""
Stage 0: Preflight checks.

Verifies:
- Required directories exist
- IMAP credentials available
- RAG service connectivity
- Disk space sufficient
- Dependencies importable
"""

import os
import shutil
import socket
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Tuple
from urllib.request import urlopen
from urllib.error import URLError

from ..config import get_config, IngestConfig

logger = logging.getLogger(__name__)


@dataclass
class PreflightResult:
    """Result of preflight checks."""
    passed: bool = True
    checks: List[Tuple[str, bool, str]] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

    def add_check(self, name: str, passed: bool, message: str = "") -> None:
        self.checks.append((name, passed, message))
        if not passed:
            self.passed = False
            self.errors.append(f"{name}: {message}")

    def add_warning(self, message: str) -> None:
        self.warnings.append(message)

    def summary(self) -> str:
        lines = []
        for name, passed, msg in self.checks:
            status = "✓" if passed else "✗"
            lines.append(f"  [{status}] {name}: {msg}")
        if self.warnings:
            lines.append("")
            lines.append("Warnings:")
            for w in self.warnings:
                lines.append(f"  ⚠ {w}")
        return "\n".join(lines)


class PreflightStage:
    """
    Stage 0: Preflight checks before pipeline execution.

    Checks:
    - Directory paths exist and are writable
    - IMAP credentials are configured
    - RAG API is reachable (if enabled)
    - Disk space is sufficient
    - Required Python modules are available
    """

    def __init__(self, config: Optional[IngestConfig] = None):
        self.config = config or get_config()

    def run(self, deep_imap_check: bool = False) -> PreflightResult:
        """
        Execute all preflight checks.

        Args:
            deep_imap_check: If True, performs actual IMAP login/mailbox test
        """
        result = PreflightResult()

        # 1. Check directories
        self._check_directories(result)

        # 2. Check IMAP credentials
        self._check_imap_credentials(result)

        # 3. Check IMAP connectivity (DNS + optional auth)
        self._check_imap_connectivity(result, deep_check=deep_imap_check)

        # 4. Check RAG connectivity
        self._check_rag_connectivity(result)

        # 5. Check disk space
        self._check_disk_space(result)

        # 6. Check dependencies
        self._check_dependencies(result)

        return result

    def _check_directories(self, result: PreflightResult) -> None:
        """Verify required directories exist and are writable."""
        dirs_to_check = [
            ("dataroom_root", self.config.dataroom_root),
            ("state_db_parent", self.config.state_db_path.parent),
            ("intake_dropzone", self.config.intake_dropzone_path),
            ("cache_dir", self.config.cache_dir),
            ("log_dir", self.config.log_dir),
        ]

        for name, path in dirs_to_check:
            if not path.exists():
                # Try to create it
                try:
                    path.mkdir(parents=True, exist_ok=True)
                    result.add_check(name, True, f"Created {path}")
                except Exception as e:
                    result.add_check(name, False, f"Cannot create {path}: {e}")
            elif not os.access(path, os.W_OK):
                result.add_check(name, False, f"{path} is not writable")
            else:
                result.add_check(name, True, f"{path} OK")

    def _check_imap_credentials(self, result: PreflightResult) -> None:
        """Check IMAP credentials are available."""
        creds_file = self.config.credentials_file

        if not creds_file.exists():
            result.add_check(
                "imap_credentials",
                False,
                f"Credentials file not found: {creds_file}"
            )
            return

        # Check file contains required vars (canonical names from old system)
        # GMAIL_EMAIL and GMAIL_APP_PASSWORD are the canonical var names
        required_vars = ["GMAIL_EMAIL", "GMAIL_APP_PASSWORD"]
        found_vars = set()

        try:
            with open(creds_file) as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#"):
                        if "=" in line:
                            var_name = line.split("=", 1)[0].strip()
                            found_vars.add(var_name)
        except Exception as e:
            result.add_check("imap_credentials", False, f"Cannot read {creds_file}: {e}")
            return

        missing = [v for v in required_vars if v not in found_vars]
        if missing:
            result.add_check(
                "imap_credentials",
                False,
                f"Missing vars in credentials: {', '.join(missing)}"
            )
        else:
            result.add_check("imap_credentials", True, "Credentials configured")

    def _check_imap_connectivity(self, result: PreflightResult, deep_check: bool = False) -> None:
        """
        Check IMAP server connectivity.

        Args:
            deep_check: If True, also tests login and mailbox access
        """
        imap_host = "imap.gmail.com"
        imap_port = 993

        # Step 1: DNS/TCP connectivity
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(10)
            sock.connect((imap_host, imap_port))
            sock.close()
            result.add_check("imap_connectivity", True, f"{imap_host}:{imap_port} reachable")
        except socket.gaierror as e:
            result.add_check("imap_connectivity", False, f"DNS resolution failed: {e}")
            return
        except socket.timeout:
            result.add_check("imap_connectivity", False, f"Connection timeout to {imap_host}:{imap_port}")
            return
        except socket.error as e:
            result.add_check("imap_connectivity", False, f"Connection failed: {e}")
            return

        if not deep_check:
            return

        # Step 2: IMAP login test (only if deep_check requested)
        import imaplib

        # Load credentials
        creds_file = self.config.credentials_file
        creds = {}
        try:
            with open(creds_file) as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#") and "=" in line:
                        key, value = line.split("=", 1)
                        creds[key.strip()] = value.strip().strip('"').strip("'")
        except Exception as e:
            result.add_check("imap_auth", False, f"Cannot read credentials: {e}")
            return

        email_addr = creds.get("GMAIL_EMAIL")
        password = creds.get("GMAIL_APP_PASSWORD")

        if not email_addr or not password:
            result.add_check("imap_auth", False, "Missing GMAIL_EMAIL or GMAIL_APP_PASSWORD")
            return

        try:
            imap = imaplib.IMAP4_SSL(imap_host, imap_port)
            try:
                imap.login(email_addr, password)
                result.add_check("imap_auth", True, "IMAP login successful")

                # Step 3: Mailbox select test
                try:
                    status, _ = imap.select("INBOX", readonly=True)
                    if status == "OK":
                        result.add_check("imap_mailbox", True, "INBOX accessible")
                    else:
                        result.add_check("imap_mailbox", False, f"INBOX select failed: {status}")
                except Exception as e:
                    result.add_check("imap_mailbox", False, f"Mailbox select error: {e}")

                imap.logout()
            except imaplib.IMAP4.error as e:
                error_msg = str(e)
                if "AUTHENTICATIONFAILED" in error_msg or "Invalid credentials" in error_msg:
                    result.add_check("imap_auth", False, "Authentication failed (check credentials)")
                else:
                    result.add_check("imap_auth", False, f"IMAP error: {error_msg}")
        except Exception as e:
            result.add_check("imap_auth", False, f"IMAP connection error: {e}")

    def _check_rag_connectivity(self, result: PreflightResult) -> None:
        """Check RAG API is reachable."""
        rag_url = self.config.rag_api_url

        # Extract host/port from URL
        try:
            from urllib.parse import urlparse
            parsed = urlparse(rag_url)
            host = parsed.hostname or "localhost"
            port = parsed.port or 80

            # Quick socket check
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(5)
            try:
                sock.connect((host, port))
                result.add_check("rag_connectivity", True, f"RAG service reachable at {host}:{port}")
            except (socket.timeout, socket.error) as e:
                result.add_warning(f"RAG service not reachable at {host}:{port}: {e}")
                result.add_check("rag_connectivity", True, "RAG not reachable (non-fatal)")
            finally:
                sock.close()
        except Exception as e:
            result.add_warning(f"RAG connectivity check failed: {e}")
            result.add_check("rag_connectivity", True, "RAG check skipped (non-fatal)")

    def _check_disk_space(self, result: PreflightResult) -> None:
        """Check disk space is sufficient."""
        min_free_gb = 1.0  # Minimum 1GB free

        try:
            usage = shutil.disk_usage(self.config.dataroom_root)
            free_gb = usage.free / (1024 ** 3)

            if free_gb < min_free_gb:
                result.add_check(
                    "disk_space",
                    False,
                    f"Low disk space: {free_gb:.1f}GB free (need {min_free_gb}GB)"
                )
            else:
                result.add_check("disk_space", True, f"{free_gb:.1f}GB free")
        except Exception as e:
            result.add_check("disk_space", False, f"Cannot check disk space: {e}")

    def _check_dependencies(self, result: PreflightResult) -> None:
        """Check required Python modules are available."""
        required_modules = [
            ("imaplib", "Standard library"),
            ("email", "Standard library"),
            ("sqlite3", "Standard library"),
        ]

        optional_modules = [
            ("PyPDF2", "PDF extraction"),
            ("docx", "DOCX extraction"),
            ("openpyxl", "Excel extraction"),
        ]

        all_ok = True
        for mod_name, purpose in required_modules:
            try:
                __import__(mod_name)
            except ImportError:
                result.add_check(f"dep_{mod_name}", False, f"Required module not found: {mod_name}")
                all_ok = False

        for mod_name, purpose in optional_modules:
            try:
                __import__(mod_name)
            except ImportError:
                result.add_warning(f"Optional module not found: {mod_name} ({purpose})")

        if all_ok:
            result.add_check("dependencies", True, "All required modules available")


def preflight_check(
    config: Optional[IngestConfig] = None,
    deep_imap_check: bool = False
) -> PreflightResult:
    """
    Convenience function to run preflight checks.

    Args:
        config: Pipeline configuration
        deep_imap_check: If True, tests IMAP login and mailbox access

    Usage:
        result = preflight_check()
        if not result.passed:
            print("Preflight failed:")
            print(result.summary())
            sys.exit(1)
    """
    stage = PreflightStage(config)
    return stage.run(deep_imap_check=deep_imap_check)
