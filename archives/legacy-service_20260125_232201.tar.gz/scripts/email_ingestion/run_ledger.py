"""
Run ledger integration for email ingestion pipeline.

Provides utilities for:
- Recording runs to JSONL run-ledger
- Timing individual stages and operations
- Integration with SQLite state store
"""

import json
import os
import socket
import time
import logging
import fcntl
from contextlib import contextmanager
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Any, Optional, List

from .config import get_config

logger = logging.getLogger(__name__)


@dataclass
class RunEntry:
    """A single run ledger entry."""
    run_id: str
    component: str
    started_at: str
    ended_at: Optional[str] = None
    status: str = "running"  # running/success/fail
    artifacts: List[str] = field(default_factory=list)
    metrics: Dict[str, Any] = field(default_factory=dict)
    errors: List[str] = field(default_factory=list)
    correlation: Dict[str, str] = field(default_factory=dict)
    written_at: Optional[str] = None
    host: str = field(default_factory=lambda: socket.gethostname())
    pid: int = field(default_factory=os.getpid)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dict for JSON serialization."""
        return asdict(self)


class StageTimer:
    """Context manager for timing pipeline stages."""

    # Stage name to number mapping
    STAGE_NUMBERS = {
        "preflight": 0,
        "fetch": 1,
        "normalize": 2,
        "match": 3,
        "persist": 4,
        "extract": 5,
        "classify": 6,
        "index": 7,
    }

    def __init__(self, stage_name: str, run_id: str, store=None, email_id: int = None):
        self.stage_name = stage_name
        self.stage_number = self.STAGE_NUMBERS.get(stage_name, -1)
        self.run_id = run_id
        self.store = store
        self.email_id = email_id
        self.start_time: Optional[float] = None
        self.end_time: Optional[float] = None
        self.duration_ms: Optional[float] = None
        self.started_at: Optional[str] = None
        self.ended_at: Optional[str] = None
        self.error: Optional[str] = None

    def __enter__(self) -> "StageTimer":
        self.start_time = time.perf_counter()
        self.started_at = datetime.now(timezone.utc).isoformat()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> bool:
        self.end_time = time.perf_counter()
        self.ended_at = datetime.now(timezone.utc).isoformat()
        self.duration_ms = (self.end_time - self.start_time) * 1000

        # Capture error if exception occurred
        status = "success"
        if exc_type is not None:
            status = "fail"
            self.error = f"{exc_type.__name__}: {exc_val}"

        # Record to SQLite if store is available
        if self.store:
            try:
                self.store.record_timing(
                    run_id=self.run_id,
                    email_id=self.email_id,
                    stage=self.stage_number,
                    stage_name=self.stage_name,
                    started_at=self.started_at,
                    ended_at=self.ended_at,
                    status=status,
                    error=self.error,
                )
            except Exception as e:
                logger.warning(f"Failed to record timing to store: {e}")

        return False  # Don't suppress exceptions


class RunLedger:
    """
    Manager for run ledger entries.

    Provides crash-safe JSONL logging with file locking.
    """

    def __init__(self, ledger_path: Optional[Path] = None):
        self.config = get_config()
        self.ledger_path = ledger_path or self.config.run_ledger_path
        self._ensure_parent_dir()

    def _ensure_parent_dir(self) -> None:
        """Ensure the ledger directory exists."""
        self.ledger_path.parent.mkdir(parents=True, exist_ok=True)

    def _append_entry(self, entry: RunEntry) -> None:
        """Append entry to ledger with file locking."""
        entry.written_at = datetime.now(timezone.utc).isoformat()
        line = json.dumps(entry.to_dict()) + "\n"

        with open(self.ledger_path, "a") as f:
            fcntl.flock(f.fileno(), fcntl.LOCK_EX)
            try:
                f.write(line)
                f.flush()
            finally:
                fcntl.flock(f.fileno(), fcntl.LOCK_UN)

    def start_run(
        self,
        run_id: str,
        component: str = "email_ingestion",
        correlation: Optional[Dict[str, str]] = None,
    ) -> RunEntry:
        """
        Start a new run and record to ledger.

        Args:
            run_id: Unique run identifier
            component: Component name
            correlation: Optional correlation metadata

        Returns:
            RunEntry for this run
        """
        entry = RunEntry(
            run_id=run_id,
            component=component,
            started_at=datetime.now(timezone.utc).isoformat(),
            status="running",
            correlation=correlation or {},
        )

        self._append_entry(entry)
        logger.info(f"[{run_id}] Run started: {component}")

        return entry

    def end_run(
        self,
        entry: RunEntry,
        status: str = "success",
        artifacts: Optional[List[str]] = None,
        metrics: Optional[Dict[str, Any]] = None,
        errors: Optional[List[str]] = None,
    ) -> RunEntry:
        """
        End a run and record final entry to ledger.

        Args:
            entry: The RunEntry from start_run
            status: Final status (success/fail)
            artifacts: List of artifact paths produced
            metrics: Metrics from the run
            errors: List of error messages

        Returns:
            Updated RunEntry
        """
        entry.ended_at = datetime.now(timezone.utc).isoformat()
        entry.status = status
        if artifacts:
            entry.artifacts = artifacts
        if metrics:
            entry.metrics = metrics
        if errors:
            entry.errors = errors

        self._append_entry(entry)

        log_level = logging.INFO if status == "success" else logging.ERROR
        logger.log(
            log_level,
            f"[{entry.run_id}] Run ended: {status} "
            f"(metrics: {json.dumps(entry.metrics)})"
        )

        return entry

    def get_recent_runs(
        self,
        component: Optional[str] = None,
        limit: int = 10,
        status_filter: Optional[str] = None,
    ) -> List[RunEntry]:
        """
        Get recent runs from ledger.

        Args:
            component: Filter by component name
            limit: Max entries to return
            status_filter: Filter by status

        Returns:
            List of RunEntry objects
        """
        if not self.ledger_path.exists():
            return []

        entries = []
        with open(self.ledger_path, "r") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    data = json.loads(line)
                    # Only include completed runs (not "running")
                    if data.get("status") == "running":
                        continue
                    if component and data.get("component") != component:
                        continue
                    if status_filter and data.get("status") != status_filter:
                        continue

                    entry = RunEntry(
                        run_id=data.get("run_id", ""),
                        component=data.get("component", ""),
                        started_at=data.get("started_at", ""),
                        ended_at=data.get("ended_at"),
                        status=data.get("status", ""),
                        artifacts=data.get("artifacts", []),
                        metrics=data.get("metrics", {}),
                        errors=data.get("errors", []),
                        correlation=data.get("correlation", {}),
                        written_at=data.get("written_at"),
                        host=data.get("host", ""),
                        pid=data.get("pid", 0),
                    )
                    entries.append(entry)
                except json.JSONDecodeError:
                    continue

        # Return most recent entries
        return entries[-limit:]


@contextmanager
def timed_stage(stage_name: str, run_id: str, store=None):
    """
    Context manager for timing a pipeline stage.

    Usage:
        with timed_stage("fetch", run_id, store) as timer:
            # do work
        print(f"Stage took {timer.duration_ms}ms")
    """
    timer = StageTimer(stage_name, run_id, store)
    with timer:
        yield timer


@contextmanager
def run_context(
    run_id: str,
    component: str = "email_ingestion",
    correlation: Optional[Dict[str, str]] = None,
    ledger: Optional[RunLedger] = None,
):
    """
    Context manager for a complete pipeline run.

    Usage:
        with run_context("RUN-123", "email_ingestion") as ctx:
            ctx.add_metric("emails_processed", 10)
            ctx.add_artifact("/path/to/log")
            # do work
    """
    _ledger = ledger or RunLedger()
    entry = _ledger.start_run(run_id, component, correlation)

    class RunContext:
        def __init__(self):
            self.artifacts = []
            self.metrics = {}
            self.errors = []

        def add_artifact(self, path: str) -> None:
            self.artifacts.append(path)

        def add_metric(self, key: str, value: Any) -> None:
            self.metrics[key] = value

        def add_error(self, error: str) -> None:
            self.errors.append(error)

        def set_metrics(self, metrics: Dict[str, Any]) -> None:
            self.metrics.update(metrics)

    ctx = RunContext()

    try:
        yield ctx
        _ledger.end_run(
            entry,
            status="success",
            artifacts=ctx.artifacts,
            metrics=ctx.metrics,
            errors=ctx.errors if ctx.errors else None,
        )
    except Exception as e:
        ctx.add_error(f"{type(e).__name__}: {str(e)}")
        _ledger.end_run(
            entry,
            status="fail",
            artifacts=ctx.artifacts,
            metrics=ctx.metrics,
            errors=ctx.errors,
        )
        raise


def generate_run_id(prefix: str = "EMAIL") -> str:
    """
    Generate a unique run ID.

    Format: {prefix}-{YYYYMMDD}T{HHMMSS}Z-{pid}

    Example: EMAIL-20251228T013000Z-12345
    """
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    pid = os.getpid()
    return f"{prefix}-{timestamp}-{pid}"


# Singleton instance
_ledger: Optional[RunLedger] = None


def get_run_ledger() -> RunLedger:
    """Get or create the singleton RunLedger instance."""
    global _ledger
    if _ledger is None:
        _ledger = RunLedger()
    return _ledger
