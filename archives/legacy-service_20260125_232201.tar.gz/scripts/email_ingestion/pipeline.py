"""
Email Ingestion Pipeline Orchestrator.

Coordinates execution of all pipeline stages with:
- Checkpoint-based crash recovery
- Run ledger integration
- Timing metrics
- Configurable modes (normal, rebuild, dry-run)
"""

import logging
import sys
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Any

from .config import get_config, IngestConfig
from .run_ledger import (
    generate_run_id,
    run_context,
    timed_stage,
    get_run_ledger,
)
from .state import get_state_store, CheckpointManager
from .state.sqlite_store import EmailRecord, RunRecord
from .stages import (
    PreflightStage,
    preflight_check,
    FetchStage,
    NormalizeStage,
    MatchStage,
)
from .stages.stage_1_fetch import RawEmail
from .stages.stage_2_normalize import NormalizedEmail
from .stages.stage_3_match import MatchResult
from .stages.stage_4_persist import PersistStage

logger = logging.getLogger(__name__)


@dataclass
class PipelineStats:
    """Statistics from a pipeline run."""
    run_id: str = ""
    started_at: str = ""
    ended_at: str = ""
    duration_seconds: float = 0.0

    # Fetch stats
    emails_found: int = 0
    emails_filtered: int = 0

    # Normalize stats
    emails_normalized: int = 0
    duplicates_skipped: int = 0

    # Match stats
    matched_existing: int = 0
    new_deals: int = 0
    junk_rejected: int = 0

    # Persist stats
    attachments_downloaded: int = 0
    files_saved: int = 0

    # Index stats
    files_indexed: int = 0

    # Stage timings
    stage_timings: Dict[str, float] = field(default_factory=dict)

    # Errors
    errors: List[str] = field(default_factory=list)


@dataclass
class PipelineOptions:
    """Options for pipeline execution."""
    # Mode
    dry_run: bool = False
    rebuild: bool = False

    # Date range
    since_date: Optional[datetime] = None
    days_lookback: int = 3
    hours_lookback: int = 72

    # Limits
    max_emails: int = 100

    # Features
    skip_preflight: bool = False
    skip_index: bool = False

    # Broker filters
    broker_emails: List[str] = field(default_factory=list)
    broker_domains: List[str] = field(default_factory=list)


class Pipeline:
    """
    Main email ingestion pipeline.

    Stages:
        0. Preflight - Check paths, dependencies, connectivity
        1. Fetch - IMAP email fetch
        2. Normalize - Create canonical records with stable IDs
        3. Match - Match to existing deals or queue for creation
        4. Persist - Save attachments, content, manifests
        5. Extract - Text extraction from documents
        6. Classify - Optional Gemini classification
        7. Index - RAG indexing

    Usage:
        pipeline = Pipeline()
        stats = pipeline.run()
        print(f"Processed {stats.emails_normalized} emails")
    """

    def __init__(
        self,
        config: Optional[IngestConfig] = None,
        options: Optional[PipelineOptions] = None
    ):
        self.config = config or get_config()
        self.options = options or PipelineOptions()
        self.store = get_state_store()
        self.run_id: Optional[str] = None
        self.checkpoint_mgr: Optional[CheckpointManager] = None

    def run(self) -> PipelineStats:
        """
        Execute the full pipeline.

        Returns:
            PipelineStats with run metrics
        """
        self.run_id = generate_run_id("EMAIL")
        self.checkpoint_mgr = CheckpointManager(self.run_id)
        stats = PipelineStats(run_id=self.run_id)
        stats.started_at = datetime.now(timezone.utc).isoformat()

        logger.info(f"[{self.run_id}] Pipeline starting...")
        if self.options.dry_run:
            logger.info("[DRY RUN] No changes will be persisted")
        if self.options.rebuild:
            logger.info(f"[REBUILD] Reprocessing from {self.options.since_date or 'last N days'}")

        # Record run start in SQLite
        run_record = RunRecord(
            run_id=self.run_id,
            started_at=stats.started_at,
            mode="rebuild" if self.options.rebuild else ("dry_run" if self.options.dry_run else "normal"),
            since_date=self.options.since_date.isoformat() if self.options.since_date else None,
            days_lookback=self.options.days_lookback,
            force=self.options.rebuild,
            dry_run=self.options.dry_run,
        )
        if not self.options.dry_run:
            self.store.start_run(run_record)

        try:
            with run_context(self.run_id, "email_ingestion") as ctx:
                # Stage 0: Preflight
                if not self.options.skip_preflight:
                    self._run_preflight(stats, ctx)

                # Stage 1: Fetch
                raw_emails = self._run_fetch(stats, ctx)
                if not raw_emails:
                    logger.info("No emails to process")
                    ctx.add_metric("emails_fetched", 0)
                    stats.ended_at = datetime.now(timezone.utc).isoformat()
                    return stats

                # Stage 2: Normalize
                normalized = self._run_normalize(stats, ctx, raw_emails)
                if not normalized:
                    logger.info("No emails after normalization")
                    stats.ended_at = datetime.now(timezone.utc).isoformat()
                    return stats

                # Stage 3: Match
                matches = self._run_match(stats, ctx, normalized)

                # Stages 4-7: Persist, Extract, Classify, Index
                # (Implemented in later phases)
                self._run_persist(stats, ctx, matches, raw_emails)

                # Record metrics
                ctx.set_metrics({
                    "emails_fetched": stats.emails_found,
                    "emails_normalized": stats.emails_normalized,
                    "duplicates_skipped": stats.duplicates_skipped,
                    "matched_existing": stats.matched_existing,
                    "new_deals": stats.new_deals,
                    "junk_rejected": stats.junk_rejected,
                })

        except Exception as e:
            logger.error(f"Pipeline failed: {e}")
            stats.errors.append(str(e))
            raise
        finally:
            stats.ended_at = datetime.now(timezone.utc).isoformat()
            if stats.started_at:
                start = datetime.fromisoformat(stats.started_at.replace('Z', '+00:00'))
                end = datetime.fromisoformat(stats.ended_at.replace('Z', '+00:00'))
                # Ensure both are timezone-aware
                if start.tzinfo is None:
                    start = start.replace(tzinfo=timezone.utc)
                if end.tzinfo is None:
                    end = end.replace(tzinfo=timezone.utc)
                stats.duration_seconds = (end - start).total_seconds()

            # Update run record
            if not self.options.dry_run:
                self.store.end_run(
                    self.run_id,
                    status="success" if not stats.errors else "fail",
                    emails_fetched=stats.emails_found,
                    emails_processed=stats.emails_normalized,
                    stage_timings=stats.stage_timings,
                    errors=stats.errors,
                )

        logger.info(
            f"[{self.run_id}] Pipeline complete: "
            f"{stats.emails_normalized} processed, "
            f"{stats.matched_existing} matched, "
            f"{stats.new_deals} new deals, "
            f"{stats.duration_seconds:.1f}s"
        )

        return stats

    def _run_preflight(self, stats: PipelineStats, ctx) -> None:
        """Execute preflight stage."""
        with timed_stage("preflight", self.run_id, self.store) as timer:
            stage = PreflightStage(self.config)
            result = stage.run()

            if not result.passed:
                for error in result.errors:
                    stats.errors.append(f"Preflight: {error}")
                raise RuntimeError(f"Preflight failed: {result.errors}")

            logger.info("Preflight passed")
            stats.stage_timings["preflight"] = timer.duration_ms

    def _run_fetch(self, stats: PipelineStats, ctx) -> List[RawEmail]:
        """Execute fetch stage."""
        with timed_stage("fetch", self.run_id, self.store) as timer:
            self.checkpoint_mgr.begin_stage(1, total_items=self.options.max_emails)

            stage = FetchStage(self.config)

            # Calculate since date
            since_date = self.options.since_date
            if not since_date and self.options.days_lookback:
                since_date = datetime.now(timezone.utc) - timedelta(days=self.options.days_lookback)

            result = stage.run(
                since_date=since_date,
                hours_back=self.options.hours_lookback,
                max_results=self.options.max_emails,
                broker_emails=self.options.broker_emails,
                broker_domains=self.options.broker_domains,
            )

            if not result.success:
                stats.errors.append(f"Fetch: {result.error}")
                raise RuntimeError(f"Fetch failed: {result.error}")

            stats.emails_found = result.total_found
            stats.emails_filtered = result.filtered_count
            stats.stage_timings["fetch"] = timer.duration_ms

            self.checkpoint_mgr.complete_stage(1)

            return result.emails

    def _run_normalize(
        self,
        stats: PipelineStats,
        ctx,
        raw_emails: List[RawEmail]
    ) -> List[NormalizedEmail]:
        """Execute normalize stage."""
        with timed_stage("normalize", self.run_id, self.store) as timer:
            self.checkpoint_mgr.begin_stage(2, total_items=len(raw_emails))

            # In rebuild mode, don't check for duplicates
            check_duplicates = not self.options.rebuild

            stage = NormalizeStage(self.config, check_duplicates=check_duplicates)
            result = stage.run(raw_emails, self.run_id)

            stats.emails_normalized = len(result.normalized)
            stats.duplicates_skipped = result.skipped_duplicates
            stats.stage_timings["normalize"] = timer.duration_ms

            self.checkpoint_mgr.complete_stage(2)

            return result.normalized

    def _run_match(
        self,
        stats: PipelineStats,
        ctx,
        normalized: List[NormalizedEmail]
    ) -> List[MatchResult]:
        """Execute match stage."""
        with timed_stage("match", self.run_id, self.store) as timer:
            self.checkpoint_mgr.begin_stage(3, total_items=len(normalized))

            stage = MatchStage(self.config)
            result = stage.run(normalized, self.run_id)

            stats.matched_existing = result.matched_existing
            stats.new_deals = result.new_deals
            stats.junk_rejected = result.junk_rejected
            stats.stage_timings["match"] = timer.duration_ms

            self.checkpoint_mgr.complete_stage(3)

            return result.matches

    def _run_persist(
        self,
        stats: PipelineStats,
        ctx,
        matches: List[MatchResult],
        raw_emails: List[RawEmail]
    ) -> None:
        """Execute persist stage with event emission."""
        with timed_stage("persist", self.run_id, self.store) as timer:
            self.checkpoint_mgr.begin_stage(4, total_items=len(matches))

            stage = PersistStage(self.config)
            result = stage.run(
                matches=matches,
                run_id=self.run_id,
                dry_run=self.options.dry_run
            )

            stats.files_saved = result.emails_persisted
            if result.errors:
                for error in result.errors:
                    stats.errors.append(f"Persist: {error}")

            logger.info(
                f"Persist complete: {result.emails_persisted} saved, "
                f"{result.events_emitted} events emitted"
            )

            stats.stage_timings["persist"] = timer.duration_ms
            self.checkpoint_mgr.complete_stage(4)


def main():
    """CLI entry point."""
    import argparse

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s"
    )

    parser = argparse.ArgumentParser(description="Email ingestion pipeline")
    parser.add_argument("--dry-run", action="store_true", help="Preview without changes")
    parser.add_argument("--rebuild", action="store_true", help="Reprocess historical emails")
    parser.add_argument("--days", type=int, default=3, help="Days to look back")
    parser.add_argument("--since", type=str, help="Process since date (YYYY-MM-DD)")
    parser.add_argument("--max-emails", type=int, default=100, help="Max emails to fetch")
    parser.add_argument("--skip-preflight", action="store_true", help="Skip preflight checks")

    args = parser.parse_args()

    options = PipelineOptions(
        dry_run=args.dry_run,
        rebuild=args.rebuild,
        days_lookback=args.days,
        max_emails=args.max_emails,
        skip_preflight=args.skip_preflight,
    )

    if args.since:
        try:
            options.since_date = datetime.fromisoformat(args.since)
        except ValueError:
            logger.error(f"Invalid date format: {args.since}")
            sys.exit(1)

    pipeline = Pipeline(options=options)

    try:
        stats = pipeline.run()
        if stats.errors:
            sys.exit(1)
    except Exception as e:
        logger.error(f"Pipeline failed: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
