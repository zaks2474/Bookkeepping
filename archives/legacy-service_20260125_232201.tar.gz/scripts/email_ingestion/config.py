"""
Configuration for the email ingestion pipeline.

All paths and settings can be overridden via environment variables.
"""

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional, List


@dataclass
class IngestConfig:
    """Configuration for email ingestion pipeline."""

    # Paths
    dataroom_root: Path = field(default_factory=lambda: Path(
        os.getenv("DATAROOM_ROOT", "/home/zaks/DataRoom")
    ))
    state_db_path: Path = field(default_factory=lambda: Path(
        os.getenv("ZAKOPS_STATE_DB", "/home/zaks/DataRoom/.deal-registry/ingest_state.db")
    ))
    registry_path: Path = field(default_factory=lambda: Path(
        os.getenv("ZAKOPS_DEAL_REGISTRY_PATH", "/home/zaks/DataRoom/.deal-registry/deal_registry.json")
    ))
    quarantine_path: Path = field(default_factory=lambda: Path(
        os.getenv("ZAKOPS_QUARANTINE_PATH", "/home/zaks/DataRoom/.deal-registry/quarantine.json")
    ))
    run_ledger_path: Path = field(default_factory=lambda: Path(
        os.getenv("ZAKOPS_RUN_LEDGER_PATH", "/home/zaks/logs/run-ledger.jsonl")
    ))
    intake_dropzone_path: Path = field(default_factory=lambda: Path(
        os.getenv("ZAKOPS_INTAKE_DROPZONE", "/home/zaks/DataRoom/.intake-dropzone")
    ))
    cache_dir: Path = field(default_factory=lambda: Path(
        os.getenv("ZAKOPS_CACHE_DIR", "/home/zaks/.cache")
    ))
    log_dir: Path = field(default_factory=lambda: Path(
        os.getenv("ZAKOPS_LOG_DIR", "/home/zaks/logs")
    ))

    # IMAP settings
    imap_server: str = field(default_factory=lambda: os.getenv("IMAP_SERVER", "imap.gmail.com"))
    imap_port: int = field(default_factory=lambda: int(os.getenv("IMAP_PORT", "993")))
    credentials_file: Path = field(default_factory=lambda: Path(
        os.getenv("EMAIL_SYNC_CREDENTIALS", "/home/zaks/.config/email_sync.env")
    ))

    # RAG settings
    rag_api_url: str = field(default_factory=lambda: os.getenv("RAG_API_URL", "http://localhost:8052/rag/add"))
    rag_url_prefix: str = field(default_factory=lambda: os.getenv(
        "ZAKOPS_RAG_URL_PREFIX", "https://dataroom.local/DataRoom"
    ))

    # Gemini worker settings
    gemini_enabled: bool = field(default_factory=lambda:
        os.getenv("CLASSIFICATION_ENABLE_CLOUD", "").lower() == "true"
    )
    gemini_daily_budget_usd: float = field(default_factory=lambda:
        float(os.getenv("GEMINI_DAILY_BUDGET_USD", "5.0"))
    )
    gemini_per_request_max_usd: float = field(default_factory=lambda:
        float(os.getenv("GEMINI_PER_REQUEST_MAX_USD", "0.50"))
    )
    gemini_timeout_seconds: int = field(default_factory=lambda:
        int(os.getenv("GEMINI_TIMEOUT_SECONDS", "45"))
    )

    # Processing limits
    max_attachment_size_mb: int = field(default_factory=lambda:
        int(os.getenv("MAX_ATTACHMENT_SIZE_MB", "50"))
    )
    max_extract_chars: int = field(default_factory=lambda:
        int(os.getenv("MAX_EXTRACT_CHARS", "100000"))
    )
    max_index_file_size_mb: int = field(default_factory=lambda:
        int(os.getenv("MAX_INDEX_FILE_SIZE_MB", "10"))
    )
    pdf_table_max_pages: int = field(default_factory=lambda:
        int(os.getenv("EMAIL_SYNC_PDF_TABLE_MAX_PAGES", "60"))
    )

    # Matching thresholds
    match_confidence_accept: float = field(default_factory=lambda:
        float(os.getenv("MATCH_CONFIDENCE_ACCEPT", "0.70"))
    )
    match_confidence_quarantine: float = field(default_factory=lambda:
        float(os.getenv("MATCH_CONFIDENCE_QUARANTINE", "0.40"))
    )

    # Auth-required domains (links that need operator intervention)
    auth_required_domains: List[str] = field(default_factory=lambda: [
        "axial.net",
        "tupelo.ai",
        "vestedbb.com",
        "dealroom.net",
        "firmex.com",
        "docusign.com",
        "adobesign.com",
        "hellosign.com",
        "pandadoc.com",
    ])

    # Acquisition keywords for email filtering
    acquisition_keywords: List[str] = field(default_factory=lambda: [
        "CIM", "teaser", "NDA", "listing", "opportunity",
        "acquisition", "executive summary", "confidential memorandum",
        "business for sale", "asking price", "EBITDA", "SDE",
        "seller financing", "deal flow", "investment opportunity",
    ])

    def ensure_directories(self) -> None:
        """Ensure all required directories exist."""
        dirs = [
            self.state_db_path.parent,
            self.intake_dropzone_path,
            self.cache_dir,
            self.log_dir,
        ]
        for d in dirs:
            d.mkdir(parents=True, exist_ok=True)


# Singleton config instance
_config: Optional[IngestConfig] = None


def get_config() -> IngestConfig:
    """Get or create the singleton config instance."""
    global _config
    if _config is None:
        _config = IngestConfig()
    return _config


def reset_config() -> None:
    """Reset config for testing."""
    global _config
    _config = None
