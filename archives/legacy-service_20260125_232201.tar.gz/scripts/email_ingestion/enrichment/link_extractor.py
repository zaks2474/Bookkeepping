"""
Link Extractor - Extract and classify URLs from email content.

Handles:
- URL extraction from text/HTML
- URL normalization and deduplication
- Classification by type (CIM, teaser, dataroom, etc.)
- Auth-required detection
- Vendor identification
"""

import re
import logging
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import List, Optional, Set, Tuple
from urllib.parse import urlparse, parse_qs, urljoin

logger = logging.getLogger(__name__)


class LinkType(Enum):
    """Classification of material link types."""
    CIM = "cim"
    TEASER = "teaser"
    DATAROOM = "dataroom"
    NDA = "nda"
    FINANCIALS = "financials"
    CALENDAR = "calendar"
    DOCS = "docs"
    UNKNOWN = "unknown"


class LinkStatus(Enum):
    """Status of a material link."""
    PENDING = "pending"
    FETCHED = "fetched"
    AUTH_REQUIRED = "auth_required"
    FAILED = "failed"
    EXPIRED = "expired"


# Known vendors and their patterns
VENDOR_PATTERNS = {
    "sharefile": [r"sharefile\.com", r"sf-api\.com"],
    "dropbox": [r"dropbox\.com", r"db\.tt"],
    "google_drive": [r"drive\.google\.com", r"docs\.google\.com"],
    "onedrive": [r"onedrive\.live\.com", r"1drv\.ms", r"sharepoint\.com"],
    "box": [r"box\.com", r"app\.box\.com"],
    "datasite": [r"datasite\.com", r"merrillcorp\.com"],
    "intralinks": [r"intralinks\.com", r"il\.ws"],
    "firmex": [r"firmex\.com"],
    "axial": [r"axial\.net", r"axial\.com"],
    "dealroom": [r"dealroom\.net"],
    "tupelo": [r"tupelo\.ai"],
    "vestedbb": [r"vestedbb\.com"],
    "docusign": [r"docusign\.com", r"docusign\.net"],
    "pandadoc": [r"pandadoc\.com"],
    "calendly": [r"calendly\.com"],
    "hubspot": [r"hubspot\.com", r"hs-sites\.com"],
    "acquire": [r"acquire\.com"],
}

# Domains that typically require authentication
AUTH_REQUIRED_DOMAINS = {
    "axial.net",
    "axial.com",
    "tupelo.ai",
    "vestedbb.com",
    "dealroom.net",
    "firmex.com",
    "datasite.com",
    "intralinks.com",
    "merrillcorp.com",
}

# URL path patterns that suggest auth is required
AUTH_PATH_PATTERNS = [
    r"/login",
    r"/signin",
    r"/auth",
    r"/sso",
    r"/oauth",
    r"/account",
    r"/secure",
]

# Link type classification patterns
LINK_TYPE_PATTERNS = {
    LinkType.CIM: [
        r"cim",
        r"confidential.*information.*memorandum",
        r"information.*memorandum",
        r"offering.*memorandum",
        r"investment.*memorandum",
    ],
    LinkType.TEASER: [
        r"teaser",
        r"executive.*summary",
        r"blind.*profile",
        r"investment.*summary",
    ],
    LinkType.DATAROOM: [
        r"dataroom",
        r"data.*room",
        r"vdr",
        r"virtual.*data.*room",
        r"due.*diligence",
    ],
    LinkType.NDA: [
        r"nda",
        r"non.*disclosure",
        r"confidentiality.*agreement",
        r"ca\b",
    ],
    LinkType.FINANCIALS: [
        r"financial",
        r"p&l",
        r"balance.*sheet",
        r"income.*statement",
        r"cash.*flow",
    ],
    LinkType.CALENDAR: [
        r"calendar",
        r"schedule",
        r"booking",
        r"appointment",
        r"meet",
        r"calendly",
    ],
    LinkType.DOCS: [
        r"document",
        r"file",
        r"attachment",
        r"download",
    ],
}


@dataclass
class MaterialLink:
    """Represents a material link extracted from an email."""
    url: str
    normalized_url: str
    link_type: LinkType = LinkType.UNKNOWN
    label: Optional[str] = None
    source_email_id: Optional[str] = None
    source_timestamp: Optional[str] = None
    requires_auth: bool = False
    vendor_hint: Optional[str] = None
    status: LinkStatus = LinkStatus.PENDING
    context_text: Optional[str] = None  # Surrounding text for classification
    classification_confidence: float = 0.0

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "url": self.url,
            "normalized_url": self.normalized_url,
            "link_type": self.link_type.value,
            "label": self.label,
            "source_email_id": self.source_email_id,
            "source_timestamp": self.source_timestamp,
            "requires_auth": self.requires_auth,
            "vendor_hint": self.vendor_hint,
            "status": self.status.value,
            "context_text": self.context_text,
            "classification_confidence": self.classification_confidence,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "MaterialLink":
        """Create from dictionary."""
        return cls(
            url=data["url"],
            normalized_url=data["normalized_url"],
            link_type=LinkType(data.get("link_type", "unknown")),
            label=data.get("label"),
            source_email_id=data.get("source_email_id"),
            source_timestamp=data.get("source_timestamp"),
            requires_auth=data.get("requires_auth", False),
            vendor_hint=data.get("vendor_hint"),
            status=LinkStatus(data.get("status", "pending")),
            context_text=data.get("context_text"),
            classification_confidence=data.get("classification_confidence", 0.0),
        )


class LinkExtractor:
    """
    Extracts and classifies URLs from email content.

    Usage:
        extractor = LinkExtractor()
        links = extractor.extract(email_body, email_html)
        for link in links:
            print(f"{link.url} -> {link.link_type.value}")
    """

    # URL regex pattern
    URL_PATTERN = re.compile(
        r'https?://[^\s<>"\')\]]+',
        re.IGNORECASE
    )

    # HTML href pattern
    HREF_PATTERN = re.compile(
        r'<a\s+[^>]*href=["\']([^"\']+)["\'][^>]*>([^<]*)</a>',
        re.IGNORECASE | re.DOTALL
    )

    # Tracking/redirect URL patterns to skip
    SKIP_PATTERNS = [
        r"unsubscribe",
        r"email.*preferences",
        r"manage.*subscription",
        r"view.*browser",
        r"tracking",
        r"click\.",
        r"trk\.",
        r"pixel",
        r"beacon",
        r"t\.co/",  # Twitter shortlinks (tracking)
        r"bit\.ly/.*utm",  # Bitly with tracking
    ]

    def __init__(self):
        self._skip_compiled = [re.compile(p, re.IGNORECASE) for p in self.SKIP_PATTERNS]
        self._vendor_compiled = {
            vendor: [re.compile(p, re.IGNORECASE) for p in patterns]
            for vendor, patterns in VENDOR_PATTERNS.items()
        }
        self._type_compiled = {
            link_type: [re.compile(p, re.IGNORECASE) for p in patterns]
            for link_type, patterns in LINK_TYPE_PATTERNS.items()
        }

    def extract(
        self,
        body_text: Optional[str] = None,
        body_html: Optional[str] = None,
        source_email_id: Optional[str] = None,
        source_timestamp: Optional[str] = None,
    ) -> List[MaterialLink]:
        """
        Extract and classify all material links from email content.

        Args:
            body_text: Plain text email body
            body_html: HTML email body
            source_email_id: Email message ID for tracking
            source_timestamp: Email received timestamp

        Returns:
            List of MaterialLink objects, deduplicated and classified
        """
        links: List[MaterialLink] = []
        seen_urls: Set[str] = set()

        # Extract from HTML (preferred - includes labels)
        if body_html:
            html_links = self._extract_from_html(body_html)
            for url, label, context in html_links:
                normalized = self._normalize_url(url)
                if normalized and normalized not in seen_urls:
                    if not self._should_skip(url, normalized):
                        seen_urls.add(normalized)
                        link = self._create_link(
                            url, normalized, label, context,
                            source_email_id, source_timestamp
                        )
                        links.append(link)

        # Extract from plain text
        if body_text:
            text_links = self._extract_from_text(body_text)
            for url, context in text_links:
                normalized = self._normalize_url(url)
                if normalized and normalized not in seen_urls:
                    if not self._should_skip(url, normalized):
                        seen_urls.add(normalized)
                        link = self._create_link(
                            url, normalized, None, context,
                            source_email_id, source_timestamp
                        )
                        links.append(link)

        logger.debug(f"Extracted {len(links)} links from email")
        return links

    def _extract_from_html(self, html: str) -> List[Tuple[str, Optional[str], str]]:
        """Extract URLs from HTML with their labels and context."""
        results = []

        for match in self.HREF_PATTERN.finditer(html):
            url = match.group(1)
            label = match.group(2).strip()

            # Get surrounding context (100 chars before/after)
            start = max(0, match.start() - 100)
            end = min(len(html), match.end() + 100)
            context = html[start:end]

            # Clean label
            label = re.sub(r'\s+', ' ', label).strip()
            if not label:
                label = None

            results.append((url, label, context))

        # Also find bare URLs not in href
        for match in self.URL_PATTERN.finditer(html):
            url = match.group(0)
            # Check if this URL is already captured via href
            if not any(url in r[0] for r in results):
                start = max(0, match.start() - 100)
                end = min(len(html), match.end() + 100)
                context = html[start:end]
                results.append((url, None, context))

        return results

    def _extract_from_text(self, text: str) -> List[Tuple[str, str]]:
        """Extract URLs from plain text with context."""
        results = []

        for match in self.URL_PATTERN.finditer(text):
            url = match.group(0)
            # Get surrounding context
            start = max(0, match.start() - 100)
            end = min(len(text), match.end() + 100)
            context = text[start:end]
            results.append((url, context))

        return results

    def _normalize_url(self, url: str) -> Optional[str]:
        """Normalize URL for deduplication."""
        try:
            # Clean trailing punctuation
            url = url.rstrip('.,;:!?)\'"]')

            parsed = urlparse(url)
            if not parsed.scheme or not parsed.netloc:
                return None

            # Lowercase scheme and host
            normalized = f"{parsed.scheme.lower()}://{parsed.netloc.lower()}"

            # Keep path but normalize
            path = parsed.path.rstrip('/')
            if path:
                normalized += path

            # Keep query params (they often contain important info)
            if parsed.query:
                # Remove common tracking params
                params = parse_qs(parsed.query)
                filtered = {
                    k: v for k, v in params.items()
                    if not k.lower().startswith(('utm_', 'ref', 'source', 'mc_', 'fb_'))
                }
                if filtered:
                    from urllib.parse import urlencode
                    normalized += '?' + urlencode(filtered, doseq=True)

            return normalized

        except Exception as e:
            logger.debug(f"Failed to normalize URL {url}: {e}")
            return None

    def _should_skip(self, url: str, normalized: str) -> bool:
        """Check if URL should be skipped (tracking, unsubscribe, etc.)."""
        combined = url + " " + normalized
        for pattern in self._skip_compiled:
            if pattern.search(combined):
                return True
        return False

    def _create_link(
        self,
        url: str,
        normalized: str,
        label: Optional[str],
        context: str,
        source_email_id: Optional[str],
        source_timestamp: Optional[str],
    ) -> MaterialLink:
        """Create a MaterialLink with classification."""
        link = MaterialLink(
            url=url,
            normalized_url=normalized,
            label=label,
            source_email_id=source_email_id,
            source_timestamp=source_timestamp,
            context_text=context[:200] if context else None,
        )

        # Detect vendor
        link.vendor_hint = self._detect_vendor(normalized)

        # Detect if auth required
        link.requires_auth = self._requires_auth(normalized, link.vendor_hint)
        if link.requires_auth:
            link.status = LinkStatus.AUTH_REQUIRED

        # Classify link type
        link.link_type, link.classification_confidence = self._classify_type(
            label, context, normalized
        )

        return link

    def _detect_vendor(self, url: str) -> Optional[str]:
        """Detect vendor from URL."""
        for vendor, patterns in self._vendor_compiled.items():
            for pattern in patterns:
                if pattern.search(url):
                    return vendor
        return None

    def _requires_auth(self, url: str, vendor: Optional[str]) -> bool:
        """Determine if URL requires authentication."""
        parsed = urlparse(url)
        domain = parsed.netloc.lower()

        # Remove www prefix
        if domain.startswith('www.'):
            domain = domain[4:]

        # Check known auth-required domains
        for auth_domain in AUTH_REQUIRED_DOMAINS:
            if domain == auth_domain or domain.endswith('.' + auth_domain):
                return True

        # Check URL path patterns
        for pattern in AUTH_PATH_PATTERNS:
            if re.search(pattern, parsed.path, re.IGNORECASE):
                return True

        # Known vendors that always require auth
        auth_vendors = {"axial", "tupelo", "vestedbb", "dealroom", "firmex", "datasite", "intralinks"}
        if vendor in auth_vendors:
            return True

        return False

    def _classify_type(
        self,
        label: Optional[str],
        context: str,
        url: str
    ) -> Tuple[LinkType, float]:
        """Classify link type based on label, context, and URL."""
        # Combine all text for matching
        combined = " ".join(filter(None, [label, context, url])).lower()

        # Score each type
        scores = {}
        for link_type, patterns in self._type_compiled.items():
            score = 0
            for pattern in patterns:
                matches = pattern.findall(combined)
                score += len(matches)

                # Bonus for label match (more reliable)
                if label and pattern.search(label.lower()):
                    score += 2

                # Bonus for URL path match
                if pattern.search(url.lower()):
                    score += 1

            if score > 0:
                scores[link_type] = score

        if not scores:
            return LinkType.UNKNOWN, 0.0

        # Get highest scoring type
        best_type = max(scores, key=scores.get)
        max_score = scores[best_type]

        # Calculate confidence (normalized 0-1)
        confidence = min(1.0, max_score / 5.0)

        return best_type, confidence

    def extract_from_email(self, email) -> List[MaterialLink]:
        """
        Convenience method to extract links from a NormalizedEmail object.

        Args:
            email: NormalizedEmail object with body_text, body_html, message_id, received_date

        Returns:
            List of MaterialLink objects
        """
        return self.extract(
            body_text=getattr(email, 'body_text', None),
            body_html=getattr(email, 'body_html', None),
            source_email_id=getattr(email, 'message_id', None),
            source_timestamp=getattr(email, 'received_date', None),
        )
