"""
Name Resolver - Resolve and normalize company names and display names.

Handles:
- Company name extraction from email subjects and bodies
- Display name normalization (clean, consistent formatting)
- Broker name extraction
- Alias detection and tracking
"""

import re
import logging
from dataclasses import dataclass, field
from typing import List, Optional, Set, Tuple, Dict
from enum import Enum

logger = logging.getLogger(__name__)


class NameSource(Enum):
    """Source of a resolved name."""
    SUBJECT = "subject"
    BODY = "body"
    SENDER = "sender"
    ATTACHMENT = "attachment"
    CIM = "cim"
    MANUAL = "manual"


@dataclass
class CompanyNameResult:
    """Result of company name resolution."""
    resolved_name: str
    display_name: str
    confidence: float
    source: NameSource
    raw_matches: List[str] = field(default_factory=list)
    is_code_name: bool = False
    industry_hints: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "resolved_name": self.resolved_name,
            "display_name": self.display_name,
            "confidence": self.confidence,
            "source": self.source.value,
            "raw_matches": self.raw_matches,
            "is_code_name": self.is_code_name,
            "industry_hints": self.industry_hints,
        }


@dataclass
class BrokerInfo:
    """Extracted broker information."""
    name: str
    email: Optional[str] = None
    company: Optional[str] = None
    phone: Optional[str] = None
    domain: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "email": self.email,
            "company": self.company,
            "phone": self.phone,
            "domain": self.domain,
        }


# Common words to strip from company names
STRIP_WORDS = {
    "inc", "inc.", "llc", "llc.", "ltd", "ltd.", "corp", "corp.",
    "corporation", "company", "co", "co.", "group", "holdings",
    "enterprises", "services", "solutions", "partners", "lp", "lp.",
    "the", "a", "an",
}

# Common broker company patterns
BROKER_PATTERNS = [
    r"(?:from|via|presented by|listed by)\s+([A-Z][A-Za-z\s&]+(?:Advisors?|Partners?|Capital|Group|LLC|Inc\.?))",
    r"([A-Z][A-Za-z\s&]+(?:M&A|Mergers|Acquisitions|Business Brokers?))",
    r"([A-Z][A-Za-z\s&]+(?:Investment Banking|Corporate Finance))",
]

# Industry keywords for hinting
INDUSTRY_KEYWORDS = {
    "software": ["software", "saas", "tech", "technology", "app", "platform", "digital"],
    "manufacturing": ["manufacturing", "industrial", "fabrication", "machining"],
    "healthcare": ["healthcare", "medical", "health", "pharma", "clinical"],
    "services": ["services", "consulting", "agency", "professional"],
    "retail": ["retail", "store", "commerce", "ecommerce", "e-commerce"],
    "food": ["food", "beverage", "restaurant", "catering", "hospitality"],
    "construction": ["construction", "building", "contractor", "hvac", "plumbing"],
    "logistics": ["logistics", "transportation", "shipping", "freight", "distribution"],
    "finance": ["finance", "financial", "insurance", "accounting", "tax"],
}

# Code name patterns (Project X, Operation Y, etc.)
CODE_NAME_PATTERNS = [
    r"Project\s+([A-Z][a-z]+)",
    r"Operation\s+([A-Z][a-z]+)",
    r"Deal\s+([A-Z][a-z]+)",
    r"Target\s+([A-Z][a-z]+)",
]


class NameResolver:
    """
    Resolves and normalizes company names from email content.

    Usage:
        resolver = NameResolver()
        result = resolver.resolve_company_name(subject, body)
        print(f"Company: {result.display_name} ({result.confidence:.0%})")
    """

    def __init__(self):
        self._broker_patterns = [re.compile(p, re.IGNORECASE) for p in BROKER_PATTERNS]
        self._code_patterns = [re.compile(p) for p in CODE_NAME_PATTERNS]

    def resolve_company_name(
        self,
        subject: Optional[str] = None,
        body: Optional[str] = None,
        sender_name: Optional[str] = None,
        existing_aliases: Optional[List[str]] = None,
    ) -> Optional[CompanyNameResult]:
        """
        Resolve company name from email content.

        Args:
            subject: Email subject line
            body: Email body text
            sender_name: Sender display name
            existing_aliases: Known aliases for matching

        Returns:
            CompanyNameResult if found, None otherwise
        """
        candidates = []

        # Try subject first (highest confidence)
        if subject:
            subject_result = self._extract_from_subject(subject)
            if subject_result:
                candidates.append(subject_result)

        # Try body
        if body:
            body_result = self._extract_from_body(body[:2000])  # Limit body scan
            if body_result:
                candidates.append(body_result)

        # Score candidates against existing aliases
        if existing_aliases and candidates:
            for candidate in candidates:
                alias_boost = self._score_against_aliases(
                    candidate.resolved_name,
                    existing_aliases
                )
                candidate.confidence = min(1.0, candidate.confidence + alias_boost)

        if not candidates:
            return None

        # Return highest confidence
        best = max(candidates, key=lambda x: x.confidence)
        return best

    def _extract_from_subject(self, subject: str) -> Optional[CompanyNameResult]:
        """Extract company name from email subject."""
        raw_matches = []

        # Check for code names first
        for pattern in self._code_patterns:
            match = pattern.search(subject)
            if match:
                code_name = match.group(0)
                return CompanyNameResult(
                    resolved_name=code_name,
                    display_name=code_name,
                    confidence=0.9,
                    source=NameSource.SUBJECT,
                    raw_matches=[code_name],
                    is_code_name=True,
                )

        # Common subject patterns
        patterns = [
            # "RE: Company Name - Deal Type"
            r"(?:RE:|FW:|Fwd:)?\s*([A-Z][A-Za-z0-9\s&\-]+?)(?:\s*[-–—]\s*|\s*:\s*)",
            # "New Listing: Company Name"
            r"(?:New Listing|Just Listed|For Sale|Available)[:!]?\s*([A-Z][A-Za-z0-9\s&\-]+)",
            # "CIM - Company Name"
            r"(?:CIM|Teaser|Executive Summary|NDA)(?:\s*[-–—:])?\s*([A-Z][A-Za-z0-9\s&\-]+)",
            # Quoted name "Company Name"
            r'"([A-Z][A-Za-z0-9\s&\-]+)"',
        ]

        for pattern in patterns:
            match = re.search(pattern, subject)
            if match:
                name = match.group(1).strip()
                # Skip if too short or just common words
                if len(name) > 3 and name.lower() not in STRIP_WORDS:
                    raw_matches.append(name)

        if not raw_matches:
            return None

        # Take first match (most reliable in subject)
        best_match = raw_matches[0]
        display_name = self._normalize_display_name(best_match)
        industry_hints = self._detect_industry(subject)

        return CompanyNameResult(
            resolved_name=self._normalize_for_matching(best_match),
            display_name=display_name,
            confidence=0.7,
            source=NameSource.SUBJECT,
            raw_matches=raw_matches,
            industry_hints=industry_hints,
        )

    def _extract_from_body(self, body: str) -> Optional[CompanyNameResult]:
        """Extract company name from email body."""
        raw_matches = []

        # Look for explicit company mentions
        patterns = [
            # "the Company" or "Target Company" often refers to deal target
            r"(?:the|target|subject)\s+company\s*[,:]\s*([A-Z][A-Za-z0-9\s&\-]+)",
            # "Company Name is a leading..."
            r"([A-Z][A-Za-z0-9\s&]+)\s+is\s+a\s+(?:leading|premier|growing|established)",
            # "Business Overview: Company Name"
            r"(?:Business|Company)\s+(?:Overview|Summary|Description)\s*[:\-]\s*([A-Z][A-Za-z0-9\s&\-]+)",
            # "About Company Name"
            r"About\s+([A-Z][A-Za-z0-9\s&\-]+)",
        ]

        for pattern in patterns:
            matches = re.findall(pattern, body)
            for match in matches:
                name = match.strip()
                if len(name) > 3 and name.lower() not in STRIP_WORDS:
                    raw_matches.append(name)

        if not raw_matches:
            return None

        # Take most common match
        from collections import Counter
        counter = Counter(raw_matches)
        best_match = counter.most_common(1)[0][0]
        display_name = self._normalize_display_name(best_match)
        industry_hints = self._detect_industry(body)

        return CompanyNameResult(
            resolved_name=self._normalize_for_matching(best_match),
            display_name=display_name,
            confidence=0.5,  # Lower confidence from body
            source=NameSource.BODY,
            raw_matches=list(set(raw_matches)),
            industry_hints=industry_hints,
        )

    def _normalize_display_name(self, name: str) -> str:
        """Normalize name for display (clean, proper casing)."""
        # Remove extra whitespace
        name = re.sub(r'\s+', ' ', name).strip()

        # Title case, but preserve acronyms
        words = name.split()
        normalized = []

        for word in words:
            # Skip strippable words at start
            if not normalized and word.lower() in {'the', 'a', 'an'}:
                continue

            # Preserve all-caps (likely acronym)
            if word.isupper() and len(word) <= 4:
                normalized.append(word)
            # Preserve mixed case that looks intentional
            elif any(c.isupper() for c in word[1:]):
                normalized.append(word)
            else:
                normalized.append(word.title())

        return ' '.join(normalized)

    def _normalize_for_matching(self, name: str) -> str:
        """Normalize name for matching (lowercase, no punctuation)."""
        # Lowercase
        name = name.lower()

        # Remove punctuation except &
        name = re.sub(r'[^\w\s&]', '', name)

        # Remove strip words
        words = [w for w in name.split() if w not in STRIP_WORDS]

        # Join with single spaces
        return ' '.join(words)

    def _detect_industry(self, text: str) -> List[str]:
        """Detect industry hints from text."""
        text_lower = text.lower()
        industries = []

        for industry, keywords in INDUSTRY_KEYWORDS.items():
            for keyword in keywords:
                if keyword in text_lower:
                    industries.append(industry)
                    break

        return industries

    def _score_against_aliases(self, name: str, aliases: List[str]) -> float:
        """Score name against existing aliases."""
        normalized = self._normalize_for_matching(name)

        for alias in aliases:
            alias_norm = self._normalize_for_matching(alias)

            # Exact match
            if normalized == alias_norm:
                return 0.3

            # Substring match
            if normalized in alias_norm or alias_norm in normalized:
                return 0.2

            # Word overlap
            name_words = set(normalized.split())
            alias_words = set(alias_norm.split())
            overlap = len(name_words & alias_words)
            if overlap >= 2:
                return 0.1

        return 0.0

    def extract_broker_info(
        self,
        sender: str,
        sender_email: str,
        body: Optional[str] = None,
    ) -> Optional[BrokerInfo]:
        """
        Extract broker information from email.

        Args:
            sender: Sender display name
            sender_email: Sender email address
            body: Email body for additional extraction

        Returns:
            BrokerInfo if extractable
        """
        # Parse sender name
        name = self._clean_sender_name(sender)
        if not name:
            return None

        # Extract domain for company hint
        domain = sender_email.split('@')[-1] if '@' in sender_email else None

        # Try to extract company from body
        company = None
        if body:
            for pattern in self._broker_patterns:
                match = pattern.search(body[:1000])
                if match:
                    company = match.group(1).strip()
                    break

        # Try to extract phone from body
        phone = None
        if body:
            phone_match = re.search(
                r'(?:phone|tel|call|mobile)[:.]?\s*([+\d\-.()\s]{10,20})',
                body[:2000],
                re.IGNORECASE
            )
            if phone_match:
                phone = phone_match.group(1).strip()

        return BrokerInfo(
            name=name,
            email=sender_email,
            company=company,
            phone=phone,
            domain=domain,
        )

    def _clean_sender_name(self, sender: str) -> str:
        """Clean sender display name."""
        # Remove email part if present
        if '<' in sender:
            sender = sender.split('<')[0].strip()

        # Remove quotes
        sender = sender.strip('"\'')

        # Remove extra whitespace
        sender = re.sub(r'\s+', ' ', sender).strip()

        return sender

    def generate_display_name_from_deal_id(self, deal_id: str) -> str:
        """
        Generate a clean display name from a deal ID.

        Example: "just-listed-300k-rev-saas-2025" -> "Just Listed 300K Rev SaaS"
        """
        # Remove year suffix
        name = re.sub(r'-\d{4}$', '', deal_id)

        # Split on hyphens
        words = name.split('-')

        # Normalize each word
        normalized = []
        for word in words:
            # Preserve known acronyms
            if word.upper() in {'SBA', 'EBITDA', 'ARR', 'MRR', 'SAAS', 'B2B', 'B2C', 'API'}:
                normalized.append(word.upper())
            # Handle numbers with K/M suffix
            elif re.match(r'^\d+[km]?$', word.lower()):
                normalized.append(word.upper())
            else:
                normalized.append(word.title())

        return ' '.join(normalized)

    def match_existing_deal(
        self,
        resolved_name: str,
        existing_deals: Dict[str, List[str]],  # deal_id -> aliases
    ) -> Optional[Tuple[str, float]]:
        """
        Match resolved name against existing deals.

        Args:
            resolved_name: Normalized company name
            existing_deals: Map of deal_id -> list of aliases

        Returns:
            Tuple of (deal_id, confidence) if matched, None otherwise
        """
        normalized = self._normalize_for_matching(resolved_name)

        best_match = None
        best_score = 0.0

        for deal_id, aliases in existing_deals.items():
            for alias in aliases:
                alias_norm = self._normalize_for_matching(alias)

                # Exact match
                if normalized == alias_norm:
                    return (deal_id, 1.0)

                # Calculate similarity score
                score = self._calculate_similarity(normalized, alias_norm)
                if score > best_score:
                    best_score = score
                    best_match = deal_id

        if best_match and best_score >= 0.6:
            return (best_match, best_score)

        return None

    def _calculate_similarity(self, name1: str, name2: str) -> float:
        """Calculate similarity score between two names."""
        # Simple word overlap score
        words1 = set(name1.split())
        words2 = set(name2.split())

        if not words1 or not words2:
            return 0.0

        intersection = len(words1 & words2)
        union = len(words1 | words2)

        return intersection / union if union > 0 else 0.0
