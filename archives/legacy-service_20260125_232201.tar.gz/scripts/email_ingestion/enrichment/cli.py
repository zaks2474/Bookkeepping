#!/usr/bin/env python3
"""
Enrichment CLI - Command-line interface for deal enrichment operations.

Usage:
    python -m email_ingestion.enrichment.cli audit     # Audit enrichment
    python -m email_ingestion.enrichment.cli pending   # Show pending links
    python -m email_ingestion.enrichment.cli run       # Run enrichment pass
"""

import argparse
import json
import sys
from pathlib import Path
from datetime import datetime


REGISTRY_PATH = Path("/home/zaks/DataRoom/.deal-registry/deal_registry.json")
LINK_QUEUE_PATH = Path("/home/zaks/DataRoom/.deal-registry/link_intake_queue.json")


def cmd_audit():
    """Run enrichment audit and print report."""
    if not REGISTRY_PATH.exists():
        print("  [✗] Registry not found")
        sys.exit(1)

    data = json.loads(REGISTRY_PATH.read_text())
    deals = data.get("deals", {})

    print(f"  Total deals:           {len(deals)}")

    with_materials = sum(1 for d in deals.values() if d.get("materials"))
    with_display = sum(1 for d in deals.values() if d.get("display_name"))
    with_broker = sum(1 for d in deals.values() if d.get("broker"))
    enriched = sum(1 for d in deals.values() if d.get("enriched_at"))
    total_mats = sum(len(d.get("materials", [])) for d in deals.values())

    print(f"  With materials:        {with_materials}")
    print(f"  With display name:     {with_display}")
    print(f"  With broker info:      {with_broker}")
    print(f"  Enriched (any):        {enriched}")
    print(f"  Total material links:  {total_mats}")

    # Count by type
    mat_types = {}
    auth_pending = 0
    for d in deals.values():
        for m in d.get("materials", []):
            t = m.get("link_type", "unknown")
            mat_types[t] = mat_types.get(t, 0) + 1
            if m.get("requires_auth") and m.get("status") in ("pending", "auth_required"):
                auth_pending += 1

    print()
    print("  Materials by type:")
    for t, c in sorted(mat_types.items(), key=lambda x: -x[1]):
        print(f"    {t}: {c}")

    print()
    print(f"  Auth-required pending: {auth_pending}")

    if LINK_QUEUE_PATH.exists():
        queue = json.loads(LINK_QUEUE_PATH.read_text())
        pending = [l for l in queue if l.get("status") == "pending"]
        print(f"  Link queue pending:    {len(pending)}")

    print()
    missing = [d for d in deals if not deals[d].get("display_name")]
    if missing:
        print(f"  [!] {len(missing)} deals missing display_name")
        for did in missing[:5]:
            print(f"      - {did}")
        if len(missing) > 5:
            print(f"      ... and {len(missing) - 5} more")
    else:
        print("  [✓] All deals have display_name")


def cmd_pending():
    """Show pending auth-required links."""
    if not LINK_QUEUE_PATH.exists():
        print("  No link queue found (no auth-required links yet)")
        return

    queue = json.loads(LINK_QUEUE_PATH.read_text())
    pending = [l for l in queue if l.get("status") in ("pending", "auth_required")]

    if not pending:
        print("  [✓] No pending auth-required links")
        return

    print(f"  Pending links: {len(pending)}")
    print()

    by_vendor = {}
    for l in pending:
        v = l.get("vendor_hint", "unknown")
        by_vendor.setdefault(v, []).append(l)

    for vendor, links in sorted(by_vendor.items()):
        print(f"  {vendor}: {len(links)} links")
        for l in links[:3]:
            print(f"    - {l.get('url', '?')[:60]}...")
            print(f"      Deal: {l.get('deal_id', '?')}")


def cmd_run():
    """Run enrichment pass on all deals."""
    print("  Running enrichment pass...")
    print()

    # Import here to avoid circular imports
    sys.path.insert(0, str(Path(__file__).parent.parent.parent))

    from email_ingestion.enrichment.enrichment_stage import EnrichmentStage
    from email_ingestion.state.sqlite_store import get_state_store

    # Get emails for each deal from the state store
    store = get_state_store()
    conn = store._get_connection()
    cursor = conn.cursor()

    # Get all matched emails with their data
    cursor.execute("""
        SELECT deal_id, subject, sender, sender_email, message_id, received_date, body_text, body_html
        FROM processed_emails
        WHERE deal_id IS NOT NULL AND status = 'matched'
        ORDER BY deal_id, received_date
    """)

    deal_emails = {}
    for row in cursor.fetchall():
        deal_id = row[0]
        if deal_id not in deal_emails:
            deal_emails[deal_id] = []
        deal_emails[deal_id].append({
            "subject": row[1] or "",
            "sender": row[2] or "",
            "sender_email": row[3] or "",
            "message_id": row[4],
            "received_date": row[5],
            "body_text": row[6] if len(row) > 6 else None,
            "body_html": row[7] if len(row) > 7 else None,
        })

    if not deal_emails:
        print("  No matched emails found in database")
        print("  Run 'make rebuild-30d' first to populate the database")
        return

    print(f"  Found {sum(len(v) for v in deal_emails.values())} emails for {len(deal_emails)} deals")

    # Run enrichment
    stage = EnrichmentStage(
        dataroom_root=Path("/home/zaks/DataRoom"),
    )
    stats = stage.run(deal_emails, dry_run=False)

    print()
    print("  Enrichment Results:")
    print(f"    Deals processed:      {stats.deals_processed}")
    print(f"    Deals enriched:       {stats.deals_enriched}")
    print(f"    Links found:          {stats.total_links_found}")
    print(f"    Auth-required:        {stats.total_auth_required}")
    print(f"    Display names set:    {stats.display_names_updated}")
    print(f"    Broker info extracted:{stats.broker_info_extracted}")

    if stats.errors:
        print()
        print(f"  [!] {len(stats.errors)} errors:")
        for err in stats.errors[:5]:
            print(f"      - {err}")


def main():
    parser = argparse.ArgumentParser(description="Deal Enrichment CLI")
    parser.add_argument(
        "command",
        choices=["audit", "pending", "run"],
        help="Command to run"
    )

    args = parser.parse_args()

    if args.command == "audit":
        cmd_audit()
    elif args.command == "pending":
        cmd_pending()
    elif args.command == "run":
        cmd_run()


if __name__ == "__main__":
    main()
