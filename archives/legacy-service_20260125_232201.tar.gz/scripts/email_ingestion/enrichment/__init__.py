"""
Deal Enrichment Module

Extracts and normalizes deal information from emails:
- Link extraction and classification
- Company name resolution
- Broker info extraction
- Display name normalization
"""

from .link_extractor import LinkExtractor, MaterialLink
from .name_resolver import NameResolver, CompanyNameResult
from .enrichment_stage import EnrichmentStage, EnrichmentResult

__all__ = [
    'LinkExtractor',
    'MaterialLink',
    'NameResolver',
    'CompanyNameResult',
    'EnrichmentStage',
    'EnrichmentResult',
]
