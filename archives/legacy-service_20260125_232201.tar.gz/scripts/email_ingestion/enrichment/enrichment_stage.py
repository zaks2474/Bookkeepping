"""
Enrichment Stage - Enrich deal records with extracted information.

This stage:
1. Runs link extraction on matched emails
2. Resolves company names and display names
3. Extracts broker information
4. Updates deal records with enrichment data
5. Queues auth-required links for manual download
"""

import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Any
import sys

# Add parent path for imports
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from .link_extractor import LinkExtractor, MaterialLink, LinkType, LinkStatus
from .name_resolver import NameResolver, CompanyNameResult, BrokerInfo

logger = logging.getLogger(__name__)


@dataclass
class EnrichmentResult:
    """Result of enrichment for a single deal."""
    deal_id: str
    success: bool = True

    # Links
    links_found: int = 0
    links_new: int = 0
    auth_required_links: int = 0

    # Names
    display_name_updated: bool = False
    company_name_resolved: bool = False
    broker_info_updated: bool = False

    # Errors
    errors: List[str] = field(default_factory=list)

    # Details
    materials: List[MaterialLink] = field(default_factory=list)
    resolved_name: Optional[CompanyNameResult] = None
    broker_info: Optional[BrokerInfo] = None


@dataclass
class EnrichmentStats:
    """Aggregate stats from enrichment run."""
    deals_processed: int = 0
    deals_enriched: int = 0
    total_links_found: int = 0
    total_auth_required: int = 0
    display_names_updated: int = 0
    broker_info_extracted: int = 0
    errors: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "deals_processed": self.deals_processed,
            "deals_enriched": self.deals_enriched,
            "total_links_found": self.total_links_found,
            "total_auth_required": self.total_auth_required,
            "display_names_updated": self.display_names_updated,
            "broker_info_extracted": self.broker_info_extracted,
            "errors": self.errors,
        }


class EnrichmentStage:
    """
    Enrichment stage for the email ingestion pipeline.

    Enriches deal records with:
    - Material links (CIM, teaser, dataroom, etc.)
    - Display name (cleaned, normalized)
    - Target company name (resolved)
    - Broker information (name, company, phone)
    - Last email timestamp
    """

    def __init__(
        self,
        dataroom_root: Path,
        registry_path: Optional[Path] = None,
        link_queue_path: Optional[Path] = None,
    ):
        self.dataroom_root = Path(dataroom_root)
        self.registry_path = registry_path or (
            self.dataroom_root / ".deal-registry" / "deal_registry.json"
        )
        self.link_queue_path = link_queue_path or (
            self.dataroom_root / ".deal-registry" / "link_intake_queue.json"
        )

        self.link_extractor = LinkExtractor()
        self.name_resolver = NameResolver()

        self._registry_cache = None
        self._link_queue = None

    @property
    def registry(self) -> dict:
        """Load registry lazily."""
        if self._registry_cache is None:
            if self.registry_path.exists():
                with open(self.registry_path) as f:
                    self._registry_cache = json.load(f)
            else:
                self._registry_cache = {"deals": {}, "metadata": {}}
        return self._registry_cache

    def _save_registry(self):
        """Save registry back to disk."""
        if self._registry_cache:
            with open(self.registry_path, 'w') as f:
                json.dump(self._registry_cache, f, indent=2)

    @property
    def link_queue(self) -> List[dict]:
        """Load link queue lazily."""
        if self._link_queue is None:
            if self.link_queue_path.exists():
                with open(self.link_queue_path) as f:
                    self._link_queue = json.load(f)
            else:
                self._link_queue = []
        return self._link_queue

    def _save_link_queue(self):
        """Save link queue to disk."""
        if self._link_queue is not None:
            with open(self.link_queue_path, 'w') as f:
                json.dump(self._link_queue, f, indent=2)

    def run(
        self,
        deal_emails: Dict[str, List[dict]],  # deal_id -> list of email records
        dry_run: bool = False,
    ) -> EnrichmentStats:
        """
        Run enrichment on a batch of deal emails.

        Args:
            deal_emails: Map of deal_id -> list of email records
                        Each email record should have: subject, body_text, body_html,
                        sender, sender_email, message_id, received_date
            dry_run: If True, don't persist changes

        Returns:
            EnrichmentStats with aggregate results
        """
        stats = EnrichmentStats()

        for deal_id, emails in deal_emails.items():
            try:
                result = self.enrich_deal(deal_id, emails, dry_run=dry_run)
                stats.deals_processed += 1

                if result.links_found > 0 or result.display_name_updated or result.broker_info_updated:
                    stats.deals_enriched += 1

                stats.total_links_found += result.links_found
                stats.total_auth_required += result.auth_required_links

                if result.display_name_updated:
                    stats.display_names_updated += 1
                if result.broker_info_updated:
                    stats.broker_info_extracted += 1

                stats.errors.extend(result.errors)

            except Exception as e:
                logger.warning(f"Failed to enrich {deal_id}: {e}")
                stats.errors.append(f"{deal_id}: {e}")

        # Save changes
        if not dry_run:
            self._save_registry()
            self._save_link_queue()

        logger.info(
            f"Enrichment complete: {stats.deals_enriched}/{stats.deals_processed} deals enriched, "
            f"{stats.total_links_found} links found, {stats.total_auth_required} auth-required"
        )

        return stats

    def enrich_deal(
        self,
        deal_id: str,
        emails: List[dict],
        dry_run: bool = False,
    ) -> EnrichmentResult:
        """
        Enrich a single deal from its emails.

        Args:
            deal_id: Deal ID
            emails: List of email records for this deal
            dry_run: If True, don't persist changes

        Returns:
            EnrichmentResult with details
        """
        result = EnrichmentResult(deal_id=deal_id)

        # Get existing deal data
        deal_data = self.registry.get("deals", {}).get(deal_id, {})
        existing_materials = deal_data.get("materials", [])
        existing_urls = {m.get("normalized_url") for m in existing_materials}

        all_links = []
        all_names = []
        all_brokers = []
        last_email_date = None

        # Process each email
        for email in emails:
            # Extract links
            links = self.link_extractor.extract(
                body_text=email.get("body_text"),
                body_html=email.get("body_html"),
                source_email_id=email.get("message_id"),
                source_timestamp=email.get("received_date"),
            )
            all_links.extend(links)

            # Resolve company name
            # Extract alias strings from alias dicts (registry format: [{"alias": "...", ...}, ...])
            raw_aliases = deal_data.get("aliases", [])
            alias_strings = [
                a.get("alias") if isinstance(a, dict) else a
                for a in raw_aliases
                if (isinstance(a, dict) and a.get("alias")) or isinstance(a, str)
            ]
            name_result = self.name_resolver.resolve_company_name(
                subject=email.get("subject"),
                body=email.get("body_text"),
                sender_name=email.get("sender"),
                existing_aliases=alias_strings,
            )
            if name_result:
                all_names.append(name_result)

            # Extract broker info
            broker = self.name_resolver.extract_broker_info(
                sender=email.get("sender", ""),
                sender_email=email.get("sender_email", ""),
                body=email.get("body_text"),
            )
            if broker:
                all_brokers.append(broker)

            # Track last email date
            email_date = email.get("received_date")
            if email_date:
                if last_email_date is None or email_date > last_email_date:
                    last_email_date = email_date

        # Deduplicate and filter new links
        new_links = []
        for link in all_links:
            if link.normalized_url not in existing_urls:
                existing_urls.add(link.normalized_url)
                new_links.append(link)

                if link.requires_auth:
                    result.auth_required_links += 1

        result.links_found = len(all_links)
        result.links_new = len(new_links)
        result.materials = new_links

        # Select best company name
        if all_names:
            best_name = max(all_names, key=lambda x: x.confidence)
            if best_name.confidence >= 0.5:
                result.resolved_name = best_name
                result.company_name_resolved = True

        # Select best broker (most recent)
        if all_brokers:
            result.broker_info = all_brokers[-1]  # Most recent email
            result.broker_info_updated = True

        # Update deal record
        if not dry_run:
            self._update_deal_record(
                deal_id=deal_id,
                new_links=new_links,
                name_result=result.resolved_name,
                broker_info=result.broker_info,
                last_email_date=last_email_date,
            )

            # Check if display name needs updating
            if result.resolved_name and not deal_data.get("display_name"):
                result.display_name_updated = True

        return result

    def _update_deal_record(
        self,
        deal_id: str,
        new_links: List[MaterialLink],
        name_result: Optional[CompanyNameResult],
        broker_info: Optional[BrokerInfo],
        last_email_date: Optional[str],
    ):
        """Update deal record in registry."""
        deals = self.registry.setdefault("deals", {})
        deal = deals.setdefault(deal_id, {})

        # Add new materials
        materials = deal.setdefault("materials", [])
        for link in new_links:
            materials.append(link.to_dict())

            # Queue auth-required links
            if link.requires_auth:
                self._queue_auth_link(deal_id, link)

        # Update display name if not set
        if name_result and not deal.get("display_name"):
            deal["display_name"] = name_result.display_name
            deal["target_company_name"] = name_result.resolved_name
            deal["enrichment_confidence"] = name_result.confidence

            # Add to aliases if not present (use proper Alias format for registry compatibility)
            aliases = deal.setdefault("aliases", [])
            # Check if alias already exists (compare by alias string)
            existing_alias_strs = {
                a.get("alias") if isinstance(a, dict) else a
                for a in aliases
            }
            if name_result.resolved_name not in existing_alias_strs:
                aliases.append({
                    "alias": name_result.resolved_name,
                    "alias_normalized": name_result.resolved_name.lower().replace(" ", "-"),
                    "alias_type": "enrichment",
                    "confidence": name_result.confidence,
                    "source": "enrichment",
                    "created_at": datetime.now(timezone.utc).isoformat(),
                })

        # Update broker info
        if broker_info:
            deal["broker"] = broker_info.to_dict()

        # Update last email timestamp
        if last_email_date:
            deal["last_email_at"] = last_email_date

        # Update enrichment timestamp
        deal["enriched_at"] = datetime.now(timezone.utc).isoformat()

    def _queue_auth_link(self, deal_id: str, link: MaterialLink):
        """Add auth-required link to intake queue."""
        queue_entry = {
            "url": link.url,
            "normalized_url": link.normalized_url,
            "deal_id": deal_id,
            "vendor_hint": link.vendor_hint,
            "link_type": link.link_type.value,
            "status": "pending",
            "source_email_id": link.source_email_id,
            "queued_at": datetime.now(timezone.utc).isoformat(),
        }

        # Check if already queued
        for existing in self.link_queue:
            if existing.get("normalized_url") == link.normalized_url:
                return  # Already queued

        self.link_queue.append(queue_entry)
        logger.info(f"Queued auth-required link for {deal_id}: {link.url[:60]}...")

    def get_pending_auth_links(self) -> List[dict]:
        """Get all pending auth-required links."""
        return [l for l in self.link_queue if l.get("status") == "pending"]

    def mark_link_fetched(
        self,
        normalized_url: str,
        local_path: str,
        operator_note: Optional[str] = None,
    ):
        """Mark a queued link as fetched."""
        for entry in self.link_queue:
            if entry.get("normalized_url") == normalized_url:
                entry["status"] = "fetched"
                entry["local_path"] = local_path
                entry["fetched_at"] = datetime.now(timezone.utc).isoformat()
                if operator_note:
                    entry["operator_note"] = operator_note
                self._save_link_queue()
                return True
        return False

    def audit_enrichment(self) -> dict:
        """
        Audit enrichment quality across all deals.

        Returns:
            Audit report with stats and issues
        """
        report = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "total_deals": 0,
            "deals_with_materials": 0,
            "deals_with_display_name": 0,
            "deals_with_broker": 0,
            "total_materials": 0,
            "materials_by_type": {},
            "auth_required_pending": 0,
            "issues": [],
        }

        deals = self.registry.get("deals", {})
        report["total_deals"] = len(deals)

        for deal_id, deal in deals.items():
            materials = deal.get("materials", [])
            if materials:
                report["deals_with_materials"] += 1
                report["total_materials"] += len(materials)

                for mat in materials:
                    link_type = mat.get("link_type", "unknown")
                    report["materials_by_type"][link_type] = \
                        report["materials_by_type"].get(link_type, 0) + 1

            if deal.get("display_name"):
                report["deals_with_display_name"] += 1
            else:
                report["issues"].append({
                    "deal_id": deal_id,
                    "issue": "missing_display_name",
                })

            if deal.get("broker"):
                report["deals_with_broker"] += 1

        # Count pending auth links
        report["auth_required_pending"] = len(self.get_pending_auth_links())

        return report
