"""
ZakOps Email Ingestion Pipeline

A staged pipeline for email-to-DataRoom ingestion with:
- SQLite state store (WAL mode) for crash-safe persistence
- Deterministic-first matching with Gemini worker fallback
- Link intake queue for auth-required URLs
- Full audit trail via events and run-ledger
"""

__version__ = "1.0.0"

from .config import get_config, IngestConfig
from .run_ledger import (
    RunLedger,
    get_run_ledger,
    generate_run_id,
    run_context,
    timed_stage,
)
from .pipeline import Pipeline, PipelineOptions, PipelineStats
