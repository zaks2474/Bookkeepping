#!/usr/bin/env python3
"""
Smoke tests for ZakOps Email Ingestion Pipeline.

Usage:
    python -m email_ingestion.smoke_test
    python -m email_ingestion.smoke_test --test preflight
    python -m email_ingestion.smoke_test --test chat
    python -m email_ingestion.smoke_test --test all
"""

import argparse
import asyncio
import sys
from pathlib import Path

# Add scripts directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))


def test_preflight():
    """Run preflight checks."""
    print("=" * 60)
    print("  Preflight Check")
    print("=" * 60)

    from email_ingestion.stages import preflight_check

    result = preflight_check()

    for name, ok, msg in result.checks:
        status = "✓" if ok else "✗"
        print(f"  [{status}] {name}: {msg}")

    if result.warnings:
        print("\nWarnings:")
        for w in result.warnings:
            print(f"  ⚠ {w}")

    print(f"\nPreflight: {'PASSED' if result.passed else 'FAILED'}")
    return result.passed


def test_sqlite_store():
    """Test SQLite state store."""
    print("\n" + "=" * 60)
    print("  SQLite State Store")
    print("=" * 60)

    from email_ingestion.state.sqlite_store import get_state_store

    store = get_state_store()
    print(f"  [✓] Store initialized: {store.db_path}")

    # Test basic operations
    conn = store._get_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) FROM processed_emails")
    email_count = cursor.fetchone()[0]
    print(f"  [✓] Processed emails: {email_count}")

    cursor.execute("SELECT COUNT(*) FROM chat_sessions")
    session_count = cursor.fetchone()[0]
    print(f"  [✓] Chat sessions: {session_count}")

    return True


def test_chat_persistence():
    """Test chat session persistence."""
    print("\n" + "=" * 60)
    print("  Chat Session Persistence")
    print("=" * 60)

    from email_ingestion.chat_persistence import ChatSessionStore

    store = ChatSessionStore()

    # Create test session
    test_id = "smoke-test-session"
    test_scope = {"type": "global"}

    store.save_session(test_id, test_scope)
    print(f"  [✓] Session created: {test_id}")

    # Add message
    store.add_message(test_id, "user", "Test message from smoke test")
    print("  [✓] Message added")

    # Load session
    loaded = store.load_session(test_id)
    if loaded and loaded.session_id == test_id:
        print(f"  [✓] Session loaded: {loaded.session_id}")
        print(f"  [✓] Messages: {len(loaded.messages)}")
    else:
        print("  [✗] Failed to load session")
        return False

    return True


async def test_chat_orchestrator():
    """Test chat orchestrator health."""
    print("\n" + "=" * 60)
    print("  Chat Orchestrator")
    print("=" * 60)

    from chat_orchestrator import get_orchestrator

    orch = get_orchestrator()

    # Check health
    health = await orch.get_health_status()
    print(f"  [{'✓' if health['status'] == 'healthy' else '⚠'}] Status: {health['status']}")
    print(f"  [✓] Providers: {health['healthy_providers']}")
    print(f"  [✓] Cache enabled: {health['cache']['enabled']}")

    # Check session persistence
    if orch.session_store:
        print("  [✓] SQLite session persistence: enabled")
    else:
        print("  [⚠] SQLite session persistence: disabled")

    return health["status"] in ("healthy", "degraded")


def test_rag_indexer():
    """Test RAG indexer configuration."""
    print("\n" + "=" * 60)
    print("  RAG Indexer")
    print("=" * 60)

    from email_ingestion.stages.stage_7_index import RAGIndexer, check_rag_connectivity

    indexer = RAGIndexer()
    print(f"  [✓] API URL: {indexer.api_url}")
    print(f"  [✓] URL prefix: {indexer.url_prefix}")
    print(f"  [✓] DataRoom root: {indexer.dataroom_root}")
    print(f"  [✓] Max file size: {indexer.max_file_size_mb}MB")

    # Test path computation
    test_path = "/home/zaks/DataRoom/01-ACTIVE-DEALS/TestDeal/doc.txt"
    rel_path = indexer.compute_rel_path(test_path)
    url = indexer.compute_url(rel_path)
    print(f"  [✓] Path computation: {rel_path}")
    print(f"  [✓] URL generation: {url}")

    # Check connectivity
    reachable, msg = check_rag_connectivity()
    print(f"  [{'✓' if reachable else '⚠'}] RAG connectivity: {msg}")

    return True


def test_gemini_worker():
    """Test Gemini worker configuration."""
    print("\n" + "=" * 60)
    print("  Gemini Worker")
    print("=" * 60)

    from email_ingestion.workers.gemini_worker import GeminiWorker

    worker = GeminiWorker()

    print(f"  [✓] Daily budget: ${worker.config.gemini_daily_budget_usd:.2f}")
    print(f"  [✓] Per-request max: ${worker.config.gemini_per_request_max_usd:.2f}")
    print(f"  [✓] Timeout: {worker.config.gemini_timeout_seconds}s")

    # Check budget gate
    budget_ok, reason = worker._check_budget("email_classification")
    print(f"  [{'✓' if budget_ok else '⚠'}] Budget gate: {reason}")

    # Check budget
    budget = worker.get_budget_status()
    print(f"  [✓] Today's spend: ${budget.daily_spent_usd:.4f}")
    print(f"  [✓] Remaining: ${budget.remaining_usd:.2f}")

    return True


def test_link_intake():
    """Test link intake queue."""
    print("\n" + "=" * 60)
    print("  Link Intake Queue")
    print("=" * 60)

    from email_ingestion.workers.link_intake import LinkIntake

    intake = LinkIntake()

    # Test URL analysis
    test_urls = [
        ("https://axial.net/deals/123", True, "Axial"),
        ("https://tupelo.ai/doc/abc", True, "Tupelo"),
        ("https://example.com/file.pdf", False, None),
    ]

    for url, expected_auth, expected_vendor in test_urls:
        info = intake.analyze_link(url)
        auth_ok = info.requires_auth == expected_auth
        vendor_ok = info.vendor == expected_vendor
        status = "✓" if auth_ok and vendor_ok else "✗"
        print(f"  [{status}] {info.domain}: auth={info.requires_auth}, vendor={info.vendor}")

    # Check drop zone
    dropzone = intake.config.intake_dropzone_path
    print(f"  [✓] Drop zone: {dropzone}")

    return True


def run_all_tests():
    """Run all smoke tests."""
    results = []

    # Synchronous tests
    results.append(("Preflight", test_preflight()))
    results.append(("SQLite Store", test_sqlite_store()))
    results.append(("Chat Persistence", test_chat_persistence()))
    results.append(("RAG Indexer", test_rag_indexer()))
    results.append(("Gemini Worker", test_gemini_worker()))
    results.append(("Link Intake", test_link_intake()))

    # Async tests
    results.append(("Chat Orchestrator", asyncio.run(test_chat_orchestrator())))

    # Summary
    print("\n" + "=" * 60)
    print("  Summary")
    print("=" * 60)

    passed = sum(1 for _, ok in results if ok)
    total = len(results)

    for name, ok in results:
        status = "✓ PASS" if ok else "✗ FAIL"
        print(f"  [{status}] {name}")

    print(f"\n  {passed}/{total} tests passed")

    return passed == total


def main():
    parser = argparse.ArgumentParser(description="ZakOps Email Ingestion Smoke Tests")
    parser.add_argument(
        "--test",
        choices=["all", "preflight", "sqlite", "chat", "rag", "gemini", "link"],
        default="all",
        help="Which test to run (default: all)"
    )
    args = parser.parse_args()

    print("=" * 60)
    print("  ZakOps Email Ingestion - Smoke Tests")
    print("=" * 60)

    if args.test == "all":
        success = run_all_tests()
    elif args.test == "preflight":
        success = test_preflight()
    elif args.test == "sqlite":
        success = test_sqlite_store()
    elif args.test == "chat":
        success = test_chat_persistence() and asyncio.run(test_chat_orchestrator())
    elif args.test == "rag":
        success = test_rag_indexer()
    elif args.test == "gemini":
        success = test_gemini_worker()
    elif args.test == "link":
        success = test_link_intake()
    else:
        success = False

    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
