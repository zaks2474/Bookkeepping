"""
Checkpoint manager for crash-safe pipeline recovery.

Provides atomic checkpoint updates so pipeline can resume from
last successful stage after crash/restart.
"""

import json
import logging
from dataclasses import dataclass, field, asdict
from typing import Optional, Dict, Any, List
from datetime import datetime, timezone

from .sqlite_store import get_state_store

logger = logging.getLogger(__name__)


@dataclass
class StageCheckpoint:
    """Checkpoint state for a pipeline stage."""
    run_id: str
    stage: int
    stage_name: str
    items_total: int
    items_completed: int
    state_snapshot: Dict[str, Any] = field(default_factory=dict)
    started_at: Optional[str] = None
    completed_at: Optional[str] = None

    @property
    def is_complete(self) -> bool:
        return self.items_completed >= self.items_total

    @property
    def progress_pct(self) -> float:
        if self.items_total == 0:
            return 100.0
        return (self.items_completed / self.items_total) * 100


class CheckpointManager:
    """
    Manages crash-safe checkpoints for pipeline stages.

    Usage:
        mgr = CheckpointManager(run_id)

        # Start a stage
        mgr.begin_stage(stage=1, name="fetch", total_items=100)

        # Update progress periodically
        for i, item in enumerate(items):
            process(item)
            if i % 10 == 0:
                mgr.update_progress(stage=1, completed=i+1)

        # Complete the stage
        mgr.complete_stage(stage=1)

        # On recovery, check last completed stage
        last = mgr.get_last_completed_stage()
        if last:
            resume_from = last.stage + 1
    """

    STAGE_NAMES = {
        0: "preflight",
        1: "fetch",
        2: "normalize",
        3: "match",
        4: "persist",
        5: "extract",
        6: "classify",
        7: "index",
    }

    def __init__(self, run_id: str):
        self.run_id = run_id
        self.store = get_state_store()
        self._active_checkpoints: Dict[int, StageCheckpoint] = {}

    def begin_stage(
        self,
        stage: int,
        total_items: int,
        name: Optional[str] = None,
        initial_state: Optional[Dict[str, Any]] = None
    ) -> StageCheckpoint:
        """
        Begin a new stage checkpoint.

        Args:
            stage: Stage number (0-7)
            total_items: Total items to process in this stage
            name: Optional stage name (defaults to STAGE_NAMES lookup)
            initial_state: Optional initial state snapshot

        Returns:
            StageCheckpoint for the stage
        """
        stage_name = name or self.STAGE_NAMES.get(stage, f"stage_{stage}")

        checkpoint = StageCheckpoint(
            run_id=self.run_id,
            stage=stage,
            stage_name=stage_name,
            items_total=total_items,
            items_completed=0,
            state_snapshot=initial_state or {},
            started_at=datetime.now(timezone.utc).isoformat(),
        )

        self._active_checkpoints[stage] = checkpoint
        self._save_checkpoint(checkpoint)

        logger.info(f"[{self.run_id}] Stage {stage} ({stage_name}) started: {total_items} items")
        return checkpoint

    def update_progress(
        self,
        stage: int,
        completed: int,
        state_update: Optional[Dict[str, Any]] = None
    ) -> None:
        """
        Update checkpoint progress.

        Args:
            stage: Stage number
            completed: Number of items completed so far
            state_update: Optional state updates to merge
        """
        checkpoint = self._active_checkpoints.get(stage)
        if not checkpoint:
            # Try to load from DB
            checkpoint = self._load_checkpoint(stage)
            if not checkpoint:
                logger.warning(f"No checkpoint found for stage {stage}")
                return
            self._active_checkpoints[stage] = checkpoint

        checkpoint.items_completed = completed
        if state_update:
            checkpoint.state_snapshot.update(state_update)

        self._save_checkpoint(checkpoint)

    def complete_stage(
        self,
        stage: int,
        final_state: Optional[Dict[str, Any]] = None
    ) -> StageCheckpoint:
        """
        Mark a stage as complete.

        Args:
            stage: Stage number
            final_state: Optional final state to save

        Returns:
            Completed StageCheckpoint
        """
        checkpoint = self._active_checkpoints.get(stage)
        if not checkpoint:
            checkpoint = self._load_checkpoint(stage)
            if not checkpoint:
                raise ValueError(f"No checkpoint found for stage {stage}")

        checkpoint.items_completed = checkpoint.items_total
        checkpoint.completed_at = datetime.now(timezone.utc).isoformat()
        if final_state:
            checkpoint.state_snapshot.update(final_state)

        self._save_checkpoint(checkpoint)

        logger.info(
            f"[{self.run_id}] Stage {stage} ({checkpoint.stage_name}) completed: "
            f"{checkpoint.items_total} items"
        )

        return checkpoint

    def fail_stage(
        self,
        stage: int,
        error: str,
        partial_state: Optional[Dict[str, Any]] = None
    ) -> None:
        """
        Record stage failure with error context.

        Args:
            stage: Stage number
            error: Error message
            partial_state: Any partial state to preserve
        """
        checkpoint = self._active_checkpoints.get(stage)
        if not checkpoint:
            checkpoint = self._load_checkpoint(stage)

        if checkpoint:
            checkpoint.state_snapshot["error"] = error
            checkpoint.state_snapshot["failed_at"] = datetime.now(timezone.utc).isoformat()
            if partial_state:
                checkpoint.state_snapshot.update(partial_state)
            self._save_checkpoint(checkpoint)

        logger.error(f"[{self.run_id}] Stage {stage} failed: {error}")

    def get_checkpoint(self, stage: int) -> Optional[StageCheckpoint]:
        """Get checkpoint for a specific stage."""
        if stage in self._active_checkpoints:
            return self._active_checkpoints[stage]
        return self._load_checkpoint(stage)

    def get_last_completed_stage(self) -> Optional[StageCheckpoint]:
        """
        Get the last fully completed stage checkpoint.

        Returns:
            StageCheckpoint of last completed stage, or None if no stages completed
        """
        conn = self.store._get_connection()
        cursor = conn.execute("""
            SELECT stage, items_total, items_completed, state_snapshot
            FROM checkpoints
            WHERE run_id = ? AND items_completed >= items_total
            ORDER BY stage DESC
            LIMIT 1
        """, (self.run_id,))

        row = cursor.fetchone()
        if not row:
            return None

        return StageCheckpoint(
            run_id=self.run_id,
            stage=row[0],
            stage_name=self.STAGE_NAMES.get(row[0], f"stage_{row[0]}"),
            items_total=row[1],
            items_completed=row[2],
            state_snapshot=json.loads(row[3]) if row[3] else {},
        )

    def get_all_checkpoints(self) -> List[StageCheckpoint]:
        """Get all checkpoints for this run."""
        conn = self.store._get_connection()
        cursor = conn.execute("""
            SELECT stage, items_total, items_completed, state_snapshot
            FROM checkpoints
            WHERE run_id = ?
            ORDER BY stage ASC
        """, (self.run_id,))

        checkpoints = []
        for row in cursor.fetchall():
            checkpoints.append(StageCheckpoint(
                run_id=self.run_id,
                stage=row[0],
                stage_name=self.STAGE_NAMES.get(row[0], f"stage_{row[0]}"),
                items_total=row[1],
                items_completed=row[2],
                state_snapshot=json.loads(row[3]) if row[3] else {},
            ))

        return checkpoints

    def get_resume_point(self) -> int:
        """
        Determine which stage to resume from.

        Returns:
            Stage number to resume from (0 if no progress)
        """
        last = self.get_last_completed_stage()
        if last is None:
            return 0

        # Resume from stage after last completed
        next_stage = last.stage + 1
        if next_stage > 7:  # All stages done
            return -1  # Signal completion

        return next_stage

    def clear_checkpoints(self) -> None:
        """Clear all checkpoints for this run (for rebuild)."""
        conn = self.store._get_connection()
        conn.execute("DELETE FROM checkpoints WHERE run_id = ?", (self.run_id,))
        conn.commit()
        self._active_checkpoints.clear()
        logger.info(f"[{self.run_id}] Cleared all checkpoints")

    def _save_checkpoint(self, checkpoint: StageCheckpoint) -> None:
        """Save checkpoint to SQLite."""
        conn = self.store._get_connection()
        conn.execute("""
            INSERT INTO checkpoints (run_id, stage, stage_name, items_total, items_completed, state_snapshot)
            VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT(run_id, stage) DO UPDATE SET
                stage_name = excluded.stage_name,
                items_total = excluded.items_total,
                items_completed = excluded.items_completed,
                state_snapshot = excluded.state_snapshot
        """, (
            checkpoint.run_id,
            checkpoint.stage,
            checkpoint.stage_name,
            checkpoint.items_total,
            checkpoint.items_completed,
            json.dumps(checkpoint.state_snapshot),
        ))
        conn.commit()

    def _load_checkpoint(self, stage: int) -> Optional[StageCheckpoint]:
        """Load checkpoint from SQLite."""
        conn = self.store._get_connection()
        cursor = conn.execute("""
            SELECT items_total, items_completed, state_snapshot
            FROM checkpoints
            WHERE run_id = ? AND stage = ?
        """, (self.run_id, stage))

        row = cursor.fetchone()
        if not row:
            return None

        return StageCheckpoint(
            run_id=self.run_id,
            stage=stage,
            stage_name=self.STAGE_NAMES.get(stage, f"stage_{stage}"),
            items_total=row[0],
            items_completed=row[1],
            state_snapshot=json.loads(row[2]) if row[2] else {},
        )


def get_checkpoint_manager(run_id: str) -> CheckpointManager:
    """Get a checkpoint manager for the given run ID."""
    return CheckpointManager(run_id)
