"""
JSON to SQLite migration for email ingestion state.

Migrates existing JSON caches to SQLite with data preservation.
"""

import json
import hashlib
import logging
from pathlib import Path
from datetime import datetime, timezone
from typing import Dict, Any, Tuple

from .sqlite_store import get_state_store, EmailRecord, DownloadRecord

logger = logging.getLogger(__name__)


class MigrationError(Exception):
    """Raised when migration fails."""
    pass


def compute_body_hash(subject: str, sender: str = "") -> str:
    """Compute a body hash from available fields (for legacy records without body)."""
    content = f"{subject}:{sender}"
    return hashlib.sha256(content.encode()).hexdigest()[:32]


def migrate_email_sync_processed(
    json_path: Path,
    dry_run: bool = False
) -> Tuple[int, int, int]:
    """
    Migrate email_sync_processed.json to SQLite.

    Args:
        json_path: Path to email_sync_processed.json
        dry_run: If True, preview only without writing

    Returns:
        Tuple of (total, migrated, skipped) counts
    """
    if not json_path.exists():
        logger.warning(f"Source file not found: {json_path}")
        return (0, 0, 0)

    with open(json_path, 'r') as f:
        data = json.load(f)

    message_ids = data.get("message_ids", {})
    if not message_ids:
        logger.info("No message_ids found in JSON")
        return (0, 0, 0)

    store = get_state_store()
    total = len(message_ids)
    migrated = 0
    skipped = 0

    # Use a migration run ID
    migration_run_id = f"MIGRATION-{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')}"

    logger.info(f"Migrating {total} email records (dry_run={dry_run})")

    for message_id, record in message_ids.items():
        # Check if already migrated
        if store.is_email_processed(message_id):
            skipped += 1
            continue

        # Extract fields from legacy record
        subject = record.get("subject", "")
        processed_at = record.get("processed_at", datetime.now(timezone.utc).isoformat())
        deal_folder = record.get("deal_folder", "")
        status = record.get("status", "processed")

        # Extract deal_id from folder path if possible
        deal_id = None
        if deal_folder:
            # Try to extract DEAL-YYYY-NNN pattern
            folder_name = Path(deal_folder).name
            if folder_name.startswith("DEAL-"):
                deal_id = folder_name

        # Create EmailRecord
        email = EmailRecord(
            message_id=message_id,
            body_hash=compute_body_hash(subject),  # Synthetic hash for legacy
            subject=subject,
            sender="",  # Not available in legacy
            received_date=processed_at,
            deal_id=deal_id,
            match_confidence=1.0 if deal_id else None,  # Assume high confidence for migrated
            quarantine_id=None,
            status=status,
            stage_completed=7,  # Assume fully processed
            run_id=migration_run_id,
            processed_at=processed_at,
        )

        if not dry_run:
            store.insert_email(email)

        migrated += 1

        if migrated % 50 == 0:
            logger.info(f"Migrated {migrated}/{total} emails...")

    logger.info(f"Email migration complete: {migrated} migrated, {skipped} skipped")
    return (total, migrated, skipped)


def migrate_downloads_processed(
    json_path: Path,
    dry_run: bool = False
) -> Tuple[int, int, int]:
    """
    Migrate downloads_processed.json to SQLite.

    Args:
        json_path: Path to downloads_processed.json
        dry_run: If True, preview only without writing

    Returns:
        Tuple of (total, migrated, skipped) counts
    """
    if not json_path.exists():
        logger.warning(f"Source file not found: {json_path}")
        return (0, 0, 0)

    with open(json_path, 'r') as f:
        data = json.load(f)

    if not data:
        logger.info("No downloads found in JSON")
        return (0, 0, 0)

    store = get_state_store()
    total = len(data)
    migrated = 0
    skipped = 0

    # Use a migration run ID
    migration_run_id = f"MIGRATION-{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')}"

    logger.info(f"Migrating {total} download records (dry_run={dry_run})")

    for key, dest_path in data.items():
        # Key format: "{filename}:{timestamp}"
        parts = key.rsplit(":", 1)
        if len(parts) == 2:
            filename, timestamp = parts
        else:
            filename = key
            timestamp = ""

        # Compute file hash from key (synthetic for legacy)
        file_hash = hashlib.sha256(key.encode()).hexdigest()[:32]

        # Check if already migrated
        if store.is_download_processed(file_hash):
            skipped += 1
            continue

        # Extract deal_id from dest_path if possible
        deal_id = None
        if dest_path:
            folder_name = Path(dest_path).name
            if folder_name.startswith("DEAL-"):
                deal_id = folder_name

        # Create DownloadRecord
        download = DownloadRecord(
            file_hash=file_hash,
            filename=filename,
            email_id=None,  # Not available in legacy
            deal_id=deal_id,
            doc_type=None,
            classification_confidence=None,
            classifier_used="legacy",
            dest_path=dest_path,
            run_id=migration_run_id,
        )

        if not dry_run:
            store.insert_download(download)

        migrated += 1

    logger.info(f"Download migration complete: {migrated} migrated, {skipped} skipped")
    return (total, migrated, skipped)


def run_migration(
    cache_dir: Path = None,
    dry_run: bool = False,
    backup: bool = True
) -> Dict[str, Any]:
    """
    Run full migration from JSON to SQLite.

    Args:
        cache_dir: Directory containing JSON caches (defaults to /home/zaks/.cache)
        dry_run: If True, preview only without writing
        backup: If True, rename JSON files after successful migration

    Returns:
        Migration summary dict
    """
    if cache_dir is None:
        # Use config cache_dir if available, otherwise default to /home/zaks/.cache
        try:
            from ..config import get_config
            cache_dir = get_config().cache_dir
        except ImportError:
            cache_dir = Path("/home/zaks/.cache")

    email_json = cache_dir / "email_sync_processed.json"
    downloads_json = cache_dir / "downloads_processed.json"

    summary = {
        "started_at": datetime.now(timezone.utc).isoformat(),
        "dry_run": dry_run,
        "emails": {"total": 0, "migrated": 0, "skipped": 0},
        "downloads": {"total": 0, "migrated": 0, "skipped": 0},
        "errors": [],
    }

    # Migrate emails
    try:
        total, migrated, skipped = migrate_email_sync_processed(email_json, dry_run)
        summary["emails"] = {"total": total, "migrated": migrated, "skipped": skipped}
    except Exception as e:
        logger.error(f"Email migration failed: {e}")
        summary["errors"].append(f"emails: {str(e)}")

    # Migrate downloads
    try:
        total, migrated, skipped = migrate_downloads_processed(downloads_json, dry_run)
        summary["downloads"] = {"total": total, "migrated": migrated, "skipped": skipped}
    except Exception as e:
        logger.error(f"Download migration failed: {e}")
        summary["errors"].append(f"downloads: {str(e)}")

    # Backup original files (rename to .migrated)
    if backup and not dry_run and not summary["errors"]:
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")

        if email_json.exists():
            backup_path = email_json.with_suffix(f".json.migrated_{timestamp}")
            email_json.rename(backup_path)
            logger.info(f"Backed up {email_json} to {backup_path}")

        if downloads_json.exists():
            backup_path = downloads_json.with_suffix(f".json.migrated_{timestamp}")
            downloads_json.rename(backup_path)
            logger.info(f"Backed up {downloads_json} to {backup_path}")

    summary["completed_at"] = datetime.now(timezone.utc).isoformat()
    summary["success"] = len(summary["errors"]) == 0

    return summary


def verify_migration(cache_dir: Path = None) -> Dict[str, Any]:
    """
    Verify migration by comparing JSON and SQLite record counts.

    Args:
        cache_dir: Directory containing original JSON caches

    Returns:
        Verification results
    """
    if cache_dir is None:
        try:
            from ..config import get_config
            cache_dir = get_config().cache_dir
        except ImportError:
            cache_dir = Path("/home/zaks/.cache")

    store = get_state_store()
    results = {"verified": True, "details": {}}

    # Check email counts
    email_json = cache_dir / "email_sync_processed.json"
    if email_json.exists():
        with open(email_json) as f:
            json_data = json.load(f)
        json_count = len(json_data.get("message_ids", {}))

        conn = store._get_connection()
        cursor = conn.execute("SELECT COUNT(*) FROM processed_emails")
        sqlite_count = cursor.fetchone()[0]

        results["details"]["emails"] = {
            "json_count": json_count,
            "sqlite_count": sqlite_count,
            "match": sqlite_count >= json_count,
        }
        if sqlite_count < json_count:
            results["verified"] = False

    # Check download counts
    downloads_json = cache_dir / "downloads_processed.json"
    if downloads_json.exists():
        with open(downloads_json) as f:
            json_data = json.load(f)
        json_count = len(json_data)

        conn = store._get_connection()
        cursor = conn.execute("SELECT COUNT(*) FROM processed_downloads")
        sqlite_count = cursor.fetchone()[0]

        results["details"]["downloads"] = {
            "json_count": json_count,
            "sqlite_count": sqlite_count,
            "match": sqlite_count >= json_count,
        }
        if sqlite_count < json_count:
            results["verified"] = False

    return results


# CLI entry point
if __name__ == "__main__":
    import argparse
    import sys

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s"
    )

    parser = argparse.ArgumentParser(description="Migrate JSON caches to SQLite")
    parser.add_argument("--dry-run", action="store_true", help="Preview without writing")
    parser.add_argument("--no-backup", action="store_true", help="Don't backup JSON files")
    parser.add_argument("--verify", action="store_true", help="Verify migration only")
    parser.add_argument("--cache-dir", type=Path, help="Cache directory path")

    args = parser.parse_args()

    if args.verify:
        results = verify_migration(args.cache_dir)
        print(json.dumps(results, indent=2))
        sys.exit(0 if results["verified"] else 1)

    summary = run_migration(
        cache_dir=args.cache_dir,
        dry_run=args.dry_run,
        backup=not args.no_backup,
    )

    print(json.dumps(summary, indent=2))
    sys.exit(0 if summary["success"] else 1)
