"""
State management for email ingestion pipeline.

Provides SQLite-based state storage with:
- WAL mode for concurrent reads
- Atomic transactions
- Crash-safe checkpoints
- Idempotent operations
"""

from .sqlite_store import SQLiteStateStore, get_state_store
from .checkpoint import CheckpointManager
