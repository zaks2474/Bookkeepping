"""
SQLite state store for email ingestion pipeline.

Features:
- WAL mode for concurrent reads during writes
- Atomic transactions for crash safety
- Idempotent operations (same email twice = 1 record)
- Support for rebuild window mode
"""

import json
import sqlite3
import threading
from contextlib import contextmanager
from dataclasses import dataclass, asdict
from datetime import datetime, date, timezone
from pathlib import Path
from typing import Optional, List, Dict, Any, Iterator

from ..config import get_config


# Schema version for migrations
SCHEMA_VERSION = 2


SCHEMA_SQL = """
-- Schema version tracking
CREATE TABLE IF NOT EXISTS schema_version (
    version INTEGER PRIMARY KEY,
    applied_at TEXT NOT NULL
);

-- Processed emails (replaces email_sync_processed.json)
CREATE TABLE IF NOT EXISTS processed_emails (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    message_id TEXT UNIQUE NOT NULL,
    body_hash TEXT NOT NULL,
    subject TEXT,
    sender TEXT,
    sender_email TEXT,
    received_date TEXT,
    deal_id TEXT,
    match_confidence REAL,
    match_type TEXT,
    quarantine_id TEXT,
    status TEXT DEFAULT 'pending',
    stage_completed INTEGER DEFAULT 0,
    run_id TEXT NOT NULL,
    processed_at TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    error_message TEXT,
    body_text TEXT,
    body_html TEXT,
    UNIQUE(body_hash, sender)
);

CREATE INDEX IF NOT EXISTS idx_emails_status ON processed_emails(status);
CREATE INDEX IF NOT EXISTS idx_emails_deal_id ON processed_emails(deal_id);
CREATE INDEX IF NOT EXISTS idx_emails_run_id ON processed_emails(run_id);
CREATE INDEX IF NOT EXISTS idx_emails_received ON processed_emails(received_date);
CREATE INDEX IF NOT EXISTS idx_emails_message_id ON processed_emails(message_id);

-- Processed downloads/attachments
CREATE TABLE IF NOT EXISTS processed_downloads (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    file_hash TEXT UNIQUE NOT NULL,
    filename TEXT NOT NULL,
    original_path TEXT,
    email_id INTEGER REFERENCES processed_emails(id),
    deal_id TEXT,
    doc_type TEXT,
    classification_confidence REAL,
    classifier_used TEXT,
    dest_path TEXT,
    text_extracted INTEGER DEFAULT 0,
    indexed_to_rag INTEGER DEFAULT 0,
    run_id TEXT NOT NULL,
    processed_at TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_downloads_deal_id ON processed_downloads(deal_id);
CREATE INDEX IF NOT EXISTS idx_downloads_email_id ON processed_downloads(email_id);
CREATE INDEX IF NOT EXISTS idx_downloads_file_hash ON processed_downloads(file_hash);

-- Ingestion runs
CREATE TABLE IF NOT EXISTS ingestion_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id TEXT UNIQUE NOT NULL,
    started_at TEXT NOT NULL,
    ended_at TEXT,
    duration_seconds REAL,
    mode TEXT DEFAULT 'normal',
    since_date TEXT,
    days_lookback INTEGER,
    force INTEGER DEFAULT 0,
    dry_run INTEGER DEFAULT 0,
    status TEXT DEFAULT 'running',
    emails_fetched INTEGER DEFAULT 0,
    emails_processed INTEGER DEFAULT 0,
    emails_skipped INTEGER DEFAULT 0,
    emails_failed INTEGER DEFAULT 0,
    emails_quarantined INTEGER DEFAULT 0,
    attachments_processed INTEGER DEFAULT 0,
    deals_created INTEGER DEFAULT 0,
    deals_updated INTEGER DEFAULT 0,
    files_indexed INTEGER DEFAULT 0,
    links_queued INTEGER DEFAULT 0,
    links_fetched INTEGER DEFAULT 0,
    errors TEXT DEFAULT '[]',
    stage_timings TEXT DEFAULT '{}',
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_runs_status ON ingestion_runs(status);
CREATE INDEX IF NOT EXISTS idx_runs_started ON ingestion_runs(started_at);

-- Per-email per-stage timing rows
CREATE TABLE IF NOT EXISTS timings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id TEXT NOT NULL,
    email_id INTEGER REFERENCES processed_emails(id),
    stage INTEGER NOT NULL,
    stage_name TEXT NOT NULL,
    started_at TEXT,
    ended_at TEXT,
    duration_ms INTEGER,
    status TEXT,
    error TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_timings_run_id ON timings(run_id);
CREATE INDEX IF NOT EXISTS idx_timings_email_id ON timings(email_id);

-- Crash-safe checkpoints
CREATE TABLE IF NOT EXISTS checkpoints (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id TEXT NOT NULL,
    stage INTEGER NOT NULL,
    stage_name TEXT NOT NULL,
    item_type TEXT,
    item_id TEXT,
    items_total INTEGER,
    items_completed INTEGER,
    state_snapshot TEXT,
    started_at TEXT,
    completed_at TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(run_id, stage)
);

-- Daily provider budgets and spend tracking
CREATE TABLE IF NOT EXISTS budgets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT NOT NULL,
    provider TEXT NOT NULL,
    daily_limit_usd REAL DEFAULT 5.0,
    spent_usd REAL DEFAULT 0.0,
    request_count INTEGER DEFAULT 0,
    last_updated TEXT,
    UNIQUE(date, provider)
);

-- Link intake queue
CREATE TABLE IF NOT EXISTS link_intake_queue (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    url TEXT NOT NULL,
    url_hash TEXT UNIQUE NOT NULL,
    source_email_id INTEGER REFERENCES processed_emails(id),
    deal_id TEXT,
    requires_auth INTEGER DEFAULT 0,
    vendor TEXT,
    status TEXT DEFAULT 'pending',
    fetch_attempts INTEGER DEFAULT 0,
    last_attempt_at TEXT,
    error_message TEXT,
    downloaded_path TEXT,
    operator_note TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_links_status ON link_intake_queue(status);
CREATE INDEX IF NOT EXISTS idx_links_deal_id ON link_intake_queue(deal_id);
CREATE INDEX IF NOT EXISTS idx_links_url_hash ON link_intake_queue(url_hash);

-- Chat sessions (backend persistence)
CREATE TABLE IF NOT EXISTS chat_sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT UNIQUE NOT NULL,
    scope_type TEXT NOT NULL,
    scope_deal_id TEXT,
    scope_doc_url TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    last_activity TEXT,
    turn_count INTEGER DEFAULT 0,
    context_summary TEXT
);

CREATE INDEX IF NOT EXISTS idx_sessions_deal_id ON chat_sessions(scope_deal_id);

-- Chat messages
CREATE TABLE IF NOT EXISTS chat_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL REFERENCES chat_sessions(session_id),
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    timestamp TEXT NOT NULL,
    citations TEXT,
    proposals TEXT,
    timings TEXT,
    provider_used TEXT,
    cache_hit INTEGER DEFAULT 0,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_messages_session ON chat_messages(session_id);
"""


@dataclass
class EmailRecord:
    """Record of a processed email."""
    message_id: str
    body_hash: str
    subject: Optional[str] = None
    sender: Optional[str] = None
    sender_email: Optional[str] = None
    received_date: Optional[str] = None
    deal_id: Optional[str] = None
    match_confidence: Optional[float] = None
    match_type: Optional[str] = None
    quarantine_id: Optional[str] = None
    status: str = "pending"
    stage_completed: int = 0
    run_id: str = ""
    processed_at: Optional[str] = None
    error_message: Optional[str] = None
    body_text: Optional[str] = None
    body_html: Optional[str] = None
    id: Optional[int] = None


@dataclass
class DownloadRecord:
    """Record of a processed download/attachment."""
    file_hash: str
    filename: str
    original_path: Optional[str] = None
    email_id: Optional[int] = None
    deal_id: Optional[str] = None
    doc_type: Optional[str] = None
    classification_confidence: Optional[float] = None
    classifier_used: Optional[str] = None
    dest_path: Optional[str] = None
    text_extracted: bool = False
    indexed_to_rag: bool = False
    run_id: str = ""
    processed_at: Optional[str] = None
    id: Optional[int] = None


@dataclass
class RunRecord:
    """Record of an ingestion run."""
    run_id: str
    started_at: str
    mode: str = "normal"
    since_date: Optional[str] = None
    days_lookback: Optional[int] = None
    force: bool = False
    dry_run: bool = False
    status: str = "running"
    ended_at: Optional[str] = None
    duration_seconds: Optional[float] = None
    emails_fetched: int = 0
    emails_processed: int = 0
    emails_skipped: int = 0
    emails_failed: int = 0
    emails_quarantined: int = 0
    attachments_processed: int = 0
    deals_created: int = 0
    deals_updated: int = 0
    files_indexed: int = 0
    links_queued: int = 0
    links_fetched: int = 0
    errors: List[str] = None
    stage_timings: Dict[str, float] = None
    id: Optional[int] = None

    def __post_init__(self):
        if self.errors is None:
            self.errors = []
        if self.stage_timings is None:
            self.stage_timings = {}


@dataclass
class LinkQueueItem:
    """Item in the link intake queue."""
    url: str
    url_hash: str
    source_email_id: Optional[int] = None
    deal_id: Optional[str] = None
    requires_auth: bool = False
    vendor: Optional[str] = None
    status: str = "pending"
    fetch_attempts: int = 0
    last_attempt_at: Optional[str] = None
    error_message: Optional[str] = None
    downloaded_path: Optional[str] = None
    operator_note: Optional[str] = None
    id: Optional[int] = None


class SQLiteStateStore:
    """
    SQLite-based state store for email ingestion.

    Uses WAL mode for better concurrency and crash safety.
    Thread-safe with connection pooling per thread.
    """

    def __init__(self, db_path: Optional[Path] = None):
        """Initialize the state store."""
        if db_path is None:
            db_path = get_config().state_db_path
        self.db_path = Path(db_path)
        self._local = threading.local()
        self._lock = threading.Lock()
        self._init_db()

    def _get_connection(self) -> sqlite3.Connection:
        """Get or create a thread-local connection."""
        if not hasattr(self._local, "conn") or self._local.conn is None:
            self._local.conn = sqlite3.connect(
                str(self.db_path),
                check_same_thread=False,
                isolation_level=None,  # Autocommit mode for explicit transactions
            )
            self._local.conn.row_factory = sqlite3.Row
            # Enable WAL mode for better concurrency
            self._local.conn.execute("PRAGMA journal_mode=WAL")
            self._local.conn.execute("PRAGMA synchronous=NORMAL")
            self._local.conn.execute("PRAGMA foreign_keys=ON")
        return self._local.conn

    @contextmanager
    def transaction(self) -> Iterator[sqlite3.Connection]:
        """Context manager for a transaction."""
        conn = self._get_connection()
        try:
            conn.execute("BEGIN")
            yield conn
            conn.execute("COMMIT")
        except Exception:
            conn.execute("ROLLBACK")
            raise

    def _init_db(self) -> None:
        """Initialize the database schema."""
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        conn = self._get_connection()

        # Check current schema version
        try:
            cursor = conn.execute("SELECT version FROM schema_version ORDER BY version DESC LIMIT 1")
            row = cursor.fetchone()
            current_version = row["version"] if row else 0
        except sqlite3.OperationalError:
            current_version = 0

        # Apply schema if needed
        if current_version < SCHEMA_VERSION:
            conn.executescript(SCHEMA_SQL)
            conn.execute(
                "INSERT OR REPLACE INTO schema_version (version, applied_at) VALUES (?, ?)",
                (SCHEMA_VERSION, datetime.now(timezone.utc).isoformat())
            )

    def close(self) -> None:
        """Close the connection."""
        if hasattr(self._local, "conn") and self._local.conn:
            self._local.conn.close()
            self._local.conn = None

    # ========== Email Operations ==========

    def get_email_by_message_id(self, message_id: str) -> Optional[EmailRecord]:
        """Get an email record by message ID."""
        conn = self._get_connection()
        cursor = conn.execute(
            "SELECT * FROM processed_emails WHERE message_id = ?",
            (message_id,)
        )
        row = cursor.fetchone()
        if row:
            return EmailRecord(**dict(row))
        return None

    def get_email_by_body_hash(self, body_hash: str, sender: str) -> Optional[EmailRecord]:
        """Get an email record by body hash and sender."""
        conn = self._get_connection()
        cursor = conn.execute(
            "SELECT * FROM processed_emails WHERE body_hash = ? AND sender = ?",
            (body_hash, sender)
        )
        row = cursor.fetchone()
        if row:
            return EmailRecord(**dict(row))
        return None

    def is_email_processed(self, message_id: str, body_hash: str = None, sender: str = None) -> bool:
        """Check if an email has already been processed."""
        # Check by message_id first
        if self.get_email_by_message_id(message_id):
            return True
        # Fallback to body_hash + sender
        if body_hash and sender:
            return self.get_email_by_body_hash(body_hash, sender) is not None
        return False

    def insert_email(self, email: EmailRecord) -> int:
        """Insert a new email record. Returns the row ID."""
        conn = self._get_connection()
        cursor = conn.execute(
            """
            INSERT INTO processed_emails (
                message_id, body_hash, subject, sender, sender_email, received_date,
                deal_id, match_confidence, match_type, quarantine_id,
                status, stage_completed, run_id, processed_at, error_message,
                body_text, body_html
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                email.message_id, email.body_hash, email.subject, email.sender,
                email.sender_email, email.received_date, email.deal_id, email.match_confidence,
                email.match_type, email.quarantine_id, email.status,
                email.stage_completed, email.run_id, email.processed_at,
                email.error_message, email.body_text, email.body_html
            )
        )
        return cursor.lastrowid

    def update_email(self, email_id: int, **kwargs) -> None:
        """Update an email record."""
        if not kwargs:
            return
        conn = self._get_connection()
        set_clause = ", ".join(f"{k} = ?" for k in kwargs.keys())
        values = list(kwargs.values()) + [email_id]
        conn.execute(
            f"UPDATE processed_emails SET {set_clause} WHERE id = ?",
            values
        )

    def update_email_status(
        self,
        email_id: int,
        status: str,
        stage_completed: int = None,
        error_message: str = None
    ) -> None:
        """Update email processing status."""
        updates = {"status": status}
        if stage_completed is not None:
            updates["stage_completed"] = stage_completed
        if error_message is not None:
            updates["error_message"] = error_message
        if status in ("processed", "failed", "quarantined"):
            updates["processed_at"] = datetime.now(timezone.utc).isoformat()
        self.update_email(email_id, **updates)

    def get_pending_emails(self, run_id: str = None) -> List[EmailRecord]:
        """Get emails with pending status."""
        conn = self._get_connection()
        if run_id:
            cursor = conn.execute(
                "SELECT * FROM processed_emails WHERE status = 'pending' AND run_id = ?",
                (run_id,)
            )
        else:
            cursor = conn.execute(
                "SELECT * FROM processed_emails WHERE status = 'pending'"
            )
        return [EmailRecord(**dict(row)) for row in cursor.fetchall()]

    def get_emails_in_window(self, since_date: str) -> List[EmailRecord]:
        """Get emails received since a given date (for rebuild mode)."""
        conn = self._get_connection()
        cursor = conn.execute(
            "SELECT * FROM processed_emails WHERE received_date >= ? ORDER BY received_date DESC",
            (since_date,)
        )
        return [EmailRecord(**dict(row)) for row in cursor.fetchall()]

    # ========== Download Operations ==========

    def get_download_by_hash(self, file_hash: str) -> Optional[DownloadRecord]:
        """Get a download record by file hash."""
        conn = self._get_connection()
        cursor = conn.execute(
            "SELECT * FROM processed_downloads WHERE file_hash = ?",
            (file_hash,)
        )
        row = cursor.fetchone()
        if row:
            return DownloadRecord(**dict(row))
        return None

    def is_download_processed(self, file_hash: str) -> bool:
        """Check if a download has already been processed."""
        return self.get_download_by_hash(file_hash) is not None

    def insert_download(self, download: DownloadRecord) -> int:
        """Insert a new download record. Returns the row ID."""
        conn = self._get_connection()
        cursor = conn.execute(
            """
            INSERT INTO processed_downloads (
                file_hash, filename, original_path, email_id, deal_id,
                doc_type, classification_confidence, classifier_used,
                dest_path, text_extracted, indexed_to_rag, run_id, processed_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                download.file_hash, download.filename, download.original_path,
                download.email_id, download.deal_id, download.doc_type,
                download.classification_confidence, download.classifier_used,
                download.dest_path, int(download.text_extracted),
                int(download.indexed_to_rag), download.run_id, download.processed_at
            )
        )
        return cursor.lastrowid

    def update_download(self, download_id: int, **kwargs) -> None:
        """Update a download record."""
        if not kwargs:
            return
        conn = self._get_connection()
        set_clause = ", ".join(f"{k} = ?" for k in kwargs.keys())
        values = list(kwargs.values()) + [download_id]
        conn.execute(
            f"UPDATE processed_downloads SET {set_clause} WHERE id = ?",
            values
        )

    # ========== Run Operations ==========

    def start_run(self, run: RunRecord) -> int:
        """Start a new ingestion run. Returns the row ID."""
        conn = self._get_connection()
        cursor = conn.execute(
            """
            INSERT INTO ingestion_runs (
                run_id, started_at, mode, since_date, days_lookback,
                force, dry_run, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                run.run_id, run.started_at, run.mode, run.since_date,
                run.days_lookback, int(run.force), int(run.dry_run), run.status
            )
        )
        return cursor.lastrowid

    def update_run(self, run_id: str, **kwargs) -> None:
        """Update a run record."""
        if not kwargs:
            return
        conn = self._get_connection()

        # Handle special fields
        if "errors" in kwargs:
            kwargs["errors"] = json.dumps(kwargs["errors"])
        if "stage_timings" in kwargs:
            kwargs["stage_timings"] = json.dumps(kwargs["stage_timings"])

        set_clause = ", ".join(f"{k} = ?" for k in kwargs.keys())
        values = list(kwargs.values()) + [run_id]
        conn.execute(
            f"UPDATE ingestion_runs SET {set_clause} WHERE run_id = ?",
            values
        )

    def end_run(self, run_id: str, status: str, **kwargs) -> None:
        """End an ingestion run."""
        ended_at = datetime.now(timezone.utc).isoformat()
        conn = self._get_connection()

        # Calculate duration
        cursor = conn.execute(
            "SELECT started_at FROM ingestion_runs WHERE run_id = ?",
            (run_id,)
        )
        row = cursor.fetchone()
        if row:
            started = datetime.fromisoformat(row["started_at"].replace('Z', '+00:00'))
            if started.tzinfo is None:
                started = started.replace(tzinfo=timezone.utc)
            duration = (datetime.now(timezone.utc) - started).total_seconds()
            kwargs["duration_seconds"] = duration

        kwargs["status"] = status
        kwargs["ended_at"] = ended_at
        self.update_run(run_id, **kwargs)

    def get_run(self, run_id: str) -> Optional[RunRecord]:
        """Get a run record."""
        conn = self._get_connection()
        cursor = conn.execute(
            "SELECT * FROM ingestion_runs WHERE run_id = ?",
            (run_id,)
        )
        row = cursor.fetchone()
        if row:
            data = dict(row)
            data["errors"] = json.loads(data.get("errors") or "[]")
            data["stage_timings"] = json.loads(data.get("stage_timings") or "{}")
            data["force"] = bool(data.get("force"))
            data["dry_run"] = bool(data.get("dry_run"))
            return RunRecord(**data)
        return None

    def get_recent_runs(self, limit: int = 10) -> List[RunRecord]:
        """Get recent ingestion runs."""
        conn = self._get_connection()
        cursor = conn.execute(
            "SELECT * FROM ingestion_runs ORDER BY started_at DESC LIMIT ?",
            (limit,)
        )
        runs = []
        for row in cursor.fetchall():
            data = dict(row)
            data["errors"] = json.loads(data.get("errors") or "[]")
            data["stage_timings"] = json.loads(data.get("stage_timings") or "{}")
            data["force"] = bool(data.get("force"))
            data["dry_run"] = bool(data.get("dry_run"))
            runs.append(RunRecord(**data))
        return runs

    # ========== Timing Operations ==========

    def record_timing(
        self,
        run_id: str,
        email_id: Optional[int],
        stage: int,
        stage_name: str,
        started_at: str,
        ended_at: str,
        status: str,
        error: str = None
    ) -> None:
        """Record timing for a stage."""
        conn = self._get_connection()
        start = datetime.fromisoformat(started_at)
        end = datetime.fromisoformat(ended_at)
        duration_ms = int((end - start).total_seconds() * 1000)

        conn.execute(
            """
            INSERT INTO timings (
                run_id, email_id, stage, stage_name, started_at, ended_at,
                duration_ms, status, error
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (run_id, email_id, stage, stage_name, started_at, ended_at,
             duration_ms, status, error)
        )

    def get_stage_timings(self, run_id: str) -> Dict[str, float]:
        """Get aggregate timings by stage for a run."""
        conn = self._get_connection()
        cursor = conn.execute(
            """
            SELECT stage_name, SUM(duration_ms) as total_ms
            FROM timings WHERE run_id = ?
            GROUP BY stage_name
            """,
            (run_id,)
        )
        return {row["stage_name"]: row["total_ms"] for row in cursor.fetchall()}

    # ========== Budget Operations ==========

    def get_budget(self, provider: str, for_date: date = None) -> Dict[str, Any]:
        """Get budget status for a provider."""
        if for_date is None:
            for_date = date.today()
        date_str = for_date.isoformat()
        config = get_config()

        conn = self._get_connection()
        cursor = conn.execute(
            "SELECT * FROM budgets WHERE date = ? AND provider = ?",
            (date_str, provider)
        )
        row = cursor.fetchone()

        if row:
            return {
                "date": row["date"],
                "provider": row["provider"],
                "daily_limit_usd": row["daily_limit_usd"],
                "spent_usd": row["spent_usd"],
                "request_count": row["request_count"],
                "remaining_usd": row["daily_limit_usd"] - row["spent_usd"],
                "can_use": row["spent_usd"] < row["daily_limit_usd"],
            }

        # Return default if no record
        return {
            "date": date_str,
            "provider": provider,
            "daily_limit_usd": config.gemini_daily_budget_usd,
            "spent_usd": 0.0,
            "request_count": 0,
            "remaining_usd": config.gemini_daily_budget_usd,
            "can_use": True,
        }

    def record_budget_usage(
        self,
        provider: str,
        cost_usd: float,
        for_date: date = None
    ) -> bool:
        """Record budget usage. Returns True if within budget."""
        if for_date is None:
            for_date = date.today()
        date_str = for_date.isoformat()
        config = get_config()

        conn = self._get_connection()

        # Upsert the budget record
        conn.execute(
            """
            INSERT INTO budgets (date, provider, daily_limit_usd, spent_usd, request_count, last_updated)
            VALUES (?, ?, ?, ?, 1, ?)
            ON CONFLICT(date, provider) DO UPDATE SET
                spent_usd = spent_usd + ?,
                request_count = request_count + 1,
                last_updated = ?
            """,
            (
                date_str, provider, config.gemini_daily_budget_usd, cost_usd,
                datetime.now(timezone.utc).isoformat(), cost_usd, datetime.now(timezone.utc).isoformat()
            )
        )

        # Check if still within budget
        budget = self.get_budget(provider, for_date)
        return budget["can_use"]

    # ========== Link Queue Operations ==========

    def queue_link(self, link: LinkQueueItem) -> int:
        """Add a link to the intake queue. Returns row ID."""
        conn = self._get_connection()
        cursor = conn.execute(
            """
            INSERT OR IGNORE INTO link_intake_queue (
                url, url_hash, source_email_id, deal_id, requires_auth,
                vendor, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                link.url, link.url_hash, link.source_email_id, link.deal_id,
                int(link.requires_auth), link.vendor, link.status
            )
        )
        return cursor.lastrowid or self._get_link_id(link.url_hash)

    def _get_link_id(self, url_hash: str) -> Optional[int]:
        """Get link ID by URL hash."""
        conn = self._get_connection()
        cursor = conn.execute(
            "SELECT id FROM link_intake_queue WHERE url_hash = ?",
            (url_hash,)
        )
        row = cursor.fetchone()
        return row["id"] if row else None

    def get_link_by_hash(self, url_hash: str) -> Optional[LinkQueueItem]:
        """Get a link queue item by URL hash."""
        conn = self._get_connection()
        cursor = conn.execute(
            "SELECT * FROM link_intake_queue WHERE url_hash = ?",
            (url_hash,)
        )
        row = cursor.fetchone()
        if row:
            data = dict(row)
            data["requires_auth"] = bool(data["requires_auth"])
            return LinkQueueItem(**data)
        return None

    def get_pending_links(self, status: str = "pending") -> List[LinkQueueItem]:
        """Get links with a given status."""
        conn = self._get_connection()
        cursor = conn.execute(
            "SELECT * FROM link_intake_queue WHERE status = ? ORDER BY created_at",
            (status,)
        )
        links = []
        for row in cursor.fetchall():
            data = dict(row)
            data["requires_auth"] = bool(data["requires_auth"])
            links.append(LinkQueueItem(**data))
        return links

    def get_auth_required_links(self) -> List[LinkQueueItem]:
        """Get links requiring operator action."""
        return self.get_pending_links("auth_required")

    def update_link(self, url_hash: str, **kwargs) -> None:
        """Update a link queue item."""
        if not kwargs:
            return
        kwargs["updated_at"] = datetime.now(timezone.utc).isoformat()
        conn = self._get_connection()
        set_clause = ", ".join(f"{k} = ?" for k in kwargs.keys())
        values = list(kwargs.values()) + [url_hash]
        conn.execute(
            f"UPDATE link_intake_queue SET {set_clause} WHERE url_hash = ?",
            values
        )

    def mark_link_fetched(self, url_hash: str, downloaded_path: str) -> None:
        """Mark a link as successfully fetched."""
        self.update_link(url_hash, status="fetched", downloaded_path=downloaded_path)

    def mark_link_failed(self, url_hash: str, error: str) -> None:
        """Mark a link as failed."""
        conn = self._get_connection()
        conn.execute(
            """
            UPDATE link_intake_queue SET
                status = 'failed',
                fetch_attempts = fetch_attempts + 1,
                last_attempt_at = ?,
                error_message = ?,
                updated_at = ?
            WHERE url_hash = ?
            """,
            (
                datetime.now(timezone.utc).isoformat(),
                error,
                datetime.now(timezone.utc).isoformat(),
                url_hash
            )
        )

    # ========== Chat Session Operations ==========

    def get_chat_session(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Get a chat session with messages."""
        conn = self._get_connection()

        # Get session
        cursor = conn.execute(
            "SELECT * FROM chat_sessions WHERE session_id = ?",
            (session_id,)
        )
        session = cursor.fetchone()
        if not session:
            return None

        # Get messages
        cursor = conn.execute(
            """
            SELECT * FROM chat_messages
            WHERE session_id = ?
            ORDER BY timestamp ASC
            """,
            (session_id,)
        )
        messages = []
        for row in cursor.fetchall():
            msg = dict(row)
            msg["citations"] = json.loads(msg.get("citations") or "[]")
            msg["proposals"] = json.loads(msg.get("proposals") or "[]")
            msg["timings"] = json.loads(msg.get("timings") or "{}")
            msg["cache_hit"] = bool(msg.get("cache_hit"))
            messages.append(msg)

        return {
            "session_id": session["session_id"],
            "scope_type": session["scope_type"],
            "scope_deal_id": session["scope_deal_id"],
            "scope_doc_url": session["scope_doc_url"],
            "created_at": session["created_at"],
            "last_activity": session["last_activity"],
            "turn_count": session["turn_count"],
            "messages": messages,
        }

    def create_chat_session(
        self,
        session_id: str,
        scope_type: str,
        scope_deal_id: str = None,
        scope_doc_url: str = None
    ) -> None:
        """Create a new chat session."""
        conn = self._get_connection()
        now = datetime.now(timezone.utc).isoformat()
        conn.execute(
            """
            INSERT OR IGNORE INTO chat_sessions (
                session_id, scope_type, scope_deal_id, scope_doc_url,
                created_at, last_activity, turn_count
            ) VALUES (?, ?, ?, ?, ?, ?, 0)
            """,
            (session_id, scope_type, scope_deal_id, scope_doc_url, now, now)
        )

    def add_chat_message(
        self,
        session_id: str,
        role: str,
        content: str,
        citations: List[Dict] = None,
        proposals: List[Dict] = None,
        timings: Dict = None,
        provider_used: str = None,
        cache_hit: bool = False
    ) -> None:
        """Add a message to a chat session."""
        conn = self._get_connection()
        now = datetime.now(timezone.utc).isoformat()

        conn.execute(
            """
            INSERT INTO chat_messages (
                session_id, role, content, timestamp, citations, proposals,
                timings, provider_used, cache_hit
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                session_id, role, content, now,
                json.dumps(citations or []),
                json.dumps(proposals or []),
                json.dumps(timings or {}),
                provider_used,
                int(cache_hit)
            )
        )

        # Update session
        conn.execute(
            """
            UPDATE chat_sessions SET
                last_activity = ?,
                turn_count = turn_count + 1
            WHERE session_id = ?
            """,
            (now, session_id)
        )

    def update_chat_message_proposals(self, message_id: int, proposals: List[Dict[str, Any]]) -> None:
        """Update the proposals JSON for a single chat message (by message row id)."""
        conn = self._get_connection()
        proposals_json = json.dumps(proposals or [])
        with self.transaction() as tx:
            tx.execute(
                "UPDATE chat_messages SET proposals = ? WHERE id = ?",
                (proposals_json, int(message_id)),
            )

    def get_active_sessions(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Get recently active chat sessions."""
        conn = self._get_connection()
        cursor = conn.execute(
            """
            SELECT * FROM chat_sessions
            ORDER BY last_activity DESC
            LIMIT ?
            """,
            (limit,)
        )
        return [dict(row) for row in cursor.fetchall()]

    # ========== Stats / Utilities ==========

    def get_stats(self) -> Dict[str, Any]:
        """Get overall statistics."""
        conn = self._get_connection()

        stats = {}

        # Email stats
        cursor = conn.execute(
            "SELECT status, COUNT(*) as count FROM processed_emails GROUP BY status"
        )
        stats["emails"] = {row["status"]: row["count"] for row in cursor.fetchall()}

        # Download stats
        cursor = conn.execute("SELECT COUNT(*) as count FROM processed_downloads")
        stats["downloads"] = cursor.fetchone()["count"]

        # Run stats
        cursor = conn.execute(
            "SELECT status, COUNT(*) as count FROM ingestion_runs GROUP BY status"
        )
        stats["runs"] = {row["status"]: row["count"] for row in cursor.fetchall()}

        # Link queue stats
        cursor = conn.execute(
            "SELECT status, COUNT(*) as count FROM link_intake_queue GROUP BY status"
        )
        stats["links"] = {row["status"]: row["count"] for row in cursor.fetchall()}

        # Chat stats
        cursor = conn.execute("SELECT COUNT(*) as count FROM chat_sessions")
        stats["chat_sessions"] = cursor.fetchone()["count"]

        return stats

    def vacuum(self) -> None:
        """Compact the database."""
        conn = self._get_connection()
        conn.execute("VACUUM")


# Singleton instance
_store: Optional[SQLiteStateStore] = None


def get_state_store(db_path: Path = None) -> SQLiteStateStore:
    """Get or create the singleton state store."""
    global _store
    if _store is None:
        _store = SQLiteStateStore(db_path)
    return _store


def reset_state_store() -> None:
    """Reset the state store (for testing)."""
    global _store
    if _store:
        _store.close()
    _store = None
