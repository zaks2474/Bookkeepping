"""
Worker modules for email ingestion pipeline.

Workers handle specialized processing tasks:
- GeminiWorker: AI classification with guardrails
- LinkIntake: Auth-required link queue management
"""

from .gemini_worker import GeminiWorker, GeminiResult
from .link_intake import LinkIntake, LinkInfo, FetchResult

__all__ = [
    "GeminiWorker",
    "GeminiResult",
    "LinkIntake",
    "LinkInfo",
    "FetchResult",
]
