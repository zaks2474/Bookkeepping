"""
Link Intake Queue for auth-required URLs.

Workflow:
1. Email processing detects links
2. Public links are auto-fetched
3. Auth-required links are queued with status 'auth_required'
4. Dashboard shows pending items in "Link Intake" view
5. Operator manually downloads files from portals
6. Operator places files in drop zone: ~/.intake-dropzone/{url_hash}_{filename}
7. Scanner (cron job) detects files, matches by url_hash prefix
8. File moved to deal folder, link marked 'fetched', event emitted

Auth-Required Domains:
- axial.net
- tupelo.ai
- vestedbb.com
- dealroom.net
- firmex.com
- docusign.com
- adobesign.com
- hellosign.com
- pandadoc.com
"""

import hashlib
import logging
import os
import re
import shutil
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple
from urllib.parse import urlparse, urlunparse
import urllib.request
import ssl

from ..config import get_config, IngestConfig
from ..state.sqlite_store import get_state_store, LinkQueueItem

logger = logging.getLogger(__name__)


@dataclass
class LinkInfo:
    """Information about a detected link."""
    url: str
    url_hash: str
    domain: str
    vendor: Optional[str] = None
    requires_auth: bool = False
    source_email_id: Optional[int] = None
    deal_id: Optional[str] = None


@dataclass
class FetchResult:
    """Result of fetching a link."""
    success: bool = False
    saved_path: Optional[str] = None
    content_type: Optional[str] = None
    size_bytes: int = 0
    error: Optional[str] = None


@dataclass
class DropZoneScanResult:
    """Result of scanning drop zone."""
    files_found: int = 0
    files_matched: int = 0
    files_moved: int = 0
    errors: List[str] = field(default_factory=list)


class LinkIntake:
    """
    Manages the link intake queue for auth-required URLs.

    Features:
    - Detect auth-required vs public links
    - Auto-fetch public links
    - Queue auth-required links for operator
    - Scan drop zone for operator-downloaded files
    - Move files to deal folders
    """

    # Known auth-required domain patterns
    AUTH_REQUIRED_VENDORS = {
        "axial.net": "Axial",
        "tupelo.ai": "Tupelo",
        "vestedbb.com": "Vested",
        "dealroom.net": "DealRoom",
        "firmex.com": "Firmex",
        "docusign.com": "DocuSign",
        "docusign.net": "DocuSign",
        "adobesign.com": "AdobeSign",
        "echosign.com": "AdobeSign",
        "hellosign.com": "HelloSign",
        "pandadoc.com": "PandaDoc",
        "dataroom.ansarada.com": "Ansarada",
        "intralinks.com": "Intralinks",
        "box.com": "Box",
        "dropbox.com": "Dropbox",
    }

    # Patterns for document URLs (likely downloadable)
    DOC_URL_PATTERNS = [
        r'\.pdf(\?|$)',
        r'\.docx?(\?|$)',
        r'\.xlsx?(\?|$)',
        r'\.pptx?(\?|$)',
        r'/download[/\?]',
        r'/attachment[/\?]',
        r'/file[/\?]',
    ]

    def __init__(self, config: Optional[IngestConfig] = None):
        self.config = config or get_config()
        self.store = get_state_store()
        self._ensure_dropzone()

    def _ensure_dropzone(self) -> None:
        """Ensure drop zone directory exists."""
        dropzone = self.config.intake_dropzone_path
        dropzone.mkdir(parents=True, exist_ok=True)

    def compute_url_hash(self, url: str) -> str:
        """Compute stable hash for URL (for file matching)."""
        # Normalize URL first
        normalized = self.normalize_url(url)
        return hashlib.sha256(normalized.encode()).hexdigest()[:12]

    def normalize_url(self, url: str) -> str:
        """Normalize URL for consistent hashing."""
        try:
            parsed = urlparse(url)
            # Remove tracking parameters
            path = parsed.path.rstrip('/')
            # Keep only essential parts
            return f"{parsed.scheme}://{parsed.netloc}{path}"
        except Exception:
            return url

    def is_auth_required(self, url: str) -> Tuple[bool, Optional[str]]:
        """
        Check if URL requires authentication.

        Returns:
            Tuple of (requires_auth, vendor_name)
        """
        try:
            parsed = urlparse(url)
            domain = parsed.netloc.lower()

            # Check direct domain match
            for pattern, vendor in self.AUTH_REQUIRED_VENDORS.items():
                if domain.endswith(pattern):
                    return True, vendor

            # Check config-defined domains
            for auth_domain in self.config.auth_required_domains:
                if domain.endswith(auth_domain.lower()):
                    return True, auth_domain

            return False, None

        except Exception:
            return False, None

    def analyze_link(
        self,
        url: str,
        source_email_id: Optional[int] = None,
        deal_id: Optional[str] = None
    ) -> LinkInfo:
        """
        Analyze a link and create LinkInfo.

        Args:
            url: The URL to analyze
            source_email_id: ID of source email (for tracking)
            deal_id: Associated deal ID

        Returns:
            LinkInfo with analysis results
        """
        url_hash = self.compute_url_hash(url)
        requires_auth, vendor = self.is_auth_required(url)

        try:
            parsed = urlparse(url)
            domain = parsed.netloc.lower()
        except Exception:
            domain = ""

        return LinkInfo(
            url=url,
            url_hash=url_hash,
            domain=domain,
            vendor=vendor,
            requires_auth=requires_auth,
            source_email_id=source_email_id,
            deal_id=deal_id,
        )

    def queue_link(self, link_info: LinkInfo) -> int:
        """
        Queue a link for processing.

        Args:
            link_info: LinkInfo from analyze_link

        Returns:
            Queue item ID
        """
        item = LinkQueueItem(
            url=link_info.url,
            url_hash=link_info.url_hash,
            source_email_id=link_info.source_email_id,
            deal_id=link_info.deal_id,
            requires_auth=link_info.requires_auth,
            vendor=link_info.vendor,
            status="auth_required" if link_info.requires_auth else "pending",
        )

        return self.store.queue_link(item)

    def fetch_public_link(
        self,
        url: str,
        dest_dir: Path,
        timeout: int = 30
    ) -> FetchResult:
        """
        Fetch a public link.

        Args:
            url: URL to fetch
            dest_dir: Directory to save file
            timeout: Request timeout in seconds

        Returns:
            FetchResult with download status
        """
        result = FetchResult()

        try:
            # Create SSL context that doesn't verify (for some sites)
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE

            req = urllib.request.Request(
                url,
                headers={'User-Agent': 'Mozilla/5.0 (compatible; ZakOps/1.0)'}
            )

            with urllib.request.urlopen(req, timeout=timeout, context=ctx) as response:
                content_type = response.headers.get('Content-Type', '')
                content_disp = response.headers.get('Content-Disposition', '')

                # Determine filename
                filename = self._extract_filename(url, content_disp)

                # Read content
                data = response.read()

                # Save file
                dest_dir.mkdir(parents=True, exist_ok=True)
                save_path = dest_dir / filename

                with open(save_path, 'wb') as f:
                    f.write(data)

                result.success = True
                result.saved_path = str(save_path)
                result.content_type = content_type
                result.size_bytes = len(data)

        except urllib.error.HTTPError as e:
            result.error = f"HTTP {e.code}: {e.reason}"
        except urllib.error.URLError as e:
            result.error = f"URL Error: {e.reason}"
        except TimeoutError:
            result.error = "Request timed out"
        except Exception as e:
            result.error = str(e)

        return result

    def _extract_filename(self, url: str, content_disposition: str) -> str:
        """Extract filename from URL or Content-Disposition header."""
        # Try Content-Disposition first
        if content_disposition:
            match = re.search(r'filename[*]?=(?:"([^"]+)"|([^\s;]+))', content_disposition)
            if match:
                return match.group(1) or match.group(2)

        # Fall back to URL path
        try:
            parsed = urlparse(url)
            path = parsed.path
            if '/' in path:
                filename = path.rsplit('/', 1)[-1]
                if filename:
                    return filename
        except Exception:
            pass

        # Generate a name from URL hash
        url_hash = self.compute_url_hash(url)
        return f"download_{url_hash}"

    def scan_dropzone(self) -> DropZoneScanResult:
        """
        Scan drop zone for operator-downloaded files.

        Files should be named: {url_hash}_{original_filename}

        Returns:
            DropZoneScanResult with scan results
        """
        result = DropZoneScanResult()
        dropzone = self.config.intake_dropzone_path

        if not dropzone.exists():
            return result

        for file_path in dropzone.iterdir():
            if not file_path.is_file():
                continue

            result.files_found += 1
            filename = file_path.name

            # Try to extract url_hash from filename
            # Expected format: {url_hash}_{original_filename}
            if '_' in filename:
                url_hash = filename.split('_', 1)[0]

                # Look up in queue
                queue_item = self.store.get_link_by_hash(url_hash)

                if queue_item:
                    result.files_matched += 1

                    # Move file to deal folder
                    try:
                        moved = self._move_to_deal(file_path, queue_item)
                        if moved:
                            result.files_moved += 1
                            # Update queue status
                            self.store.update_link_status(
                                url_hash,
                                status="fetched",
                                downloaded_path=str(moved),
                            )
                            logger.info(f"Processed drop zone file: {filename} -> {moved}")
                    except Exception as e:
                        result.errors.append(f"{filename}: {e}")
                        logger.error(f"Failed to process drop zone file {filename}: {e}")

        return result

    def _move_to_deal(self, file_path: Path, queue_item: LinkQueueItem) -> Optional[Path]:
        """
        Move file from drop zone to deal folder.

        Returns:
            New file path or None if failed
        """
        deal_id = queue_item.deal_id
        if not deal_id:
            logger.warning(f"No deal_id for queued link: {queue_item.url}")
            return None

        # Find deal folder
        dataroom = self.config.dataroom_root
        deal_folder = None

        # Search common locations
        search_dirs = [
            dataroom / "00-PIPELINE" / "Inbound",
            dataroom / "00-PIPELINE" / "Active",
            dataroom / "01-ACTIVE-DEALS",
        ]

        for search_dir in search_dirs:
            if not search_dir.exists():
                continue
            for folder in search_dir.iterdir():
                if folder.is_dir() and deal_id in folder.name:
                    deal_folder = folder
                    break
            if deal_folder:
                break

        if not deal_folder:
            logger.warning(f"Deal folder not found for {deal_id}")
            return None

        # Determine destination subfolder based on vendor
        vendor = queue_item.vendor or "downloads"
        dest_dir = deal_folder / "03-DOWNLOADS" / vendor
        dest_dir.mkdir(parents=True, exist_ok=True)

        # Generate unique filename
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
        original_name = file_path.name
        if '_' in original_name:
            # Remove url_hash prefix
            original_name = original_name.split('_', 1)[1]

        dest_filename = f"{timestamp}_{original_name}"
        dest_path = dest_dir / dest_filename

        # Move file
        shutil.move(str(file_path), str(dest_path))

        return dest_path

    def get_pending_links(self, status: str = "auth_required") -> List[Dict[str, Any]]:
        """
        Get pending links from queue.

        Args:
            status: Filter by status (default: auth_required)

        Returns:
            List of pending link items
        """
        return self.store.get_pending_links(status=status)

    def process_links_from_email(
        self,
        links: List[str],
        email_id: Optional[int] = None,
        deal_id: Optional[str] = None,
        deal_folder: Optional[Path] = None,
        dry_run: bool = False
    ) -> Tuple[int, int, int]:
        """
        Process links extracted from an email.

        Args:
            links: List of URLs from email
            email_id: Source email ID
            deal_id: Associated deal ID
            deal_folder: Deal folder path for saving downloads
            dry_run: If True, don't actually fetch/queue

        Returns:
            Tuple of (fetched_count, queued_count, skipped_count)
        """
        fetched = 0
        queued = 0
        skipped = 0

        for url in links:
            # Skip non-document URLs
            if not self._is_likely_document(url):
                skipped += 1
                continue

            # Analyze link
            info = self.analyze_link(url, email_id, deal_id)

            # Check if already processed
            existing = self.store.get_link_by_hash(info.url_hash)
            if existing:
                skipped += 1
                continue

            if dry_run:
                if info.requires_auth:
                    queued += 1
                else:
                    fetched += 1
                continue

            if info.requires_auth:
                # Queue for operator
                self.queue_link(info)
                queued += 1
                logger.info(f"Queued auth-required link: {info.vendor or info.domain}")
            else:
                # Try to fetch
                if deal_folder:
                    result = self.fetch_public_link(
                        url,
                        deal_folder / "03-DOWNLOADS" / "auto"
                    )
                    if result.success:
                        fetched += 1
                        # Queue with fetched status
                        info_item = LinkQueueItem(
                            url=info.url,
                            url_hash=info.url_hash,
                            source_email_id=email_id,
                            deal_id=deal_id,
                            requires_auth=False,
                            status="fetched",
                            downloaded_path=result.saved_path,
                        )
                        self.store.queue_link(info_item)
                    else:
                        # Queue as pending for retry
                        self.queue_link(info)
                        skipped += 1
                else:
                    skipped += 1

        return fetched, queued, skipped

    def _is_likely_document(self, url: str) -> bool:
        """Check if URL is likely a document download."""
        url_lower = url.lower()

        for pattern in self.DOC_URL_PATTERNS:
            if re.search(pattern, url_lower):
                return True

        # Check if it's a known document portal
        requires_auth, _ = self.is_auth_required(url)
        if requires_auth:
            return True

        return False


def scan_dropzone_cron():
    """
    Entry point for cron job to scan drop zone.

    Usage in crontab:
        */5 * * * * python -c "from email_ingestion.workers.link_intake import scan_dropzone_cron; scan_dropzone_cron()"
    """
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s"
    )

    intake = LinkIntake()
    result = intake.scan_dropzone()

    if result.files_found > 0:
        logger.info(
            f"Drop zone scan: {result.files_found} found, "
            f"{result.files_matched} matched, {result.files_moved} moved"
        )
        if result.errors:
            for error in result.errors:
                logger.error(f"  Error: {error}")
