"""
Gemini Worker with guardrails for email/document classification.

Guardrails:
1. Secret scan gate - blocks if secrets detected in content
2. Daily budget cap - max $/day across all tasks
3. Per-request max - max $/request
4. Timeout with retry - 45s timeout, 1 retry
5. Fallback to deterministic rules on any failure
"""

import hashlib
import logging
import os
import re
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone, date
from enum import Enum
from typing import Dict, List, Optional, Any, Tuple

from ..config import get_config, IngestConfig
from ..state.sqlite_store import get_state_store

logger = logging.getLogger(__name__)


class TaskType(Enum):
    """Supported Gemini task types."""
    EMAIL_CLASSIFICATION = "email_classification"
    DOC_TYPE_CLASSIFICATION = "doc_type_classification"
    KEY_FIELD_EXTRACTION = "key_field_extraction"
    MISSING_MATERIALS = "missing_materials"


@dataclass
class GeminiResult:
    """Result from Gemini classification."""
    success: bool = False
    label: Optional[str] = None
    confidence: float = 0.0
    reason: str = ""
    extracted_fields: Dict[str, Any] = field(default_factory=dict)
    citations: List[str] = field(default_factory=list)
    fallback_used: bool = False
    cost_usd: float = 0.0
    latency_ms: float = 0.0
    error: Optional[str] = None


@dataclass
class BudgetStatus:
    """Current budget status."""
    daily_limit_usd: float
    daily_spent_usd: float
    remaining_usd: float
    request_count: int
    last_reset: str
    is_exhausted: bool


class SecretScanner:
    """
    Scans content for secrets/sensitive data.

    Detects:
    - API keys (AWS, Google, OpenAI, etc.)
    - Private keys (RSA, SSH)
    - Passwords in common formats
    - Credit card numbers
    - SSN patterns
    """

    # Secret patterns
    PATTERNS = [
        # AWS
        (r'AKIA[0-9A-Z]{16}', 'AWS Access Key'),
        (r'aws_secret_access_key\s*=\s*[\"\']?([A-Za-z0-9/+=]{40})[\"\']?', 'AWS Secret Key'),

        # Google
        (r'AIza[0-9A-Za-z\-_]{35}', 'Google API Key'),
        (r'ya29\.[0-9A-Za-z\-_]+', 'Google OAuth Token'),

        # OpenAI
        (r'sk-[a-zA-Z0-9]{48}', 'OpenAI API Key'),

        # Generic API keys
        (r'api[_-]?key\s*[=:]\s*[\"\']?([a-zA-Z0-9_\-]{20,})[\"\']?', 'Generic API Key'),
        (r'bearer\s+[a-zA-Z0-9_\-\.]+', 'Bearer Token'),

        # Private keys
        (r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----', 'Private Key'),
        (r'-----BEGIN CERTIFICATE-----', 'Certificate'),

        # Passwords
        (r'password\s*[=:]\s*[\"\']?([^\s\"\']{8,})[\"\']?', 'Password'),

        # Credit cards (basic patterns)
        (r'\b(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13})\b', 'Credit Card'),

        # SSN
        (r'\b\d{3}-\d{2}-\d{4}\b', 'SSN'),
    ]

    def __init__(self):
        self._compiled = [(re.compile(p, re.IGNORECASE), name) for p, name in self.PATTERNS]

    def scan(self, content: str) -> List[Tuple[str, str]]:
        """
        Scan content for secrets.

        Returns:
            List of (matched_text, secret_type) tuples
        """
        findings = []
        for pattern, name in self._compiled:
            for match in pattern.finditer(content):
                # Redact the actual value
                redacted = match.group(0)[:10] + "..." if len(match.group(0)) > 10 else match.group(0)
                findings.append((redacted, name))

        return findings

    def has_secrets(self, content: str) -> bool:
        """Check if content contains any secrets."""
        return len(self.scan(content)) > 0


class GeminiWorker:
    """
    Gated Gemini worker for classification tasks.

    Usage:
        worker = GeminiWorker()

        # Check if available
        if not worker.is_available():
            print("Gemini disabled or budget exhausted")

        # Classify email
        result = worker.classify_email(subject, body, sender)
        if result.success:
            print(f"Classification: {result.label} ({result.confidence})")
        else:
            print(f"Fallback used: {result.reason}")
    """

    # Task costs (approximate, in USD per 1K tokens)
    TASK_COSTS = {
        TaskType.EMAIL_CLASSIFICATION: 0.001,  # Short context
        TaskType.DOC_TYPE_CLASSIFICATION: 0.002,  # Medium context
        TaskType.KEY_FIELD_EXTRACTION: 0.003,  # Longer context
        TaskType.MISSING_MATERIALS: 0.002,
    }

    # Classification labels
    EMAIL_LABELS = [
        "deal_opportunity",
        "nda_request",
        "cim_delivery",
        "financial_data",
        "broker_intro",
        "follow_up",
        "marketing",
        "junk",
        "other",
    ]

    DOC_TYPE_LABELS = [
        "CIM",
        "TEASER",
        "NDA",
        "FINANCIALS",
        "TAX_RETURN",
        "LEGAL",
        "CUSTOMER_LIST",
        "EMPLOYEE_LIST",
        "CONTRACT",
        "OTHER",
    ]

    def __init__(self, config: Optional[IngestConfig] = None):
        self.config = config or get_config()
        self.store = get_state_store()
        self.secret_scanner = SecretScanner()
        self._client = None

    @property
    def enabled(self) -> bool:
        """Check if Gemini is enabled in config."""
        return self.config.gemini_enabled

    def is_available(self) -> bool:
        """Check if Gemini worker is available (enabled + has budget)."""
        if not self.enabled:
            return False

        status = self.get_budget_status()
        return not status.is_exhausted

    def get_budget_status(self) -> BudgetStatus:
        """Get current budget status from SQLite."""
        today = date.today()
        budget_type = "gemini"

        budget = self.store.get_budget(budget_type, today)

        if budget:
            spent = budget.get("spent_usd", 0.0)
            limit = budget.get("daily_limit_usd", self.config.gemini_daily_budget_usd)
            return BudgetStatus(
                daily_limit_usd=limit,
                daily_spent_usd=spent,
                remaining_usd=budget.get("remaining_usd", max(0, limit - spent)),
                request_count=budget.get("request_count", 0),
                last_reset=budget.get("date", today.isoformat()),
                is_exhausted=not budget.get("can_use", True),
            )

        # No budget record yet, full budget available
        return BudgetStatus(
            daily_limit_usd=self.config.gemini_daily_budget_usd,
            daily_spent_usd=0.0,
            remaining_usd=self.config.gemini_daily_budget_usd,
            request_count=0,
            last_reset=today.isoformat(),
            is_exhausted=False,
        )

    def _check_budget(self, task: TaskType, estimated_tokens: int = 1000) -> Tuple[bool, str]:
        """
        Check if budget allows this request.

        Returns:
            Tuple of (allowed, reason)
        """
        status = self.get_budget_status()

        if status.is_exhausted:
            return False, f"Daily budget exhausted (${status.daily_spent_usd:.2f}/${status.daily_limit_usd:.2f})"

        # Estimate cost
        cost_per_1k = self.TASK_COSTS.get(task, 0.002)
        estimated_cost = (estimated_tokens / 1000) * cost_per_1k

        if estimated_cost > self.config.gemini_per_request_max_usd:
            return False, f"Estimated cost ${estimated_cost:.3f} exceeds per-request limit ${self.config.gemini_per_request_max_usd:.2f}"

        if status.remaining_usd < estimated_cost:
            return False, f"Insufficient budget: need ${estimated_cost:.3f}, have ${status.remaining_usd:.3f}"

        return True, "OK"

    def _record_usage(self, task: TaskType, cost_usd: float) -> None:
        """Record usage to budget tracker."""
        self.store.record_budget_usage(
            provider="gemini",
            cost_usd=cost_usd,
            for_date=date.today(),
        )

    def _check_secrets(self, content: str) -> Tuple[bool, List[str]]:
        """
        Check content for secrets.

        Returns:
            Tuple of (has_secrets, list of findings)
        """
        findings = self.secret_scanner.scan(content)
        return len(findings) > 0, [f"{t}: {r}" for r, t in findings]

    def classify_email(
        self,
        subject: str,
        body: str,
        sender: str,
        fallback_label: str = "other"
    ) -> GeminiResult:
        """
        Classify an email using Gemini with guardrails.

        Args:
            subject: Email subject
            body: Email body text
            sender: Sender email address
            fallback_label: Default label if classification fails

        Returns:
            GeminiResult with classification
        """
        result = GeminiResult()
        start_time = time.perf_counter()

        # Gate 1: Check if enabled
        if not self.enabled:
            result.fallback_used = True
            result.label = fallback_label
            result.reason = "Gemini disabled"
            return result

        # Gate 2: Check for secrets
        content = f"{subject}\n{body}"
        has_secrets, findings = self._check_secrets(content)
        if has_secrets:
            result.fallback_used = True
            result.label = fallback_label
            result.reason = f"Secret detected: {findings[0]}"
            logger.warning(f"Secret scan blocked Gemini: {findings[0]}")
            return result

        # Gate 3: Check budget
        estimated_tokens = len(content.split()) * 1.5  # Rough estimate
        allowed, reason = self._check_budget(TaskType.EMAIL_CLASSIFICATION, int(estimated_tokens))
        if not allowed:
            result.fallback_used = True
            result.label = fallback_label
            result.reason = reason
            logger.info(f"Budget blocked Gemini: {reason}")
            return result

        # Call Gemini (with timeout)
        try:
            label, confidence, extracted = self._call_gemini_email(subject, body, sender)
            result.success = True
            result.label = label
            result.confidence = confidence
            result.extracted_fields = extracted

            # Calculate actual cost
            actual_cost = self.TASK_COSTS[TaskType.EMAIL_CLASSIFICATION] * (estimated_tokens / 1000)
            result.cost_usd = actual_cost
            self._record_usage(TaskType.EMAIL_CLASSIFICATION, actual_cost)

        except TimeoutError:
            result.fallback_used = True
            result.label = fallback_label
            result.reason = "Timeout"
            result.error = "Gemini request timed out"
        except Exception as e:
            result.fallback_used = True
            result.label = fallback_label
            result.reason = f"Error: {str(e)}"
            result.error = str(e)
            logger.error(f"Gemini call failed: {e}")

        result.latency_ms = (time.perf_counter() - start_time) * 1000
        return result

    def classify_document(
        self,
        filename: str,
        text_content: str,
        fallback_label: str = "OTHER"
    ) -> GeminiResult:
        """
        Classify a document type using Gemini with guardrails.

        Args:
            filename: Document filename
            text_content: Extracted text content
            fallback_label: Default label if classification fails

        Returns:
            GeminiResult with classification
        """
        result = GeminiResult()
        start_time = time.perf_counter()

        # Gate 1: Check if enabled
        if not self.enabled:
            result.fallback_used = True
            result.label = fallback_label
            result.reason = "Gemini disabled"
            return result

        # Gate 2: Check for secrets
        content = f"{filename}\n{text_content[:5000]}"  # Limit content
        has_secrets, findings = self._check_secrets(content)
        if has_secrets:
            result.fallback_used = True
            result.label = fallback_label
            result.reason = f"Secret detected: {findings[0]}"
            return result

        # Gate 3: Check budget
        estimated_tokens = len(content.split()) * 1.5
        allowed, reason = self._check_budget(TaskType.DOC_TYPE_CLASSIFICATION, int(estimated_tokens))
        if not allowed:
            result.fallback_used = True
            result.label = fallback_label
            result.reason = reason
            return result

        # Call Gemini (with timeout)
        try:
            label, confidence = self._call_gemini_doc(filename, text_content)
            result.success = True
            result.label = label
            result.confidence = confidence

            actual_cost = self.TASK_COSTS[TaskType.DOC_TYPE_CLASSIFICATION] * (estimated_tokens / 1000)
            result.cost_usd = actual_cost
            self._record_usage(TaskType.DOC_TYPE_CLASSIFICATION, actual_cost)

        except TimeoutError:
            result.fallback_used = True
            result.label = fallback_label
            result.reason = "Timeout"
        except Exception as e:
            result.fallback_used = True
            result.label = fallback_label
            result.reason = f"Error: {str(e)}"

        result.latency_ms = (time.perf_counter() - start_time) * 1000
        return result

    def _call_gemini_email(
        self,
        subject: str,
        body: str,
        sender: str
    ) -> Tuple[str, float, Dict]:
        """
        Make actual Gemini API call for email classification.

        Returns:
            Tuple of (label, confidence, extracted_fields)
        """
        # TODO: Implement actual Gemini API call
        # For now, use deterministic fallback
        return self._deterministic_email_classify(subject, body, sender)

    def _call_gemini_doc(self, filename: str, text_content: str) -> Tuple[str, float]:
        """
        Make actual Gemini API call for document classification.

        Returns:
            Tuple of (label, confidence)
        """
        # TODO: Implement actual Gemini API call
        # For now, use deterministic fallback
        return self._deterministic_doc_classify(filename, text_content)

    def _deterministic_email_classify(
        self,
        subject: str,
        body: str,
        sender: str
    ) -> Tuple[str, float, Dict]:
        """Deterministic fallback for email classification."""
        combined = f"{subject} {body}".lower()

        # Check for NDA
        if any(kw in combined for kw in ["nda", "non-disclosure", "confidentiality agreement"]):
            return "nda_request", 0.8, {}

        # Check for CIM
        if any(kw in combined for kw in ["cim", "confidential information memorandum", "offering memorandum"]):
            return "cim_delivery", 0.8, {}

        # Check for financial data
        if any(kw in combined for kw in ["financial statement", "p&l", "balance sheet", "income statement"]):
            return "financial_data", 0.7, {}

        # Check for deal opportunity
        if any(kw in combined for kw in ["new listing", "for sale", "acquisition opportunity", "ebitda", "asking price"]):
            return "deal_opportunity", 0.7, {}

        # Check for marketing/junk
        if any(kw in combined for kw in ["unsubscribe", "newsletter", "promotional"]):
            return "marketing", 0.8, {}

        return "other", 0.5, {}

    def _deterministic_doc_classify(self, filename: str, text_content: str) -> Tuple[str, float]:
        """Deterministic fallback for document classification."""
        combined = f"{filename} {text_content[:2000]}".lower()

        # Check filename patterns
        if any(kw in filename.lower() for kw in ["cim", "memorandum", "offering"]):
            return "CIM", 0.8

        if any(kw in filename.lower() for kw in ["teaser", "executive summary"]):
            return "TEASER", 0.8

        if any(kw in filename.lower() for kw in ["nda", "non-disclosure", "confidentiality"]):
            return "NDA", 0.8

        if any(kw in filename.lower() for kw in ["financial", "p&l", "income", "balance"]):
            return "FINANCIALS", 0.7

        if any(kw in filename.lower() for kw in ["tax return", "form 1040", "form 1120"]):
            return "TAX_RETURN", 0.7

        # Check content patterns
        if any(kw in combined for kw in ["executive summary", "investment highlights", "company overview"]):
            return "CIM", 0.6

        if any(kw in combined for kw in ["confidentiality", "non-disclosure", "agree not to disclose"]):
            return "NDA", 0.6

        return "OTHER", 0.4
