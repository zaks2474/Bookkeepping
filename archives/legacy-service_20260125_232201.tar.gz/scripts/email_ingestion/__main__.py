"""Allow running package as module: python -m email_ingestion"""
from .cli import main

if __name__ == "__main__":
    main()
