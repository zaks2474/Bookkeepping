#!/usr/bin/env python3
"""
CLI entry point for email ingestion pipeline.

Usage:
    python -m email_ingestion.cli [options]
    python /home/zaks/scripts/email_ingestion/cli.py [options]

Examples:
    # Normal run (last 3 days)
    python -m email_ingestion.cli

    # Dry run preview
    python -m email_ingestion.cli --dry-run

    # Rebuild from specific date
    python -m email_ingestion.cli --rebuild --since 2025-01-01

    # Rebuild last 30 days (comprehensive)
    python -m email_ingestion.cli --rebuild --days 30 --max-emails 500

    # Dry-run preview before rebuild
    python -m email_ingestion.cli --rebuild --days 30 --dry-run
"""

import argparse
import json
import logging
import sys
from datetime import datetime, timezone
from pathlib import Path

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from email_ingestion import Pipeline, PipelineOptions, PipelineStats
from email_ingestion.config import get_config


def setup_logging(verbose: bool = False, log_file: str = None) -> None:
    """Configure logging."""
    level = logging.DEBUG if verbose else logging.INFO
    handlers = [logging.StreamHandler()]

    if log_file:
        handlers.append(logging.FileHandler(log_file))

    logging.basicConfig(
        level=level,
        format="%(asctime)s - %(levelname)s - %(message)s",
        handlers=handlers,
    )


def print_stats(stats: PipelineStats, dry_run: bool = False) -> None:
    """Print pipeline statistics."""
    mode = "DRY RUN PREVIEW" if dry_run else "PIPELINE RESULTS"
    print("\n" + "=" * 70)
    print(f"  {mode}")
    print("=" * 70)
    print(f"  Run ID:           {stats.run_id}")
    print(f"  Duration:         {stats.duration_seconds:.1f}s")
    print()
    print("  FETCH:")
    print(f"    Emails found:   {stats.emails_found}")
    print(f"    Filtered:       {stats.emails_filtered}")
    print()
    print("  NORMALIZE:")
    print(f"    Processed:      {stats.emails_normalized}")
    print(f"    Duplicates:     {stats.duplicates_skipped} (dedup hit rate: {100*stats.duplicates_skipped/max(1,stats.emails_found):.1f}%)")
    print()
    print("  MATCH:")
    print(f"    Matched deals:  {stats.matched_existing}")
    print(f"    New deals:      {stats.new_deals}")
    print(f"    Junk rejected:  {stats.junk_rejected}")
    print()
    print("  PERSIST:")
    print(f"    Attachments:    {stats.attachments_downloaded}")
    print(f"    Files saved:    {stats.files_saved}")
    print()
    print("  INDEX (RAG):")
    print(f"    Files indexed:  {stats.files_indexed}")
    print()
    if stats.stage_timings:
        print("  TIMINGS:")
        for stage, ms in stats.stage_timings.items():
            if ms is not None:
                print(f"    {stage}: {ms:.0f}ms")
            else:
                print(f"    {stage}: N/A")
    if stats.errors:
        print()
        print("  ERRORS:")
        for error in stats.errors:
            print(f"    - {error}")
    print("=" * 70)


def generate_report(stats: PipelineStats, options: PipelineOptions, report_path: Path) -> None:
    """Generate a JSON report file."""
    report = {
        "run_id": stats.run_id,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "mode": "rebuild" if options.rebuild else ("dry_run" if options.dry_run else "normal"),
        "dry_run": options.dry_run,
        "duration_seconds": stats.duration_seconds,
        "date_range": {
            "since_date": options.since_date.isoformat() if options.since_date else None,
            "days_lookback": options.days_lookback,
        },
        "fetch": {
            "emails_found": stats.emails_found,
            "emails_filtered": stats.emails_filtered,
        },
        "normalize": {
            "emails_processed": stats.emails_normalized,
            "duplicates_skipped": stats.duplicates_skipped,
            "dedup_hit_rate_pct": round(100 * stats.duplicates_skipped / max(1, stats.emails_found), 2),
        },
        "match": {
            "matched_existing_deals": stats.matched_existing,
            "new_deals_created": stats.new_deals,
            "junk_rejected": stats.junk_rejected,
        },
        "persist": {
            "attachments_downloaded": stats.attachments_downloaded,
            "files_saved": stats.files_saved,
        },
        "index": {
            "files_indexed": stats.files_indexed,
        },
        "stage_timings_ms": stats.stage_timings,
        "errors": stats.errors,
        "success": len(stats.errors) == 0,
    }

    report_path.parent.mkdir(parents=True, exist_ok=True)
    with open(report_path, "w") as f:
        json.dump(report, f, indent=2)

    print(f"\n  Report saved to: {report_path}")


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        description="Email ingestion pipeline for ZakOps DataRoom",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  Normal run (last 3 days):
    python -m email_ingestion.cli

  Preview without changes:
    python -m email_ingestion.cli --dry-run

  Rebuild last 30 days (dry-run first):
    python -m email_ingestion.cli --rebuild --days 30 --max-emails 500 --dry-run

  Rebuild last 30 days (real):
    python -m email_ingestion.cli --rebuild --days 30 --max-emails 500 --report

  Rebuild from specific date:
    python -m email_ingestion.cli --rebuild --since 2025-01-01 --max-emails 500
        """
    )

    # Mode options
    mode_group = parser.add_argument_group("Mode")
    mode_group.add_argument(
        "--dry-run",
        action="store_true",
        help="Preview without making changes"
    )
    mode_group.add_argument(
        "--rebuild",
        action="store_true",
        help="Reprocess historical emails (ignores dedup cache)"
    )

    # Date range options
    date_group = parser.add_argument_group("Date Range")
    date_group.add_argument(
        "--since",
        type=str,
        metavar="DATE",
        help="Process emails since DATE (YYYY-MM-DD)"
    )
    date_group.add_argument(
        "--days",
        type=int,
        default=3,
        metavar="N",
        help="Days to look back (default: 3)"
    )
    date_group.add_argument(
        "--hours",
        type=int,
        default=72,
        metavar="N",
        help="Hours to look back (default: 72)"
    )

    # Limit options
    limit_group = parser.add_argument_group("Limits")
    limit_group.add_argument(
        "--max-emails",
        type=int,
        default=100,
        metavar="N",
        help="Maximum emails to fetch (default: 100, use 500+ for 30-day rebuild)"
    )

    # Control options
    control_group = parser.add_argument_group("Control")
    control_group.add_argument(
        "--skip-preflight",
        action="store_true",
        help="Skip preflight checks"
    )
    control_group.add_argument(
        "--skip-index",
        action="store_true",
        help="Skip RAG indexing"
    )

    # Output options
    output_group = parser.add_argument_group("Output")
    output_group.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Verbose output"
    )
    output_group.add_argument(
        "-q", "--quiet",
        action="store_true",
        help="Minimal output"
    )
    output_group.add_argument(
        "--report",
        action="store_true",
        help="Generate JSON report file in /home/zaks/logs/ingest_reports/"
    )
    output_group.add_argument(
        "--report-path",
        type=str,
        metavar="PATH",
        help="Custom path for JSON report file"
    )

    args = parser.parse_args()

    # Setup logging
    if not args.quiet:
        setup_logging(args.verbose)

    # Build options
    options = PipelineOptions(
        dry_run=args.dry_run,
        rebuild=args.rebuild,
        days_lookback=args.days,
        hours_lookback=args.hours,
        max_emails=args.max_emails,
        skip_preflight=args.skip_preflight,
        skip_index=args.skip_index,
    )

    # Parse since date
    if args.since:
        try:
            options.since_date = datetime.fromisoformat(args.since)
        except ValueError:
            print(f"Error: Invalid date format '{args.since}'. Use YYYY-MM-DD.", file=sys.stderr)
            sys.exit(1)

    # Determine report path
    report_path = None
    if args.report or args.report_path:
        if args.report_path:
            report_path = Path(args.report_path)
        else:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            mode_tag = "rebuild" if args.rebuild else "ingest"
            report_path = Path(f"/home/zaks/logs/ingest_reports/{mode_tag}_{timestamp}.json")

    # Run pipeline
    pipeline = Pipeline(options=options)

    try:
        stats = pipeline.run()

        if not args.quiet:
            print_stats(stats, dry_run=args.dry_run)

        # Generate report if requested
        if report_path:
            generate_report(stats, options, report_path)

        if stats.errors:
            sys.exit(1)

    except KeyboardInterrupt:
        print("\nInterrupted by user", file=sys.stderr)
        sys.exit(130)
    except Exception as e:
        logging.error(f"Pipeline failed: {e}")
        if args.verbose:
            import traceback
            traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
