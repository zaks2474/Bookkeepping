"""
Chat session persistence for the chat orchestrator.

Provides SQLite-backed session storage that can be used by
the existing chat_orchestrator.py to persist sessions across
server restarts.

Usage:
    from email_ingestion.chat_persistence import ChatSessionStore

    store = ChatSessionStore()

    # Save a session
    store.save_session(session_id, scope, messages)

    # Load a session
    data = store.load_session(session_id)

    # Add a message
    store.add_message(session_id, role, content, citations, proposals, timings)
"""

import json
import logging
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Dict, List, Optional, Any

from .state.sqlite_store import get_state_store

logger = logging.getLogger(__name__)


@dataclass
class PersistedMessage:
    """A persisted chat message."""
    role: str
    content: str
    timestamp: str
    citations: List[str] = field(default_factory=list)
    proposals: List[Dict] = field(default_factory=list)
    timings: Dict[str, Any] = field(default_factory=dict)
    provider_used: Optional[str] = None
    cache_hit: bool = False


@dataclass
class PersistedSession:
    """A persisted chat session."""
    session_id: str
    scope_type: str
    scope_deal_id: Optional[str] = None
    scope_doc_url: Optional[str] = None
    created_at: str = ""
    last_activity: str = ""
    turn_count: int = 0
    context_summary: Optional[str] = None
    messages: List[PersistedMessage] = field(default_factory=list)


class ChatSessionStore:
    """
    SQLite-backed chat session storage.

    Provides persistence for chat sessions so they survive
    server restarts.
    """

    def __init__(self):
        self._store = None

    @property
    def store(self):
        """Lazy-load the state store."""
        if self._store is None:
            self._store = get_state_store()
        return self._store

    def save_session(
        self,
        session_id: str,
        scope: Dict[str, Any],
        messages: Optional[List[Dict]] = None
    ) -> None:
        """
        Save or update a chat session.

        Args:
            session_id: Unique session identifier
            scope: Session scope (type, deal_id, etc.)
            messages: Optional list of messages to save
        """
        scope_type = scope.get("type", "general")
        scope_deal_id = scope.get("deal_id")
        scope_doc_url = scope.get("doc_url")

        # Create or update session
        self.store.create_chat_session(
            session_id=session_id,
            scope_type=scope_type,
            scope_deal_id=scope_deal_id,
            scope_doc_url=scope_doc_url,
        )

        # Save messages if provided
        if messages:
            for msg in messages:
                self.add_message(
                    session_id=session_id,
                    role=msg.get("role", "user"),
                    content=msg.get("content", ""),
                    citations=msg.get("citations", []),
                    proposals=msg.get("proposals", []),
                    timings=msg.get("timings", {}),
                    provider_used=msg.get("provider_used"),
                    cache_hit=msg.get("cache_hit", False),
                )

        logger.debug(f"Saved session {session_id}")

    def load_session(self, session_id: str) -> Optional[PersistedSession]:
        """
        Load a chat session with all messages.

        Args:
            session_id: Session ID to load

        Returns:
            PersistedSession or None if not found
        """
        data = self.store.get_chat_session(session_id)
        if not data:
            return None

        # Parse messages
        messages = []
        for msg in data.get("messages", []):
            messages.append(PersistedMessage(
                role=msg.get("role", "user"),
                content=msg.get("content", ""),
                timestamp=msg.get("timestamp", ""),
                citations=msg.get("citations", []),
                proposals=msg.get("proposals", []),
                timings=msg.get("timings", {}),
                provider_used=msg.get("provider_used"),
                cache_hit=bool(msg.get("cache_hit", False)),
            ))

        # Session data is at top level of dict (not nested under "session")
        return PersistedSession(
            session_id=session_id,
            scope_type=data.get("scope_type", "general"),
            scope_deal_id=data.get("scope_deal_id"),
            scope_doc_url=data.get("scope_doc_url"),
            created_at=data.get("created_at", ""),
            last_activity=data.get("last_activity", ""),
            turn_count=data.get("turn_count", 0),
            context_summary=data.get("context_summary"),
            messages=messages,
        )

    def add_message(
        self,
        session_id: str,
        role: str,
        content: str,
        citations: Optional[List] = None,
        proposals: Optional[List] = None,
        timings: Optional[Dict] = None,
        provider_used: Optional[str] = None,
        cache_hit: bool = False
    ) -> None:
        """
        Add a message to a session.

        Args:
            session_id: Session ID
            role: Message role (user/assistant/system)
            content: Message content
            citations: Optional citations list
            proposals: Optional proposals list
            timings: Optional timing data
            provider_used: LLM provider used
            cache_hit: Whether response was from cache
        """
        self.store.add_chat_message(
            session_id=session_id,
            role=role,
            content=content,
            citations=citations,
            proposals=proposals,
            timings=timings,
            provider_used=provider_used,
            cache_hit=cache_hit,
        )

    def update_proposal(self, session_id: str, proposal_id: str, proposal: Dict[str, Any]) -> bool:
        """
        Update a proposal inside the persisted message JSON (best-effort).

        This keeps proposal status/result stable across refreshes and restarts.

        Returns:
            True if a proposal was updated, False otherwise.
        """
        data = self.store.get_chat_session(session_id)
        if not data:
            return False

        messages = data.get("messages", [])
        for msg in messages:
            proposals = msg.get("proposals") or []
            if not isinstance(proposals, list):
                continue

            updated = False
            for idx, p in enumerate(proposals):
                if isinstance(p, dict) and p.get("proposal_id") == proposal_id:
                    proposals[idx] = dict(proposal)
                    updated = True
                    break

            if updated:
                message_id = msg.get("id")
                if message_id is None:
                    return False
                self.store.update_chat_message_proposals(message_id, proposals)
                return True

        return False

    def get_recent_sessions(
        self,
        limit: int = 50,
        scope_type: Optional[str] = None,
        deal_id: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Get recently active sessions.

        Args:
            limit: Maximum sessions to return
            scope_type: Optional filter by scope type
            deal_id: Optional filter by deal ID

        Returns:
            List of session summaries
        """
        sessions = self.store.get_active_sessions(limit=limit)

        # Apply filters
        if scope_type:
            sessions = [s for s in sessions if s.get("scope_type") == scope_type]
        if deal_id:
            sessions = [s for s in sessions if s.get("scope_deal_id") == deal_id]

        return sessions

    def session_exists(self, session_id: str) -> bool:
        """Check if a session exists."""
        return self.load_session(session_id) is not None

    def get_session_messages(
        self,
        session_id: str,
        limit: Optional[int] = None,
        offset: int = 0
    ) -> List[PersistedMessage]:
        """
        Get messages from a session with pagination.

        Args:
            session_id: Session ID
            limit: Max messages to return (None = all)
            offset: Number of messages to skip

        Returns:
            List of messages
        """
        session = self.load_session(session_id)
        if not session:
            return []

        messages = session.messages

        if offset:
            messages = messages[offset:]
        if limit:
            messages = messages[:limit]

        return messages


class HybridSessionManager:
    """
    Hybrid session manager that combines in-memory and SQLite storage.

    - In-memory for fast access during active sessions
    - SQLite for persistence across restarts
    - Auto-loads from SQLite when session not in memory

    This can be used as a drop-in enhancement for the existing
    ChatOrchestrator.sessions dict.
    """

    def __init__(self):
        self._memory: Dict[str, Any] = {}  # In-memory cache
        self._store = ChatSessionStore()

    def get(self, session_id: str) -> Optional[Any]:
        """Get session, checking memory first, then SQLite."""
        # Check memory first
        if session_id in self._memory:
            return self._memory[session_id]

        # Try loading from SQLite
        persisted = self._store.load_session(session_id)
        if persisted:
            # Convert to format expected by orchestrator
            return self._persisted_to_session(persisted)

        return None

    def set(self, session_id: str, session: Any) -> None:
        """Save session to both memory and SQLite."""
        self._memory[session_id] = session

        # Extract scope and messages for persistence
        scope = getattr(session, 'scope', {})
        messages = []
        for msg in getattr(session, 'messages', []):
            messages.append({
                "role": getattr(msg, 'role', 'user'),
                "content": getattr(msg, 'content', ''),
                "timestamp": getattr(msg, 'timestamp', ''),
                "citations": getattr(msg, 'citations', []),
                "proposals": getattr(msg, 'proposals', []),
            })

        self._store.save_session(session_id, scope, messages)

    def __contains__(self, session_id: str) -> bool:
        """Check if session exists."""
        if session_id in self._memory:
            return True
        return self._store.session_exists(session_id)

    def __getitem__(self, session_id: str) -> Any:
        """Get session or raise KeyError."""
        result = self.get(session_id)
        if result is None:
            raise KeyError(session_id)
        return result

    def __setitem__(self, session_id: str, session: Any) -> None:
        """Set session."""
        self.set(session_id, session)

    def _persisted_to_session(self, persisted: PersistedSession) -> Dict:
        """
        Convert PersistedSession to dict format.

        Note: The orchestrator will need to reconstruct its ChatSession
        object from this data.
        """
        return {
            "session_id": persisted.session_id,
            "scope": {
                "type": persisted.scope_type,
                "deal_id": persisted.scope_deal_id,
                "doc_url": persisted.scope_doc_url,
            },
            "created_at": persisted.created_at,
            "last_activity": persisted.last_activity,
            "messages": [asdict(m) for m in persisted.messages],
        }

    def add_message(
        self,
        session_id: str,
        role: str,
        content: str,
        **kwargs
    ) -> None:
        """Add a message and persist it."""
        self._store.add_message(
            session_id=session_id,
            role=role,
            content=content,
            citations=kwargs.get("citations"),
            proposals=kwargs.get("proposals"),
            timings=kwargs.get("timings"),
            provider_used=kwargs.get("provider_used"),
            cache_hit=kwargs.get("cache_hit", False),
        )


# Singleton instance
_session_store: Optional[ChatSessionStore] = None


def get_chat_session_store() -> ChatSessionStore:
    """Get or create the singleton ChatSessionStore instance."""
    global _session_store
    if _session_store is None:
        _session_store = ChatSessionStore()
    return _session_store
