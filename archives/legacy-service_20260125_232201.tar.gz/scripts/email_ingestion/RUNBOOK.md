# ZakOps Email Ingestion Pipeline - RUNBOOK

## Quick Reference

| Command | Purpose |
|---------|---------|
| `make preflight` | Quick check (paths, creds, connectivity) |
| `make preflight-deep` | Full check (includes IMAP login test) |
| `make ingest` | Run email ingestion (THE ONE command) |
| `make status` | Show pipeline status |
| `make rebuild` | Rebuild from last 7 days |
| `make audit-runners` | Check for duplicate runners |

---

## Environment Variables

### Required
```
GMAIL_EMAIL          - Gmail address for IMAP access
GMAIL_APP_PASSWORD   - Gmail App Password (not regular password)
```

### Configuration File
```
/home/zaks/.config/email_sync.env
```

Example format:
```ini
GMAIL_EMAIL=your-email@gmail.com
GMAIL_APP_PASSWORD=xxxx-xxxx-xxxx-xxxx
```

**To get an App Password:**
1. Go to https://myaccount.google.com/apppasswords
2. Generate a new app password for "Mail"
3. Store it in the config file above

### Where Variables Are Read
- `/home/zaks/scripts/email_ingestion/stages/stage_0_preflight.py` - Preflight checks
- `/home/zaks/scripts/email_ingestion/stages/stage_1_fetch.py` - IMAP connection
- `/home/zaks/scripts/sync_acquisition_emails.py` - Legacy script (if still used)

---

## Logs

| Log File | Purpose |
|----------|---------|
| `/home/zaks/logs/email_sync.log` | Main ingestion log (cron output) |
| `/home/zaks/logs/email_sync_cron.log` | Legacy cron log (deprecated) |

**View recent logs:**
```bash
tail -100 /home/zaks/logs/email_sync.log
```

**Follow logs in real-time:**
```bash
tail -f /home/zaks/logs/email_sync.log
```

---

## State Database

**Location:**
```
/home/zaks/DataRoom/.deal-registry/ingest_state.db
```

This is the **single source of truth** for:
- Processed emails (message_id, body_hash dedup)
- Processed downloads (file_hash dedup)
- Ingestion runs (audit trail)
- Chat sessions (persistence)
- Link intake queue (auth-required URLs)

**Check database status:**
```bash
make status
```

**Direct SQLite access:**
```bash
sqlite3 /home/zaks/DataRoom/.deal-registry/ingest_state.db
```

Common queries:
```sql
-- Recent emails
SELECT subject, sender, processed_at FROM processed_emails ORDER BY processed_at DESC LIMIT 10;

-- Recent ingestion runs
SELECT run_id, started_at, ended_at, status FROM ingestion_runs ORDER BY started_at DESC LIMIT 5;

-- Pending auth-required links
SELECT url, vendor, status FROM link_intake_queue WHERE status='auth_required';
```

---

## Confirming Ingestion is Running

### 1. Check cron is scheduled
```bash
make audit-runners
```
Expected output: Exactly ONE entry in `/etc/cron.d/dataroom-automation` calling `make ingest`

### 2. Check recent runs
```bash
make status
```
Shows last run timestamp and counts.

### 3. Check logs
```bash
tail -50 /home/zaks/logs/email_sync.log
```

### 4. Check for running processes
```bash
ps aux | grep email_ingestion
```

---

## Confirming No Legacy Runners

Run the audit:
```bash
make audit-runners
```

**What to look for:**
- NO uncommented entries in user/root crontab calling `sync_acquisition_emails.py`
- NO uncommented entries in `/etc/cron.*` calling the old script
- NO systemd units for email sync
- EXACTLY ONE entry in `/etc/cron.d/dataroom-automation` calling `make ingest`

**If legacy entries found:**
1. Edit user crontab: `crontab -e`
2. Edit root crontab: `sudo crontab -e`
3. Edit cron.d files: `sudo nano /etc/cron.d/dataroom-automation`
4. Comment out or delete old entries

---

## Rotating Credentials

### Gmail App Password Rotation

1. Generate new app password at https://myaccount.google.com/apppasswords
2. Update the config file:
   ```bash
   nano /home/zaks/.config/email_sync.env
   ```
3. Test connectivity:
   ```bash
   make preflight-deep
   ```
4. Revoke old app password at https://myaccount.google.com/apppasswords

### Verification
```bash
make test-imap
```
Should show:
```
[ok] imap_auth: IMAP login successful
[ok] imap_mailbox: INBOX accessible
```

---

## Troubleshooting

### Preflight Fails: Missing Credentials
```
[X] imap_credentials: Missing vars in credentials: GMAIL_EMAIL, GMAIL_APP_PASSWORD
```
**Fix:** Check `/home/zaks/.config/email_sync.env` exists and has correct variable names.

### Preflight Fails: IMAP Connection
```
[X] imap_connectivity: Connection timeout to imap.gmail.com:993
```
**Fix:** Check network connectivity, firewall rules.

### Preflight Fails: IMAP Auth
```
[X] imap_auth: Authentication failed (check credentials)
```
**Fix:**
- Verify app password is correct
- Regenerate app password if needed
- Check 2FA is enabled on Google account

### Duplicate Emails/Records
The pipeline uses unique constraints on:
- `message_id` (UNIQUE)
- `body_hash + sender` (UNIQUE)
- `file_hash` (UNIQUE for downloads)

Running `make ingest` twice will NOT create duplicates.

### Stuck/Hung Process
```bash
# Find and kill stuck process
ps aux | grep email_ingestion
sudo kill <pid>
```

---

## Architecture

```
/home/zaks/scripts/email_ingestion/
+-- __init__.py
+-- cli.py                    # Entry point (python -m email_ingestion.cli)
+-- config.py                 # Configuration
+-- pipeline.py               # Main orchestrator
+-- Makefile                  # Command interface
+-- RUNBOOK.md                # This file
+-- stages/
|   +-- stage_0_preflight.py  # Paths, creds, connectivity
|   +-- stage_1_fetch.py      # IMAP fetch
|   +-- stage_2_normalize.py  # Canonical records
|   +-- stage_3_match.py      # Deal matching
|   +-- stage_4_persist.py    # Events, registry
|   +-- stage_5_extract.py    # Text extraction
|   +-- stage_6_classify.py   # Gemini worker (gated)
|   +-- stage_7_index.py      # RAG indexing
+-- state/
|   +-- sqlite_store.py       # SQLite state management
|   +-- checkpoint.py         # Crash-safe checkpoints
|   +-- migrations.py         # JSON to SQLite migration
+-- workers/
    +-- gemini_worker.py      # AI classification (budget-gated)
    +-- link_intake.py        # Auth-required URL queue
```

---

## Cron Schedule

Current schedule in `/etc/cron.d/dataroom-automation`:
```cron
# Business hours (06:00-21:59 Dallas): hourly at :05
5 6-21 * * * zaks cd /home/zaks/scripts/email_ingestion && make ingest >> /home/zaks/logs/email_sync.log 2>&1

# Off-hours (22:00-05:59): at 22:05 and 02:05
5 22,2 * * * zaks cd /home/zaks/scripts/email_ingestion && make ingest >> /home/zaks/logs/email_sync.log 2>&1
```

---

## Key Files Modified (2025-12-27)

| File | Change |
|------|--------|
| `/etc/cron.d/dataroom-automation` | Switched to `make ingest` |
| `/home/zaks/.config/email_sync.env` | Canonical credential file |
| `stages/stage_0_preflight.py` | Uses GMAIL_* vars, deep IMAP test |
| `stages/stage_1_fetch.py` | Uses GMAIL_* vars |
| `Makefile` | Full command interface |

---

## Version History

- **2025-12-27**: Unified IMAP credentials, eliminated duplicate runners, created RUNBOOK
- **2025-12-26**: Initial email_ingestion pipeline with SQLite state store
