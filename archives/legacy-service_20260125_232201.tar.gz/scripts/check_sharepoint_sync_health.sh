#!/bin/bash
# Check SharePoint sync health and alert on issues

LOG_FILE="/home/zaks/logs/sharepoint_sync_$(date +%Y%m%d).log"

echo "=== SharePoint Sync Health Check ==="
echo "Date: $(date)"
echo ""

# Check if sync ran today
if [ ! -f "$LOG_FILE" ]; then
    echo "⚠ WARNING: No sync log found for today"
    echo "Last sync logs available:"
    ls -la /home/zaks/logs/sharepoint_sync_*.log 2>/dev/null | tail -5
    exit 1
fi

echo "✓ Sync log found: $LOG_FILE"

# Check for errors in log
ERROR_COUNT=$(grep -c "❌\|✗ Error\|Error:" "$LOG_FILE" 2>/dev/null || echo "0")
if [ "$ERROR_COUNT" -gt 0 ]; then
    echo "⚠ WARNING: $ERROR_COUNT errors found in sync log"
    echo ""
    echo "Last errors:"
    grep "❌\|✗ Error\|Error:" "$LOG_FILE" | tail -5
else
    echo "✓ No errors in sync log"
fi

# Check uploaded count
UPLOADED_COUNT=$(grep -c "✅\|✓ Uploaded" "$LOG_FILE" 2>/dev/null || echo "0")
echo "✓ Files uploaded today: $UPLOADED_COUNT"

# Check last sync time
LAST_SYNC=$(stat -c %Y "$LOG_FILE")
CURRENT_TIME=$(date +%s)
TIME_DIFF=$((CURRENT_TIME - LAST_SYNC))
MINUTES_AGO=$((TIME_DIFF / 60))

echo "✓ Last sync activity: $MINUTES_AGO minutes ago"

# Alert if no sync in last 30 minutes (for 15-min cron)
if [ "$TIME_DIFF" -gt 1800 ]; then
    echo "⚠ WARNING: Last sync was more than 30 minutes ago"
    echo "Check if cron job is running: crontab -l | grep sharepoint"
fi

# Check cron job exists
if crontab -l 2>/dev/null | grep -q "sharepoint_sync"; then
    echo "✓ SharePoint sync cron job is configured"
else
    echo "⚠ WARNING: No SharePoint sync cron job found"
fi

echo ""
echo "=== Health Check Complete ==="
