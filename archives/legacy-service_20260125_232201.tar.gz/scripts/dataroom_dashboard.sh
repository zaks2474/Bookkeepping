#!/bin/bash
# DataRoom Intelligence Platform Dashboard

echo "╔════════════════════════════════════════════════════════════╗"
echo "║          DataRoom Intelligence Platform Status             ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo ""

# System Status
echo "📊 SYSTEM STATUS"
echo "─────────────────────────────────────────────────────────────"

# DataRoom size
DATAROOM_SIZE=$(du -sh /home/zaks/DataRoom 2>/dev/null | cut -f1)
echo "  DataRoom Size: $DATAROOM_SIZE"

# File counts
MD_COUNT=$(find /home/zaks/DataRoom -type f -name "*.md" 2>/dev/null | wc -l)
CSV_COUNT=$(find /home/zaks/DataRoom -type f -name "*.csv" 2>/dev/null | wc -l)
PDF_COUNT=$(find /home/zaks/DataRoom -type f -name "*.pdf" 2>/dev/null | wc -l)
echo "  Files: ${MD_COUNT} MD, ${CSV_COUNT} CSV, ${PDF_COUNT} PDF"

# Permission issues
ROOT_FILES_TOTAL=$(find /home/zaks/DataRoom -type f -user root 2>/dev/null | wc -l)
ROOT_FILES_ACTIONABLE=$(find /home/zaks/DataRoom -type f -user root \
    ! -path "/home/zaks/DataRoom/08-ARCHIVE/openwebui-chats/*" \
    ! -path "/home/zaks/DataRoom/.deal-registry/*" \
    2>/dev/null | wc -l)
if [ "$ROOT_FILES_TOTAL" -eq 0 ]; then
    echo "  Permissions: ✓ OK"
elif [ "$ROOT_FILES_ACTIONABLE" -eq 0 ]; then
    echo "  Permissions: ✓ OK (root-owned only in excluded areas)"
else
    echo "  Permissions: ⚠ $ROOT_FILES_ACTIONABLE root-owned files"
fi

# Malformed directories
MALFORMED=$(find /home/zaks/DataRoom -type d \( -name "*{*" -o -name "*}*" \) 2>/dev/null | wc -l)
if [ "$MALFORMED" -eq 0 ]; then
    echo "  Structure: ✓ Clean"
else
    echo "  Structure: ⚠ $MALFORMED malformed directories"
fi
echo ""

# SharePoint Sync Status
echo "☁️  SHAREPOINT SYNC"
echo "─────────────────────────────────────────────────────────────"

SYNC_LOG="/home/zaks/logs/sharepoint_sync_$(date +%Y%m%d).log"
if [ -f "$SYNC_LOG" ]; then
    LAST_SYNC=$(stat -c %Y "$SYNC_LOG")
    CURRENT=$(date +%s)
    MINUTES_AGO=$(( (CURRENT - LAST_SYNC) / 60 ))

    # Report stats for the most recent run (avoid stale errors earlier in the day).
    LAST_RUN_LINE=$(grep -n "SharePoint Sync" "$SYNC_LOG" 2>/dev/null | tail -1 | cut -d: -f1)
    if [ -n "$LAST_RUN_LINE" ]; then
        RUN_SECTION=$(tail -n +"$LAST_RUN_LINE" "$SYNC_LOG" 2>/dev/null)
    else
        RUN_SECTION=$(cat "$SYNC_LOG" 2>/dev/null)
    fi

    ERROR_COUNT=$(printf "%s" "$RUN_SECTION" | grep -c "❌\\|✗ Error" 2>/dev/null)
    UPLOADED=$(printf "%s" "$RUN_SECTION" | grep -c "✅\\|✓ Uploaded" 2>/dev/null)

    echo "  Last Sync: $MINUTES_AGO minutes ago"
    echo "  Uploaded: $UPLOADED files"

    if [ "$ERROR_COUNT" -eq 0 ]; then
        echo "  Status: ✓ OK"
    else
        echo "  Status: ⚠ $ERROR_COUNT errors"
    fi
else
    echo "  Status: ⚠ No sync today"
fi
echo ""

# RAG Index Status
echo "🔍 RAG INDEX"
echo "─────────────────────────────────────────────────────────────"

RAG_LOG="/home/zaks/logs/rag_index_$(date +%Y%m%d).log"
if [ -f "$RAG_LOG" ]; then
    LAST_RUN_LINE=$(grep -n "RAG Index" "$RAG_LOG" 2>/dev/null | tail -1 | cut -d: -f1)
    if [ -n "$LAST_RUN_LINE" ]; then
        RUN_SECTION=$(tail -n +"$LAST_RUN_LINE" "$RAG_LOG" 2>/dev/null)
    else
        RUN_SECTION=$(cat "$RAG_LOG" 2>/dev/null)
    fi

    INDEXED=$(printf "%s" "$RUN_SECTION" | grep -c "✓ Indexed" 2>/dev/null)
    SKIPPED=$(printf "%s" "$RUN_SECTION" | grep -c "Skipped" 2>/dev/null)

    echo "  Indexed Today: $INDEXED files"
    echo "  Skipped: $SKIPPED files"
    echo "  Status: ✓ OK"
else
    echo "  Status: ⚠ No indexing today"
fi

# Check RAG hash cache
if [ -f "/home/zaks/.cache/rag_index_hashes.json" ]; then
    CACHED_COUNT=$(grep -c '"' /home/zaks/.cache/rag_index_hashes.json 2>/dev/null)
    CACHED_COUNT=$((CACHED_COUNT / 2))
    echo "  Total Indexed: ~$CACHED_COUNT files"
fi
echo ""

# Deal Pipeline
echo "💼 DEAL PIPELINE"
echo "─────────────────────────────────────────────────────────────"

TRACKER="/home/zaks/DataRoom/00-PIPELINE/MASTER-DEAL-TRACKER.csv"
if [ -f "$TRACKER" ]; then
    TOTAL_DEALS=$(tail -n +2 "$TRACKER" 2>/dev/null | wc -l)
    HIGHEST=$(grep -c "HIGHEST" "$TRACKER" 2>/dev/null)
    HIGH=$(grep -c ",HIGH," "$TRACKER" 2>/dev/null)

    echo "  Total Deals: $TOTAL_DEALS"
    echo "  HIGHEST Priority: $HIGHEST"
    echo "  HIGH Priority: $HIGH"
else
    echo "  Status: ⚠ Tracker not found"
fi

# Count deals in pipeline folders
INBOUND=$(find /home/zaks/DataRoom/00-PIPELINE/Inbound -maxdepth 1 -type d 2>/dev/null | wc -l)
SCREENING=$(find /home/zaks/DataRoom/00-PIPELINE/Screening -maxdepth 1 -type d 2>/dev/null | wc -l)
QUALIFIED=$(find /home/zaks/DataRoom/00-PIPELINE/Qualified -maxdepth 1 -type d 2>/dev/null | wc -l)
ACTIVE=$(find /home/zaks/DataRoom/01-ACTIVE-DEALS -maxdepth 1 -type d 2>/dev/null | wc -l)

echo "  Pipeline: Inbound($((INBOUND-1))) → Screening($((SCREENING-1))) → Qualified($((QUALIFIED-1))) → Active($((ACTIVE-1)))"
echo ""

# Services Health
echo "🚀 SERVICES"
echo "─────────────────────────────────────────────────────────────"

# Check RAG REST API (try multiple possible ports)
RAG_OK=false
for port in 8052 8051 8080; do
    if curl -fsS "http://localhost:$port/rag/stats" >/dev/null 2>&1; then
        echo "  RAG REST API (port $port): ✓ Running"
        RAG_OK=true
        break
    fi
done
if [ "$RAG_OK" = false ]; then
    echo "  RAG REST API: ✗ Down or not found"
fi

# Check ChromaDB
if curl -s http://localhost:8002/api/v1/heartbeat >/dev/null 2>&1; then
    echo "  ChromaDB (port 8002): ✓ Running"
else
    echo "  ChromaDB (port 8002): ✗ Down"
fi

# Check vLLM
if curl -s http://localhost:8000/health >/dev/null 2>&1 || curl -s http://localhost:8000/v1/models >/dev/null 2>&1; then
    echo "  vLLM (port 8000): ✓ Running"
else
    echo "  vLLM (port 8000): ✗ Down"
fi

# Check OpenWebUI
if curl -s http://localhost:3000 >/dev/null 2>&1; then
    echo "  OpenWebUI (port 3000): ✓ Running"
else
    echo "  OpenWebUI (port 3000): ✗ Down"
fi

echo ""

# Backups
echo "💾 BACKUPS"
echo "─────────────────────────────────────────────────────────────"

BACKUP_DIR="/home/zaks/backups"
if [ -d "$BACKUP_DIR" ]; then
    DATAROOM_BACKUPS=$(find "$BACKUP_DIR/dataroom" -name "*.tar.gz" 2>/dev/null | wc -l)
    OPENWEBUI_BACKUPS=$(find "$BACKUP_DIR/openwebui" -name "*.db" 2>/dev/null | wc -l)

    echo "  DataRoom Backups: $DATAROOM_BACKUPS"
    echo "  OpenWebUI DB Backups: $OPENWEBUI_BACKUPS"

    LATEST_BACKUP=$(ls -t "$BACKUP_DIR/dataroom/"*.tar.gz 2>/dev/null | head -1)
    if [ -n "$LATEST_BACKUP" ]; then
        BACKUP_DATE=$(stat -c %y "$LATEST_BACKUP" | cut -d' ' -f1)
        BACKUP_SIZE=$(du -h "$LATEST_BACKUP" | cut -f1)
        echo "  Latest: $BACKUP_DATE ($BACKUP_SIZE)"
    fi
else
    echo "  Status: ⚠ Backup directory not found"
fi
echo ""

echo "╚════════════════════════════════════════════════════════════╝"
echo "  Dashboard generated: $(date)"
