#!/usr/bin/env python3
"""
Deferred Actions Processor

Cron job that checks for due actions and executes them.
Designed to run periodically (e.g., hourly) and process any actions
whose scheduled time has passed.

Features:
- Processes due actions in priority order
- Supports action handlers for different action types
- Emits run-ledger records for tracking
- Handles recurring actions automatically
- Safe execution with error handling

Usage:
  ./process_deferred_actions.py              # Process all due actions
  ./process_deferred_actions.py --dry-run    # Preview without executing
  ./process_deferred_actions.py --limit 10   # Process max 10 actions

Cron: 0 * * * * /usr/bin/python3 /home/zaks/scripts/process_deferred_actions.py
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

# Add scripts to path
sys.path.insert(0, str(Path(__file__).resolve().parent))

from deferred_actions import DeferredAction, DeferredActionQueue


# Configuration
RUN_LEDGER_WRITER = "/home/zaks/bookkeeping/scripts/run_ledger.py"
RUN_LEDGER_PATH = os.getenv("ZAKOPS_RUN_LEDGER_PATH", "/home/zaks/logs/run-ledger.jsonl")
NOTIFICATION_LOG = os.getenv("DEFERRED_ACTIONS_NOTIFICATION_LOG", "/home/zaks/logs/deferred_actions_notifications.log")


def _now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _emit_run_ledger(
    *,
    run_id: str,
    status: str,
    started_at: str,
    ended_at: str,
    metrics: Optional[Dict[str, Any]] = None,
    errors: Optional[List[str]] = None,
    correlation: Optional[Dict[str, str]] = None,
) -> None:
    if not os.path.exists(RUN_LEDGER_WRITER):
        return

    args = [
        "python3", RUN_LEDGER_WRITER,
        "--ledger-path", RUN_LEDGER_PATH,
        "--component", "deferred_actions_processor",
        "--run-id", run_id,
        "--status", status,
        "--started-at", started_at,
        "--ended-at", ended_at,
    ]
    for k, v in (metrics or {}).items():
        args.extend(["--metric", f"{k}={v}"])
    for e in (errors or []):
        args.extend(["--error", str(e)[:200]])
    for k, v in (correlation or {}).items():
        args.extend(["--correlation", f"{k}={v}"])

    subprocess.run(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)


def _log_notification(action: DeferredAction, message: str) -> None:
    """Log a notification for operator visibility"""
    try:
        Path(NOTIFICATION_LOG).parent.mkdir(parents=True, exist_ok=True)
        with open(NOTIFICATION_LOG, "a", encoding="utf-8") as f:
            entry = {
                "timestamp": _now_iso(),
                "action_id": action.action_id,
                "deal_id": action.deal_id,
                "action_type": action.action_type,
                "priority": action.priority,
                "message": message,
                "data": action.data,
            }
            f.write(json.dumps(entry, ensure_ascii=False, default=str) + "\n")
    except Exception:
        pass


# Action handlers
# Each handler receives the action and returns (success: bool, result: dict)

def handle_follow_up(action: DeferredAction) -> tuple[bool, Dict[str, Any]]:
    """Handle follow-up reminder actions"""
    message = action.data.get("message", "Follow-up reminder")
    _log_notification(action, f"FOLLOW-UP: {message}")
    return True, {"notification": "logged", "message": message}


def handle_check_status(action: DeferredAction) -> tuple[bool, Dict[str, Any]]:
    """Handle status check actions"""
    _log_notification(action, "STATUS CHECK: Review deal status with broker/counterparty")
    return True, {"notification": "logged"}


def handle_request_update(action: DeferredAction) -> tuple[bool, Dict[str, Any]]:
    """Handle update request actions"""
    _log_notification(action, "REQUEST UPDATE: Request update from counterparty")
    return True, {"notification": "logged"}


def handle_request_cim(action: DeferredAction) -> tuple[bool, Dict[str, Any]]:
    """Handle CIM request actions"""
    _log_notification(action, "REQUEST CIM: Request CIM/Teaser from broker")
    return True, {"notification": "logged"}


def handle_request_financials(action: DeferredAction) -> tuple[bool, Dict[str, Any]]:
    """Handle financials request actions"""
    _log_notification(action, "REQUEST FINANCIALS: Request financial documents")
    return True, {"notification": "logged"}


def handle_review_nda(action: DeferredAction) -> tuple[bool, Dict[str, Any]]:
    """Handle NDA review actions"""
    _log_notification(action, "REVIEW NDA: Check NDA status and expiration")
    return True, {"notification": "logged"}


def handle_quarterly_review(action: DeferredAction) -> tuple[bool, Dict[str, Any]]:
    """Handle quarterly review actions"""
    _log_notification(action, "QUARTERLY REVIEW: Conduct quarterly deal/portfolio review")
    return True, {"notification": "logged", "review_type": "quarterly"}


def handle_monthly_check(action: DeferredAction) -> tuple[bool, Dict[str, Any]]:
    """Handle monthly check actions"""
    _log_notification(action, "MONTHLY CHECK: Monthly status check")
    return True, {"notification": "logged", "review_type": "monthly"}


def handle_integration_milestone(action: DeferredAction) -> tuple[bool, Dict[str, Any]]:
    """Handle integration milestone actions"""
    milestone = action.data.get("milestone", "Integration milestone")
    _log_notification(action, f"INTEGRATION MILESTONE: {milestone}")
    return True, {"notification": "logged", "milestone": milestone}


def handle_loi_expiration(action: DeferredAction) -> tuple[bool, Dict[str, Any]]:
    """Handle LOI expiration warning"""
    expiration = action.data.get("expiration_date", "unknown")
    _log_notification(action, f"LOI EXPIRATION WARNING: LOI expires on {expiration}")
    return True, {"notification": "logged", "expiration_date": expiration, "priority": "high"}


def handle_exclusivity_end(action: DeferredAction) -> tuple[bool, Dict[str, Any]]:
    """Handle exclusivity period ending"""
    _log_notification(action, "EXCLUSIVITY ENDING: Exclusivity period is ending soon")
    return True, {"notification": "logged", "priority": "high"}


def handle_due_diligence_deadline(action: DeferredAction) -> tuple[bool, Dict[str, Any]]:
    """Handle DD deadline warning"""
    _log_notification(action, "DD DEADLINE: Due diligence deadline approaching")
    return True, {"notification": "logged", "priority": "high"}


def handle_ai_analysis(action: DeferredAction) -> tuple[bool, Dict[str, Any]]:
    """Handle AI analysis trigger"""
    try:
        from deal_ai_advisor import DealAIAdvisor

        stage = action.data.get("stage", "operations")
        context = action.data.get("context", {})

        advisor = DealAIAdvisor()
        result = advisor.get_advice(
            deal_id=action.deal_id,
            stage=stage,
            context=context,
            emit_event=True,
            emit_ledger=True,
        )

        if result.error:
            return False, {"error": result.error}

        _log_notification(action, f"AI ANALYSIS COMPLETE: See advisory for {action.deal_id}")
        return True, {"analysis_complete": True, "model": result.model}

    except Exception as e:
        return False, {"error": str(e)}


def handle_market_update(action: DeferredAction) -> tuple[bool, Dict[str, Any]]:
    """Handle market update check"""
    _log_notification(action, "MARKET UPDATE: Review market conditions for deal/portfolio")
    return True, {"notification": "logged"}


def handle_valuation_refresh(action: DeferredAction) -> tuple[bool, Dict[str, Any]]:
    """Handle valuation refresh"""
    _log_notification(action, "VALUATION REFRESH: Refresh valuation model with latest data")
    return True, {"notification": "logged"}


def handle_default(action: DeferredAction) -> tuple[bool, Dict[str, Any]]:
    """Default handler for unknown action types"""
    _log_notification(action, f"ACTION DUE: {action.action_type}")
    return True, {"notification": "logged", "handler": "default"}


# Handler registry
ACTION_HANDLERS: Dict[str, Callable[[DeferredAction], tuple[bool, Dict[str, Any]]]] = {
    "follow_up": handle_follow_up,
    "check_status": handle_check_status,
    "request_update": handle_request_update,
    "request_cim": handle_request_cim,
    "request_financials": handle_request_financials,
    "review_nda": handle_review_nda,
    "quarterly_review": handle_quarterly_review,
    "monthly_check": handle_monthly_check,
    "integration_milestone": handle_integration_milestone,
    "loi_expiration": handle_loi_expiration,
    "exclusivity_end": handle_exclusivity_end,
    "due_diligence_deadline": handle_due_diligence_deadline,
    "ai_analysis": handle_ai_analysis,
    "market_update": handle_market_update,
    "valuation_refresh": handle_valuation_refresh,
}


def process_action(queue: DeferredActionQueue, action: DeferredAction, dry_run: bool = False) -> tuple[bool, Dict[str, Any]]:
    """
    Process a single action.

    Returns (success, result_dict)
    """
    handler = ACTION_HANDLERS.get(action.action_type, handle_default)

    if dry_run:
        return True, {"dry_run": True, "would_execute": action.action_type}

    try:
        success, result = handler(action)

        if success:
            queue.mark_executed(action.action_id, result)
        else:
            queue.mark_failed(action.action_id, result.get("error", "unknown error"))

        return success, result

    except Exception as e:
        error_msg = f"{type(e).__name__}: {str(e)}"
        queue.mark_failed(action.action_id, error_msg)
        return False, {"error": error_msg}


def process_due_actions(
    dry_run: bool = False,
    limit: Optional[int] = None,
    verbose: bool = False,
) -> Dict[str, Any]:
    """
    Process all due actions.

    Returns summary statistics.
    """
    started_at = _now_iso()
    run_id = f"{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}_deferred_processor_{os.getpid()}"

    queue = DeferredActionQueue()
    due_actions = queue.get_due_actions()

    if limit:
        due_actions = due_actions[:limit]

    stats = {
        "total_due": len(due_actions),
        "processed": 0,
        "succeeded": 0,
        "failed": 0,
        "dry_run": dry_run,
    }

    errors: List[str] = []

    for action in due_actions:
        if verbose:
            print(f"Processing: {action.action_id} ({action.action_type}) for {action.deal_id}")

        success, result = process_action(queue, action, dry_run=dry_run)
        stats["processed"] += 1

        if success:
            stats["succeeded"] += 1
            if verbose:
                print(f"  ✓ Success: {result}")
        else:
            stats["failed"] += 1
            error = result.get("error", "unknown")
            errors.append(f"{action.action_id}: {error}")
            if verbose:
                print(f"  ✗ Failed: {error}")

    ended_at = _now_iso()

    # Emit run ledger record
    if not dry_run:
        _emit_run_ledger(
            run_id=run_id,
            status="success" if stats["failed"] == 0 else "partial",
            started_at=started_at,
            ended_at=ended_at,
            metrics={
                "total_due": stats["total_due"],
                "processed": stats["processed"],
                "succeeded": stats["succeeded"],
                "failed": stats["failed"],
            },
            errors=errors[:10],  # Limit errors in ledger
            correlation={},
        )

    return stats


def main() -> int:
    import argparse

    parser = argparse.ArgumentParser(description="Process due deferred actions")
    parser.add_argument("--dry-run", action="store_true", help="Preview without executing")
    parser.add_argument("--limit", type=int, help="Max actions to process")
    parser.add_argument("--verbose", "-v", action="store_true", help="Verbose output")
    parser.add_argument("--show-pending", action="store_true", help="Show pending actions and exit")
    args = parser.parse_args()

    queue = DeferredActionQueue()

    if args.show_pending:
        due = queue.get_due_actions()
        print(f"Due actions: {len(due)}")
        for action in due:
            print(f"  [{action.priority}] {action.action_id}")
            print(f"       Type: {action.action_type}")
            print(f"       Deal: {action.deal_id}")
            print(f"       Scheduled: {action.scheduled_for}")
        return 0

    print(f"Processing deferred actions {'(DRY RUN)' if args.dry_run else ''}...")

    stats = process_due_actions(
        dry_run=args.dry_run,
        limit=args.limit,
        verbose=args.verbose,
    )

    print(f"\nSummary:")
    print(f"  Total due: {stats['total_due']}")
    print(f"  Processed: {stats['processed']}")
    print(f"  Succeeded: {stats['succeeded']}")
    print(f"  Failed: {stats['failed']}")

    if stats["failed"] > 0:
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
