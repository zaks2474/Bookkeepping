#!/bin/bash
# Quarantine E2E Regression Check
# Usage: bash /home/zaks/scripts/test_quarantine_e2e.sh
set -e

echo "=== Quarantine E2E Check ==="
echo "Date: $(date)"
echo ""

# 1. Backend health
echo -n "[1/6] Backend API health: "
if curl -sf http://localhost:8090/api/version > /dev/null 2>&1; then
  echo "OK"
else
  echo "FAIL - Backend not responding on port 8090"
  exit 1
fi

# 2. Quarantine queue
echo -n "[2/6] Quarantine queue: "
QUEUE_RESP=$(curl -sf http://localhost:8090/api/actions/quarantine 2>/dev/null)
if [ $? -eq 0 ]; then
  COUNT=$(echo "$QUEUE_RESP" | jq '.count // 0')
  echo "OK ($COUNT items)"
else
  echo "FAIL - Could not fetch quarantine queue"
  exit 1
fi

# 3. Preview endpoint (first item)
echo -n "[3/6] Preview endpoint: "
FIRST_ID=$(echo "$QUEUE_RESP" | jq -r '.items[0].action_id // empty')
if [ -n "$FIRST_ID" ]; then
  PREVIEW=$(curl -sf "http://localhost:8090/api/actions/quarantine/$FIRST_ID/preview" 2>/dev/null)
  if echo "$PREVIEW" | jq -e '.message_id' > /dev/null 2>&1; then
    echo "OK (message_id present)"
  else
    echo "FAIL - Preview missing message_id"
    exit 1
  fi
else
  echo "SKIP (no items in queue)"
fi

# 4. Deal materials endpoint
echo -n "[4/6] Deal materials endpoint: "
MATERIALS=$(curl -sf http://localhost:8090/api/deals/DEAL-2026-088/materials 2>/dev/null || echo "{}")
if echo "$MATERIALS" | jq -e '.deal_id' > /dev/null 2>&1; then
  echo "OK"
elif echo "$MATERIALS" | jq -e '.detail' > /dev/null 2>&1; then
  echo "SKIP (deal not found - expected for test deal)"
else
  echo "FAIL - Unexpected response"
fi

# 5. Dashboard (quarantine page)
echo -n "[5/6] Dashboard quarantine page: "
if curl -sf http://localhost:3003/quarantine > /dev/null 2>&1; then
  echo "OK"
else
  echo "FAIL - Dashboard not responding"
  exit 1
fi

# 6. Dashboard (deal page)
echo -n "[6/6] Dashboard deal page: "
if curl -sf http://localhost:3003/deals/DEAL-2026-088 > /dev/null 2>&1; then
  echo "OK"
else
  echo "FAIL - Deal page not loading"
  exit 1
fi

echo ""
echo "=== All checks passed ==="
exit 0
