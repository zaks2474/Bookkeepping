#!/bin/bash
#
# ZakOps Service Restart Script
# Restarts API, actions runner, and dashboard (if running as process)
#

set -e

echo "=== ZakOps Service Restart ==="
echo "$(date '+%Y-%m-%d %H:%M:%S')"
echo ""

# Restart API
echo "Restarting zakops-api-8090.service..."
if systemctl is-active --quiet zakops-api-8090.service; then
    sudo systemctl restart zakops-api-8090.service 2>/dev/null || {
        # If sudo not available, try killing the process to trigger systemd restart
        echo "Sudo not available, killing API process to trigger restart..."
        pkill -f "deal_lifecycle_api.py" 2>/dev/null || true
        sleep 3
    }
else
    echo "API service not running, starting..."
    sudo systemctl start zakops-api-8090.service 2>/dev/null || echo "Failed to start API"
fi

# Restart actions runner
echo "Restarting kinetic-actions-runner.service..."
if systemctl is-active --quiet kinetic-actions-runner.service; then
    sudo systemctl restart kinetic-actions-runner.service 2>/dev/null || {
        echo "Sudo not available, killing runner process to trigger restart..."
        pkill -f "actions_runner.py" 2>/dev/null || true
        sleep 3
    }
else
    echo "Actions runner service not running, starting..."
    sudo systemctl start kinetic-actions-runner.service 2>/dev/null || echo "Failed to start runner"
fi

# Dashboard (if running as process, not systemd)
DASHBOARD_PID=$(pgrep -f "next dev --port 3003" || true)
if [ -n "$DASHBOARD_PID" ]; then
    echo "Dashboard running as PID $DASHBOARD_PID"
    echo "To restart dashboard: kill $DASHBOARD_PID && cd /home/zaks/zakops-dashboard && npm run dev"
else
    echo "Dashboard not running as process (may be systemd managed or stopped)"
fi

echo ""
echo "Waiting for services to stabilize..."
sleep 5

# Verify services
echo ""
echo "=== Service Status ==="
systemctl is-active zakops-api-8090.service && echo "API: active" || echo "API: inactive"
systemctl is-active kinetic-actions-runner.service && echo "Runner: active" || echo "Runner: inactive"

# Health check
echo ""
echo "=== Health Check ==="
curl -s http://localhost:8090/health | python3 -c "import sys,json; d=json.load(sys.stdin); print(f'API Health: {d}')" 2>/dev/null || echo "API health check failed"

echo ""
echo "=== Debug Config ==="
curl -s http://localhost:8090/api/debug/config | python3 -c "import sys,json; d=json.load(sys.stdin); print(f'PID: {d[\"server\"][\"pid\"]}'); print(f'Start: {d[\"server\"][\"start_time\"]}')" 2>/dev/null || echo "Debug config check failed"

echo ""
echo "Restart complete."
