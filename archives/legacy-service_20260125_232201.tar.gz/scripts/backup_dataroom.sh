#!/bin/bash
# Daily DataRoom backup

BACKUP_DIR="/home/zaks/backups/dataroom"
DATE=$(date +%Y-%m-%d)
BACKUP_FILE="$BACKUP_DIR/dataroom_$DATE.tar.gz"
LOG_FILE="/home/zaks/logs/backup.log"

echo "=== DataRoom Backup ===" | tee -a "$LOG_FILE"
echo "Date: $(date)" | tee -a "$LOG_FILE"

# Create backup directory
mkdir -p "$BACKUP_DIR"

# Check if backup already exists today
if [ -f "$BACKUP_FILE" ]; then
    echo "Backup already exists for today: $BACKUP_FILE" | tee -a "$LOG_FILE"
    echo "Size: $(du -h "$BACKUP_FILE" | cut -f1)" | tee -a "$LOG_FILE"
    exit 0
fi

echo "Creating DataRoom backup..." | tee -a "$LOG_FILE"

# Create compressed backup
tar -czf "$BACKUP_FILE" \
    -C /home/zaks \
    DataRoom \
    --exclude='DataRoom/08-ARCHIVE/openwebui-chats' \
    --exclude='DataRoom/**/cache' \
    --exclude='DataRoom/**/.git' \
    --exclude='DataRoom/**/__pycache__' \
    --exclude='DataRoom/**/node_modules' \
    --exclude='DataRoom/**/*.db' \
    2>/dev/null

# Verify backup
if [ -f "$BACKUP_FILE" ]; then
    SIZE=$(du -h "$BACKUP_FILE" | cut -f1)
    echo "✓ Backup created: $BACKUP_FILE ($SIZE)" | tee -a "$LOG_FILE"

    # Keep only last 30 days
    echo "Cleaning old backups (keeping last 30 days)..." | tee -a "$LOG_FILE"
    DELETED=$(find "$BACKUP_DIR" -name "dataroom_*.tar.gz" -mtime +30 -delete -print | wc -l)
    echo "✓ Deleted $DELETED old backups" | tee -a "$LOG_FILE"

    # List current backups
    BACKUP_COUNT=$(ls -1 "$BACKUP_DIR"/*.tar.gz 2>/dev/null | wc -l)
    TOTAL_SIZE=$(du -sh "$BACKUP_DIR" | cut -f1)
    echo "Total backups: $BACKUP_COUNT ($TOTAL_SIZE)" | tee -a "$LOG_FILE"
else
    echo "✗ Backup failed" | tee -a "$LOG_FILE"
    exit 1
fi

echo "=== Backup Complete ===" | tee -a "$LOG_FILE"
echo "" | tee -a "$LOG_FILE"
