from __future__ import annotations

import json
import os
import socket
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from ipaddress import ip_address
from typing import Any, Dict, Optional
from urllib.parse import urlparse


def _now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _debug_enabled() -> bool:
    return (os.getenv("ZAKOPS_DEBUG") or "").strip().lower() in {"1", "true", "yes", "on"}


def _webhooks_enabled() -> bool:
    raw = (os.getenv("N8N_WEBHOOKS_ENABLED") or os.getenv("ZAKOPS_N8N_WEBHOOKS_ENABLED") or "").strip().lower()
    return raw in {"1", "true", "yes", "on"}


def _host_is_local(host: str) -> bool:
    host = (host or "").strip()
    if not host:
        return False
    host_l = host.lower()
    if host_l in {"localhost", "127.0.0.1", "::1", "0.0.0.0", "host.docker.internal"}:
        return True
    try:
        ip = ip_address(host_l)
        return bool(ip.is_loopback or ip.is_private)
    except ValueError:
        pass

    try:
        infos = socket.getaddrinfo(host_l, None)
    except Exception:
        return False

    resolved_any = False
    for family, _type, _proto, _canonname, sockaddr in infos:
        if family not in (socket.AF_INET, socket.AF_INET6):
            continue
        resolved_any = True
        ip_str = sockaddr[0]
        try:
            ip = ip_address(ip_str)
        except ValueError:
            return False
        if not (ip.is_loopback or ip.is_private):
            return False
    return resolved_any


def _validate_webhook_url(url: str) -> Optional[str]:
    raw = (url or "").strip()
    if not raw:
        return "webhook_url_empty"
    parsed = urlparse(raw)
    if parsed.scheme not in {"http", "https"}:
        return "webhook_url_bad_scheme"
    host = parsed.hostname or ""
    if not _host_is_local(host):
        return "webhook_url_not_local"
    return None


def emit_event(event: str, payload: Dict[str, Any]) -> None:
    """
    Best-effort webhook emitter for n8n (or any local webhook receiver).

    - Disabled unless `N8N_WEBHOOKS_ENABLED=true` AND `ZAKOPS_N8N_WEBHOOK_URL` is set.
    - SSRF-safe: only allows localhost / loopback / RFC1918 targets.
    - Never raises (fail-safe).
    """
    if not _webhooks_enabled():
        return
    url = (os.getenv("ZAKOPS_N8N_WEBHOOK_URL") or "").strip()
    if not url:
        return
    err = _validate_webhook_url(url)
    if err:
        if _debug_enabled():
            print(f"[n8n_webhook] blocked: {err}")
        return

    body = {
        "event": str(event or "").strip()[:100],
        "timestamp": _now_iso(),
        "payload": payload or {},
    }
    data = json.dumps(body, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(url=url, method="POST", data=data, headers={"Content-Type": "application/json"})

    try:
        with urllib.request.urlopen(req, timeout=5) as resp:
            resp.read()
    except urllib.error.HTTPError as e:
        if _debug_enabled():
            print(f"[n8n_webhook] http_error code={e.code}")
        return
    except Exception as e:
        if _debug_enabled():
            print(f"[n8n_webhook] error {type(e).__name__}")
        return


def emit_quarantine_created(*, message_id: str, thread_id: Optional[str], subject: str, sender: str, classification: str) -> None:
    emit_event(
        "quarantine.created",
        {
            "message_id": message_id,
            "thread_id": thread_id,
            "subject": (subject or "")[:200],
            "sender": (sender or "")[:200],
            "classification": classification,
        },
    )


def emit_quarantine_approved(*, message_id: str, thread_id: Optional[str], deal_id: str, deal_folder: str) -> None:
    emit_event(
        "quarantine.approved",
        {
            "message_id": message_id,
            "thread_id": thread_id,
            "deal_id": deal_id,
            "deal_folder": deal_folder,
        },
    )


def emit_quarantine_rejected(*, message_id: str, thread_id: Optional[str], reason: str) -> None:
    emit_event(
        "quarantine.rejected",
        {
            "message_id": message_id,
            "thread_id": thread_id,
            "reason": (reason or "")[:200],
        },
    )


def emit_auth_required_links_detected(*, deal_id: str, count: int) -> None:
    emit_event(
        "materials.auth_required_links_detected",
        {
            "deal_id": deal_id,
            "auth_required_links": int(count),
        },
    )
