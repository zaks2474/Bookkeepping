from __future__ import annotations

import asyncio
import signal

from temporalio.client import Client
from temporalio.worker import Worker

from .activities import run_deal_lifecycle_controller_once, run_email_triage_once
from .config import load_temporal_config
from .workflows import DealLifecycleControllerOnceWorkflow, EmailTriageOnceWorkflow


async def main_async() -> None:
    cfg = load_temporal_config()
    client = await Client.connect(cfg.host, namespace=cfg.namespace)

    worker = Worker(
        client,
        task_queue=cfg.task_queue,
        workflows=[EmailTriageOnceWorkflow, DealLifecycleControllerOnceWorkflow],
        activities=[run_email_triage_once, run_deal_lifecycle_controller_once],
    )

    stop_event = asyncio.Event()

    def _stop(*_: object) -> None:
        stop_event.set()

    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, _stop)

    worker_task = asyncio.create_task(worker.run())
    await stop_event.wait()
    worker_task.cancel()
    try:
        await worker_task
    except asyncio.CancelledError:
        pass


def main() -> int:
    asyncio.run(main_async())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
