from __future__ import annotations

import argparse
import asyncio
import datetime as dt

from temporalio import client

from .config import load_temporal_config
from .workflows import DealLifecycleControllerOnceWorkflow, EmailTriageOnceWorkflow


def _build_hourly_schedule(action: client.ScheduleAction, *, paused: bool) -> client.Schedule:
    return client.Schedule(
        action=action,
        spec=client.ScheduleSpec(
            intervals=[client.ScheduleIntervalSpec(every=dt.timedelta(hours=1))],
        ),
        policy=client.SchedulePolicy(
            overlap=client.ScheduleOverlapPolicy.SKIP,
            catchup_window=dt.timedelta(minutes=10),
        ),
        state=client.ScheduleState(paused=paused, note="managed by ZakOps temporal_worker"),
    )


async def _connect() -> client.Client:
    cfg = load_temporal_config()
    return await client.Client.connect(cfg.host, namespace=cfg.namespace)


async def upsert_schedules(*, paused_on_create: bool) -> None:
    cfg = load_temporal_config()
    temporal = await _connect()

    triage_action = client.ScheduleActionStartWorkflow(
        EmailTriageOnceWorkflow.run,
        id=cfg.triage_workflow_id,
        task_queue=cfg.task_queue,
        static_summary="ZakOps email triage (hourly)",
    )
    controller_action = client.ScheduleActionStartWorkflow(
        DealLifecycleControllerOnceWorkflow.run,
        id=cfg.controller_workflow_id,
        task_queue=cfg.task_queue,
        static_summary="ZakOps deal lifecycle controller (hourly)",
    )

    desired = {
        cfg.triage_schedule_id: _build_hourly_schedule(triage_action, paused=paused_on_create),
        cfg.controller_schedule_id: _build_hourly_schedule(controller_action, paused=paused_on_create),
    }

    for schedule_id, schedule in desired.items():
        handle = temporal.get_schedule_handle(schedule_id)
        try:
            await temporal.create_schedule(schedule_id, schedule)
            print(f"created schedule: {schedule_id} (paused={schedule.state.paused})")
        except client.ScheduleAlreadyRunningError:
            async def updater(inp: client.ScheduleUpdateInput) -> client.ScheduleUpdate:
                existing_state = inp.description.schedule.state
                next_schedule = client.Schedule(
                    action=schedule.action,
                    spec=schedule.spec,
                    policy=schedule.policy,
                    state=existing_state,
                )
                return client.ScheduleUpdate(schedule=next_schedule)

            await handle.update(updater)
            desc = await handle.describe()
            print(f"updated schedule: {schedule_id} (paused={desc.schedule.state.paused})")


async def list_schedules() -> None:
    temporal = await _connect()
    async for sch in await temporal.list_schedules():
        handle = temporal.get_schedule_handle(sch.id)
        desc = await handle.describe()
        print(f"{sch.id}\tpaused={desc.schedule.state.paused}")


async def pause_schedules() -> None:
    cfg = load_temporal_config()
    temporal = await _connect()
    for schedule_id in (cfg.triage_schedule_id, cfg.controller_schedule_id):
        handle = temporal.get_schedule_handle(schedule_id)
        await handle.pause(note="paused by ZakOps operator")
        print(f"paused: {schedule_id}")


async def unpause_schedules() -> None:
    cfg = load_temporal_config()
    temporal = await _connect()
    for schedule_id in (cfg.triage_schedule_id, cfg.controller_schedule_id):
        handle = temporal.get_schedule_handle(schedule_id)
        await handle.unpause(note="unpaused by ZakOps operator")
        print(f"unpaused: {schedule_id}")


async def run_once(which: str) -> None:
    cfg = load_temporal_config()
    temporal = await _connect()
    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%d_%H%M%S")

    if which in ("triage", "all"):
        wid = f"{cfg.triage_workflow_id}-manual-{stamp}"
        await temporal.start_workflow(EmailTriageOnceWorkflow.run, id=wid, task_queue=cfg.task_queue)
        print(f"started workflow: {wid}")

    if which in ("controller", "all"):
        wid = f"{cfg.controller_workflow_id}-manual-{stamp}"
        await temporal.start_workflow(
            DealLifecycleControllerOnceWorkflow.run, id=wid, task_queue=cfg.task_queue
        )
        print(f"started workflow: {wid}")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="ZakOps Temporal schedules")
    sub = parser.add_subparsers(dest="cmd", required=True)

    upsert_p = sub.add_parser("upsert", help="Create/update hourly schedules")
    upsert_p.add_argument(
        "--paused-on-create",
        action="store_true",
        default=False,
        help="Create schedules paused (updates preserve existing pause state).",
    )
    sub.add_parser("list", help="List schedules")
    sub.add_parser("pause", help="Pause all ZakOps schedules")
    sub.add_parser("unpause", help="Unpause all ZakOps schedules")

    run_p = sub.add_parser("run-once", help="Start a manual triage/controller run")
    run_p.add_argument("which", choices=["triage", "controller", "all"], default="all", nargs="?")

    args = parser.parse_args(argv)

    if args.cmd == "upsert":
        asyncio.run(upsert_schedules(paused_on_create=args.paused_on_create))
        return 0
    if args.cmd == "list":
        asyncio.run(list_schedules())
        return 0
    if args.cmd == "pause":
        asyncio.run(pause_schedules())
        return 0
    if args.cmd == "unpause":
        asyncio.run(unpause_schedules())
        return 0
    if args.cmd == "run-once":
        asyncio.run(run_once(args.which))
        return 0
    raise AssertionError("unreachable")


if __name__ == "__main__":
    raise SystemExit(main())
