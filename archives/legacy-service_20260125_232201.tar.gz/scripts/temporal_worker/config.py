from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class TemporalConfig:
    host: str
    namespace: str
    task_queue: str
    python_bin: str
    triage_schedule_id: str
    controller_schedule_id: str
    triage_workflow_id: str
    controller_workflow_id: str


def load_temporal_config() -> TemporalConfig:
    return TemporalConfig(
        host=os.getenv("TEMPORAL_HOST", "localhost:7233"),
        namespace=os.getenv("TEMPORAL_NAMESPACE", "default"),
        task_queue=os.getenv("TEMPORAL_TASK_QUEUE", "zakops"),
        python_bin=os.getenv("ZAKOPS_ORCH_PYTHON_BIN", "python3"),
        triage_schedule_id=os.getenv("ZAKOPS_TRIAGE_SCHEDULE_ID", "zakops-email-triage-hourly"),
        controller_schedule_id=os.getenv(
            "ZAKOPS_CONTROLLER_SCHEDULE_ID", "zakops-deal-lifecycle-controller-hourly"
        ),
        triage_workflow_id=os.getenv("ZAKOPS_TRIAGE_WORKFLOW_ID", "zakops-email-triage-scheduled"),
        controller_workflow_id=os.getenv(
            "ZAKOPS_CONTROLLER_WORKFLOW_ID", "zakops-deal-lifecycle-controller-scheduled"
        ),
    )
