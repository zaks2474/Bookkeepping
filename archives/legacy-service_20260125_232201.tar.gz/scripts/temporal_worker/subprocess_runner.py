from __future__ import annotations

import datetime as dt
import subprocess
from dataclasses import asdict, dataclass
from pathlib import Path


LOG_DIR = Path("/home/zaks/logs/temporal_worker")
LOG_TAIL_BYTES = 16_384


@dataclass
class SubprocessResult:
    ok: bool
    exit_code: int
    command: list[str]
    cwd: str
    started_at: str
    finished_at: str
    duration_ms: int
    log_path: str
    log_tail: str

    def to_dict(self) -> dict:
        return asdict(self)


def _read_log_tail(path: Path, max_bytes: int) -> str:
    if not path.exists():
        return ""
    with path.open("rb") as f:
        try:
            f.seek(-max_bytes, 2)
        except OSError:
            f.seek(0)
        data = f.read()
    return data.decode("utf-8", errors="replace")


def run_command(
    *,
    command: list[str],
    cwd: str,
    timeout_s: int,
    log_prefix: str,
) -> SubprocessResult:
    LOG_DIR.mkdir(parents=True, exist_ok=True)

    started = dt.datetime.now(dt.timezone.utc)
    stamp = started.strftime("%Y%m%d_%H%M%S")
    log_path = LOG_DIR / f"{log_prefix}_{stamp}.log"

    exit_code = 1
    try:
        with log_path.open("wb") as log_file:
            proc = subprocess.Popen(command, cwd=cwd, stdout=log_file, stderr=subprocess.STDOUT)
            try:
                exit_code = proc.wait(timeout=timeout_s)
            except subprocess.TimeoutExpired:
                proc.kill()
                exit_code = 124
    except FileNotFoundError:
        exit_code = 127
    finished = dt.datetime.now(dt.timezone.utc)

    duration_ms = int((finished - started).total_seconds() * 1000)
    log_tail = _read_log_tail(log_path, LOG_TAIL_BYTES)
    ok = exit_code == 0

    return SubprocessResult(
        ok=ok,
        exit_code=exit_code,
        command=command,
        cwd=cwd,
        started_at=started.isoformat(),
        finished_at=finished.isoformat(),
        duration_ms=duration_ms,
        log_path=str(log_path),
        log_tail=log_tail,
    )

