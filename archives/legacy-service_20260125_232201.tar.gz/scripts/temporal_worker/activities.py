from __future__ import annotations

from typing import Any

from temporalio import activity

from .config import load_temporal_config
from .subprocess_runner import run_command


@activity.defn
async def run_email_triage_once(timeout_s: int = 1_200) -> dict[str, Any]:
    cfg = load_temporal_config()
    result = run_command(
        command=[cfg.python_bin, "-m", "email_triage_agent.run_once"],
        cwd="/home/zaks/bookkeeping/scripts",
        timeout_s=timeout_s,
        log_prefix="email_triage",
    )
    return result.to_dict()


@activity.defn
async def run_deal_lifecycle_controller_once(timeout_s: int = 1_200) -> dict[str, Any]:
    cfg = load_temporal_config()
    result = run_command(
        command=[cfg.python_bin, "/home/zaks/scripts/deal_lifecycle_controller.py"],
        cwd="/home/zaks",
        timeout_s=timeout_s,
        log_prefix="deal_controller",
    )
    return result.to_dict()
