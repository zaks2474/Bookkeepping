"""Temporal orchestration worker for ZakOps (local lab)."""

