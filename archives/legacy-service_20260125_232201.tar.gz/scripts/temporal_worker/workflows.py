from __future__ import annotations

import datetime as dt

from temporalio import workflow
from temporalio.common import RetryPolicy

from .activities import run_deal_lifecycle_controller_once, run_email_triage_once


def _default_retry_policy() -> RetryPolicy:
    return RetryPolicy(
        initial_interval=dt.timedelta(seconds=10),
        maximum_interval=dt.timedelta(minutes=5),
        maximum_attempts=3,
    )


@workflow.defn
class EmailTriageOnceWorkflow:
    @workflow.run
    async def run(self) -> dict:
        result = await workflow.execute_activity(
            run_email_triage_once,
            schedule_to_close_timeout=dt.timedelta(minutes=30),
            start_to_close_timeout=dt.timedelta(minutes=25),
            retry_policy=_default_retry_policy(),
        )
        if not result.get("ok", False):
            raise RuntimeError(
                f"email triage failed (exit={result.get('exit_code')}): {result.get('log_path')}"
            )
        return result


@workflow.defn
class DealLifecycleControllerOnceWorkflow:
    @workflow.run
    async def run(self) -> dict:
        result = await workflow.execute_activity(
            run_deal_lifecycle_controller_once,
            schedule_to_close_timeout=dt.timedelta(minutes=30),
            start_to_close_timeout=dt.timedelta(minutes=25),
            retry_policy=_default_retry_policy(),
        )
        if not result.get("ok", False):
            raise RuntimeError(
                f"deal controller failed (exit={result.get('exit_code')}): {result.get('log_path')}"
            )
        return result

