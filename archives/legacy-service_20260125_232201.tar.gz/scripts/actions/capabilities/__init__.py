"""Capability manifests and registry."""

