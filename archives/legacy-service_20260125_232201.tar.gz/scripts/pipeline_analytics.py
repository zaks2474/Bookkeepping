#!/usr/bin/env python3
"""
Pipeline Analytics

Deep analytics for deal pipeline:
- Per-stage throughput and velocity
- Time-in-stage analysis with anomaly detection
- Conversion funnel analysis
- Stuck deal identification and alerts
- Historical trend analysis
- Stage duration forecasting

Usage:
    python3 pipeline_analytics.py throughput
    python3 pipeline_analytics.py velocity --stage screening
    python3 pipeline_analytics.py stuck --threshold 1.5
    python3 pipeline_analytics.py funnel
    python3 pipeline_analytics.py trends --days 90
    python3 pipeline_analytics.py forecast DEAL-2025-001
"""

from __future__ import annotations

import argparse
import json
import statistics
from collections import defaultdict
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# Configuration
REGISTRY_PATH = Path("/home/zaks/DataRoom/.deal-registry/deal_registry.json")
EVENTS_DIR = Path("/home/zaks/DataRoom/.deal-registry/events")
ANALYTICS_DIR = Path("/home/zaks/DataRoom/.deal-registry/analytics")

# Ensure directories exist
ANALYTICS_DIR.mkdir(parents=True, exist_ok=True)

# Stage order for funnel analysis
STAGE_ORDER = [
    "inbound", "screening", "qualified", "loi", "diligence",
    "closing", "integration", "operations", "growth", "exit_planning",
    "closed_won"
]

# Typical stage durations (days) for benchmarking
BENCHMARK_DURATIONS = {
    "inbound": {"p50": 7, "p90": 21},
    "screening": {"p50": 14, "p90": 45},
    "qualified": {"p50": 21, "p90": 60},
    "loi": {"p50": 30, "p90": 90},
    "diligence": {"p50": 60, "p90": 120},
    "closing": {"p50": 30, "p90": 75},
    "integration": {"p50": 90, "p90": 180},
    "operations": {"p50": 365, "p90": 730},
    "growth": {"p50": 365, "p90": 730},
    "exit_planning": {"p50": 180, "p90": 365},
}


@dataclass
class StageStats:
    """Statistics for a single stage"""
    stage: str
    count: int = 0
    avg_days: float = 0.0
    median_days: float = 0.0
    min_days: float = 0.0
    max_days: float = 0.0
    p90_days: float = 0.0
    std_dev: float = 0.0
    conversion_rate: float = 0.0
    drop_rate: float = 0.0
    benchmark_p50: float = 0.0
    benchmark_p90: float = 0.0
    performance_vs_benchmark: str = "on_track"  # ahead, on_track, behind, at_risk


@dataclass
class ThroughputMetrics:
    """Pipeline throughput analysis"""
    timestamp: str
    total_active_deals: int = 0
    stage_stats: Dict[str, StageStats] = field(default_factory=dict)
    weekly_new_deals: int = 0
    weekly_closed_won: int = 0
    weekly_closed_lost: int = 0
    avg_deal_velocity_days: float = 0.0
    bottleneck_stage: Optional[str] = None


@dataclass
class FunnelMetrics:
    """Conversion funnel analysis"""
    timestamp: str
    stages: List[Dict[str, Any]] = field(default_factory=list)
    overall_conversion_rate: float = 0.0
    biggest_drop_stage: Optional[str] = None
    avg_time_to_close_won: float = 0.0
    avg_time_to_close_lost: float = 0.0


@dataclass
class StuckDeal:
    """A deal that's stuck in a stage"""
    deal_id: str
    company: str
    stage: str
    days_in_stage: int
    expected_days: float
    deviation_factor: float
    last_activity: Optional[str]
    suggested_action: str


@dataclass
class TrendPoint:
    """A point in time for trend analysis"""
    date: str
    deals_by_stage: Dict[str, int]
    total_active: int
    new_deals: int
    closed_deals: int


class PipelineAnalytics:
    """
    Deep analytics for deal pipeline performance.
    """

    def __init__(self):
        self.registry = self._load_registry()
        self.events = self._load_all_events()

    def _load_registry(self) -> Dict[str, Any]:
        """Load deal registry"""
        if REGISTRY_PATH.exists():
            with open(REGISTRY_PATH) as f:
                return json.load(f)
        return {"deals": {}}

    def _load_all_events(self) -> List[Dict[str, Any]]:
        """Load all events from event store"""
        events = []
        if EVENTS_DIR.exists():
            for event_file in EVENTS_DIR.glob("*.jsonl"):
                with open(event_file) as f:
                    for line in f:
                        line = line.strip()
                        if line:
                            try:
                                events.append(json.loads(line))
                            except json.JSONDecodeError:
                                continue
        return events

    def _get_stage_history(self, deal_id: str) -> List[Dict[str, Any]]:
        """Get stage transition history for a deal"""
        transitions = []
        for event in self.events:
            if event.get("deal_id") == deal_id and event.get("event_type") == "stage_changed":
                transitions.append({
                    "timestamp": event.get("timestamp"),
                    "from_stage": event.get("data", {}).get("from_stage"),
                    "to_stage": event.get("data", {}).get("to_stage"),
                })
        return sorted(transitions, key=lambda x: x.get("timestamp", ""))

    def _calculate_stage_durations(self) -> Dict[str, List[float]]:
        """Calculate time spent in each stage for all deals"""
        stage_durations = defaultdict(list)
        deals = self.registry.get("deals", {})

        for deal_id, deal in deals.items():
            if deal.get("status") not in ["active", "merged"]:
                continue

            history = self._get_stage_history(deal_id)

            # If no transitions, use created_at to updated_at
            if not history:
                created = deal.get("created_at")
                updated = deal.get("updated_at")
                stage = deal.get("stage", "inbound").lower()
                if created and updated:
                    try:
                        start = datetime.fromisoformat(created.replace("Z", "+00:00"))
                        end = datetime.fromisoformat(updated.replace("Z", "+00:00"))
                        days = (end - start).days
                        if days >= 0:
                            stage_durations[stage].append(days)
                    except (ValueError, TypeError):
                        pass
                continue

            # Calculate duration between transitions
            for i, transition in enumerate(history):
                to_stage = transition.get("to_stage", "").lower()
                ts = transition.get("timestamp")

                if not ts or not to_stage:
                    continue

                try:
                    start = datetime.fromisoformat(ts.replace("Z", "+00:00"))

                    # End is either next transition or now
                    if i + 1 < len(history):
                        end_ts = history[i + 1].get("timestamp")
                        end = datetime.fromisoformat(end_ts.replace("Z", "+00:00"))
                    else:
                        end = datetime.now(timezone.utc)

                    days = (end - start).days
                    if days >= 0:
                        stage_durations[to_stage].append(days)
                except (ValueError, TypeError):
                    continue

        return stage_durations

    def analyze_throughput(self) -> ThroughputMetrics:
        """
        Analyze pipeline throughput and velocity.

        Returns:
            ThroughputMetrics with detailed stage statistics
        """
        metrics = ThroughputMetrics(
            timestamp=datetime.now(timezone.utc).isoformat()
        )

        deals = self.registry.get("deals", {})
        stage_durations = self._calculate_stage_durations()
        now = datetime.now(timezone.utc)
        week_ago = now - timedelta(days=7)

        # Count deals by stage
        stage_counts = defaultdict(int)
        stage_forward = defaultdict(int)
        stage_dropped = defaultdict(int)

        for deal_id, deal in deals.items():
            if deal.get("status") == "active":
                metrics.total_active_deals += 1
                stage = deal.get("stage", "unknown").lower()
                stage_counts[stage] += 1

            # Weekly metrics
            created = deal.get("created_at")
            if created:
                try:
                    created_dt = datetime.fromisoformat(created.replace("Z", "+00:00"))
                    if created_dt > week_ago:
                        metrics.weekly_new_deals += 1
                except (ValueError, TypeError):
                    pass

            # Track outcomes
            stage = deal.get("stage", "").lower()
            if stage == "closed_won":
                metrics.weekly_closed_won += 1
            elif stage == "closed_lost":
                metrics.weekly_closed_lost += 1

        # Analyze stage transitions for conversion
        for event in self.events:
            if event.get("event_type") == "stage_changed":
                data = event.get("data", {})
                from_stage = data.get("from_stage", "").lower()
                to_stage = data.get("to_stage", "").lower()

                if to_stage == "closed_lost":
                    stage_dropped[from_stage] += 1
                elif to_stage and from_stage:
                    stage_forward[from_stage] += 1

        # Calculate statistics per stage
        max_avg_days = 0
        bottleneck = None

        for stage in STAGE_ORDER:
            durations = stage_durations.get(stage, [])
            count = stage_counts.get(stage, 0)

            stats = StageStats(
                stage=stage,
                count=count,
                benchmark_p50=BENCHMARK_DURATIONS.get(stage, {}).get("p50", 30),
                benchmark_p90=BENCHMARK_DURATIONS.get(stage, {}).get("p90", 90)
            )

            if durations:
                stats.avg_days = round(statistics.mean(durations), 1)
                stats.median_days = round(statistics.median(durations), 1)
                stats.min_days = min(durations)
                stats.max_days = max(durations)
                stats.p90_days = round(sorted(durations)[int(len(durations) * 0.9)] if len(durations) >= 5 else max(durations), 1)

                if len(durations) > 1:
                    stats.std_dev = round(statistics.stdev(durations), 1)

                # Performance vs benchmark
                if stats.median_days <= stats.benchmark_p50 * 0.8:
                    stats.performance_vs_benchmark = "ahead"
                elif stats.median_days <= stats.benchmark_p50:
                    stats.performance_vs_benchmark = "on_track"
                elif stats.median_days <= stats.benchmark_p90:
                    stats.performance_vs_benchmark = "behind"
                else:
                    stats.performance_vs_benchmark = "at_risk"

                # Track bottleneck
                if stats.avg_days > max_avg_days and count > 0:
                    max_avg_days = stats.avg_days
                    bottleneck = stage

            # Conversion rates
            forward = stage_forward.get(stage, 0)
            dropped = stage_dropped.get(stage, 0)
            total_exits = forward + dropped
            if total_exits > 0:
                stats.conversion_rate = round(forward / total_exits, 3)
                stats.drop_rate = round(dropped / total_exits, 3)

            metrics.stage_stats[stage] = stats

        metrics.bottleneck_stage = bottleneck

        # Calculate average deal velocity
        all_durations = []
        for durations in stage_durations.values():
            all_durations.extend(durations)
        if all_durations:
            metrics.avg_deal_velocity_days = round(statistics.mean(all_durations), 1)

        return metrics

    def analyze_funnel(self) -> FunnelMetrics:
        """
        Analyze conversion funnel across stages.

        Returns:
            FunnelMetrics with funnel analysis
        """
        metrics = FunnelMetrics(
            timestamp=datetime.now(timezone.utc).isoformat()
        )

        deals = self.registry.get("deals", {})

        # Count deals that reached each stage
        stage_reached = defaultdict(set)
        for deal_id, deal in deals.items():
            current_stage = deal.get("stage", "inbound").lower()

            # Mark all stages up to current
            current_idx = STAGE_ORDER.index(current_stage) if current_stage in STAGE_ORDER else 0
            for i in range(current_idx + 1):
                stage_reached[STAGE_ORDER[i]].add(deal_id)

            # Also check history
            for event in self.events:
                if event.get("deal_id") == deal_id and event.get("event_type") == "stage_changed":
                    to_stage = event.get("data", {}).get("to_stage", "").lower()
                    if to_stage in STAGE_ORDER:
                        stage_reached[to_stage].add(deal_id)

        # Build funnel
        prev_count = 0
        biggest_drop = 0
        biggest_drop_stage = None

        for i, stage in enumerate(STAGE_ORDER):
            count = len(stage_reached.get(stage, set()))

            funnel_entry = {
                "stage": stage,
                "deals_reached": count,
                "conversion_from_prev": 1.0 if i == 0 else (count / prev_count if prev_count > 0 else 0),
                "cumulative_conversion": count / len(deals) if deals else 0
            }

            if i > 0 and prev_count > 0:
                drop = 1 - funnel_entry["conversion_from_prev"]
                if drop > biggest_drop:
                    biggest_drop = drop
                    biggest_drop_stage = STAGE_ORDER[i - 1]

            metrics.stages.append(funnel_entry)
            prev_count = count

        metrics.biggest_drop_stage = biggest_drop_stage

        # Calculate time to close
        close_times_won = []
        close_times_lost = []

        for deal_id, deal in deals.items():
            stage = deal.get("stage", "").lower()
            created = deal.get("created_at")

            if stage in ["closed_won", "closed_lost"] and created:
                try:
                    start = datetime.fromisoformat(created.replace("Z", "+00:00"))
                    end = datetime.fromisoformat(deal.get("updated_at", created).replace("Z", "+00:00"))
                    days = (end - start).days

                    if stage == "closed_won":
                        close_times_won.append(days)
                    else:
                        close_times_lost.append(days)
                except (ValueError, TypeError):
                    pass

        if close_times_won:
            metrics.avg_time_to_close_won = round(statistics.mean(close_times_won), 1)
        if close_times_lost:
            metrics.avg_time_to_close_lost = round(statistics.mean(close_times_lost), 1)

        # Overall conversion
        closed_won = len(stage_reached.get("closed_won", set()))
        if deals:
            metrics.overall_conversion_rate = round(closed_won / len(deals), 3)

        return metrics

    def find_stuck_deals(self, threshold_factor: float = 1.5) -> List[StuckDeal]:
        """
        Find deals that are stuck in their current stage.

        Args:
            threshold_factor: Multiplier of benchmark p90 to consider "stuck"

        Returns:
            List of StuckDeal objects
        """
        stuck = []
        deals = self.registry.get("deals", {})
        now = datetime.now(timezone.utc)

        for deal_id, deal in deals.items():
            if deal.get("status") != "active":
                continue

            stage = deal.get("stage", "inbound").lower()
            updated = deal.get("updated_at")

            if not updated:
                continue

            try:
                last_update = datetime.fromisoformat(updated.replace("Z", "+00:00"))
                days_in_stage = (now - last_update).days

                benchmark = BENCHMARK_DURATIONS.get(stage, {})
                expected_p90 = benchmark.get("p90", 30)
                threshold = expected_p90 * threshold_factor

                if days_in_stage > threshold:
                    deviation = round(days_in_stage / expected_p90, 1)

                    # Suggest action based on stage
                    if stage in ["inbound", "screening"]:
                        action = "Review and qualify or mark as junk"
                    elif stage in ["qualified", "loi"]:
                        action = "Follow up with broker/seller or reassess interest"
                    elif stage == "diligence":
                        action = "Check DD progress, identify blockers"
                    elif stage == "closing":
                        action = "Verify closing timeline with all parties"
                    else:
                        action = "Review and take appropriate action"

                    stuck.append(StuckDeal(
                        deal_id=deal_id,
                        company=deal.get("canonical_name", deal_id),
                        stage=stage,
                        days_in_stage=days_in_stage,
                        expected_days=expected_p90,
                        deviation_factor=deviation,
                        last_activity=updated,
                        suggested_action=action
                    ))
            except (ValueError, TypeError):
                continue

        # Sort by deviation factor
        stuck.sort(key=lambda x: x.deviation_factor, reverse=True)
        return stuck

    def analyze_trends(self, days: int = 90) -> List[TrendPoint]:
        """
        Analyze pipeline trends over time.

        Args:
            days: Number of days to analyze

        Returns:
            List of weekly TrendPoints
        """
        trends = []
        now = datetime.now(timezone.utc)
        deals = self.registry.get("deals", {})

        # Build weekly snapshots
        weeks = days // 7
        for w in range(weeks, -1, -1):
            week_end = now - timedelta(days=w * 7)
            week_start = week_end - timedelta(days=7)

            # Count deals active as of this date
            stage_counts = defaultdict(int)
            total_active = 0
            new_deals = 0
            closed_deals = 0

            for deal_id, deal in deals.items():
                created = deal.get("created_at")
                updated = deal.get("updated_at")

                if not created:
                    continue

                try:
                    created_dt = datetime.fromisoformat(created.replace("Z", "+00:00"))

                    # Skip if created after this week
                    if created_dt > week_end:
                        continue

                    # Check if new this week
                    if created_dt > week_start:
                        new_deals += 1

                    # Determine stage at this point in time
                    # (simplified - use current stage if deal existed)
                    stage = deal.get("stage", "inbound").lower()

                    if deal.get("status") == "active":
                        total_active += 1
                        stage_counts[stage] += 1
                    elif stage in ["closed_won", "closed_lost"]:
                        if updated:
                            updated_dt = datetime.fromisoformat(updated.replace("Z", "+00:00"))
                            if week_start < updated_dt <= week_end:
                                closed_deals += 1

                except (ValueError, TypeError):
                    continue

            trends.append(TrendPoint(
                date=week_end.strftime("%Y-%m-%d"),
                deals_by_stage=dict(stage_counts),
                total_active=total_active,
                new_deals=new_deals,
                closed_deals=closed_deals
            ))

        return trends

    def forecast_deal(self, deal_id: str) -> Dict[str, Any]:
        """
        Forecast timeline for a specific deal based on historical patterns.

        Args:
            deal_id: Deal identifier

        Returns:
            Dict with forecast information
        """
        deal = self.registry.get("deals", {}).get(deal_id)
        if not deal:
            return {"error": f"Deal {deal_id} not found"}

        current_stage = deal.get("stage", "inbound").lower()
        stage_durations = self._calculate_stage_durations()

        # Find remaining stages
        try:
            current_idx = STAGE_ORDER.index(current_stage)
        except ValueError:
            current_idx = 0

        remaining_stages = STAGE_ORDER[current_idx + 1:]

        # Calculate expected time in current stage
        current_durations = stage_durations.get(current_stage, [])
        expected_current = statistics.median(current_durations) if current_durations else BENCHMARK_DURATIONS.get(current_stage, {}).get("p50", 30)

        # Calculate expected time for remaining stages (to closed_won)
        forecast_stages = []
        total_remaining_days = 0

        for stage in remaining_stages:
            if stage in ["closed_lost", "closed_won"]:
                continue

            durations = stage_durations.get(stage, [])
            expected = statistics.median(durations) if durations else BENCHMARK_DURATIONS.get(stage, {}).get("p50", 30)
            p90 = sorted(durations)[int(len(durations) * 0.9)] if len(durations) >= 5 else expected * 1.5

            forecast_stages.append({
                "stage": stage,
                "expected_days": round(expected, 0),
                "p90_days": round(p90, 0)
            })
            total_remaining_days += expected

        # Current time in stage
        updated = deal.get("updated_at")
        days_elapsed = 0
        if updated:
            try:
                last_update = datetime.fromisoformat(updated.replace("Z", "+00:00"))
                days_elapsed = (datetime.now(timezone.utc) - last_update).days
            except (ValueError, TypeError):
                pass

        remaining_in_current = max(0, expected_current - days_elapsed)

        return {
            "deal_id": deal_id,
            "company": deal.get("canonical_name", deal_id),
            "current_stage": current_stage,
            "days_in_current_stage": days_elapsed,
            "expected_days_in_current": round(expected_current, 0),
            "remaining_in_current": round(remaining_in_current, 0),
            "remaining_stages": forecast_stages,
            "total_days_to_close": round(remaining_in_current + total_remaining_days, 0),
            "estimated_close_date": (datetime.now(timezone.utc) + timedelta(days=remaining_in_current + total_remaining_days)).strftime("%Y-%m-%d")
        }


def main():
    parser = argparse.ArgumentParser(description="Pipeline Analytics")
    subparsers = parser.add_subparsers(dest="command", help="Commands")

    # throughput
    throughput_parser = subparsers.add_parser("throughput", help="Analyze pipeline throughput")

    # velocity
    velocity_parser = subparsers.add_parser("velocity", help="Stage velocity analysis")
    velocity_parser.add_argument("--stage", help="Specific stage to analyze")

    # stuck
    stuck_parser = subparsers.add_parser("stuck", help="Find stuck deals")
    stuck_parser.add_argument("--threshold", type=float, default=1.5, help="Threshold factor (default 1.5x p90)")

    # funnel
    funnel_parser = subparsers.add_parser("funnel", help="Conversion funnel analysis")

    # trends
    trends_parser = subparsers.add_parser("trends", help="Historical trend analysis")
    trends_parser.add_argument("--days", type=int, default=90, help="Analysis period in days")

    # forecast
    forecast_parser = subparsers.add_parser("forecast", help="Forecast deal timeline")
    forecast_parser.add_argument("deal_id", help="Deal ID to forecast")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return

    analytics = PipelineAnalytics()

    if args.command == "throughput":
        metrics = analytics.analyze_throughput()
        print(f"\n{'='*60}")
        print("PIPELINE THROUGHPUT ANALYSIS")
        print(f"{'='*60}")
        print(f"Total Active Deals: {metrics.total_active_deals}")
        print(f"Weekly New Deals: {metrics.weekly_new_deals}")
        print(f"Weekly Closed Won: {metrics.weekly_closed_won}")
        print(f"Weekly Closed Lost: {metrics.weekly_closed_lost}")
        print(f"Avg Deal Velocity: {metrics.avg_deal_velocity_days} days")
        print(f"Bottleneck Stage: {metrics.bottleneck_stage or 'None identified'}")
        print(f"\nStage Statistics:")
        for stage in STAGE_ORDER:
            stats = metrics.stage_stats.get(stage)
            if stats and stats.count > 0:
                print(f"\n  {stage.upper()}: {stats.count} deals")
                print(f"    Avg/Median: {stats.avg_days}/{stats.median_days} days")
                print(f"    Range: {stats.min_days}-{stats.max_days} days (p90: {stats.p90_days})")
                print(f"    Conversion: {stats.conversion_rate * 100:.0f}%")
                print(f"    Status: {stats.performance_vs_benchmark}")

    elif args.command == "velocity":
        metrics = analytics.analyze_throughput()
        if args.stage:
            stats = metrics.stage_stats.get(args.stage.lower())
            if stats:
                print(json.dumps(asdict(stats), indent=2))
            else:
                print(f"Stage '{args.stage}' not found")
        else:
            for stage, stats in metrics.stage_stats.items():
                if stats.count > 0:
                    print(f"{stage}: {stats.avg_days} days avg, {stats.count} deals")

    elif args.command == "stuck":
        stuck = analytics.find_stuck_deals(args.threshold)
        print(f"\n{'='*60}")
        print(f"STUCK DEALS (threshold: {args.threshold}x p90)")
        print(f"{'='*60}")
        if stuck:
            for deal in stuck[:20]:
                print(f"\n{deal.company} ({deal.deal_id})")
                print(f"  Stage: {deal.stage}")
                print(f"  Days: {deal.days_in_stage} (expected: {deal.expected_days})")
                print(f"  Deviation: {deal.deviation_factor}x")
                print(f"  Action: {deal.suggested_action}")
        else:
            print("No stuck deals found")

    elif args.command == "funnel":
        metrics = analytics.analyze_funnel()
        print(f"\n{'='*60}")
        print("CONVERSION FUNNEL")
        print(f"{'='*60}")
        for entry in metrics.stages:
            if entry["deals_reached"] > 0:
                conv = entry["conversion_from_prev"] * 100
                print(f"{entry['stage'].upper():15} {entry['deals_reached']:4} deals ({conv:5.1f}% from prev)")
        print(f"\nOverall Conversion to Won: {metrics.overall_conversion_rate * 100:.1f}%")
        print(f"Biggest Drop Stage: {metrics.biggest_drop_stage or 'N/A'}")
        print(f"Avg Time to Close Won: {metrics.avg_time_to_close_won or 'N/A'} days")
        print(f"Avg Time to Close Lost: {metrics.avg_time_to_close_lost or 'N/A'} days")

    elif args.command == "trends":
        trends = analytics.analyze_trends(args.days)
        print(f"\n{'='*60}")
        print(f"PIPELINE TRENDS (Last {args.days} days)")
        print(f"{'='*60}")
        print(f"{'Date':12} {'Active':8} {'New':6} {'Closed':8}")
        print("-" * 40)
        for point in trends:
            print(f"{point.date:12} {point.total_active:8} {point.new_deals:6} {point.closed_deals:8}")

    elif args.command == "forecast":
        forecast = analytics.forecast_deal(args.deal_id)
        if "error" in forecast:
            print(forecast["error"])
        else:
            print(f"\n{'='*60}")
            print(f"DEAL FORECAST: {forecast['company']}")
            print(f"{'='*60}")
            print(f"Current Stage: {forecast['current_stage']}")
            print(f"Days in Stage: {forecast['days_in_current_stage']}")
            print(f"Expected Days: {forecast['expected_days_in_current']}")
            print(f"Remaining in Current: {forecast['remaining_in_current']} days")
            print(f"\nRemaining Stages:")
            for stage in forecast["remaining_stages"]:
                print(f"  {stage['stage']}: ~{stage['expected_days']} days (p90: {stage['p90_days']})")
            print(f"\nTotal Days to Close: ~{forecast['total_days_to_close']} days")
            print(f"Estimated Close Date: {forecast['estimated_close_date']}")


if __name__ == "__main__":
    main()
