#!/usr/bin/env python3
"""
DataRoom RAG Indexer

Indexes DataRoom content into RAG system via POST /rag/add

Features:
- Incremental indexing (hash-based change detection)
- Intelligent exclusions (binaries, secrets, caches)
- Metadata extraction (deal, stage, doc type)
- Stable synthetic URLs for document identity
- Delete handling for removed files
"""

import os
import sys
import json
import hashlib
import requests
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Tuple, Optional
import re

# Best-effort secret scanning (prevents indexing obvious credentials).
try:
    from zakops_secret_scan import find_secrets_in_text
    SECRET_SCAN_AVAILABLE = True
except Exception:
    SECRET_SCAN_AVAILABLE = False

SECRET_SCAN_ENABLED = os.getenv("ZAKOPS_RAG_SECRET_SCAN", "1").strip().lower() not in {"0", "false", "no", "off"}

# Configuration
CONFIG = {
    "dataroom_path": "/home/zaks/DataRoom",
    "rag_api_url": os.getenv("RAG_API_URL", "http://localhost:8052/rag/add"),
    "hash_cache_file": "/home/zaks/.cache/rag_index_hashes.json",
    "log_file": f"/home/zaks/logs/rag_index_{datetime.now().strftime('%Y%m%d')}.log",
    "url_prefix": "https://dataroom.local/DataRoom",  # Synthetic URL prefix
}

# Inclusion patterns (what to index)
INCLUDE_EXTENSIONS = {
    ".md",
    ".txt",
    ".csv",
    ".json",
    ".yaml",
    ".yml",
    # ".pdf",  # Add later with OCR extraction
}

# Exclusion patterns
EXCLUDE_PATTERNS = [
    "**/cache/**",
    "**/vector_db/**",
    "**/__pycache__/**",
    "**/.env",
    "**/*secret*",
    "**/*token*",
    "**/*password*",
    "**/.DS_Store",
    "**/*.db",
    "**/{*",
    "**/*}*",
]


class DataRoomIndexer:
    def __init__(self):
        self.hash_cache = self.load_hash_cache()
        self.stats = {
            "indexed": 0,
            "skipped": 0,
            "errors": 0,
            "deleted": 0,
        }

    def load_hash_cache(self) -> Dict[str, str]:
        """Load hash cache for incremental indexing."""
        cache_file = Path(CONFIG["hash_cache_file"])
        if cache_file.exists():
            try:
                with open(cache_file, 'r') as f:
                    return json.load(f)
            except (json.JSONDecodeError, IOError):
                return {}
        return {}

    def save_hash_cache(self):
        """Save hash cache."""
        cache_file = Path(CONFIG["hash_cache_file"])
        cache_file.parent.mkdir(parents=True, exist_ok=True)
        with open(cache_file, 'w') as f:
            json.dump(self.hash_cache, f, indent=2)

    def calculate_file_hash(self, file_path: str) -> str:
        """Calculate SHA256 hash of file."""
        sha256_hash = hashlib.sha256()
        with open(file_path, "rb") as f:
            for byte_block in iter(lambda: f.read(4096), b""):
                sha256_hash.update(byte_block)
        return sha256_hash.hexdigest()

    def should_include(self, path: Path) -> bool:
        """Check if file should be indexed."""
        # Check extension
        if path.suffix.lower() not in INCLUDE_EXTENSIONS:
            return False

        # Check exclusion patterns
        path_str = str(path)
        for pattern in EXCLUDE_PATTERNS:
            if path.match(pattern) or any(p in path_str for p in ['{', '}', 'cache', 'vector_db', '__pycache__']):
                return False

        return True

    def extract_metadata(self, file_path: Path) -> Dict:
        """Extract metadata from file path and content."""
        rel_path = file_path.relative_to(CONFIG["dataroom_path"])
        parts = rel_path.parts

        metadata = {
            "source": "dataroom",
            "path": str(rel_path),
            "filename": file_path.name,
            "extension": file_path.suffix,
            "modified": datetime.fromtimestamp(file_path.stat().st_mtime).isoformat(),
        }

        # Extract section from top-level directory
        if len(parts) > 0:
            section = parts[0]
            metadata["section"] = section

            # Parse section name
            section_map = {
                "00-": "Pipeline",
                "01-": "Active Deals",
                "02-": "Portfolio",
                "03-": "Deal Sources",
                "04-": "Frameworks",
                "05-": "Advisors",
                "06-": "Knowledge Base",
                "07-": "Finance",
                "08-": "Archive",
            }
            for prefix, name in section_map.items():
                if section.startswith(prefix):
                    metadata["section_name"] = name
                    break

        # Extract deal/stage where it makes sense
        if parts and parts[0] == "00-PIPELINE" and len(parts) > 2:
            # 00-PIPELINE/<Stage>/<Deal>/...
            metadata["stage"] = parts[1]
            metadata["deal"] = parts[2]
        elif parts and parts[0] == "01-ACTIVE-DEALS" and len(parts) > 1:
            # 01-ACTIVE-DEALS/<Deal>/...
            metadata["stage"] = "Active"
            metadata["deal"] = parts[1]
        elif parts and parts[0] == "08-ARCHIVE" and len(parts) > 1:
            # 08-ARCHIVE/<Bucket>/<MaybeDeal>/...
            metadata["stage"] = parts[1]
            if len(parts) > 2:
                metadata["deal"] = parts[2]

        # Determine doc type from filename
        filename_lower = file_path.name.lower()
        doc_type_patterns = {
            "readme": "Summary",
            "nda": "NDA",
            "cim": "CIM",
            "executive-summary": "CIM",
            "financial": "Financials",
            "p&l": "Financials",
            "tracker": "Tracker",
            "analysis": "Analysis",
            "scorecard": "Analysis",
            "correspondence": "Correspondence",
            "email": "Correspondence",
        }
        metadata["doc_type"] = "Document"
        for pattern, doc_type in doc_type_patterns.items():
            if pattern in filename_lower:
                metadata["doc_type"] = doc_type
                break

        return metadata

    def generate_synthetic_url(self, file_path: Path) -> str:
        """Generate stable synthetic URL for document."""
        rel_path = file_path.relative_to(CONFIG["dataroom_path"])
        return f"{CONFIG['url_prefix']}/{rel_path}"

    def index_file(self, file_path: Path) -> bool:
        """Index a single file to RAG."""
        try:
            # Read content
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
            except UnicodeDecodeError:
                with open(file_path, 'r', encoding='latin-1') as f:
                    content = f.read()

            # Skip empty files
            if not content.strip():
                print(f"⏭ Skipped (empty): {file_path.name}")
                self.stats["skipped"] += 1
                return True

            # Prevent secret-like content from entering RAG index.
            if SECRET_SCAN_AVAILABLE and SECRET_SCAN_ENABLED:
                findings = find_secrets_in_text(content)
                if findings:
                    print(
                        f"✗ Refusing to index (secret-like content detected): {file_path.name} "
                        f"({', '.join(findings)})"
                    )
                    self.stats["errors"] += 1
                    return False

            # Generate synthetic URL
            url = self.generate_synthetic_url(file_path)

            # Extract metadata
            metadata = self.extract_metadata(file_path)

            # Prepare payload for RAG API
            payload = {
                "url": url,
                "content": content,
                "metadata": metadata,
                "chunk_size": 5000,  # Character chunking
            }

            # POST to RAG API
            response = requests.post(
                CONFIG["rag_api_url"],
                json=payload,
                timeout=30
            )

            if response.status_code == 200:
                print(f"✓ Indexed: {file_path.name}")
                self.stats["indexed"] += 1
                return True
            else:
                print(f"✗ Error indexing {file_path.name}: {response.status_code} {response.text[:100]}")
                self.stats["errors"] += 1
                return False

        except requests.exceptions.ConnectionError:
            print(f"✗ RAG API not available at {CONFIG['rag_api_url']}")
            self.stats["errors"] += 1
            return False
        except Exception as e:
            print(f"✗ Error indexing {file_path.name}: {str(e)}")
            self.stats["errors"] += 1
            return False

    def file_needs_indexing(self, file_path: Path) -> bool:
        """Check if file needs to be (re)indexed."""
        path_str = str(file_path)
        try:
            current_hash = self.calculate_file_hash(path_str)
        except (IOError, OSError):
            return False

        cached_hash = self.hash_cache.get(path_str)

        if cached_hash == current_hash:
            return False  # File unchanged

        # Update cache
        self.hash_cache[path_str] = current_hash
        return True

    def index_all(self):
        """Index all eligible DataRoom files."""
        print(f"\n{'='*60}")
        print(f"DataRoom RAG Indexing")
        print(f"Source: {CONFIG['dataroom_path']}")
        print(f"RAG API: {CONFIG['rag_api_url']}")
        print(f"{'='*60}\n")

        # Get all files
        dataroom_path = Path(CONFIG["dataroom_path"])
        if not dataroom_path.exists():
            print(f"✗ DataRoom not found at {CONFIG['dataroom_path']}")
            return False

        all_files = []

        for file_path in dataroom_path.rglob("*"):
            if file_path.is_file() and self.should_include(file_path):
                all_files.append(file_path)

        print(f"Found {len(all_files)} files to potentially index\n")

        # Index each file
        for file_path in all_files:
            # Check if needs indexing
            if not self.file_needs_indexing(file_path):
                self.stats["skipped"] += 1
                continue

            # Index
            self.index_file(file_path)

        # Save hash cache
        self.save_hash_cache()

        # Report
        print(f"\n{'='*60}")
        print(f"Indexing Complete")
        print(f"  Indexed: {self.stats['indexed']}")
        print(f"  Skipped (unchanged): {self.stats['skipped']}")
        print(f"  Errors: {self.stats['errors']}")
        print(f"{'='*60}\n")

        return self.stats["errors"] == 0


def main():
    indexer = DataRoomIndexer()
    success = indexer.index_all()
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
