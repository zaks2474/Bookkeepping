#!/usr/bin/env python3
"""
Case File Rebuilder

Rebuilds deal case files from event history and registry data.
Case files are projections - they must be safely rebuildable from events.

Deliverables (per plan section 3.1):
- rebuild_case_file(deal_id) - single deal rebuild
- rebuild_all_case_files() - batch rebuild
- reapply_stage_policy(deal_id) - regenerate deferred actions from policy
- rebuild_from_events --since <timestamp> - incremental rebuild

Usage:
    python3 case_file_rebuilder.py rebuild DEAL-2025-001
    python3 case_file_rebuilder.py rebuild-all
    python3 case_file_rebuilder.py reapply-policy DEAL-2025-001
    python3 case_file_rebuilder.py rebuild-since 2025-01-01
    python3 case_file_rebuilder.py verify DEAL-2025-001
    python3 case_file_rebuilder.py backfill
"""

from __future__ import annotations

import argparse
import json
import sys
import hashlib
from collections import defaultdict
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional, Set
import yaml

# Add paths
sys.path.insert(0, str(Path(__file__).parent))

# Configuration
REGISTRY_PATH = Path("/home/zaks/DataRoom/.deal-registry/deal_registry.json")
EVENTS_DIR = Path("/home/zaks/DataRoom/.deal-registry/events")
CASE_FILES_DIR = Path("/home/zaks/DataRoom/.deal-registry/case_files")
POLICY_PATH = Path("/home/zaks/DataRoom/.deal-registry/policy/stage_policies.yaml")
DEFERRED_ACTIONS_PATH = Path("/home/zaks/DataRoom/.deal-registry/deferred_actions.json")
RUN_LEDGER_PATH = Path("/home/zaks/logs/run-ledger.jsonl")

# Ensure directories exist
CASE_FILES_DIR.mkdir(parents=True, exist_ok=True)


@dataclass
class CaseFile:
    """Deal case file projection"""
    deal_id: str
    summary: str = ""
    key_facts: Dict[str, Any] = field(default_factory=dict)
    buy_box_fit: Optional[Dict[str, Any]] = None
    open_questions: List[str] = field(default_factory=list)
    next_actions: List[Dict[str, Any]] = field(default_factory=list)
    risk_flags: List[str] = field(default_factory=list)
    timeline: List[Dict[str, Any]] = field(default_factory=list)
    contacts: List[Dict[str, Any]] = field(default_factory=list)
    documents: List[Dict[str, Any]] = field(default_factory=list)
    notes: List[Dict[str, Any]] = field(default_factory=list)
    last_updated: str = ""
    updated_by: str = "system"
    rebuild_hash: str = ""  # Hash for idempotency checks


@dataclass
class RebuildResult:
    """Result of a rebuild operation"""
    success: bool
    deal_id: str
    message: str
    events_processed: int = 0
    fields_updated: List[str] = field(default_factory=list)
    actions_scheduled: int = 0
    warnings: List[str] = field(default_factory=list)


class CaseFileRebuilder:
    """
    Rebuilds case files from event history.

    Case files are projections that aggregate:
    - Registry data (canonical name, broker, stage)
    - Event history (emails, documents, stage changes)
    - Agent recommendations
    - Manual notes
    """

    def __init__(self):
        self.registry = self._load_registry()
        self.policy = self._load_policy()
        self.deferred_actions = self._load_deferred_actions()

    def _load_registry(self) -> Dict[str, Any]:
        """Load deal registry"""
        if REGISTRY_PATH.exists():
            with open(REGISTRY_PATH) as f:
                return json.load(f)
        return {"deals": {}}

    def _load_policy(self) -> Dict[str, Any]:
        """Load stage policies"""
        if POLICY_PATH.exists():
            with open(POLICY_PATH) as f:
                return yaml.safe_load(f) or {}
        return {}

    def _load_deferred_actions(self) -> Dict[str, Any]:
        """Load deferred actions"""
        if DEFERRED_ACTIONS_PATH.exists():
            with open(DEFERRED_ACTIONS_PATH) as f:
                return json.load(f)
        return {"actions": {}}

    def _save_deferred_actions(self):
        """Save deferred actions"""
        self.deferred_actions["updated_at"] = datetime.now(timezone.utc).isoformat()
        with open(DEFERRED_ACTIONS_PATH, "w") as f:
            json.dump(self.deferred_actions, f, indent=2)

    def _load_events(self, deal_id: str, since: Optional[datetime] = None) -> List[Dict[str, Any]]:
        """Load events for a specific deal"""
        events = []
        safe_id = deal_id.replace("/", "_").replace("\\", "_")
        event_file = EVENTS_DIR / f"{safe_id}.jsonl"

        if event_file.exists():
            with open(event_file) as f:
                for line in f:
                    line = line.strip()
                    if line:
                        try:
                            event = json.loads(line)
                            if since:
                                ts_str = event.get("timestamp", "")
                                if ts_str:
                                    ts = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
                                    if ts < since:
                                        continue
                            events.append(event)
                        except (json.JSONDecodeError, ValueError):
                            continue

        return sorted(events, key=lambda e: e.get("timestamp", ""))

    def _load_case_file(self, deal_id: str) -> Optional[CaseFile]:
        """Load existing case file"""
        case_path = CASE_FILES_DIR / f"{deal_id}.json"
        if case_path.exists():
            with open(case_path) as f:
                data = json.load(f)
                return CaseFile(
                    deal_id=data.get("deal_id", deal_id),
                    summary=data.get("summary", ""),
                    key_facts=data.get("key_facts", {}),
                    buy_box_fit=data.get("buy_box_fit"),
                    open_questions=data.get("open_questions", []),
                    next_actions=data.get("next_actions", []),
                    risk_flags=data.get("risk_flags", []),
                    timeline=data.get("timeline", []),
                    contacts=data.get("contacts", []),
                    documents=data.get("documents", []),
                    notes=data.get("notes", []),
                    last_updated=data.get("last_updated", ""),
                    updated_by=data.get("updated_by", "system"),
                    rebuild_hash=data.get("rebuild_hash", "")
                )
        return None

    def _save_case_file(self, case: CaseFile):
        """Save case file"""
        case_path = CASE_FILES_DIR / f"{case.deal_id}.json"
        with open(case_path, "w") as f:
            json.dump(asdict(case), f, indent=2)

    def _compute_hash(self, events: List[Dict[str, Any]], deal: Dict[str, Any]) -> str:
        """Compute hash for idempotency checking"""
        content = json.dumps({
            "events": [e.get("event_id") for e in events],
            "deal_updated": deal.get("updated_at"),
            "deal_stage": deal.get("stage")
        }, sort_keys=True)
        return hashlib.md5(content.encode()).hexdigest()[:16]

    def _log_run(self, operation: str, deal_id: str, result: Dict[str, Any]):
        """Log to run ledger"""
        entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "agent": "case_file_rebuilder",
            "operation": operation,
            "deal_id": deal_id,
            "result": result
        }
        with open(RUN_LEDGER_PATH, "a") as f:
            f.write(json.dumps(entry) + "\n")

    def rebuild_case_file(self, deal_id: str, force: bool = False) -> RebuildResult:
        """
        Rebuild a single deal's case file from event history.

        Args:
            deal_id: Deal identifier
            force: If True, rebuild even if hash unchanged

        Returns:
            RebuildResult with operation details
        """
        deal = self.registry.get("deals", {}).get(deal_id)
        if not deal:
            return RebuildResult(
                success=False,
                deal_id=deal_id,
                message=f"Deal {deal_id} not found in registry"
            )

        events = self._load_events(deal_id)
        current_hash = self._compute_hash(events, deal)

        # Check if rebuild needed
        existing = self._load_case_file(deal_id)
        if existing and existing.rebuild_hash == current_hash and not force:
            return RebuildResult(
                success=True,
                deal_id=deal_id,
                message="Case file is current (hash unchanged)",
                events_processed=len(events)
            )

        # Build new case file
        case = CaseFile(deal_id=deal_id)
        fields_updated = []
        warnings = []

        # Extract from registry
        case.key_facts["company_name"] = deal.get("canonical_name", "")
        case.key_facts["stage"] = deal.get("stage", "inbound")
        case.key_facts["status"] = deal.get("status", "active")
        fields_updated.append("key_facts.company_name")
        fields_updated.append("key_facts.stage")

        # Broker info
        broker = deal.get("broker")
        if broker:
            if isinstance(broker, dict):
                case.key_facts["broker"] = broker.get("name", "")
                case.key_facts["broker_contact"] = broker.get("email", "")
                case.contacts.append({
                    "type": "broker",
                    "name": broker.get("name"),
                    "email": broker.get("email"),
                    "phone": broker.get("phone")
                })
                fields_updated.append("contacts")

        # Company info
        company_info = deal.get("company_info", {})
        if isinstance(company_info, dict):
            for key in ["industry", "location", "employees"]:
                if company_info.get(key):
                    case.key_facts[key] = company_info[key]

        # Metadata
        metadata = deal.get("metadata", {})
        if isinstance(metadata, dict):
            for key in ["asking_price", "revenue", "ebitda"]:
                if metadata.get(key):
                    case.key_facts[key] = metadata[key]

        # Process events chronologically
        for event in events:
            event_type = event.get("event_type", "")
            data = event.get("data", {})
            timestamp = event.get("timestamp", "")

            # Build timeline
            case.timeline.append({
                "timestamp": timestamp,
                "event": event_type,
                "summary": data.get("summary") or event_type.replace("_", " ").title()
            })

            # Handle specific event types
            if event_type == "email_received":
                # Track email activity
                pass

            elif event_type == "document_classified":
                doc_type = data.get("document_type", "unknown")
                case.documents.append({
                    "type": doc_type,
                    "classified_at": timestamp,
                    "path": data.get("file_path"),
                    "confidence": data.get("confidence")
                })
                fields_updated.append("documents")

            elif event_type == "ai_recommendation":
                rec_type = data.get("recommendation_type", "general")
                if rec_type == "buy_box_score":
                    case.buy_box_fit = data.get("score_data")
                    fields_updated.append("buy_box_fit")
                elif rec_type == "risk_flag":
                    risk = data.get("risk")
                    if risk and risk not in case.risk_flags:
                        case.risk_flags.append(risk)
                        fields_updated.append("risk_flags")
                elif rec_type == "open_question":
                    question = data.get("question")
                    if question and question not in case.open_questions:
                        case.open_questions.append(question)
                        fields_updated.append("open_questions")

            elif event_type == "note_added":
                case.notes.append({
                    "timestamp": timestamp,
                    "author": event.get("actor", "operator"),
                    "content": data.get("content", "")
                })
                fields_updated.append("notes")

            elif event_type == "stage_changed":
                # Update key facts stage
                case.key_facts["stage"] = data.get("to_stage", case.key_facts.get("stage"))

            elif event_type in ["underwriting_complete", "analysis_complete"]:
                # Merge analysis data
                if data.get("key_facts"):
                    case.key_facts.update(data["key_facts"])
                    fields_updated.append("key_facts")
                if data.get("risks"):
                    for risk in data["risks"]:
                        if risk not in case.risk_flags:
                            case.risk_flags.append(risk)
                if data.get("questions"):
                    for q in data["questions"]:
                        if q not in case.open_questions:
                            case.open_questions.append(q)

        # Generate summary
        parts = []
        if case.key_facts.get("company_name"):
            parts.append(case.key_facts["company_name"])
        if case.key_facts.get("industry"):
            parts.append(case.key_facts["industry"])
        if case.key_facts.get("revenue"):
            parts.append(f"Revenue: {case.key_facts['revenue']}")
        if case.key_facts.get("stage"):
            parts.append(f"Stage: {case.key_facts['stage'].upper()}")
        case.summary = " | ".join(parts) if parts else f"Deal {deal_id}"
        fields_updated.append("summary")

        # Preserve manual notes from existing case file
        if existing and existing.notes:
            # Keep notes that aren't from events
            for note in existing.notes:
                if note not in case.notes:
                    case.notes.append(note)

        # Set metadata
        case.last_updated = datetime.now(timezone.utc).isoformat()
        case.updated_by = "case_file_rebuilder"
        case.rebuild_hash = current_hash

        # Save
        self._save_case_file(case)

        # Log
        self._log_run("rebuild_case_file", deal_id, {
            "events_processed": len(events),
            "fields_updated": len(set(fields_updated)),
            "hash": current_hash
        })

        return RebuildResult(
            success=True,
            deal_id=deal_id,
            message=f"Case file rebuilt from {len(events)} events",
            events_processed=len(events),
            fields_updated=list(set(fields_updated)),
            warnings=warnings
        )

    def rebuild_all_case_files(self, force: bool = False) -> Dict[str, Any]:
        """
        Rebuild all case files in the registry.

        Args:
            force: If True, rebuild even if hash unchanged

        Returns:
            Summary of rebuild operations
        """
        deals = self.registry.get("deals", {})
        results = {
            "total": len(deals),
            "rebuilt": 0,
            "skipped": 0,
            "failed": 0,
            "errors": []
        }

        for deal_id in deals:
            try:
                result = self.rebuild_case_file(deal_id, force=force)
                if result.success:
                    if "current" in result.message.lower():
                        results["skipped"] += 1
                    else:
                        results["rebuilt"] += 1
                else:
                    results["failed"] += 1
                    results["errors"].append({
                        "deal_id": deal_id,
                        "message": result.message
                    })
            except Exception as e:
                results["failed"] += 1
                results["errors"].append({
                    "deal_id": deal_id,
                    "message": str(e)
                })

        # Log summary
        self._log_run("rebuild_all_case_files", "batch", results)

        return results

    def reapply_stage_policy(self, deal_id: str) -> RebuildResult:
        """
        Reapply stage policy to regenerate eligible deferred actions.
        Does not duplicate existing scheduled actions.

        Args:
            deal_id: Deal identifier

        Returns:
            RebuildResult with actions scheduled
        """
        deal = self.registry.get("deals", {}).get(deal_id)
        if not deal:
            return RebuildResult(
                success=False,
                deal_id=deal_id,
                message=f"Deal {deal_id} not found"
            )

        stage = deal.get("stage", "inbound").lower()
        stage_policy = self.policy.get("stages", {}).get(stage, {})

        if not stage_policy:
            return RebuildResult(
                success=True,
                deal_id=deal_id,
                message=f"No policy defined for stage '{stage}'"
            )

        # Get existing pending actions for this deal
        existing_actions = set()
        actions_dict = self.deferred_actions.get("actions", {})
        for action_id, action in actions_dict.items():
            if action.get("deal_id") == deal_id and action.get("status") == "pending":
                existing_actions.add(action.get("action_type"))

        # Apply policy actions
        actions_scheduled = 0
        warnings = []

        auto_actions = stage_policy.get("auto_actions", [])
        for action_config in auto_actions:
            action_type = action_config.get("type")
            if not action_type:
                continue

            # Skip if already scheduled
            if action_type in existing_actions:
                warnings.append(f"Action '{action_type}' already scheduled, skipping")
                continue

            # Calculate schedule time
            delay_days = action_config.get("delay_days", 0)
            scheduled_for = datetime.now(timezone.utc) + timedelta(days=delay_days)

            # Create action
            action_id = f"ACT-{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S')}-{deal_id[-8:]}"

            if "actions" not in self.deferred_actions:
                self.deferred_actions["actions"] = {}

            self.deferred_actions["actions"][action_id] = {
                "action_id": action_id,
                "deal_id": deal_id,
                "action_type": action_type,
                "scheduled_for": scheduled_for.isoformat(),
                "created_at": datetime.now(timezone.utc).isoformat(),
                "priority": action_config.get("priority", "normal"),
                "data": action_config.get("data", {}),
                "metadata": {
                    "scheduled_by": "policy_reapply",
                    "stage": stage
                },
                "status": "pending",
                "executed_at": None,
                "result": None,
                "recurrence": action_config.get("recurrence")
            }
            actions_scheduled += 1

        # Save if any actions added
        if actions_scheduled > 0:
            self._save_deferred_actions()

        # Log
        self._log_run("reapply_stage_policy", deal_id, {
            "stage": stage,
            "actions_scheduled": actions_scheduled,
            "skipped": len(warnings)
        })

        return RebuildResult(
            success=True,
            deal_id=deal_id,
            message=f"Policy reapplied for stage '{stage}'",
            actions_scheduled=actions_scheduled,
            warnings=warnings
        )

    def rebuild_from_events_since(self, since: datetime) -> Dict[str, Any]:
        """
        Incrementally rebuild case files from events since a timestamp.
        Useful after schema/policy upgrades.

        Args:
            since: Only process events after this datetime

        Returns:
            Summary of rebuild operations
        """
        # Find deals with events since timestamp
        deals_to_rebuild = set()

        if EVENTS_DIR.exists():
            for event_file in EVENTS_DIR.glob("*.jsonl"):
                deal_id = event_file.stem
                events = self._load_events(deal_id, since=since)
                if events:
                    deals_to_rebuild.add(deal_id)

        results = {
            "since": since.isoformat(),
            "deals_checked": len(self.registry.get("deals", {})),
            "deals_with_new_events": len(deals_to_rebuild),
            "rebuilt": 0,
            "failed": 0,
            "errors": []
        }

        for deal_id in deals_to_rebuild:
            try:
                result = self.rebuild_case_file(deal_id, force=True)
                if result.success:
                    results["rebuilt"] += 1
                else:
                    results["failed"] += 1
                    results["errors"].append({
                        "deal_id": deal_id,
                        "message": result.message
                    })
            except Exception as e:
                results["failed"] += 1
                results["errors"].append({
                    "deal_id": deal_id,
                    "message": str(e)
                })

        # Log
        self._log_run("rebuild_from_events_since", "batch", results)

        return results

    def verify_case_file(self, deal_id: str) -> Dict[str, Any]:
        """
        Verify case file integrity and freshness.

        Args:
            deal_id: Deal identifier

        Returns:
            Verification report
        """
        deal = self.registry.get("deals", {}).get(deal_id)
        if not deal:
            return {"valid": False, "error": "Deal not found"}

        case = self._load_case_file(deal_id)
        if not case:
            return {
                "valid": False,
                "error": "Case file not found",
                "suggestion": "Run: python3 case_file_rebuilder.py rebuild " + deal_id
            }

        events = self._load_events(deal_id)
        current_hash = self._compute_hash(events, deal)

        issues = []

        # Check hash
        if case.rebuild_hash != current_hash:
            issues.append("Case file is stale (hash mismatch)")

        # Check required fields
        if not case.summary:
            issues.append("Missing summary")
        if not case.key_facts:
            issues.append("Missing key facts")

        # Check stage consistency
        if case.key_facts.get("stage") != deal.get("stage"):
            issues.append(f"Stage mismatch: case={case.key_facts.get('stage')}, registry={deal.get('stage')}")

        # Check last update age
        if case.last_updated:
            try:
                last = datetime.fromisoformat(case.last_updated.replace("Z", "+00:00"))
                age_days = (datetime.now(timezone.utc) - last).days
                if age_days > 30:
                    issues.append(f"Case file last updated {age_days} days ago")
            except (ValueError, TypeError):
                issues.append("Invalid last_updated timestamp")

        return {
            "valid": len(issues) == 0,
            "deal_id": deal_id,
            "events_count": len(events),
            "current_hash": current_hash,
            "stored_hash": case.rebuild_hash,
            "hash_match": case.rebuild_hash == current_hash,
            "last_updated": case.last_updated,
            "issues": issues,
            "suggestion": "Run: python3 case_file_rebuilder.py rebuild " + deal_id if issues else None
        }

    def backfill_all(self) -> Dict[str, Any]:
        """
        Backfill case files for all deals that don't have one.

        Returns:
            Summary of backfill operations
        """
        deals = self.registry.get("deals", {})
        results = {
            "total_deals": len(deals),
            "already_have_case_file": 0,
            "backfilled": 0,
            "failed": 0,
            "errors": []
        }

        for deal_id in deals:
            case_path = CASE_FILES_DIR / f"{deal_id}.json"
            if case_path.exists():
                results["already_have_case_file"] += 1
                continue

            try:
                result = self.rebuild_case_file(deal_id)
                if result.success:
                    results["backfilled"] += 1
                else:
                    results["failed"] += 1
                    results["errors"].append({
                        "deal_id": deal_id,
                        "message": result.message
                    })
            except Exception as e:
                results["failed"] += 1
                results["errors"].append({
                    "deal_id": deal_id,
                    "message": str(e)
                })

        # Log
        self._log_run("backfill_all", "batch", results)

        return results


def main():
    parser = argparse.ArgumentParser(description="Case File Rebuilder")
    subparsers = parser.add_subparsers(dest="command", help="Commands")

    # rebuild
    rebuild_parser = subparsers.add_parser("rebuild", help="Rebuild single case file")
    rebuild_parser.add_argument("deal_id", help="Deal ID to rebuild")
    rebuild_parser.add_argument("--force", action="store_true", help="Force rebuild even if current")

    # rebuild-all
    rebuild_all_parser = subparsers.add_parser("rebuild-all", help="Rebuild all case files")
    rebuild_all_parser.add_argument("--force", action="store_true", help="Force rebuild all")

    # reapply-policy
    policy_parser = subparsers.add_parser("reapply-policy", help="Reapply stage policy")
    policy_parser.add_argument("deal_id", help="Deal ID")

    # rebuild-since
    since_parser = subparsers.add_parser("rebuild-since", help="Rebuild from events since date")
    since_parser.add_argument("date", help="ISO date (YYYY-MM-DD)")

    # verify
    verify_parser = subparsers.add_parser("verify", help="Verify case file integrity")
    verify_parser.add_argument("deal_id", help="Deal ID to verify")

    # backfill
    backfill_parser = subparsers.add_parser("backfill", help="Backfill missing case files")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return

    rebuilder = CaseFileRebuilder()

    if args.command == "rebuild":
        result = rebuilder.rebuild_case_file(args.deal_id, force=args.force)
        print(f"\n{'='*60}")
        print(f"REBUILD: {result.deal_id}")
        print(f"{'='*60}")
        print(f"Status: {'SUCCESS' if result.success else 'FAILED'}")
        print(f"Message: {result.message}")
        if result.events_processed:
            print(f"Events Processed: {result.events_processed}")
        if result.fields_updated:
            print(f"Fields Updated: {', '.join(result.fields_updated[:10])}")
        if result.warnings:
            print(f"Warnings: {result.warnings}")

    elif args.command == "rebuild-all":
        results = rebuilder.rebuild_all_case_files(force=args.force)
        print(f"\n{'='*60}")
        print("REBUILD ALL CASE FILES")
        print(f"{'='*60}")
        print(f"Total Deals: {results['total']}")
        print(f"Rebuilt: {results['rebuilt']}")
        print(f"Skipped (current): {results['skipped']}")
        print(f"Failed: {results['failed']}")
        if results["errors"]:
            print(f"\nErrors:")
            for err in results["errors"][:5]:
                print(f"  - {err['deal_id']}: {err['message']}")

    elif args.command == "reapply-policy":
        result = rebuilder.reapply_stage_policy(args.deal_id)
        print(f"\n{'='*60}")
        print(f"REAPPLY POLICY: {result.deal_id}")
        print(f"{'='*60}")
        print(f"Status: {'SUCCESS' if result.success else 'FAILED'}")
        print(f"Message: {result.message}")
        print(f"Actions Scheduled: {result.actions_scheduled}")
        if result.warnings:
            print(f"Warnings:")
            for w in result.warnings:
                print(f"  - {w}")

    elif args.command == "rebuild-since":
        since = datetime.fromisoformat(args.date).replace(tzinfo=timezone.utc)
        results = rebuilder.rebuild_from_events_since(since)
        print(f"\n{'='*60}")
        print(f"REBUILD SINCE: {args.date}")
        print(f"{'='*60}")
        print(f"Deals Checked: {results['deals_checked']}")
        print(f"Deals with New Events: {results['deals_with_new_events']}")
        print(f"Rebuilt: {results['rebuilt']}")
        print(f"Failed: {results['failed']}")

    elif args.command == "verify":
        result = rebuilder.verify_case_file(args.deal_id)
        print(f"\n{'='*60}")
        print(f"VERIFY: {args.deal_id}")
        print(f"{'='*60}")
        print(f"Valid: {result['valid']}")
        if result.get("error"):
            print(f"Error: {result['error']}")
        else:
            print(f"Events Count: {result.get('events_count')}")
            print(f"Hash Match: {result.get('hash_match')}")
            print(f"Last Updated: {result.get('last_updated')}")
            if result.get("issues"):
                print(f"Issues:")
                for issue in result["issues"]:
                    print(f"  - {issue}")
        if result.get("suggestion"):
            print(f"\nSuggestion: {result['suggestion']}")

    elif args.command == "backfill":
        results = rebuilder.backfill_all()
        print(f"\n{'='*60}")
        print("BACKFILL CASE FILES")
        print(f"{'='*60}")
        print(f"Total Deals: {results['total_deals']}")
        print(f"Already Have Case File: {results['already_have_case_file']}")
        print(f"Backfilled: {results['backfilled']}")
        print(f"Failed: {results['failed']}")


if __name__ == "__main__":
    main()
