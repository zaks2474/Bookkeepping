#!/usr/bin/env python3
"""
Deal AI Advisory Layer

Provides stage-appropriate AI assistance throughout the deal lifecycle.
AI advises, humans decide - especially for critical stages (LOI, closing, exit).

Features:
- Stage-specific prompts and analysis
- Risk identification
- Document gap detection
- Valuation sanity checks
- Integration with local vLLM (default) or cloud (opt-in)

Safety:
- Never auto-executes actions
- Returns recommendations only
- No raw content logging (hashes + metadata only)
"""

from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

try:
    import requests
except ImportError:
    requests = None

# Add scripts to path for imports
sys.path.insert(0, str(Path(__file__).resolve().parent))

try:
    from deal_state_machine import DealStage, AI_ADVISORY_STAGES
except ImportError:
    DealStage = None
    AI_ADVISORY_STAGES = {}

try:
    from deal_events import DealEventStore, emit_ai_recommendation
except ImportError:
    DealEventStore = None
    emit_ai_recommendation = None


# Configuration
RUN_LEDGER_WRITER = "/home/zaks/bookkeeping/scripts/run_ledger.py"
RUN_LEDGER_PATH = os.getenv("ZAKOPS_RUN_LEDGER_PATH", "/home/zaks/logs/run-ledger.jsonl")

DEFAULT_LOCAL_API = os.getenv("ZAKOPS_API_URL", "http://localhost:8000/v1")
DEFAULT_MODEL = os.getenv("AI_ADVISORY_MODEL", "Qwen/Qwen2.5-32B-Instruct-AWQ")


def _sha256(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8", errors="ignore")).hexdigest()[:16]


def _now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _emit_run_ledger(
    *,
    run_id: str,
    status: str,
    started_at: str,
    ended_at: str,
    metrics: Optional[Dict[str, Any]] = None,
    correlation: Optional[Dict[str, str]] = None,
) -> None:
    if not os.path.exists(RUN_LEDGER_WRITER):
        return

    args = [
        "python3", RUN_LEDGER_WRITER,
        "--ledger-path", RUN_LEDGER_PATH,
        "--component", "ai_advisory",
        "--run-id", run_id,
        "--status", status,
        "--started-at", started_at,
        "--ended-at", ended_at,
    ]
    for k, v in (metrics or {}).items():
        args.extend(["--metric", f"{k}={v}"])
    for k, v in (correlation or {}).items():
        args.extend(["--correlation", f"{k}={v}"])

    subprocess.run(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)


# Stage-specific prompt templates
STAGE_PROMPTS = {
    "inbound": """You are analyzing a new inbound deal opportunity.

Deal Context:
{context}

Provide a brief assessment covering:
1. Initial fit score (1-10) based on available information
2. Key strengths (2-3 bullet points)
3. Potential concerns or red flags (2-3 bullet points)
4. Recommended next steps (2-3 actions)
5. Information gaps that should be filled

Keep response concise and actionable. Format as structured sections.""",

    "screening": """You are conducting initial screening on a deal.

Deal Context:
{context}

Analyze and provide:
1. Financial quick-look assessment
2. Industry/sector fit analysis
3. Key risk factors identified
4. Comparable deals or companies (if context allows)
5. Go/No-Go recommendation with confidence level

Be specific about what additional information would improve the assessment.""",

    "qualified": """You are evaluating a qualified deal for potential LOI.

Deal Context:
{context}

Provide strategic analysis:
1. Valuation range estimate (with methodology notes)
2. Deal structure suggestions
3. Key negotiation points to consider
4. Synergy potential assessment
5. Critical due diligence items to prioritize

Focus on actionable insights for deal structuring.""",

    "loi": """You are reviewing LOI terms for a deal.

Deal Context:
{context}

Analyze the LOI terms and provide:
1. Terms assessment (favorable/neutral/unfavorable for each key term)
2. Suggested modifications or counter-points
3. Risk allocation analysis
4. Recommended protective provisions
5. Timeline feasibility assessment

Highlight any unusual or concerning provisions.""",

    "diligence": """You are supporting due diligence on a deal.

Deal Context:
{context}

Provide due diligence guidance:
1. Risk areas requiring deep investigation
2. Document gaps or missing information
3. Expert consultations recommended (legal, accounting, industry)
4. Integration complexity assessment
5. Deal-breaker scenarios to monitor

Prioritize findings by impact and likelihood.""",

    "closing": """You are supporting deal closing activities.

Deal Context:
{context}

Provide closing checklist review:
1. Outstanding items requiring resolution
2. Risk mitigation confirmations needed
3. Day-1 readiness assessment
4. Post-close priority actions
5. Integration team handoff items

Focus on ensuring nothing falls through the cracks.""",

    "integration": """You are supporting post-acquisition integration.

Deal Context:
{context}

Provide integration guidance:
1. 30-60-90 day priority actions
2. Quick wins to capture
3. Potential integration challenges
4. Key personnel retention priorities
5. Customer/vendor communication recommendations

Balance speed with stability.""",

    "operations": """You are monitoring ongoing operations for a portfolio company.

Deal Context:
{context}

Provide operational insights:
1. Performance vs. expectations assessment
2. Anomalies or trends requiring attention
3. Improvement opportunities identified
4. Resource allocation recommendations
5. Risk factors to monitor

Focus on actionable operational improvements.""",

    "growth": """You are analyzing growth opportunities for a portfolio company.

Deal Context:
{context}

Provide growth analysis:
1. Organic growth opportunities
2. Potential add-on acquisition targets
3. Market expansion possibilities
4. Product/service line extensions
5. Strategic partnership opportunities

Prioritize by ROI potential and execution feasibility.""",

    "exit_planning": """You are supporting exit planning for a portfolio company.

Deal Context:
{context}

Provide exit planning analysis:
1. Optimal exit timing considerations
2. Valuation optimization opportunities
3. Potential buyer universe
4. Deal structure preferences (strategic vs. financial)
5. Pre-exit value enhancement actions

Focus on maximizing exit value and certainty.""",
}


@dataclass
class AdvisoryResult:
    """Result of an AI advisory request"""
    deal_id: str
    stage: str
    recommendation: str
    confidence: float
    model: str
    context_hash: str
    timestamp: str
    tokens_used: int = 0
    latency_ms: int = 0
    error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class DealAIAdvisor:
    """
    AI advisory layer for deal lifecycle management.

    Usage:
        advisor = DealAIAdvisor()
        result = advisor.get_advice(
            deal_id="DEAL-2025-001",
            stage="screening",
            context={"company": "Acme Corp", "revenue": "$5M", ...}
        )
    """

    def __init__(
        self,
        api_base: Optional[str] = None,
        model: Optional[str] = None,
        event_store: Optional["DealEventStore"] = None,
    ):
        self.api_base = (api_base or DEFAULT_LOCAL_API).rstrip("/")
        self.model = model or DEFAULT_MODEL
        self.event_store = event_store
        self.enabled = os.getenv("AI_ADVISORY_ENABLED", "true").lower() in {"true", "1", "yes"}

    def get_advice(
        self,
        deal_id: str,
        stage: str,
        context: Dict[str, Any],
        emit_event: bool = True,
        emit_ledger: bool = True,
    ) -> AdvisoryResult:
        """
        Get AI advice for a deal at a specific stage.

        Args:
            deal_id: Deal identifier
            stage: Current deal stage
            context: Deal context (company info, financials, documents, etc.)
            emit_event: Whether to emit a deal event
            emit_ledger: Whether to emit a run ledger record

        Returns:
            AdvisoryResult with recommendation
        """
        import time
        started = time.monotonic()
        started_at = _now_iso()
        run_id = f"{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}_ai_advisory_{os.getpid()}"

        context_str = self._format_context(context)
        context_hash = _sha256(context_str)

        if not self.enabled:
            return AdvisoryResult(
                deal_id=deal_id,
                stage=stage,
                recommendation="AI advisory is disabled. Set AI_ADVISORY_ENABLED=true to enable.",
                confidence=0.0,
                model="disabled",
                context_hash=context_hash,
                timestamp=started_at,
                error="disabled",
            )

        # Get stage-specific prompt
        prompt_template = STAGE_PROMPTS.get(stage.lower(), STAGE_PROMPTS.get("inbound"))
        prompt = prompt_template.format(context=context_str)

        try:
            response = self._call_llm(prompt)
            ended = time.monotonic()

            result = AdvisoryResult(
                deal_id=deal_id,
                stage=stage,
                recommendation=response.get("content", ""),
                confidence=0.85,  # Default confidence for successful calls
                model=self.model,
                context_hash=context_hash,
                timestamp=started_at,
                tokens_used=response.get("tokens", 0),
                latency_ms=int((ended - started) * 1000),
            )

            # Emit event if requested
            if emit_event and self.event_store and emit_ai_recommendation:
                emit_ai_recommendation(
                    self.event_store,
                    deal_id=deal_id,
                    recommendation=result.recommendation[:500],  # Truncate for event
                    confidence=result.confidence,
                    model=self.model,
                    context=f"stage={stage}",
                )

            # Emit ledger record if requested
            if emit_ledger:
                _emit_run_ledger(
                    run_id=run_id,
                    status="success",
                    started_at=started_at,
                    ended_at=_now_iso(),
                    metrics={
                        "tokens": result.tokens_used,
                        "latency_ms": result.latency_ms,
                    },
                    correlation={
                        "deal_id": deal_id,
                        "stage": stage,
                        "context_hash": context_hash,
                        "model": self.model,
                    },
                )

            return result

        except Exception as e:
            ended = time.monotonic()
            error_msg = f"{type(e).__name__}: {str(e)}"

            if emit_ledger:
                _emit_run_ledger(
                    run_id=run_id,
                    status="fail",
                    started_at=started_at,
                    ended_at=_now_iso(),
                    metrics={"latency_ms": int((ended - started) * 1000)},
                    correlation={
                        "deal_id": deal_id,
                        "stage": stage,
                        "error": error_msg[:100],
                    },
                )

            return AdvisoryResult(
                deal_id=deal_id,
                stage=stage,
                recommendation="",
                confidence=0.0,
                model=self.model,
                context_hash=context_hash,
                timestamp=started_at,
                latency_ms=int((ended - started) * 1000),
                error=error_msg,
            )

    def _format_context(self, context: Dict[str, Any]) -> str:
        """Format context dict into readable string"""
        lines = []
        for key, value in context.items():
            if isinstance(value, (dict, list)):
                value = json.dumps(value, indent=2, default=str)
            lines.append(f"- {key}: {value}")
        return "\n".join(lines) if lines else "No context provided."

    def _call_llm(self, prompt: str) -> Dict[str, Any]:
        """Call the LLM API"""
        if requests is None:
            raise RuntimeError("requests library not available")

        endpoint = f"{self.api_base}/chat/completions"

        payload = {
            "model": self.model,
            "messages": [
                {
                    "role": "system",
                    "content": "You are a seasoned M&A advisor providing strategic guidance. Be concise, specific, and actionable. Never recommend actions that would violate regulations or ethical standards.",
                },
                {"role": "user", "content": prompt},
            ],
            "temperature": 0.3,
            "max_tokens": 1500,
        }

        response = requests.post(endpoint, json=payload, timeout=60)
        response.raise_for_status()
        data = response.json()

        content = ""
        tokens = 0
        if "choices" in data and data["choices"]:
            content = data["choices"][0].get("message", {}).get("content", "")
        if "usage" in data:
            tokens = data["usage"].get("total_tokens", 0)

        return {"content": content, "tokens": tokens}

    def get_stage_context(self, stage: str) -> str:
        """Get advisory context description for a stage"""
        if DealStage:
            try:
                stage_enum = DealStage.from_str(stage)
                return AI_ADVISORY_STAGES.get(stage_enum, "General deal advisory")
            except Exception:
                pass
        return AI_ADVISORY_STAGES.get(stage, "General deal advisory")

    def get_checklist(self, stage: str) -> List[str]:
        """Get stage-specific checklist items"""
        checklists = {
            "inbound": [
                "Verify source/broker reputation",
                "Check sector fit against criteria",
                "Confirm basic financial metrics available",
                "Identify any immediate disqualifiers",
            ],
            "screening": [
                "Review 3-year financials (P&L, Balance Sheet)",
                "Assess customer concentration",
                "Check management team background",
                "Identify key risks and mitigants",
            ],
            "qualified": [
                "Complete preliminary valuation",
                "Draft term sheet structure",
                "Identify key negotiation points",
                "Plan due diligence scope",
            ],
            "loi": [
                "Review all LOI terms",
                "Confirm exclusivity period",
                "Verify purchase price and structure",
                "Check closing conditions",
            ],
            "diligence": [
                "Financial DD complete",
                "Legal DD complete",
                "Operational DD complete",
                "Tax DD complete",
                "Environmental DD (if applicable)",
            ],
            "closing": [
                "All conditions precedent satisfied",
                "Financing confirmed",
                "Required approvals obtained",
                "Closing documents ready",
            ],
            "integration": [
                "Day-1 checklist complete",
                "Key personnel retention confirmed",
                "Systems integration plan in place",
                "Communication plan executed",
            ],
            "operations": [
                "Monthly financial review",
                "KPI tracking active",
                "Board reporting current",
                "Annual budget on track",
            ],
            "growth": [
                "Growth initiatives identified",
                "Add-on pipeline active",
                "Expansion opportunities assessed",
                "Investment thesis on track",
            ],
            "exit_planning": [
                "Exit timing analysis complete",
                "Valuation optimization identified",
                "Buyer list prepared",
                "Exit readiness assessment done",
            ],
        }
        return checklists.get(stage.lower(), ["Review deal status", "Update stakeholders"])


def get_quick_advice(
    deal_id: str,
    stage: str,
    context: Dict[str, Any],
) -> AdvisoryResult:
    """Quick helper function to get AI advice"""
    advisor = DealAIAdvisor()
    return advisor.get_advice(deal_id, stage, context)


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Deal AI Advisor CLI")
    parser.add_argument("command", choices=["advice", "checklist", "stages"])
    parser.add_argument("--deal-id", default="CLI-TEST", help="Deal ID")
    parser.add_argument("--stage", default="inbound", help="Deal stage")
    parser.add_argument("--context", default="{}", help="JSON context")
    parser.add_argument("--no-event", action="store_true", help="Skip event emission")
    parser.add_argument("--no-ledger", action="store_true", help="Skip ledger emission")
    args = parser.parse_args()

    advisor = DealAIAdvisor()

    if args.command == "stages":
        print("Available stages and AI advisory focus:")
        for stage, focus in STAGE_PROMPTS.items():
            # Extract first line of prompt as summary
            summary = focus.split("\n")[0].replace("You are ", "").strip(".")
            print(f"  {stage}: {summary}")

    elif args.command == "checklist":
        checklist = advisor.get_checklist(args.stage)
        print(f"Checklist for {args.stage}:")
        for i, item in enumerate(checklist, 1):
            print(f"  {i}. {item}")

    elif args.command == "advice":
        try:
            context = json.loads(args.context)
        except json.JSONDecodeError:
            context = {"raw": args.context}

        print(f"Getting AI advice for {args.deal_id} at stage {args.stage}...")
        result = advisor.get_advice(
            deal_id=args.deal_id,
            stage=args.stage,
            context=context,
            emit_event=not args.no_event,
            emit_ledger=not args.no_ledger,
        )

        if result.error:
            print(f"\nError: {result.error}")
        else:
            print(f"\n{'='*60}")
            print(f"AI Advisory - {args.stage.upper()}")
            print(f"{'='*60}")
            print(result.recommendation)
            print(f"\n{'='*60}")
            print(f"Model: {result.model}")
            print(f"Confidence: {result.confidence:.0%}")
            print(f"Latency: {result.latency_ms}ms")
            print(f"Tokens: {result.tokens_used}")
