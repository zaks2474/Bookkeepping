#!/usr/bin/env python3
"""
Deal Case Manager Agent

Mission: "Keep deal moving."
- Convert events into next actions
- Update case file projections
- Suggest (not execute) stage transitions
- Schedule follow-ups based on policy

This agent is the primary lifecycle coordinator for deals.

Inputs:
- New emails, document arrivals
- Operator notes
- Due deferred actions
- Registry and event history

Outputs:
- Deal events
- Stage transition recommendations (not auto-executed for gated stages)
- Deferred actions (scheduled follow-ups)
- Case file updates

Hard Boundaries:
- No sending emails directly
- No destructive operations
- No auto-transitions for approval-gated stages

Usage:
    python3 deal_case_manager.py summarize DEAL-2025-001
    python3 deal_case_manager.py process-events DEAL-2025-001
    python3 deal_case_manager.py suggest-actions DEAL-2025-001
    python3 deal_case_manager.py update-case-file DEAL-2025-001
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

# Add paths
sys.path.insert(0, str(Path(__file__).parent))
sys.path.insert(0, str(Path("/home/zaks/Zaks-llm/src")))

from deal_registry import DealRegistry
from deal_events import DealEventStore, DealEvent
from deferred_actions import DeferredActionQueue
from deal_state_machine import DealStateMachine, DealStage
from schema_validators import PolicyLoader, validate_event

# Configuration
REGISTRY_PATH = "/home/zaks/DataRoom/.deal-registry/deal_registry.json"
CASE_FILES_DIR = Path("/home/zaks/DataRoom/.deal-registry/case_files")
RUN_LEDGER_PATH = Path("/home/zaks/logs/run-ledger.jsonl")


# Allowed actions that agents can request
ALLOWED_AGENT_ACTIONS: Set[str] = {
    "emit_event",              # Add event to deal's event log
    "update_case_file",        # Update case file projection
    "schedule_action",         # Queue a deferred action
    "recommend_stage_transition",  # Suggest (not execute) stage change
    "create_checkpoint",       # Save progress for long operations
    "create_draft",            # Comms agent only - create draft artifact
    "add_open_question",       # Add question to case file
    "add_risk_flag",           # Flag a risk in case file
    "request_additional_info", # Log info request (doesn't send)
}


@dataclass
class AgentAction:
    """A validated action produced by an agent"""
    action_type: str
    deal_id: str
    data: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def validate(self) -> bool:
        """Validate action is in allowed set"""
        return self.action_type in ALLOWED_AGENT_ACTIONS


@dataclass
class AgentResult:
    """Result of an agent invocation"""
    success: bool
    summary: str
    events: List[Dict[str, Any]] = field(default_factory=list)
    scheduled_actions: List[Dict[str, Any]] = field(default_factory=list)
    case_file_update: Optional[Dict[str, Any]] = None
    stage_recommendation: Optional[Dict[str, Any]] = None
    confidence: float = 0.0
    errors: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "success": self.success,
            "summary": self.summary,
            "events": self.events,
            "scheduled_actions": self.scheduled_actions,
            "case_file_update": self.case_file_update,
            "stage_recommendation": self.stage_recommendation,
            "confidence": self.confidence,
            "errors": self.errors,
        }


@dataclass
class DealContext:
    """Full context for a deal"""
    deal_id: str
    deal: Any  # Deal object from registry
    stage: str
    events: List[DealEvent]
    case_file: Optional[Dict[str, Any]]
    pending_actions: List[Any]
    policy: Dict[str, Any]

    def to_prompt_context(self) -> str:
        """Convert to prompt-friendly context string"""
        lines = [
            f"# Deal Context: {self.deal_id}",
            f"Canonical Name: {self.deal.canonical_name}",
            f"Stage: {self.stage}",
            f"Status: {self.deal.status}",
        ]

        if self.deal.broker:
            lines.append(f"Broker: {self.deal.broker.name} ({self.deal.broker.email})")

        if self.deal.metadata.asking_price:
            lines.append(f"Asking Price: {self.deal.metadata.asking_price}")
        if self.deal.metadata.ebitda:
            lines.append(f"EBITDA: {self.deal.metadata.ebitda}")

        lines.append(f"\n## Recent Events ({len(self.events)} total)")
        for event in self.events[-10:]:
            lines.append(f"- [{event.timestamp[:10]}] {event.event_type}: {event.actor}")

        if self.case_file:
            lines.append("\n## Case File Summary")
            if self.case_file.get("summary"):
                lines.append(f"Summary: {self.case_file['summary']}")
            if self.case_file.get("open_questions"):
                lines.append(f"Open Questions: {len(self.case_file['open_questions'])}")
            if self.case_file.get("risk_flags"):
                lines.append(f"Risk Flags: {', '.join(self.case_file['risk_flags'])}")

        lines.append(f"\n## Pending Actions ({len(self.pending_actions)})")
        for action in self.pending_actions[:5]:
            lines.append(f"- {action.action_type}: due {action.scheduled_for[:10]}")

        return "\n".join(lines)


class DealCaseManagerAgent:
    """
    Deal Case Manager Agent - keeps deals moving through the lifecycle.

    This agent:
    - Analyzes deal state and recent activity
    - Suggests next actions based on policy
    - Updates case file projections
    - Recommends stage transitions
    - Schedules follow-ups
    """

    def __init__(self, llm_router=None):
        self.registry = DealRegistry(REGISTRY_PATH)
        self.event_store = DealEventStore()
        self.action_queue = DeferredActionQueue()
        self.policy_loader = PolicyLoader()
        self.llm_router = llm_router
        self._ensure_dirs()

    def _ensure_dirs(self):
        """Ensure required directories exist"""
        CASE_FILES_DIR.mkdir(parents=True, exist_ok=True)
        RUN_LEDGER_PATH.parent.mkdir(parents=True, exist_ok=True)

    def _log_run(self, deal_id: str, task: str, result: AgentResult) -> None:
        """Log agent run to ledger"""
        entry = {
            "timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "agent": "case_manager",
            "deal_id": deal_id,
            "task": task,
            "success": result.success,
            "summary": result.summary[:200],
            "confidence": result.confidence,
            "events_emitted": len(result.events),
            "actions_scheduled": len(result.scheduled_actions),
        }
        with open(RUN_LEDGER_PATH, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry) + "\n")

    def load_context(self, deal_id: str) -> Optional[DealContext]:
        """Load full context for a deal"""
        deal = self.registry.get_deal(deal_id)
        if not deal:
            return None

        events = self.event_store.get_events(deal_id, limit=100)
        pending_actions = self.action_queue.get_actions_for_deal(deal_id, status="pending")
        case_file = self._load_case_file(deal_id)
        stage_policy = self.policy_loader.get_stage_policy(deal.stage) or {}

        return DealContext(
            deal_id=deal_id,
            deal=deal,
            stage=deal.stage,
            events=events,
            case_file=case_file,
            pending_actions=pending_actions,
            policy=stage_policy,
        )

    def _load_case_file(self, deal_id: str) -> Optional[Dict[str, Any]]:
        """Load case file if exists"""
        case_file_path = CASE_FILES_DIR / f"{deal_id}.json"
        if case_file_path.exists():
            try:
                with open(case_file_path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except (json.JSONDecodeError, IOError):
                pass
        return None

    def _save_case_file(self, deal_id: str, case_file: Dict[str, Any]) -> None:
        """Save case file"""
        case_file["last_updated"] = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        case_file["updated_by"] = "case_manager_agent"
        case_file_path = CASE_FILES_DIR / f"{deal_id}.json"
        with open(case_file_path, "w", encoding="utf-8") as f:
            json.dump(case_file, f, indent=2, ensure_ascii=False)

    def summarize(self, deal_id: str) -> AgentResult:
        """
        Generate or update deal summary.

        Uses LLM to create a concise summary of the deal state.
        """
        context = self.load_context(deal_id)
        if not context:
            return AgentResult(
                success=False,
                summary=f"Deal not found: {deal_id}",
                errors=[f"Deal {deal_id} not found in registry"],
            )

        # Build summary from available data
        deal = context.deal
        summary_parts = []

        # Basic info
        if deal.company_info.sector:
            summary_parts.append(f"{deal.company_info.sector}")

        if deal.metadata.asking_price:
            summary_parts.append(f"Asking: {deal.metadata.asking_price}")

        if deal.metadata.ebitda:
            summary_parts.append(f"EBITDA: {deal.metadata.ebitda}")

        if deal.broker:
            summary_parts.append(f"via {deal.broker.company or deal.broker.name}")

        summary = ", ".join(summary_parts) if summary_parts else f"Deal in {context.stage} stage"

        # Use LLM for enhanced summary if available
        if self.llm_router:
            try:
                prompt = f"""Based on this deal context, provide a concise 1-2 sentence summary:

{context.to_prompt_context()}

Provide a brief, factual summary focusing on: business type, key metrics, and current status."""

                response = self.llm_router.invoke_with_fallback(
                    "summarization",
                    prompt,
                    system_prompt="You are a deal analyst. Provide concise, factual summaries.",
                )
                if response.content:
                    summary = response.content.strip()[:500]
            except Exception as e:
                pass  # Fall back to basic summary

        # Update case file with summary
        case_file = context.case_file or {"deal_id": deal_id}
        case_file["summary"] = summary
        self._save_case_file(deal_id, case_file)

        result = AgentResult(
            success=True,
            summary=summary,
            case_file_update={"summary": summary},
            confidence=0.8,
        )
        self._log_run(deal_id, "summarize", result)
        return result

    def suggest_actions(self, deal_id: str) -> AgentResult:
        """
        Suggest next actions based on deal state and policy.

        Analyzes:
        - Current stage and policy
        - Recent activity (or lack thereof)
        - Missing documents
        - Open questions
        """
        context = self.load_context(deal_id)
        if not context:
            return AgentResult(
                success=False,
                summary=f"Deal not found: {deal_id}",
                errors=[f"Deal {deal_id} not found in registry"],
            )

        suggested_actions = []
        stage_policy = context.policy

        # Check for stall
        stall_days = stage_policy.get("stall_alert_days", 30)
        last_activity = None
        if context.events:
            last_activity = context.events[-1].timestamp

        if last_activity:
            days_since = self._days_since(last_activity)
            if days_since > stall_days:
                suggested_actions.append({
                    "type": "follow_up",
                    "reason": f"No activity for {days_since} days (stall threshold: {stall_days})",
                    "priority": "high",
                })

        # Check for missing documents based on stage
        stage = context.stage.upper()
        if stage == "INBOUND":
            if not context.deal.metadata.cim_received:
                suggested_actions.append({
                    "type": "request_materials",
                    "material_type": "CIM",
                    "reason": "CIM not yet received",
                    "priority": "normal",
                })
        elif stage == "SCREENING":
            if not context.deal.metadata.cim_received:
                suggested_actions.append({
                    "type": "request_materials",
                    "material_type": "CIM",
                    "reason": "Cannot complete screening without CIM",
                    "priority": "high",
                })

        # Check for stage advancement potential
        sm = DealStateMachine(context.stage, deal_id)
        if not sm.is_terminal():
            for next_stage in sm.get_allowed_transitions():
                if self._should_suggest_advance(context, next_stage):
                    needs_approval = sm.requires_approval(next_stage)
                    suggested_actions.append({
                        "type": "stage_transition",
                        "to_stage": next_stage.value,
                        "requires_approval": needs_approval,
                        "reason": self._get_advance_reason(context, next_stage),
                    })

        # Schedule follow-up if no pending actions
        if not context.pending_actions and not sm.is_terminal():
            suggested_actions.append({
                "type": "schedule_follow_up",
                "delay_days": 7,
                "reason": "No pending actions - schedule routine follow-up",
                "priority": "normal",
            })

        result = AgentResult(
            success=True,
            summary=f"Suggested {len(suggested_actions)} action(s) for {deal_id}",
            scheduled_actions=suggested_actions,
            confidence=0.75,
        )
        self._log_run(deal_id, "suggest_actions", result)
        return result

    def _days_since(self, iso_timestamp: str) -> int:
        """Calculate days since timestamp"""
        try:
            if iso_timestamp.endswith("Z"):
                iso_timestamp = iso_timestamp[:-1] + "+00:00"
            ts = datetime.fromisoformat(iso_timestamp)
            now = datetime.now(timezone.utc)
            return max(0, (now - ts).days)
        except (ValueError, TypeError):
            return 0

    def _should_suggest_advance(self, context: DealContext, next_stage: DealStage) -> bool:
        """Check if we should suggest advancing to next stage"""
        current = context.stage.upper()
        target = next_stage.value.upper()

        # INBOUND → SCREENING: Need CIM
        if current == "INBOUND" and target == "SCREENING":
            return context.deal.metadata.cim_received

        # SCREENING → QUALIFIED: Need analysis complete
        if current == "SCREENING" and target == "QUALIFIED":
            # Check if underwriter analysis exists
            analysis_events = [
                e for e in context.events
                if e.event_type == "ai_recommendation" and "underwriter" in e.actor
            ]
            return len(analysis_events) > 0

        return False

    def _get_advance_reason(self, context: DealContext, next_stage: DealStage) -> str:
        """Get reason for stage advancement suggestion"""
        current = context.stage.upper()
        target = next_stage.value.upper()

        if current == "INBOUND" and target == "SCREENING":
            return "CIM received - ready for initial analysis"
        if current == "SCREENING" and target == "QUALIFIED":
            return "Analysis complete - consider qualification"
        if target == "CLOSED_LOST":
            return "Consider closing if deal is not viable"

        return f"Review for potential advancement to {target}"

    def process_events(self, deal_id: str, since: Optional[str] = None) -> AgentResult:
        """
        Process recent events and update case file accordingly.

        This is the main "keep deal moving" function that:
        - Reads recent events
        - Updates case file with new information
        - Triggers policy-based actions
        """
        context = self.load_context(deal_id)
        if not context:
            return AgentResult(
                success=False,
                summary=f"Deal not found: {deal_id}",
                errors=[f"Deal {deal_id} not found in registry"],
            )

        # Filter events to process
        events_to_process = context.events
        if since:
            events_to_process = [e for e in context.events if e.timestamp > since]

        if not events_to_process:
            return AgentResult(
                success=True,
                summary="No new events to process",
                confidence=1.0,
            )

        # Process each event type
        case_file = context.case_file or {"deal_id": deal_id}
        emitted_events = []
        scheduled_actions = []

        for event in events_to_process:
            if event.event_type == "email_received":
                # Track email in case file
                if "emails_received" not in case_file:
                    case_file["emails_received"] = 0
                case_file["emails_received"] += 1

            elif event.event_type == "document_classified":
                doc_type = event.data.get("doc_type")
                if doc_type == "CIM":
                    case_file["cim_received"] = True
                    # Apply CIM policy
                    if context.stage.upper() == "INBOUND":
                        emitted_events.append({
                            "type": "ai_recommendation",
                            "data": {
                                "agent": "case_manager",
                                "recommendation_type": "stage_transition",
                                "summary": "CIM received - recommend advancing to SCREENING",
                            }
                        })

            elif event.event_type == "ai_recommendation":
                # Track AI insights
                if "ai_insights" not in case_file:
                    case_file["ai_insights"] = []
                case_file["ai_insights"].append({
                    "agent": event.data.get("agent"),
                    "summary": event.data.get("summary"),
                    "timestamp": event.timestamp,
                })

        # Save updated case file
        self._save_case_file(deal_id, case_file)

        result = AgentResult(
            success=True,
            summary=f"Processed {len(events_to_process)} events for {deal_id}",
            events=emitted_events,
            scheduled_actions=scheduled_actions,
            case_file_update=case_file,
            confidence=0.85,
        )
        self._log_run(deal_id, "process_events", result)
        return result

    def update_case_file(
        self,
        deal_id: str,
        updates: Dict[str, Any],
    ) -> AgentResult:
        """
        Update case file with provided data.

        Validates updates and merges with existing case file.
        """
        context = self.load_context(deal_id)
        if not context:
            return AgentResult(
                success=False,
                summary=f"Deal not found: {deal_id}",
                errors=[f"Deal {deal_id} not found in registry"],
            )

        case_file = context.case_file or {"deal_id": deal_id}

        # Merge updates
        for key, value in updates.items():
            if key in {"open_questions", "risk_flags", "ai_insights"}:
                # Append to lists
                if key not in case_file:
                    case_file[key] = []
                if isinstance(value, list):
                    case_file[key].extend(value)
                else:
                    case_file[key].append(value)
            else:
                case_file[key] = value

        self._save_case_file(deal_id, case_file)

        # Emit update event
        self.event_store.create_event(
            deal_id=deal_id,
            event_type="case_file_updated",
            actor="case_manager_agent",
            data={"updated_fields": list(updates.keys())},
        )

        result = AgentResult(
            success=True,
            summary=f"Updated case file for {deal_id}: {', '.join(updates.keys())}",
            case_file_update=case_file,
            confidence=1.0,
        )
        self._log_run(deal_id, "update_case_file", result)
        return result

    def schedule_action(
        self,
        deal_id: str,
        action_type: str,
        delay_days: int = 7,
        priority: str = "normal",
        data: Optional[Dict[str, Any]] = None,
    ) -> AgentResult:
        """
        Schedule a deferred action for the deal.
        """
        context = self.load_context(deal_id)
        if not context:
            return AgentResult(
                success=False,
                summary=f"Deal not found: {deal_id}",
                errors=[f"Deal {deal_id} not found in registry"],
            )

        action_id = self.action_queue.schedule_relative(
            deal_id=deal_id,
            action_type=action_type,
            days_from_now=delay_days,
            priority=priority,
            data=data or {},
            metadata={"scheduled_by": "case_manager_agent"},
        )

        # Emit event
        self.event_store.create_event(
            deal_id=deal_id,
            event_type="action_scheduled",
            actor="case_manager_agent",
            data={
                "action_id": action_id,
                "action_type": action_type,
                "delay_days": delay_days,
            },
        )

        result = AgentResult(
            success=True,
            summary=f"Scheduled {action_type} for {deal_id} in {delay_days} days",
            scheduled_actions=[{
                "action_id": action_id,
                "action_type": action_type,
                "delay_days": delay_days,
            }],
            confidence=1.0,
        )
        self._log_run(deal_id, "schedule_action", result)
        return result


def main():
    parser = argparse.ArgumentParser(description="Deal Case Manager Agent CLI")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # summarize
    summarize_p = subparsers.add_parser("summarize", help="Generate deal summary")
    summarize_p.add_argument("deal_id", help="Deal ID")

    # suggest-actions
    suggest_p = subparsers.add_parser("suggest-actions", help="Suggest next actions")
    suggest_p.add_argument("deal_id", help="Deal ID")

    # process-events
    process_p = subparsers.add_parser("process-events", help="Process recent events")
    process_p.add_argument("deal_id", help="Deal ID")
    process_p.add_argument("--since", help="Process events since timestamp")

    # update-case-file
    update_p = subparsers.add_parser("update-case-file", help="Update case file")
    update_p.add_argument("deal_id", help="Deal ID")
    update_p.add_argument("--data", help="JSON data to update")

    # schedule-action
    schedule_p = subparsers.add_parser("schedule-action", help="Schedule deferred action")
    schedule_p.add_argument("deal_id", help="Deal ID")
    schedule_p.add_argument("--type", required=True, help="Action type")
    schedule_p.add_argument("--days", type=int, default=7, help="Days from now")
    schedule_p.add_argument("--priority", default="normal", help="Priority level")

    # Add --json flag to all commands
    for p in [summarize_p, suggest_p, process_p, update_p, schedule_p]:
        p.add_argument("--json", action="store_true", help="Output as JSON")

    args = parser.parse_args()

    # Initialize agent (without LLM for CLI)
    agent = DealCaseManagerAgent()

    if args.command == "summarize":
        result = agent.summarize(args.deal_id)
    elif args.command == "suggest-actions":
        result = agent.suggest_actions(args.deal_id)
    elif args.command == "process-events":
        result = agent.process_events(args.deal_id, since=args.since)
    elif args.command == "update-case-file":
        data = json.loads(args.data) if args.data else {}
        result = agent.update_case_file(args.deal_id, data)
    elif args.command == "schedule-action":
        result = agent.schedule_action(
            args.deal_id,
            action_type=args.type,
            delay_days=args.days,
            priority=args.priority,
        )
    else:
        parser.print_help()
        return

    if args.json:
        print(json.dumps(result.to_dict(), indent=2))
    else:
        print(f"\n{'=' * 60}")
        print(f"Case Manager: {args.command}")
        print(f"{'=' * 60}")
        print(f"Success: {result.success}")
        print(f"Summary: {result.summary}")

        if result.scheduled_actions:
            print(f"\nSuggested Actions ({len(result.scheduled_actions)}):")
            for action in result.scheduled_actions:
                print(f"  - {action.get('type', action.get('action_type'))}: {action.get('reason', '')}")

        if result.stage_recommendation:
            print(f"\nStage Recommendation: {result.stage_recommendation}")

        if result.errors:
            print(f"\nErrors: {', '.join(result.errors)}")


if __name__ == "__main__":
    main()
